"use client"

import { ChevronLeft } from "lucide-react"
import Link from "next/link"

export default function UserAgreementPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-border z-10">
        <div className="flex items-center h-14 px-4">
          <Link href="/login" className="p-2 -ml-2">
            <ChevronLeft className="h-6 w-6" />
          </Link>
          <h1 className="flex-1 text-center font-medium pr-8">在线协议</h1>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-6">
        <Link href="#" className="text-primary text-sm">English Version</Link>
        
        <h2 className="text-xl font-bold text-center my-8">歌觅用户服务协议</h2>
        
        <p className="text-sm text-muted-foreground mb-6">更新日期：2026年4月1日</p>
        
        <h3 className="font-bold mb-4">特别提示</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          欢迎使用歌觅公司为您提供的歌觅平台。请您务必审慎并完整阅读以下内容，特别是免除或者限制歌觅公司责任的条款、对用户权利进行限制的条款、规定本协议的适用法律及有权解决争议的司法管辖区的条款。
          <span className="font-bold">限制、免责条款或者其他涉及您重大权益的条款可能以加粗等形式提示您重点注意</span>。
          请注意，目前在您的地区可能无法使用歌觅平台上的某些服务和功能（特别是涉及身份认证和支付的功能）。给您带来的不便，我们深表歉意，并正在努力尽快（如可能）提供这些服务和功能。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          本协议中的"歌觅"是与其中国境外运营版本即"Go With Me"相区别的产品。本协议适用于歌觅用户，即注册于中国境内的用户。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          如您注册于中国境外，您是Go With Me用户，适用
          <Link href="#" className="text-primary">Go With Me Terms of Service</Link>。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          如您未满18周岁或未满您居住所在地要求可使用歌觅平台的年龄，请不要使用歌觅平台。
        </p>
        
        <p className="text-sm leading-relaxed mb-6">
          除非您已充分阅读并接受本协议所有条款，否则您无权使用歌觅平台。如您不同意本协议或其中任何条款，您应立即停止使用歌觅平台。您点击"同意"，或者您使用歌觅平台，或者以其他任何明示或者默示方式表示接受本协议的，均视为您已阅读并同意本协议。本协议即在您与歌觅公司之间产生法律效力，成为对双方均具有约束力的法律文件。
        </p>

        <h3 className="font-bold mb-4">一、协议的范围</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          1.1 本协议是您与歌觅公司之间关于您使用歌觅平台所订立的协议。"歌觅公司"是指运营歌觅平台的公司及其关联公司。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          1.2 本协议项下的服务是指歌觅公司向用户提供的包括但不限于旅行社交、行程分享、即时通讯、信息发布等互联网服务。
        </p>

        <h3 className="font-bold mb-4">二、账号注册与使用</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          2.1 您确认，在您完成注册程序或以其他歌觅公司允许的方式实际使用歌觅平台服务时，您应当是具备完全民事权利能力和完全民事行为能力的自然人、法人或其他组织。若您不具备前述主体资格，请勿使用服务，否则您及您的监护人应承担因此而导致的一切后果，且歌觅公司有权注销或永久冻结您的账号，并向您及您的监护人索偿。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          2.2 您注册成功后，歌觅公司将给予您一个用户账号及相应的密码，该用户账号和密码由您负责保管；您应当对以其用户账号进行的所有活动和事件负法律责任。
        </p>

        <h3 className="font-bold mb-4">三、用户行为规范</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          3.1 您在使用歌觅平台服务过程中，必须遵循以下原则：
        </p>
        
        <p className="text-sm leading-relaxed mb-4 pl-4">
          （1）遵守中国有关的法律和法规；<br/>
          （2）遵守所有与网络服务有关的网络协议、规定和程序；<br/>
          （3）不得为任何非法目的而使用网络服务系统；<br/>
          （4）不得利用歌觅平台服务从事任何可能对互联网正常运转造成不利影响的行为；<br/>
          （5）不得利用歌觅平台服务传输任何骚扰性的、中伤他人的、辱骂性的、恐吓性的、庸俗淫秽的或其他任何非法的信息资料；<br/>
          （6）不得利用歌觅平台服务进行任何不利于歌觅公司的行为。
        </p>

        <h3 className="font-bold mb-4">四、知识产权</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          4.1 歌觅平台的一切著作权、商标权、专利权、商业秘密等知识产权，以及与歌觅平台相关的所有信息内容（包括但不限于文字、图片、音频、视频、图表、界面设计、版面框架、有关数据或电子文档等）均受中华人民共和国法律法规和相应的国际条约保护，歌觅公司享有上述知识产权。
        </p>

        <h3 className="font-bold mb-4">五、免责声明</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          5.1 歌觅公司不保证网络服务一定能满足用户的要求，也不保证网络服务不会中断，对网络服务的及时性、安全性、准确性也都不作保证。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          5.2 对于因不可抗力或歌觅公司不能控制的原因造成的网络服务中断或其他缺陷，歌觅公司不承担任何责任，但将尽力减少因此而给用户造成的损失和影响。
        </p>

        <h3 className="font-bold mb-4">六、协议修改</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          6.1 歌觅公司有权随时修改本协议的任何条款，一旦本协议的内容发生变动，歌觅公司将会在歌觅平台上公布修改之后的协议内容。歌觅公司也可选择通过其他适当方式（如系统通知）向用户通知修改内容。
        </p>
        
        <p className="text-sm leading-relaxed mb-8">
          6.2 如果不同意歌觅公司对本协议相关条款所做的修改，用户有权停止使用网络服务。如果用户继续使用网络服务，则视为用户接受歌觅公司对本协议相关条款所做的修改。
        </p>
      </div>
    </div>
  )
}
