"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ChevronDown, Smartphone, Check } from "lucide-react"
import { ParticleText } from "@/components/particle-text"

// Multi-language translations
const translations: Record<string, {
  wechatLogin: string
  appleLogin: string
  otherMethods: string
  phoneLogin: string
  qqLogin: string
  agreement: string
  userAgreement: string
  privacyPolicy: string
  childProtection: string
}> = {
  "中文": {
    wechatLogin: "微信登录",
    appleLogin: "通过 Apple 登录",
    otherMethods: "其他登录方式",
    phoneLogin: "手机号登录",
    qqLogin: "QQ登录",
    agreement: "我已阅读并同意",
    userAgreement: "《用户协议》",
    privacyPolicy: "《隐私政策》",
    childProtection: "《儿童/青少年个人信息保护规则》",
  },
  "English": {
    wechatLogin: "Login with WeChat",
    appleLogin: "Sign in with Apple",
    otherMethods: "Other login methods",
    phoneLogin: "Phone Login",
    qqLogin: "QQ Login",
    agreement: "I have read and agree to",
    userAgreement: "User Agreement",
    privacyPolicy: "Privacy Policy",
    childProtection: "Child Protection Policy",
  },
  "日本語": {
    wechatLogin: "WeChatでログイン",
    appleLogin: "Appleでサインイン",
    otherMethods: "他のログイン方法",
    phoneLogin: "電話番号でログイン",
    qqLogin: "QQでログイン",
    agreement: "以下に同意します",
    userAgreement: "利用規約",
    privacyPolicy: "プライバシーポリシー",
    childProtection: "児童保護ポリシー",
  },
  "한국어": {
    wechatLogin: "WeChat으로 로그인",
    appleLogin: "Apple로 로그인",
    otherMethods: "다른 로그인 방법",
    phoneLogin: "전화번호 로그인",
    qqLogin: "QQ 로그인",
    agreement: "다음에 동의합니다",
    userAgreement: "이용약관",
    privacyPolicy: "개인정보 처리방침",
    childProtection: "아동 보호 정책",
  },
  "Français": {
    wechatLogin: "Connexion WeChat",
    appleLogin: "Se connecter avec Apple",
    otherMethods: "Autres méthodes",
    phoneLogin: "Connexion téléphone",
    qqLogin: "Connexion QQ",
    agreement: "J'accepte les",
    userAgreement: "Conditions d'utilisation",
    privacyPolicy: "Politique de confidentialité",
    childProtection: "Protection des enfants",
  },
  "Español": {
    wechatLogin: "Iniciar con WeChat",
    appleLogin: "Iniciar con Apple",
    otherMethods: "Otros métodos",
    phoneLogin: "Iniciar con teléfono",
    qqLogin: "Iniciar con QQ",
    agreement: "Acepto los",
    userAgreement: "Términos de uso",
    privacyPolicy: "Política de privacidad",
    childProtection: "Protección infantil",
  },
  "Deutsch": {
    wechatLogin: "Mit WeChat anmelden",
    appleLogin: "Mit Apple anmelden",
    otherMethods: "Andere Methoden",
    phoneLogin: "Mit Telefon anmelden",
    qqLogin: "Mit QQ anmelden",
    agreement: "Ich stimme zu",
    userAgreement: "Nutzungsbedingungen",
    privacyPolicy: "Datenschutz",
    childProtection: "Kinderschutz",
  },
  "Italiano": {
    wechatLogin: "Accedi con WeChat",
    appleLogin: "Accedi con Apple",
    otherMethods: "Altri metodi",
    phoneLogin: "Accedi con telefono",
    qqLogin: "Accedi con QQ",
    agreement: "Accetto i",
    userAgreement: "Termini di servizio",
    privacyPolicy: "Privacy Policy",
    childProtection: "Protezione minori",
  },
}

export default function LoginPage() {
  const router = useRouter()
  const [agreed, setAgreed] = useState(false)
  const [language, setLanguage] = useState("中文")
  const [showLanguageDropdown, setShowLanguageDropdown] = useState(false)
  const [showOtherMethods, setShowOtherMethods] = useState(false)

  const languages = ["中文", "English", "日本語", "한국어", "Français", "Español", "Deutsch", "Italiano"]
  const t = translations[language]

  const handleLogin = () => {
    if (agreed) {
      router.push("/")
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-white px-6 py-8">
        {/* Language selector */}
        <div className="flex justify-end">
          <div className="relative">
            <button
              onClick={() => setShowLanguageDropdown(!showLanguageDropdown)}
              className="flex items-center gap-2 px-4 py-2 bg-muted/50 rounded-full text-sm"
            >
              <span>{language}</span>
              <ChevronDown className="h-4 w-4" />
            </button>
            {showLanguageDropdown && (
              <div className="absolute right-0 top-full mt-2 bg-white rounded-xl shadow-lg overflow-hidden z-10 min-w-[140px]">
                {languages.map((lang) => (
                  <button
                    key={lang}
                    onClick={() => {
                      setLanguage(lang)
                      setShowLanguageDropdown(false)
                    }}
                    className={`flex items-center gap-2 w-full px-4 py-2.5 text-sm text-left hover:bg-muted/50 ${
                      language === lang ? "text-primary font-medium bg-primary/5" : ""
                    }`}
                  >
                    {language === lang && <Check className="h-4 w-4 text-primary" />}
                    <span className={language === lang ? "" : "ml-6"}>{lang}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Particle Text Animation */}
        <div className="flex-1 flex items-center justify-center">
          <ParticleText />
        </div>

        {/* WeChat Login Button */}
        <button
          onClick={handleLogin}
          disabled={!agreed}
          className="w-full py-4 bg-[#07C160] text-white rounded-full font-medium text-base flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#06AD56] transition-colors mb-4"
        >
          {/* WeChat Icon - two chat bubbles */}
          <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
            <path d="M8.691 2.188C3.891 2.188 0 5.476 0 9.53c0 2.212 1.17 4.203 3.002 5.55a.59.59 0 0 1 .213.665l-.39 1.48c-.019.07-.048.141-.048.213 0 .163.13.295.29.295a.326.326 0 0 0 .167-.054l1.903-1.114a.864.864 0 0 1 .717-.098 10.16 10.16 0 0 0 2.837.403c.276 0 .543-.027.811-.05-.857-2.578.157-4.972 1.932-6.446 1.703-1.415 3.882-1.98 5.853-1.838-.576-3.583-4.196-6.348-8.596-6.348zM5.785 5.991c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 0 1-1.162 1.178A1.17 1.17 0 0 1 4.623 7.17c0-.651.52-1.18 1.162-1.18zm5.813 0c.642 0 1.162.529 1.162 1.18a1.17 1.17 0 0 1-1.162 1.178 1.17 1.17 0 0 1-1.162-1.178c0-.651.52-1.18 1.162-1.18zm5.34 2.867c-1.797-.052-3.746.512-5.28 1.786-1.72 1.428-2.687 3.72-1.78 6.22.942 2.453 3.666 4.229 6.884 4.229.826 0 1.622-.12 2.361-.336a.722.722 0 0 1 .598.082l1.584.926a.272.272 0 0 0 .14.047c.134 0 .24-.111.24-.247 0-.06-.023-.12-.038-.177l-.327-1.233a.582.582 0 0 1-.023-.156.49.49 0 0 1 .201-.398C23.024 18.48 24 16.82 24 14.98c0-3.21-2.931-5.837-6.656-6.088V8.87l-.018-.012h-.002zm-2.749 2.662c.535 0 .969.44.969.982a.976.976 0 0 1-.969.983.976.976 0 0 1-.969-.983c0-.542.434-.982.97-.982zm4.844 0c.535 0 .969.44.969.982a.976.976 0 0 1-.969.983.976.976 0 0 1-.969-.983c0-.542.434-.982.969-.982z"/>
          </svg>
          {t.wechatLogin}
        </button>

        {/* Apple Login Button */}
        <button
          onClick={handleLogin}
          disabled={!agreed}
          className="w-full py-4 bg-white text-foreground rounded-full font-medium text-base flex items-center justify-center gap-2 border border-border disabled:opacity-50 disabled:cursor-not-allowed hover:bg-muted/50 transition-colors mb-6"
        >
          <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
            <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
          </svg>
          {t.appleLogin}
        </button>

        {/* Other login methods */}
        <button
          onClick={() => setShowOtherMethods(!showOtherMethods)}
          className="w-full text-center text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center justify-center gap-1 mb-4"
        >
          {t.otherMethods}
          <ChevronDown className={`h-4 w-4 transition-transform ${showOtherMethods ? "rotate-180" : ""}`} />
        </button>

        {/* QQ and Phone login */}
        {showOtherMethods && (
          <div className="flex justify-center gap-8 mb-6">
            <button
              onClick={handleLogin}
              disabled={!agreed}
              className="flex flex-col items-center gap-2 disabled:opacity-50"
            >
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm border border-border overflow-hidden">
                <Image
                  src="/images/qq-icon.png"
                  alt="QQ"
                  width={40}
                  height={40}
                  className="object-contain"
                />
              </div>
              <span className="text-xs text-muted-foreground">{t.qqLogin}</span>
            </button>
            <button
              onClick={handleLogin}
              disabled={!agreed}
              className="flex flex-col items-center gap-2 disabled:opacity-50"
            >
              <div className="w-12 h-12 bg-foreground rounded-full flex items-center justify-center text-background">
                <Smartphone className="h-6 w-6" />
              </div>
              <span className="text-xs text-muted-foreground">{t.phoneLogin}</span>
            </button>
          </div>
        )}

        {/* Agreement */}
        <div className="flex items-start gap-3">
          <button
            onClick={() => setAgreed(!agreed)}
            className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 mt-0.5 ${
              agreed ? "bg-primary border-primary" : "border-muted-foreground"
            }`}
          >
            {agreed && (
              <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            )}
          </button>
          <p className="text-xs text-muted-foreground leading-relaxed">
            {t.agreement}
            <Link href="/agreement" className="text-primary ml-1">{t.userAgreement}</Link>
            {language === "中文" ? " " : " & "}
            <Link href="/privacy" className="text-primary">{t.privacyPolicy}</Link>
            <br />
            <Link href="/child-protection" className="text-primary">{t.childProtection}</Link>
          </p>
        </div>

    </div>
  )
}
