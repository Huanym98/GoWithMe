"use client"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { ChevronLeft, Plus, ChevronRight, ChevronDown, X, Upload } from "lucide-react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

// Currency options
const currencies = ["CNY", "KRW", "JPY", "USD", "EUR", "GBP", "HKD", "TWD", "SGD", "THB"]

// Expense categories
const categories = ["餐饮", "交通", "酒店", "门票", "购物", "代购", "其他"]

// Expense types
const expenseTypes = ["全员均摊", "部分成员分摊", "个人支出", "代购/代付"]

// Mock data
const billData = {
  id: "1",
  tripId: "1",
  tripTitle: "秘鲁智利旅行搭子账单",
  members: [
    { id: "1", name: "HYM", role: "发起人", avatar: "H" },
    { id: "2", name: "WSH", role: "成员", avatar: "W" },
    { id: "3", name: "LYS", role: "成员", avatar: "L" },
  ],
  activities: [
    { user: "HYM", action: "HYM 将一笔费用标记为已确认", time: "2026/4/7 14:19:01" },
    { user: "HYM", action: "HYM 新增了一笔「车辆罚单」，由 HYM、WSH、LYS 承担", time: "2026/4/7 14:18:07" },
    { user: "HYM", action: "HYM 邀请 LYS 加入账单", time: "2026/4/7 14:15:18" },
    { user: "HYM", action: "HYM 将一笔费用标记为已确认", time: "2026/4/7 14:12:35" },
    { user: "HYM", action: "HYM 将一笔费用标记为已确认", time: "2026/4/7 14:12:28" },
    { user: "HYM", action: "HYM 修改了「韩国第一顿饭-外卖炸鸡」", time: "2026/4/7 13:21:01" },
    { user: "HYM", action: "HYM 修改了「第一晚的住宿」", time: "2026/4/7 13:20:37" },
    { user: "HYM", action: "HYM 将一笔费用标记为有争议", time: "2026/4/7 11:56:39" },
  ],
  expenses: [
    { id: "1", title: "车辆罚单", payer: "LYS", amount: 70, currency: "USD", participants: ["HYM", "WSH", "LYS"], time: "2026/4/7 06:17:00", status: "confirmed" },
    { id: "2", title: "第一晚的住宿", payer: "HYM", amount: 40000, currency: "KRW", participants: ["HYM", "WSH"], time: "2026/4/6 11:44:00", status: "confirmed" },
    { id: "3", title: "韩国第一顿饭-外卖炸鸡", payer: "HYM", amount: 20000, currency: "KRW", participants: ["HYM", "WSH"], time: "2026/4/6 08:56:00", status: "confirmed" },
  ],
  settlement: {
    members: [
      { name: "HYM", paid: 282.40, shouldPay: 301.78, balance: -19.38, color: "text-red-500" },
      { name: "WSH", paid: 0, shouldPay: 301.78, balance: -301.78, color: "text-red-500" },
      { name: "LYS", paid: 481.73, shouldPay: 160.58, balance: 321.15, color: "text-emerald-500" },
    ],
    transfers: [
      { from: "HYM", to: "LYS", amount: 19.38 },
      { from: "WSH", to: "LYS", amount: 301.78 },
    ]
  }
}

export default function BillDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [showAddExpense, setShowAddExpense] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const totalPages = 2
  
  // Form state for new expense
  const [expenseForm, setExpenseForm] = useState({
    type: "全员均摊",
    category: "餐饮",
    amount: "",
    currency: "CNY",
    payer: "HYM",
    time: new Date().toISOString().slice(0, 16).replace("T", " "),
    actualCNY: "",
    estimatedCNY: "",
    note: "",
    participants: ["HYM", "WSH", "LYS"],
    status: "待确认"
  })

  const toggleParticipant = (name: string) => {
    setExpenseForm(prev => ({
      ...prev,
      participants: prev.participants.includes(name)
        ? prev.participants.filter(p => p !== name)
        : [...prev.participants, name]
    }))
  }

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Header */}
      <header className="bg-background border-b border-border sticky top-0 z-10">
        <div className="flex items-center justify-between px-4 py-3">
          <Link href={`/trip/${billData.tripId}`} className="p-2 -ml-2">
            <ChevronLeft className="h-5 w-5" />
          </Link>
          <h1 className="text-lg font-semibold">账单详情</h1>
          <div className="w-9" />
        </div>
      </header>

      <div className="max-w-4xl mx-auto p-4">
        {/* Members */}
        <div className="flex items-center gap-4 mb-6 overflow-x-auto pb-2">
          {billData.members.map((member) => (
            <div key={member.id} className="flex flex-col items-center gap-1 shrink-0">
              <Avatar className="h-12 w-12">
                <AvatarFallback className="bg-muted text-foreground">{member.avatar}</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium">{member.name}</span>
              <span className="text-xs text-muted-foreground">{member.role}</span>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Left column */}
          <div className="space-y-6">
            {/* Activity log */}
            <div className="bg-background rounded-xl p-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold">账单动态</h2>
                <span className="text-xs text-muted-foreground">任何人修改后，这里都会留下轨迹</span>
              </div>
              <div className="space-y-4 max-h-80 overflow-y-auto">
                {billData.activities.map((activity, index) => (
                  <div key={index} className="flex items-start justify-between gap-4">
                    <div>
                      <p className="font-medium text-sm">{activity.user}</p>
                      <p className="text-sm text-muted-foreground">{activity.action}</p>
                    </div>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">{activity.time}</span>
                  </div>
                ))}
              </div>
              {/* Pagination */}
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                <span className="text-sm text-muted-foreground">第 {currentPage} / {totalPages} 页（共 15 条）</span>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                    disabled={currentPage === 1}
                    className="px-3 py-1.5 text-sm border border-border rounded-lg disabled:opacity-50"
                  >
                    上一页
                  </button>
                  <button 
                    onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                    disabled={currentPage === totalPages}
                    className="px-3 py-1.5 text-sm border border-border rounded-lg disabled:opacity-50"
                  >
                    下一页
                  </button>
                </div>
              </div>
            </div>

            {/* Expense list */}
            <div className="bg-background rounded-xl p-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold">费用明细</h2>
                <button 
                  onClick={() => setShowAddExpense(true)}
                  className="px-3 py-1.5 text-sm border border-border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  新增费用
                </button>
              </div>
              <div className="space-y-4">
                {billData.expenses.map((expense) => (
                  <div key={expense.id} className="pb-4 border-b border-border last:border-0 last:pb-0">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className="font-medium">{expense.title}</h3>
                        <p className="text-sm text-muted-foreground">
                          {expense.payer} 支付 · {expense.currency} {expense.amount.toLocaleString()} · {expense.participants.join("、")}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">{expense.time}</p>
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <button className="px-2.5 py-1 text-xs border border-emerald-500 text-emerald-500 rounded-lg">已确认</button>
                        <button className="px-2.5 py-1 text-xs border border-border rounded-lg hover:bg-muted/50">修改</button>
                        <button className="px-2.5 py-1 text-xs border border-border rounded-lg hover:bg-muted/50">有争议</button>
                        <button className="px-2.5 py-1 text-xs border border-border rounded-lg hover:bg-muted/50">待确认</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right column - Settlement */}
          <div className="bg-background rounded-xl p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold">结算结果</h2>
              <span className="text-xs text-muted-foreground">先透明，再结算</span>
            </div>
            
            {/* Member balances */}
            <div className="space-y-4 mb-6">
              {billData.settlement.members.map((member) => (
                <div key={member.name} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{member.name}</p>
                    <p className="text-sm text-muted-foreground">
                      垫付 ¥{member.paid.toFixed(2)} · 应承担 ¥{member.shouldPay.toFixed(2)}
                    </p>
                  </div>
                  <span className={`font-semibold ${member.color}`}>
                    {member.balance > 0 ? "应收" : "应付"} ¥{Math.abs(member.balance).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>

            {/* Optimal transfer scheme */}
            <div className="pt-4 border-t border-border">
              <h3 className="font-semibold mb-3">最优转账方案</h3>
              <div className="space-y-2">
                {billData.settlement.transfers.map((transfer, index) => (
                  <p key={index} className="text-sm">
                    {transfer.from} → {transfer.to}：¥{transfer.amount.toFixed(2)}
                  </p>
                ))}
              </div>
            </div>

            <p className="text-xs text-muted-foreground mt-4">
              数据来源：用户发布的行程，按出发日期与今天比较自动区分"去过 / 计划去"。
            </p>
          </div>
        </div>
      </div>

      {/* Add Expense Modal */}
      {showAddExpense && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-background rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div>
                <h2 className="text-lg font-semibold">新增费用</h2>
                <p className="text-sm text-muted-foreground">一笔一笔记清楚，后续就能快速结算。</p>
              </div>
              <button onClick={() => setShowAddExpense(false)} className="text-muted-foreground">
                关闭
              </button>
            </div>

            <div className="p-4 space-y-4">
              {/* Expense type and category */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1.5 block">费用类型</label>
                  <select 
                    value={expenseForm.type}
                    onChange={(e) => setExpenseForm(prev => ({ ...prev, type: e.target.value }))}
                    className="w-full h-10 px-3 bg-background border border-border rounded-lg text-sm"
                  >
                    {expenseTypes.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1.5 block">分类</label>
                  <select 
                    value={expenseForm.category}
                    onChange={(e) => setExpenseForm(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full h-10 px-3 bg-background border border-border rounded-lg text-sm"
                  >
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Amount and currency */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1.5 block">金额</label>
                  <input 
                    type="number"
                    value={expenseForm.amount}
                    onChange={(e) => setExpenseForm(prev => ({ ...prev, amount: e.target.value }))}
                    placeholder="0.00"
                    className="w-full h-10 px-3 bg-background border border-border rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1.5 block">币种</label>
                  <select 
                    value={expenseForm.currency}
                    onChange={(e) => setExpenseForm(prev => ({ ...prev, currency: e.target.value }))}
                    className="w-full h-10 px-3 bg-background border border-border rounded-lg text-sm"
                  >
                    {currencies.map(cur => (
                      <option key={cur} value={cur}>{cur}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Payer and time */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1.5 block">付款人</label>
                  <select 
                    value={expenseForm.payer}
                    onChange={(e) => setExpenseForm(prev => ({ ...prev, payer: e.target.value }))}
                    className="w-full h-10 px-3 bg-background border border-border rounded-lg text-sm"
                  >
                    {billData.members.map(member => (
                      <option key={member.id} value={member.name}>{member.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium mb-1.5 block">费用时间</label>
                  <input 
                    type="datetime-local"
                    value={expenseForm.time.replace(" ", "T")}
                    onChange={(e) => setExpenseForm(prev => ({ ...prev, time: e.target.value.replace("T", " ") }))}
                    className="w-full h-10 px-3 bg-background border border-border rounded-lg text-sm"
                  />
                </div>
              </div>

              {/* CNY conversion */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1.5 block">实际CNY结算金额（可选）</label>
                  <input 
                    type="number"
                    value={expenseForm.actualCNY}
                    onChange={(e) => setExpenseForm(prev => ({ ...prev, actualCNY: e.target.value }))}
                    placeholder="0.00"
                    className="w-full h-10 px-3 bg-background border border-border rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1.5 block">估算CNY结算金额（可选）</label>
                  <input 
                    type="number"
                    value={expenseForm.estimatedCNY}
                    onChange={(e) => setExpenseForm(prev => ({ ...prev, estimatedCNY: e.target.value }))}
                    placeholder="0.00"
                    className="w-full h-10 px-3 bg-background border border-border rounded-lg text-sm bg-muted/30"
                    disabled
                  />
                </div>
              </div>

              {/* Note */}
              <div>
                <label className="text-sm font-medium mb-1.5 block">备注</label>
                <input 
                  type="text"
                  value={expenseForm.note}
                  onChange={(e) => setExpenseForm(prev => ({ ...prev, note: e.target.value }))}
                  placeholder="例如：晚餐 / 打车 / 门票"
                  className="w-full h-10 px-3 bg-background border border-border rounded-lg text-sm"
                />
              </div>

              {/* Receipt upload */}
              <div>
                <label className="text-sm font-medium mb-1.5 block">小票或截图（可选）</label>
                <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                  <p className="font-medium">点击上传图片</p>
                  <p className="text-sm text-muted-foreground mt-1">支持最多 6 张图片，单张不超过 10MB</p>
                </div>
              </div>

              {/* Participants */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium">承担人</label>
                  <span className="text-xs text-muted-foreground">全员均摊时，系统会自动选中全部账单成员。</span>
                </div>
                <div className="flex gap-2">
                  {billData.members.map(member => (
                    <button
                      key={member.id}
                      onClick={() => toggleParticipant(member.name)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        expenseForm.participants.includes(member.name)
                          ? "bg-foreground text-background"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {member.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Status */}
              <div>
                <label className="text-sm font-medium mb-1.5 block">状态</label>
                <select 
                  value={expenseForm.status}
                  onChange={(e) => setExpenseForm(prev => ({ ...prev, status: e.target.value }))}
                  className="w-full h-10 px-3 bg-background border border-border rounded-lg text-sm"
                >
                  <option value="待确认">待确认</option>
                  <option value="已确认">已确认</option>
                  <option value="有争议">有争议</option>
                </select>
              </div>
            </div>

            {/* Footer */}
            <div className="flex justify-end gap-3 p-4 border-t border-border">
              <button 
                onClick={() => setShowAddExpense(false)}
                className="px-4 py-2 text-sm border border-border rounded-lg hover:bg-muted/50 transition-colors"
              >
                取消
              </button>
              <button 
                onClick={() => setShowAddExpense(false)}
                className="px-4 py-2 text-sm bg-foreground text-background rounded-lg"
              >
                保存
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
