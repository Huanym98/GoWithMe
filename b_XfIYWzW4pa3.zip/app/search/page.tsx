"use client"

import { useState } from "react"
import { ArrowLeft, Search, X } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Search result types
type SearchTab = "全部" | "行程" | "日记" | "用户" | "攻略" | "成就"

// Mock search results
const mockResults = {
  users: [
    { id: "1", name: "旅行者小鱼", avatar: "", badge: "初次结伴", trips: 3, diaries: 5 },
    { id: "2", name: "环球旅人Emma", avatar: "", badge: "环游世界", trips: 12, diaries: 8 },
    { id: "3", name: "背包客阿杰", avatar: "", badge: "徒步达人", trips: 8, diaries: 15 },
  ],
  trips: [
    { id: "1", title: "京都樱花季5日游", user: "小鱼", date: "2024-03-20", destination: "日本·京都" },
    { id: "2", title: "首尔美食探店之旅", user: "Emma", date: "2024-04-15", destination: "韩国·首尔" },
    { id: "3", title: "巴厘岛蜜月行程", user: "佳琪", date: "2024-05-01", destination: "印尼·巴厘岛" },
  ],
  diaries: [
    { id: "1", title: "在京都遇见最美的春天", user: "小鱼", date: "2024-03-25", likes: 128 },
    { id: "2", title: "首尔街头的烟火气", user: "Emma", date: "2024-04-20", likes: 89 },
    { id: "3", title: "巴厘岛日落最佳观赏点", user: "阿杰", date: "2024-05-10", likes: 256 },
  ],
  guides: [
    { id: "japan", name: "日本", guidesCount: 156, cities: ["东京", "大阪", "京都"] },
    { id: "korea", name: "韩国", guidesCount: 89, cities: ["首尔", "釜山", "济州岛"] },
    { id: "thailand", name: "泰国", guidesCount: 72, cities: ["曼谷", "清迈", "普吉岛"] },
  ],
  achievements: [
    { id: "1", name: "初见西湖", city: "杭州", type: "bronze", description: "每个杭州故事，都该从西湖开始。" },
    { id: "2", name: "东京初体验", city: "东京", type: "bronze", description: "第一次踏上日本的土地。" },
    { id: "3", name: "美食猎人", city: "成都", type: "silver", description: "品尝10家地道川菜馆。" },
  ],
}

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState<SearchTab>("全部")
  const [hasSearched, setHasSearched] = useState(false)

  const tabs: SearchTab[] = ["全部", "行程", "日记", "用户", "攻略", "成就"]

  const handleSearch = () => {
    if (searchQuery.trim()) {
      setHasSearched(true)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch()
    }
  }

  const clearSearch = () => {
    setSearchQuery("")
    setHasSearched(false)
  }

  // Trophy icon component
  const TrophyIcon = ({ type }: { type: string }) => {
    const colors = {
      diamond: "text-cyan-400",
      gold: "text-amber-400",
      silver: "text-slate-400",
      bronze: "text-orange-400",
    }
    return (
      <span className={`text-lg ${colors[type as keyof typeof colors] || colors.bronze}`}>
        🏆
      </span>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background border-b border-border">
        <div className="flex items-center gap-3 px-4 py-3">
          <Link href="/" className="p-1">
            <ArrowLeft className="h-5 w-5 text-foreground" />
          </Link>
          <div className="flex-1 relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="搜索行程、日记、用户、攻略..."
              className="w-full h-10 pl-4 pr-10 bg-muted rounded-full text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20"
              autoFocus
            />
            {searchQuery && (
              <button
                onClick={clearSearch}
                className="absolute right-12 top-1/2 -translate-y-1/2 p-1"
              >
                <X className="h-4 w-4 text-muted-foreground" />
              </button>
            )}
          </div>
          <button
            onClick={handleSearch}
            className="px-4 py-2 text-sm font-medium text-primary"
          >
            搜索
          </button>
        </div>

        {/* Tabs */}
        {hasSearched && (
          <div className="flex items-center gap-1 px-4 pb-3 overflow-x-auto scrollbar-hide">
            {tabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-1.5 rounded-full text-sm whitespace-nowrap transition-colors ${
                  activeTab === tab
                    ? "bg-foreground text-background font-medium"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        )}
      </header>

      {/* Content */}
      <div className="px-4 py-4">
        {!hasSearched ? (
          // Empty state
          <div className="flex flex-col items-center justify-center py-20">
            <Search className="h-12 w-12 text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground text-sm">输入关键词搜索</p>
          </div>
        ) : (
          // Search results
          <div className="space-y-6">
            {/* Users section */}
            {(activeTab === "全部" || activeTab === "用户") && (
              <section>
                <h3 className="text-sm font-semibold text-foreground mb-3">用户</h3>
                <div className="space-y-3">
                  {mockResults.users.map((user) => (
                    <Link
                      key={user.id}
                      href={`/profile/${user.id}`}
                      className="flex items-center gap-3 p-3 bg-card rounded-xl border border-border/50"
                    >
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={user.avatar} />
                        <AvatarFallback className="bg-primary/10 text-primary">
                          {user.name[0]}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-foreground">{user.name}</p>
                        <p className="text-xs text-muted-foreground">
                          勋章: 🏅 {user.badge}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          行程 {user.trips} 条 | 日记 {user.diaries} 条
                        </p>
                      </div>
                    </Link>
                  ))}
                </div>
              </section>
            )}

            {/* Trips section */}
            {(activeTab === "全部" || activeTab === "行程") && (
              <section>
                <h3 className="text-sm font-semibold text-foreground mb-3">行程</h3>
                <div className="space-y-3">
                  {mockResults.trips.map((trip) => (
                    <Link
                      key={trip.id}
                      href={`/trip/${trip.id}`}
                      className="block p-3 bg-card rounded-xl border border-border/50"
                    >
                      <p className="font-medium text-foreground mb-1">{trip.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {trip.user} · {trip.date}
                      </p>
                      <p className="text-xs text-primary mt-1">{trip.destination}</p>
                    </Link>
                  ))}
                </div>
              </section>
            )}

            {/* Diaries section */}
            {(activeTab === "全部" || activeTab === "日记") && (
              <section>
                <h3 className="text-sm font-semibold text-foreground mb-3">日记</h3>
                <div className="space-y-3">
                  {mockResults.diaries.map((diary) => (
                    <Link
                      key={diary.id}
                      href={`/diary/${diary.id}`}
                      className="block p-3 bg-card rounded-xl border border-border/50"
                    >
                      <p className="font-medium text-foreground mb-1">{diary.title}</p>
                      <div className="flex items-center justify-between">
                        <p className="text-xs text-muted-foreground">
                          {diary.user} · {diary.date}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          ❤️ {diary.likes}
                        </p>
                      </div>
                    </Link>
                  ))}
                </div>
              </section>
            )}

            {/* Guides section */}
            {(activeTab === "全部" || activeTab === "攻略") && (
              <section>
                <h3 className="text-sm font-semibold text-foreground mb-3">攻略</h3>
                <div className="space-y-3">
                  {mockResults.guides.map((guide) => (
                    <Link
                      key={guide.id}
                      href={`/guides/country/${guide.id}`}
                      className="block p-3 bg-card rounded-xl border border-border/50"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium text-foreground">{guide.name}</p>
                        <p className="text-xs text-muted-foreground">{guide.guidesCount} 篇攻略</p>
                      </div>
                      <div className="flex gap-1.5 flex-wrap">
                        {guide.cities.map((city) => (
                          <span
                            key={city}
                            className="px-2 py-0.5 bg-muted/50 rounded text-xs text-muted-foreground"
                          >
                            {city}
                          </span>
                        ))}
                      </div>
                    </Link>
                  ))}
                </div>
              </section>
            )}

            {/* Achievements section */}
            {(activeTab === "全部" || activeTab === "成就") && (
              <section>
                <h3 className="text-sm font-semibold text-foreground mb-3">成就</h3>
                <div className="space-y-3">
                  {mockResults.achievements.map((achievement) => (
                    <div
                      key={achievement.id}
                      className="p-3 bg-card rounded-xl border border-border/50"
                    >
                      <div className="flex items-center gap-3">
                        <TrophyIcon type={achievement.type} />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-foreground">{achievement.name}</p>
                          <p className="text-xs text-muted-foreground">{achievement.city}</p>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-xs ${
                          achievement.type === "gold" ? "bg-amber-100 text-amber-700" :
                          achievement.type === "silver" ? "bg-slate-100 text-slate-700" :
                          "bg-orange-100 text-orange-700"
                        }`}>
                          {achievement.type === "gold" ? "黄金" :
                           achievement.type === "silver" ? "白银" : "青铜"}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">{achievement.description}</p>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
