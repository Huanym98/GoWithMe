"use client"

import { useState } from "react"
import { ChevronDown, X, Maximize2, ChevronLeft } from "lucide-react"
import Link from "next/link"
import { BottomTabBar } from "@/components/bottom-tab-bar"

// Location data with trips
const locationData = [
  {
    id: "seoul",
    name: "首尔",
    country: "韩国",
    emoji: "🍜🛍️",
    position: { x: 72, y: 35 }, // percentage position on map
    visited: 1,
    planned: 1,
    trips: {
      visited: [
        { id: "1", title: "首尔美食之旅", user: "小婷", avatar: "🍜", date: "2024-03-15" },
      ],
      planned: [
        { id: "2", title: "首尔购物计划", user: "Emma", avatar: "🛍️", date: "2024-06-20" },
      ],
    },
  },
  {
    id: "tokyo",
    name: "东京",
    country: "日本",
    emoji: "🍣🌸",
    position: { x: 78, y: 38 },
    visited: 2,
    planned: 1,
    trips: {
      visited: [
        { id: "3", title: "东京赏樱之旅", user: "佳琪", avatar: "🌸", date: "2024-04-01" },
        { id: "4", title: "东京美食探索", user: "Lily", avatar: "🍣", date: "2024-02-10" },
      ],
      planned: [
        { id: "5", title: "东京夏日祭", user: "晓燕", avatar: "🎆", date: "2024-08-15" },
      ],
    },
  },
  {
    id: "hongkong",
    name: "香港",
    country: "中国",
    emoji: "🏙️🍵",
    position: { x: 68, y: 48 },
    visited: 1,
    planned: 0,
    trips: {
      visited: [
        { id: "6", title: "香港周末游", user: "小鱼", avatar: "🏙️", date: "2024-01-20" },
      ],
      planned: [],
    },
  },
  {
    id: "bangkok",
    name: "曼谷",
    country: "泰国",
    emoji: "🛕🍜",
    position: { x: 58, y: 52 },
    visited: 0,
    planned: 2,
    trips: {
      visited: [],
      planned: [
        { id: "7", title: "曼谷寺庙巡礼", user: "小婷", avatar: "🛕", date: "2024-07-10" },
        { id: "8", title: "曼谷美食探索", user: "佳琪", avatar: "🍜", date: "2024-09-05" },
      ],
    },
  },
  {
    id: "paris",
    name: "巴黎",
    country: "法国",
    emoji: "🗼🥐",
    position: { x: 30, y: 32 },
    visited: 1,
    planned: 1,
    trips: {
      visited: [
        { id: "9", title: "巴黎浪漫之旅", user: "Emma", avatar: "🗼", date: "2024-02-14" },
      ],
      planned: [
        { id: "10", title: "法国艺术之旅", user: "Lily", avatar: "🎨", date: "2024-10-01" },
      ],
    },
  },
  {
    id: "newyork",
    name: "纽约",
    country: "美国",
    emoji: "🗽🍕",
    position: { x: 18, y: 38 },
    visited: 0,
    planned: 1,
    trips: {
      visited: [],
      planned: [
        { id: "11", title: "纽约城市探索", user: "晓燕", avatar: "🗽", date: "2024-12-20" },
      ],
    },
  },
]

const continents = ["全部大洲", "亚洲", "欧洲", "北美洲", "南美洲", "大洋洲", "非洲"]

export default function WorldMapPage() {
  const [mapMode, setMapMode] = useState<"2D" | "3D">("3D")
  const [selectedLocation, setSelectedLocation] = useState<typeof locationData[0] | null>(null)
  const [selectedContinent, setSelectedContinent] = useState("全部大洲")
  const [showContinentDropdown, setShowContinentDropdown] = useState(false)

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      {/* Header */}
      <div className="absolute top-4 left-4 z-20">
        <Link href="/" className="flex items-center gap-2 text-white/80 hover:text-white">
          <ChevronLeft className="h-5 w-5" />
        </Link>
      </div>
      
      <div className="absolute top-4 left-12 z-20">
        <span className="px-3 py-1.5 bg-slate-800/80 backdrop-blur-sm rounded-lg text-sm">
          世界地图 Beta
        </span>
      </div>

      {/* Continent filter */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 w-64">
        <button
          onClick={() => setShowContinentDropdown(!showContinentDropdown)}
          className="w-full flex items-center justify-between px-4 py-2.5 bg-slate-800/90 backdrop-blur-sm rounded-lg"
        >
          <span>{selectedContinent}</span>
          <ChevronDown className="h-4 w-4" />
        </button>
        {showContinentDropdown && (
          <div className="absolute top-full mt-2 w-full bg-slate-800 rounded-lg overflow-hidden shadow-xl">
            {continents.map((continent) => (
              <button
                key={continent}
                onClick={() => {
                  setSelectedContinent(continent)
                  setShowContinentDropdown(false)
                }}
                className={`w-full px-4 py-2.5 text-left hover:bg-slate-700 transition-colors ${
                  selectedContinent === continent ? "bg-slate-700" : ""
                }`}
              >
                {continent}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Search bar */}
      <div className="absolute top-16 left-1/2 -translate-x-1/2 z-20 w-80 mt-2">
        <input
          type="text"
          placeholder="搜索国家 / 城市 / 勋章"
          className="w-full px-4 py-2.5 bg-slate-800/90 backdrop-blur-sm rounded-lg text-sm placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-slate-600"
        />
      </div>

      {/* 2D/3D Toggle */}
      <div className="absolute top-16 left-1/2 translate-x-24 z-20 mt-2 flex items-center gap-1 bg-slate-800/90 backdrop-blur-sm rounded-lg p-1">
        <button
          onClick={() => setMapMode("2D")}
          className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
            mapMode === "2D" 
              ? "bg-emerald-500 text-white" 
              : "text-slate-300 hover:text-white"
          }`}
        >
          2D
        </button>
        <button
          onClick={() => setMapMode("3D")}
          className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
            mapMode === "3D" 
              ? "bg-emerald-500 text-white" 
              : "text-slate-300 hover:text-white"
          }`}
        >
          3D
        </button>
        <button className="p-1.5 text-slate-300 hover:text-white">
          <Maximize2 className="h-4 w-4" />
        </button>
      </div>

      {/* Map container */}
      <div className="relative w-full h-screen overflow-hidden">
        {mapMode === "3D" ? (
          // 3D Globe view
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative w-[500px] h-[500px]">
              {/* Globe background */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-slate-700 to-slate-900 shadow-2xl overflow-hidden">
                {/* Simplified continent shapes */}
                <svg viewBox="0 0 100 100" className="w-full h-full opacity-30">
                  {/* Asia */}
                  <path d="M55 25 L75 30 L80 45 L70 55 L55 50 L50 35 Z" fill="currentColor" className="text-slate-500" />
                  {/* Europe */}
                  <path d="M35 20 L50 25 L48 35 L35 38 L30 30 Z" fill="currentColor" className="text-slate-500" />
                  {/* Africa */}
                  <path d="M35 45 L48 42 L52 60 L40 70 L32 55 Z" fill="currentColor" className="text-slate-500" />
                  {/* Americas */}
                  <path d="M15 25 L25 30 L28 50 L20 65 L12 45 Z" fill="currentColor" className="text-slate-500" />
                </svg>
              </div>

              {/* Location markers on globe */}
              {locationData.map((location) => (
                <button
                  key={location.id}
                  onClick={() => setSelectedLocation(location)}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 z-10"
                  style={{ 
                    left: `${location.position.x - 10}%`, 
                    top: `${location.position.y + 5}%` 
                  }}
                >
                  <div className={`px-3 py-2 rounded-xl backdrop-blur-sm transition-all hover:scale-105 ${
                    selectedLocation?.id === location.id
                      ? "bg-slate-700/95 ring-2 ring-emerald-500"
                      : "bg-slate-800/90"
                  }`}>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{location.name}</span>
                      <span className="text-base">{location.emoji}</span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      去过 {location.visited} · 计划 {location.planned}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          // 2D Map view
          <div className="absolute inset-0 bg-slate-800">
            {/* Simple world map background */}
            <svg viewBox="0 0 100 60" className="w-full h-full" preserveAspectRatio="xMidYMid slice">
              {/* Ocean */}
              <rect width="100" height="60" fill="#1e293b" />
              {/* Continents - simplified shapes */}
              {/* North America */}
              <path d="M5 10 L25 8 L28 25 L20 35 L8 30 Z" fill="#334155" />
              {/* South America */}
              <path d="M18 38 L28 35 L30 55 L20 58 L15 48 Z" fill="#334155" />
              {/* Europe */}
              <path d="M38 8 L52 10 L50 22 L40 25 L35 18 Z" fill="#334155" />
              {/* Africa */}
              <path d="M38 28 L55 25 L58 48 L45 55 L35 42 Z" fill="#334155" />
              {/* Asia */}
              <path d="M52 8 L85 10 L90 35 L75 40 L60 38 L55 20 Z" fill="#334155" />
              {/* Australia */}
              <path d="M75 45 L90 43 L92 55 L78 57 Z" fill="#334155" />
            </svg>

            {/* Location markers on 2D map */}
            {locationData.map((location) => (
              <button
                key={location.id}
                onClick={() => setSelectedLocation(location)}
                className="absolute transform -translate-x-1/2 -translate-y-1/2 z-10"
                style={{ 
                  left: `${location.position.x}%`, 
                  top: `${location.position.y}%` 
                }}
              >
                <div className={`px-3 py-2 rounded-xl backdrop-blur-sm transition-all hover:scale-105 ${
                  selectedLocation?.id === location.id
                    ? "bg-slate-700/95 ring-2 ring-emerald-500"
                    : "bg-slate-800/90"
                }`}>
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">{location.name}</span>
                    <span className="text-base">{location.emoji}</span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    去过 {location.visited} · 计划 {location.planned}
                  </p>
                </div>
              </button>
            ))}
          </div>
        )}

        {/* Selected location detail panel */}
        {selectedLocation && (
          <div className="absolute top-28 right-4 w-72 bg-slate-800/95 backdrop-blur-sm rounded-2xl p-4 z-30">
            {/* Close button */}
            <button
              onClick={() => setSelectedLocation(null)}
              className="absolute top-3 right-3 p-1 hover:bg-slate-700 rounded-full transition-colors"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Location header */}
            <div className="mb-4">
              <span className="text-xs text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded">
                {selectedLocation.country} · {selectedLocation.name}
              </span>
              <h2 className="text-2xl font-bold mt-2">{selectedLocation.name}</h2>
              <p className="text-slate-400 text-sm">
                去过 {selectedLocation.visited} 人 · 计划 {selectedLocation.planned} 人
              </p>
            </div>

            {/* Emoji avatars */}
            <div className="flex gap-2 mb-4">
              {selectedLocation.emoji.split("").filter(c => c.trim()).slice(0, 2).map((emoji, i) => (
                <span key={i} className="w-10 h-10 bg-slate-700 rounded-xl flex items-center justify-center text-xl">
                  {emoji}
                </span>
              ))}
            </div>

            {/* Stats - inline layout */}
            <div className="flex items-center gap-4 mb-4 bg-slate-700/50 rounded-xl p-3">
              <div className="flex-1 text-center border-r border-slate-600">
                <p className="text-xs text-emerald-400 mb-1">已经去过</p>
                <p className="text-2xl font-bold">{selectedLocation.visited}</p>
              </div>
              <div className="flex-1 text-center">
                <p className="text-xs text-emerald-400 mb-1">未来计划去</p>
                <p className="text-2xl font-bold">{selectedLocation.planned}</p>
              </div>
            </div>

            {/* Trip lists */}
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {selectedLocation.trips.visited.length > 0 && (
                <>
                  <p className="text-xs text-slate-400">已去过</p>
                  {selectedLocation.trips.visited.map((trip) => (
                    <Link 
                      key={trip.id}
                      href={`/trip/${trip.id}`}
                      className="flex items-center gap-3 p-2.5 bg-slate-700/30 rounded-lg hover:bg-slate-700/50 transition-colors"
                    >
                      <span className="w-9 h-9 bg-slate-600 rounded-full flex items-center justify-center text-lg">
                        {trip.avatar}
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{trip.title}</p>
                        <p className="text-xs text-slate-400">{trip.user} · {trip.date}</p>
                      </div>
                    </Link>
                  ))}
                </>
              )}
              
              {selectedLocation.trips.planned.length > 0 && (
                <>
                  <p className="text-xs text-slate-400 mt-3">未来计划</p>
                  {selectedLocation.trips.planned.map((trip) => (
                    <Link 
                      key={trip.id}
                      href={`/trip/${trip.id}`}
                      className="flex items-center gap-3 p-2.5 bg-slate-700/30 rounded-lg hover:bg-slate-700/50 transition-colors"
                    >
                      <span className="w-9 h-9 bg-slate-600 rounded-full flex items-center justify-center text-lg">
                        {trip.avatar}
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{trip.title}</p>
                        <p className="text-xs text-slate-400">{trip.user} · {trip.date}</p>
                      </div>
                    </Link>
                  ))}
                </>
              )}
            </div>

            {/* Footer note */}
            <p className="text-xs text-slate-500 mt-4">
              数据来源：用户发布的行程，按出发日期与今天比较自动区分"去过 / 计划去"。
            </p>
          </div>
        )}
      </div>

      {/* Mode indicator */}
      <div className="absolute bottom-24 right-4 text-xs text-slate-500">
        当前：{mapMode === "3D" ? "3D 球体" : "2D 平面"} · 仅点击 2D / 3D 按钮切换
      </div>

      {/* Bottom tab bar */}
      <BottomTabBar activeTab="world" />
    </div>
  )
}
