"use client"

import { useState } from "react"
import { Search, ChevronRight, Star } from "lucide-react"
import { BottomTabBar } from "@/components/bottom-tab-bar"
import Image from "next/image"
import Link from "next/link"

const continents = [
  { id: "asia", name: "亚洲" },
  { id: "europe", name: "欧洲" },
  { id: "north-america", name: "北美洲" },
  { id: "oceania", name: "大洋洲" },
  { id: "south-america", name: "南美洲" },
  { id: "africa", name: "非洲" },
]

const guidesData = {
  asia: {
    featured: {
      name: "日本",
      image: "/images/guide-tokyo.jpg",
      description: "樱花、美食、动漫圣地",
    },
    countries: [
      {
        id: "japan",
        name: "日本",
        image: "/images/guide-tokyo.jpg",
        guidesCount: 2847,
        cities: ["东京", "大阪", "京都", "北海道", "冲绳"],
      },
      {
        id: "korea",
        name: "韩国",
        image: "/images/seoul.jpg",
        guidesCount: 1563,
        cities: ["首尔", "釜山", "济州岛"],
      },
      {
        id: "thailand",
        name: "泰国",
        image: "/images/guide-bangkok.jpg",
        guidesCount: 1892,
        cities: ["曼谷", "清迈", "普吉岛", "芭提雅"],
      },
      {
        id: "singapore",
        name: "新加坡",
        image: "/images/guide-singapore.jpg",
        guidesCount: 876,
        cities: ["新加坡市"],
      },
      {
        id: "vietnam",
        name: "越南",
        image: "/images/bali.jpg",
        guidesCount: 654,
        cities: ["胡志明市", "河内", "岘港"],
      },
      {
        id: "indonesia",
        name: "印度尼西亚",
        image: "/images/bali.jpg",
        guidesCount: 1124,
        cities: ["巴厘岛", "雅加达"],
      },
    ],
  },
  europe: {
    featured: {
      name: "法国",
      image: "/images/paris.jpg",
      description: "浪漫之都、艺术殿堂",
    },
    countries: [
      {
        id: "france",
        name: "法国",
        image: "/images/paris.jpg",
        guidesCount: 2156,
        cities: ["巴黎", "尼斯", "里昂"],
      },
      {
        id: "italy",
        name: "意大利",
        image: "/images/paris.jpg",
        guidesCount: 1987,
        cities: ["罗马", "米兰", "威尼斯", "佛罗伦萨"],
      },
      {
        id: "uk",
        name: "英国",
        image: "/images/paris.jpg",
        guidesCount: 1654,
        cities: ["伦敦", "爱丁堡", "曼彻斯特"],
      },
      {
        id: "spain",
        name: "西班牙",
        image: "/images/paris.jpg",
        guidesCount: 1432,
        cities: ["巴塞罗那", "马德里", "塞维利亚"],
      },
    ],
  },
  "north-america": {
    featured: {
      name: "美国",
      image: "/images/guide-singapore.jpg",
      description: "多元文化、自然奇观",
    },
    countries: [
      {
        id: "usa",
        name: "美国",
        image: "/images/guide-singapore.jpg",
        guidesCount: 3254,
        cities: ["纽约", "洛杉矶", "旧金山", "拉斯维加斯"],
      },
      {
        id: "canada",
        name: "加拿大",
        image: "/images/guide-singapore.jpg",
        guidesCount: 987,
        cities: ["温哥华", "多伦多", "蒙特利尔"],
      },
    ],
  },
  oceania: {
    featured: {
      name: "澳大利亚",
      image: "/images/guide-singapore.jpg",
      description: "阳光海滩、野生动物",
    },
    countries: [
      {
        id: "australia",
        name: "澳大利亚",
        image: "/images/guide-singapore.jpg",
        guidesCount: 1456,
        cities: ["悉尼", "墨尔本", "黄金海岸"],
      },
      {
        id: "new-zealand",
        name: "新西兰",
        image: "/images/guide-singapore.jpg",
        guidesCount: 876,
        cities: ["奥克兰", "皇后镇"],
      },
    ],
  },
  "south-america": {
    featured: {
      name: "巴西",
      image: "/images/bali.jpg",
      description: "热情桑巴、亚马逊雨林",
    },
    countries: [
      {
        id: "brazil",
        name: "巴西",
        image: "/images/bali.jpg",
        guidesCount: 654,
        cities: ["里约热内卢", "圣保罗"],
      },
      {
        id: "argentina",
        name: "阿根廷",
        image: "/images/bali.jpg",
        guidesCount: 432,
        cities: ["布宜诺斯艾利斯"],
      },
    ],
  },
  africa: {
    featured: {
      name: "埃及",
      image: "/images/bali.jpg",
      description: "金字塔、尼罗河",
    },
    countries: [
      {
        id: "egypt",
        name: "埃及",
        image: "/images/bali.jpg",
        guidesCount: 543,
        cities: ["开罗", "卢克索"],
      },
      {
        id: "south-africa",
        name: "南非",
        image: "/images/bali.jpg",
        guidesCount: 321,
        cities: ["开普敦", "约翰内斯堡"],
      },
    ],
  },
}

export default function GuidesPage() {
  const [activeContinent, setActiveContinent] = useState("asia")
  const [savedCountries, setSavedCountries] = useState<string[]>([])
  const [showAllCountries, setShowAllCountries] = useState(false)

  const currentData = guidesData[activeContinent as keyof typeof guidesData]

  // Get all countries from all continents
  const allCountries = Object.values(guidesData).flatMap(data => data.countries)
    .sort((a, b) => b.guidesCount - a.guidesCount)

  const toggleSave = (countryId: string) => {
    setSavedCountries((prev) =>
      prev.includes(countryId)
        ? prev.filter((id) => id !== countryId)
        : [...prev, countryId]
    )
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-background pt-safe">
        <div className="px-5 py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-foreground">查攻略</h1>
            <button className="p-2 rounded-full hover:bg-muted/50 transition-colors">
              <Search className="h-5 w-5 text-muted-foreground" />
            </button>
          </div>

          {/* Continent tabs */}
          <div className="flex gap-2 overflow-x-auto scrollbar-hide -mx-5 px-5 pb-2">
            {continents.map((continent) => (
              <button
                key={continent.id}
                onClick={() => setActiveContinent(continent.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                  activeContinent === continent.id
                    ? "bg-foreground text-background"
                    : "bg-muted/50 text-muted-foreground hover:bg-muted"
                }`}
              >
                {continent.name}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Featured country */}
      <section className="px-5 mb-6">
        <div className="relative h-40 rounded-2xl overflow-hidden">
          <Image
            src={currentData.featured.image}
            alt={currentData.featured.name}
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-4 left-4 text-white">
            <h3 className="text-xl font-bold">{currentData.featured.name}</h3>
            <p className="text-sm text-white/80">{currentData.featured.description}</p>
          </div>
        </div>
      </section>

      {/* Countries list */}
      <section className="px-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-foreground">
            {showAllCountries ? "全部热门国家" : "热门国家"}
          </h2>
          <button 
            onClick={() => setShowAllCountries(!showAllCountries)}
            className="flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            {showAllCountries ? "收起" : "更多"} 
            <ChevronRight className={`h-4 w-4 transition-transform ${showAllCountries ? "rotate-90" : ""}`} />
          </button>
        </div>

        <div className="flex flex-col gap-3">
          {(showAllCountries ? allCountries : currentData.countries).map((country) => (
            <div
              key={country.id}
              className="flex items-center gap-4 p-3 bg-card rounded-xl border border-border/50"
            >
              {/* Country image */}
              <Link href={`/guides/country/${country.id}`} className="relative w-16 h-16 rounded-lg overflow-hidden shrink-0">
                <Image
                  src={country.image}
                  alt={country.name}
                  fill
                  className="object-cover"
                />
              </Link>

              {/* Country info */}
              <Link href={`/guides/country/${country.id}`} className="flex-1 min-w-0">
                <h3 className="font-semibold text-foreground mb-1">{country.name}</h3>
                <p className="text-sm text-muted-foreground mb-2">
                  {country.guidesCount} 篇攻略
                </p>
                <div className="flex gap-1.5 flex-wrap">
                  {country.cities.slice(0, 4).map((city) => (
                    <span
                      key={city}
                      className="px-2 py-0.5 bg-muted/50 rounded text-xs text-muted-foreground"
                    >
                      {city}
                    </span>
                  ))}
                  {country.cities.length > 4 && (
                    <span className="px-2 py-0.5 text-xs text-muted-foreground">
                      +{country.cities.length - 4}
                    </span>
                  )}
                </div>
              </Link>

              {/* Save button */}
              <button
                onClick={() => toggleSave(country.id)}
                className="flex flex-col items-center gap-1 shrink-0"
              >
                <Star
                  className={`h-5 w-5 ${
                    savedCountries.includes(country.id)
                      ? "fill-amber-500 text-amber-500"
                      : "text-muted-foreground"
                  }`}
                />
                <span
                  className={`text-xs ${
                    savedCountries.includes(country.id)
                      ? "text-amber-500"
                      : "text-muted-foreground"
                  }`}
                >
                  收藏
                </span>
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Bottom tab bar */}
      <BottomTabBar activeTab="guides" />
    </div>
  )
}
