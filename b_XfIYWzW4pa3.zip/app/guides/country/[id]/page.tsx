"use client"

import { use } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Star, MapPin, Clock } from "lucide-react"
import { BottomTabBar } from "@/components/bottom-tab-bar"

// Mock data for countries
const countryData: Record<string, {
  name: string
  nameEn: string
  image: string
  description: string
  guideCount: number
  recommendDays: string
  cities: {
    id: string
    name: string
    image: string
    guideCount: number
    highlights: string[]
  }[]
}> = {
  japan: {
    name: "日本",
    nameEn: "Japan",
    image: "/images/country-japan.jpg",
    description: "樱花、温泉、美食、动漫文化的完美融合",
    guideCount: 156,
    recommendDays: "7-14 天",
    cities: [
      {
        id: "tokyo",
        name: "东京",
        image: "/images/guide-tokyo.jpg",
        guideCount: 45,
        highlights: ["涩谷", "新宿", "浅草寺", "秋叶原"],
      },
      {
        id: "osaka",
        name: "大阪",
        image: "/images/guide-osaka.jpg",
        guideCount: 32,
        highlights: ["道顿堀", "心斋桥", "大阪城", "环球影城"],
      },
      {
        id: "kyoto",
        name: "京都",
        image: "/images/kyoto.jpg",
        guideCount: 38,
        highlights: ["伏见稻荷", "金阁寺", "岚山", "祇园"],
      },
      {
        id: "hokkaido",
        name: "北海道",
        image: "/images/bali.jpg",
        guideCount: 28,
        highlights: ["札幌", "小樽", "富良野", "函馆"],
      },
    ],
  },
  korea: {
    name: "韩国",
    nameEn: "South Korea",
    image: "/images/seoul.jpg",
    description: "K-pop、韩剧取景地、美妆购物天堂",
    guideCount: 89,
    recommendDays: "5-7 天",
    cities: [
      {
        id: "seoul",
        name: "首尔",
        image: "/images/seoul.jpg",
        guideCount: 52,
        highlights: ["明洞", "弘大", "景福宫", "北村韩屋村"],
      },
      {
        id: "busan",
        name: "釜山",
        image: "/images/guide-bangkok.jpg",
        guideCount: 24,
        highlights: ["海云台", "甘川文化村", "札嘎其市场"],
      },
      {
        id: "jeju",
        name: "济州岛",
        image: "/images/bali.jpg",
        guideCount: 18,
        highlights: ["城山日出峰", "牛岛", "天帝渊瀑布"],
      },
    ],
  },
}

export default function CountryGuidePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const country = countryData[id] || countryData.japan

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header with background */}
      <div className="relative">
        <div className="absolute inset-0 h-72">
          <Image
            src={country.image}
            alt={country.name}
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/20 to-background" />
        </div>

        {/* Navigation */}
        <div className="relative z-10 px-5 pt-12 pb-4">
          <Link
            href="/guides"
            className="inline-flex items-center gap-2 text-white/90 hover:text-white transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>返回攻略集</span>
          </Link>
        </div>

        {/* Country info card */}
        <div className="relative z-10 mx-5 mt-16 bg-background/95 backdrop-blur-sm rounded-2xl p-6 shadow-lg">
          <p className="text-sm text-muted-foreground mb-1">国家攻略主题页</p>
          <h1 className="text-3xl font-bold text-foreground mb-2">
            {country.name} <span className="text-muted-foreground font-normal text-lg">国家攻略</span>
          </h1>
          <p className="text-muted-foreground mb-4">{country.description}</p>

          <div className="flex gap-4 mb-4">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-muted/50 rounded-lg">
              <Star className="h-4 w-4 text-amber-500" />
              <span className="text-sm font-medium">{country.guideCount} 篇攻略</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 bg-muted/50 rounded-lg">
              <Clock className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium">推荐游玩 {country.recommendDays}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Cities section */}
      <section className="px-5 mt-8">
        <h2 className="text-xl font-bold text-foreground mb-4">热门城市</h2>
        <div className="space-y-4">
          {country.cities.map((city) => (
            <Link
              key={city.id}
              href={`/guides/city/${city.id}`}
              className="block bg-card rounded-2xl overflow-hidden border border-border/50 hover:shadow-md transition-shadow"
            >
              <div className="flex">
                <div className="relative w-32 h-32 shrink-0">
                  <Image
                    src={city.image}
                    alt={city.name}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="flex-1 p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-lg font-semibold text-foreground">{city.name}</h3>
                      <p className="text-sm text-muted-foreground mt-0.5">{city.guideCount} 篇攻略</p>
                    </div>
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="flex gap-1.5 flex-wrap mt-3">
                    {city.highlights.map((highlight) => (
                      <span
                        key={highlight}
                        className="px-2 py-0.5 bg-muted/50 rounded text-xs text-muted-foreground"
                      >
                        {highlight}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Travel tips */}
      <section className="px-5 mt-8">
        <h2 className="text-xl font-bold text-foreground mb-4">旅行贴士</h2>
        <div className="bg-card rounded-2xl p-5 border border-border/50">
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-foreground mb-1">最佳旅行时间</h3>
              <p className="text-sm text-muted-foreground">春季（3-5月）樱花季，秋季（9-11月）红叶季最为推荐</p>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">签证信息</h3>
              <p className="text-sm text-muted-foreground">中国公民需办理旅游签证，可选择单次或多次入境</p>
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">货币与支付</h3>
              <p className="text-sm text-muted-foreground">当地货币为日元，部分商户支持支付宝/微信支付</p>
            </div>
          </div>
        </div>
      </section>

      <BottomTabBar activeTab="guides" />
    </div>
  )
}
