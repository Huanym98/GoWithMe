"use client"

import { use } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Heart, Share2, Bookmark, MessageCircle, Eye, Clock, MapPin } from "lucide-react"
import { BottomTabBar } from "@/components/bottom-tab-bar"

// Mock data for guide details
const guideDetailData: Record<string, {
  title: string
  subtitle: string
  coverImage: string
  author: {
    name: string
    avatar: string
  }
  publishDate: string
  readTime: string
  views: number
  likes: number
  comments: number
  location: string
  tags: string[]
  content: {
    type: "text" | "image" | "tip" | "heading"
    content: string
    caption?: string
  }[]
  relatedGuides: {
    id: string
    title: string
    image: string
  }[]
}> = {
  "shibuya-crossing": {
    title: "涩谷十字路口",
    subtitle: "世界上最繁忙的十字路口，感受东京的脉搏",
    coverImage: "/images/guide-tokyo.jpg",
    author: {
      name: "旅行达人小王",
      avatar: "/images/avatar.png",
    },
    publishDate: "2026年3月15日",
    readTime: "5分钟",
    views: 12580,
    likes: 856,
    comments: 128,
    location: "东京都�的谷区",
    tags: ["网红打卡", "摄影圣地", "东京必去"],
    content: [
      {
        type: "heading",
        content: "关于涩谷十字路口",
      },
      {
        type: "text",
        content: "涩谷十字路口（Shibuya Crossing）是世界上最繁忙的行人交叉路口之一，每次绿灯时最多可有3000人同时穿越。这里是东京的象征性地标，也是体验城市活力的绝佳地点。",
      },
      {
        type: "image",
        content: "/images/guide-tokyo.jpg",
        caption: "从SHIBUYA SKY俯瞰涩谷十字路口",
      },
      {
        type: "heading",
        content: "最佳拍摄时间",
      },
      {
        type: "text",
        content: "傍晚时分（17:00-19:00）是拍摄的黄金时段，此时华灯初上，霓虹灯与行人形成绝美画面。周五和周六晚上人流量最大，更能感受到东京的繁华。",
      },
      {
        type: "tip",
        content: "推荐前往SHIBUYA SKY展望台（门票2000日元），可以从230米高空俯瞰整个涩谷区，拍摄效果绝佳！",
      },
      {
        type: "heading",
        content: "周边推荐",
      },
      {
        type: "text",
        content: "涩谷站周边有大量购物中心和美食店铺。推荐前往涩谷109大楼购物，或在Hachiko出口的忠犬八公像打卡留念。附近的道玄坂和Center街也是年轻人聚集的潮流街区。",
      },
      {
        type: "image",
        content: "/images/guide-osaka.jpg",
        caption: "忠犬八公像是经典的集合地点",
      },
      {
        type: "heading",
        content: "交通指南",
      },
      {
        type: "text",
        content: "搭乘JR山手线、东京Metro银座线、半藏门线、副都心线至涩谷站，从Hachiko出口步行即到。建议购买东京Metro一日券，方便在市内游览。",
      },
    ],
    relatedGuides: [
      { id: "tokyo-tower", title: "东京塔夜景攻略", image: "/images/guide-osaka.jpg" },
      { id: "sensoji", title: "浅草寺和服体验", image: "/images/kyoto.jpg" },
      { id: "shinjuku", title: "新宿歌舞伎町夜游", image: "/images/seoul.jpg" },
    ],
  },
  "tokyo-tower": {
    title: "东京塔",
    subtitle: "东京的浪漫地标，日剧中的经典场景",
    coverImage: "/images/guide-osaka.jpg",
    author: {
      name: "日本通小李",
      avatar: "/images/avatar.png",
    },
    publishDate: "2026年3月10日",
    readTime: "4分钟",
    views: 9850,
    likes: 720,
    comments: 95,
    location: "东京都港区",
    tags: ["夜景", "地标建筑", "约会圣地"],
    content: [
      {
        type: "heading",
        content: "东京塔简介",
      },
      {
        type: "text",
        content: "东京塔（Tokyo Tower）建于1958年，高333米，是东京的标志性建筑。虽然后来建成了更高的晴空塔，但东京塔依然是许多人心中东京的象征，更是日剧中的经典取景地。",
      },
      {
        type: "image",
        content: "/images/guide-osaka.jpg",
        caption: "夜幕下的东京塔散发着温暖的橙色光芒",
      },
      {
        type: "tip",
        content: "晚上的东京塔会根据季节和节日变换灯光颜色，夏季是白色「钻石点灯」，冬季是橙色「地标点灯」。",
      },
    ],
    relatedGuides: [
      { id: "shibuya-crossing", title: "涩谷十字路口", image: "/images/guide-tokyo.jpg" },
      { id: "sensoji", title: "浅草寺和服体验", image: "/images/kyoto.jpg" },
    ],
  },
  "sensoji": {
    title: "浅草寺",
    subtitle: "东京最古老的寺庙，体验传统日本文化",
    coverImage: "/images/kyoto.jpg",
    author: {
      name: "文化探索者",
      avatar: "/images/avatar.png",
    },
    publishDate: "2026年3月8日",
    readTime: "6分钟",
    views: 15200,
    likes: 980,
    comments: 156,
    location: "东京都台东区",
    tags: ["寺庙", "和服体验", "传统文化"],
    content: [
      {
        type: "heading",
        content: "浅草寺历史",
      },
      {
        type: "text",
        content: "浅草寺（Senso-ji）创建于公元628年，是东京都内最古老的寺院。雷门的大红灯笼是东京的标志性景观，仲见世商店街则保留了江户时代的风情。",
      },
      {
        type: "image",
        content: "/images/kyoto.jpg",
        caption: "雷门是浅草寺的标志性入口",
      },
    ],
    relatedGuides: [
      { id: "shibuya-crossing", title: "涩谷十字路口", image: "/images/guide-tokyo.jpg" },
      { id: "tokyo-tower", title: "东京塔夜景攻略", image: "/images/guide-osaka.jpg" },
    ],
  },
  "westlake": {
    title: "西湖",
    subtitle: "人间天堂，感受诗画江南",
    coverImage: "/images/hangzhou-westlake.jpg",
    author: {
      name: "江南游子",
      avatar: "/images/avatar.png",
    },
    publishDate: "2026年3月1日",
    readTime: "8分钟",
    views: 28500,
    likes: 1520,
    comments: 230,
    location: "浙江省杭州市",
    tags: ["世界遗产", "自然风光", "文化名胜"],
    content: [
      {
        type: "heading",
        content: "西湖十景",
      },
      {
        type: "text",
        content: "西湖是中国首批国家重点风景名胜区之一，世界文化遗产。传统的「西湖十景」包括苏堤春晓、曲院风荷、平湖秋月、断桥残雪等，每一处都有其独特的意境和故事。",
      },
      {
        type: "image",
        content: "/images/hangzhou-westlake.jpg",
        caption: "西湖断桥，白娘子与许仙相遇之地",
      },
    ],
    relatedGuides: [
      { id: "leifeng-tower", title: "雷峰塔日落", image: "/images/hangzhou-westlake.jpg" },
    ],
  },
}

// Default fallback for unknown guides
const defaultGuide = {
  title: "攻略详情",
  subtitle: "探索更多精彩内容",
  coverImage: "/images/guide-tokyo.jpg",
  author: {
    name: "歌觅用户",
    avatar: "/images/avatar.png",
  },
  publishDate: "2026年4月1日",
  readTime: "5分钟",
  views: 1000,
  likes: 100,
  comments: 20,
  location: "待更新",
  tags: ["攻略", "旅行"],
  content: [
    {
      type: "text" as const,
      content: "该攻略内容正在编辑中，敬请期待...",
    },
  ],
  relatedGuides: [],
}

export default function GuideDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const guide = guideDetailData[id] || defaultGuide

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="flex items-center justify-between px-4 py-3">
          <Link href="/guides" className="p-2 -ml-2">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <h1 className="text-base font-medium">攻略详情</h1>
          <div className="flex gap-2">
            <button className="p-2">
              <Share2 className="h-5 w-5" />
            </button>
            <button className="p-2">
              <Bookmark className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Cover image */}
      <div className="relative w-full h-56">
        <Image
          src={guide.coverImage}
          alt={guide.title}
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4">
          <h1 className="text-2xl font-bold text-white mb-1">{guide.title}</h1>
          <p className="text-white/80 text-sm">{guide.subtitle}</p>
        </div>
      </div>

      {/* Author & stats */}
      <div className="px-4 py-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative w-10 h-10 rounded-full overflow-hidden">
              <Image
                src={guide.author.avatar}
                alt={guide.author.name}
                fill
                className="object-cover"
              />
            </div>
            <div>
              <p className="font-medium text-sm">{guide.author.name}</p>
              <p className="text-xs text-muted-foreground">{guide.publishDate}</p>
            </div>
          </div>
          <button className="px-4 py-1.5 bg-primary text-primary-foreground rounded-full text-sm font-medium">
            关注
          </button>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-4 mt-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Eye className="h-4 w-4" />
            <span>{guide.views.toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <span>{guide.readTime}</span>
          </div>
          <div className="flex items-center gap-1">
            <MapPin className="h-4 w-4" />
            <span>{guide.location}</span>
          </div>
        </div>

        {/* Tags */}
        <div className="flex gap-2 mt-3 flex-wrap">
          {guide.tags.map((tag) => (
            <span
              key={tag}
              className="px-2 py-1 bg-muted text-xs rounded-md"
            >
              #{tag}
            </span>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-6 space-y-4">
        {guide.content.map((block, index) => {
          switch (block.type) {
            case "heading":
              return (
                <h2 key={index} className="text-lg font-bold text-foreground pt-2">
                  {block.content}
                </h2>
              )
            case "text":
              return (
                <p key={index} className="text-foreground/90 leading-relaxed">
                  {block.content}
                </p>
              )
            case "image":
              return (
                <div key={index} className="space-y-2">
                  <div className="relative w-full h-48 rounded-xl overflow-hidden">
                    <Image
                      src={block.content}
                      alt={block.caption || ""}
                      fill
                      className="object-cover"
                    />
                  </div>
                  {block.caption && (
                    <p className="text-xs text-muted-foreground text-center">
                      {block.caption}
                    </p>
                  )}
                </div>
              )
            case "tip":
              return (
                <div
                  key={index}
                  className="bg-amber-50 border border-amber-200 rounded-xl p-4"
                >
                  <p className="text-sm text-amber-900">
                    <span className="font-medium">小贴士：</span>
                    {block.content}
                  </p>
                </div>
              )
            default:
              return null
          }
        })}
      </div>

      {/* Related guides */}
      {guide.relatedGuides.length > 0 && (
        <div className="px-4 py-6 border-t border-border">
          <h3 className="text-lg font-bold mb-4">相关攻略</h3>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {guide.relatedGuides.map((related) => (
              <Link
                key={related.id}
                href={`/guides/detail/${related.id}`}
                className="shrink-0"
              >
                <div className="relative w-32 h-24 rounded-xl overflow-hidden">
                  <Image
                    src={related.image}
                    alt={related.title}
                    fill
                    className="object-cover"
                  />
                </div>
                <p className="text-sm mt-2 max-w-32 line-clamp-2">{related.title}</p>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Bottom action bar */}
      <div className="fixed bottom-16 left-0 right-0 bg-background border-t border-border px-4 py-3">
        <div className="flex items-center justify-center gap-8">
          <button className="flex flex-col items-center gap-1">
            <Heart className="h-5 w-5" />
            <span className="text-xs">{guide.likes}</span>
          </button>
          <button className="flex flex-col items-center gap-1">
            <MessageCircle className="h-5 w-5" />
            <span className="text-xs">{guide.comments}</span>
          </button>
          <button className="flex flex-col items-center gap-1">
            <Bookmark className="h-5 w-5" />
            <span className="text-xs">收藏</span>
          </button>
        </div>
      </div>

      <BottomTabBar activeTab="guides" />
    </div>
  )
}
