"use client"

import { use, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Star, Clock } from "lucide-react"
import { BottomTabBar } from "@/components/bottom-tab-bar"

// Mock data for cities
const cityData: Record<string, {
  name: string
  country: string
  image: string
  description: string
  guideCount: number
  recommendDays: string
  categories: string[]
  sections: {
    title: string
    description: string
    tags: string[]
    items: {
      id: string
      name: string
      image: string
    }[]
  }[]
}> = {
  tokyo: {
    name: "东京",
    country: "日本",
    image: "/images/guide-tokyo.jpg",
    description: "潮流时尚 / 动漫圣地 / 美食天堂 / 购物血拼",
    guideCount: 45,
    recommendDays: "3-5 天",
    categories: ["返回攻略集", "经典路线", "美食打卡", "网红景点", "购物攻略"],
    sections: [
      {
        title: "网红景点打卡",
        description: "涩谷十字路口、东京塔、浅草寺与新宿夜景",
        tags: ["涩谷", "东京塔", "浅草寺", "新宿"],
        items: [
          { id: "shibuya-crossing", name: "涩谷十字路口", image: "/images/guide-tokyo.jpg" },
          { id: "tokyo-tower", name: "东京塔", image: "/images/guide-osaka.jpg" },
          { id: "sensoji", name: "浅草寺", image: "/images/kyoto.jpg" },
          { id: "shinjuku", name: "新宿歌舞伎町", image: "/images/seoul.jpg" },
        ],
      },
      {
        title: "美食攻略",
        description: "寿司、拉面、烧肉与甜品探店",
        tags: ["寿司", "拉面", "烧肉", "甜品", "居酒屋"],
        items: [
          { id: "tsukiji-sushi", name: "筑地寿司", image: "/images/hangzhou-dongpo.jpg" },
          { id: "ichiran-ramen", name: "一兰拉面", image: "/images/hangzhou-dongpo.jpg" },
          { id: "wagyu-yakiniku", name: "和牛烧肉", image: "/images/hangzhou-dongpo.jpg" },
          { id: "dessert-shop", name: "甜品店", image: "/images/hangzhou-dongpo.jpg" },
        ],
      },
      {
        title: "购物攻略",
        description: "银座、原宿、秋叶原与药妆店推荐",
        tags: ["银座", "原宿", "秋叶原", "药妆"],
        items: [
          { id: "ginza-shopping", name: "银座购物", image: "/images/guide-singapore.jpg" },
          { id: "harajuku-fashion", name: "原宿潮牌", image: "/images/guide-tokyo.jpg" },
          { id: "akihabara-anime", name: "秋叶原动漫", image: "/images/guide-osaka.jpg" },
        ],
      },
    ],
  },
  hangzhou: {
    name: "杭州",
    country: "中国",
    image: "/images/hangzhou-westlake.jpg",
    description: "白金路线 / 美食打卡 / 网红景点 / 出片穿搭 / 历史名胜",
    guideCount: 22,
    recommendDays: "2-3 天",
    categories: ["返回攻略集", "白金全成就", "2天入门路线", "美食打卡", "网红景点"],
    sections: [
      {
        title: "白金路线",
        description: "主线、隐藏、挑战与 2~3 天奖杯路线",
        tags: ["白金全成就主线 + 隐藏 + 路线 + 美食全收集", "2 天白金入门路线：第一次刷城市奖杯怎么走"],
        items: [
          { id: "hangzhou-platinum", name: "白金全成就主线 + 隐藏 + 路线 + 美食全收集", image: "/images/hangzhou-westlake.jpg" },
          { id: "hangzhou-2day", name: "2 天白金入门路线：第一次刷城市奖杯怎么走", image: "/images/hangzhou-westlake.jpg" },
        ],
      },
      {
        title: "网红景点打卡",
        description: "西湖、断桥、雷峰塔、龙井与钱江新城夜景",
        tags: ["西湖", "断桥", "雷峰塔", "钱江新城夜景"],
        items: [
          { id: "westlake", name: "西湖", image: "/images/hangzhou-westlake.jpg" },
          { id: "broken-bridge", name: "断桥", image: "/images/hangzhou-westlake.jpg" },
          { id: "leifeng-tower", name: "雷峰塔", image: "/images/hangzhou-westlake.jpg" },
          { id: "qianjiang-night", name: "钱江新城夜景", image: "/images/guide-singapore.jpg" },
        ],
      },
      {
        title: "美食攻略",
        description: "杭帮菜、早餐、小馆与夜宵打卡",
        tags: ["西湖醋鱼", "东坡肉", "酒酿圆子", "龙井虾仁", "片儿川", "宋嫂鱼羹"],
        items: [
          { id: "westlake-fish", name: "西湖醋鱼", image: "/images/hangzhou-dongpo.jpg" },
          { id: "dongpo-pork", name: "东坡肉", image: "/images/hangzhou-dongpo.jpg" },
          { id: "sweet-dumplings", name: "酒酿圆子", image: "/images/hangzhou-dongpo.jpg" },
          { id: "longjing-shrimp", name: "龙井虾仁", image: "/images/hangzhou-dongpo.jpg" },
          { id: "pian-er-chuan", name: "片儿川", image: "/images/hangzhou-dongpo.jpg" },
          { id: "songsao-fish", name: "宋嫂鱼羹", image: "/images/hangzhou-dongpo.jpg" },
        ],
      },
      {
        title: "特色衣服 / 出片攻略",
        description: "汉服、citywalk、雨天西湖与季节穿搭",
        tags: ["汉服"],
        items: [
          { id: "hanfu", name: "汉服", image: "/images/hangzhou-hanfu.jpg" },
        ],
      },
      {
        title: "历史名胜人物介绍",
        description: "苏东坡、白蛇传、灵隐寺、南宋御街与城市典故",
        tags: ["苏东坡"],
        items: [
          { id: "su-dongpo", name: "苏东坡", image: "/images/hangzhou-hanfu.jpg" },
        ],
      },
    ],
  },
}

export default function CityGuidePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const city = cityData[id] || cityData.hangzhou
  const [activeCategory, setActiveCategory] = useState(city.categories[1])

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header card */}
      <div className="mx-4 mt-6">
        <div className="bg-gradient-to-br from-amber-50 via-orange-50 to-rose-50 rounded-2xl p-6">
          <p className="text-sm text-muted-foreground mb-1">城市攻略主题页</p>
          <h1 className="text-3xl font-bold text-foreground mb-2">
            {city.name} <span className="text-muted-foreground font-normal">城市攻略</span>
          </h1>
          <p className="text-muted-foreground mb-4">{city.description}</p>

          <div className="flex gap-4 mb-4">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-background/80 rounded-lg">
              <Star className="h-4 w-4 text-amber-500" />
              <span className="text-sm font-medium">{city.guideCount} 篇攻略</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 bg-background/80 rounded-lg">
              <Clock className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium">推荐游玩 {city.recommendDays}</span>
            </div>
          </div>

          {/* Category tabs */}
          <div className="flex gap-2 flex-wrap">
            {city.categories.map((category) => (
              <button
                key={category}
                onClick={() => {
                  if (category === "返回攻略集") {
                    window.history.back()
                  } else {
                    setActiveCategory(category)
                  }
                }}
                className={`px-3 py-1.5 rounded-lg text-sm transition-colors ${
                  category === "返回攻略集"
                    ? "bg-background/80 text-muted-foreground hover:bg-background"
                    : activeCategory === category
                    ? "bg-foreground text-background"
                    : "bg-background/80 text-foreground hover:bg-background"
                }`}
              >
                {category === "返回攻略集" && "← "}
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Content sections */}
      <div className="mt-6 space-y-6">
        {city.sections.map((section) => (
          <section key={section.title} className="mx-4">
            <div className="bg-card rounded-2xl p-5 border border-border/50">
              <h2 className="text-xl font-bold text-foreground mb-1">{section.title}</h2>
              <p className="text-sm text-muted-foreground mb-4">{section.description}</p>

              {/* Tags */}
              <div className="flex gap-2 flex-wrap mb-4">
                {section.tags.map((tag) => (
                  <button
                    key={tag}
                    className="px-3 py-1.5 bg-muted/50 rounded-lg text-sm text-foreground hover:bg-muted transition-colors"
                  >
                    {tag}
                  </button>
                ))}
              </div>

              {/* Items grid */}
              <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
                {section.items.map((item) => (
                  <Link 
                    key={item.id} 
                    href={`/guides/detail/${item.id}`}
                    className="shrink-0 group"
                  >
                    <div className="relative w-40 h-28 rounded-xl overflow-hidden ring-2 ring-transparent group-hover:ring-primary transition-all">
                      <Image
                        src={item.image}
                        alt={item.name}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <p className="text-sm text-foreground mt-2 max-w-40 line-clamp-2 group-hover:text-primary transition-colors">{item.name}</p>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        ))}
      </div>

      <BottomTabBar activeTab="guides" />
    </div>
  )
}
