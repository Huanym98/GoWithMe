"use client"

import { useState } from "react"
import { ArrowLeft, Sparkles, Calendar } from "lucide-react"
import Link from "next/link"

export default function PublishPage() {
  const [formData, setFormData] = useState({
    title: "",
    destination: "",
    departure: "",
    budget: "",
    departureDate: "",
    returnDate: "",
    travelPeriod: "",
    approximateReturn: "",
    travelDays: "",
    tags: "",
    attractions: "",
    itinerary: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    console.log(formData)
  }

  return (
    <div className="min-h-screen relative">
      {/* Background Image */}
      <div 
        className="fixed inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: "url('/images/publish-bg.jpg')" }}
      >
        <div className="absolute inset-0 bg-background/30 backdrop-blur-[2px]" />
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen pb-8">
        {/* Header */}
        <header className="sticky top-0 z-20 bg-background/80 backdrop-blur-md border-b border-border/50">
          <div className="flex items-center justify-between h-14 px-4 max-w-2xl mx-auto">
            <Link href="/" className="p-2 -ml-2 rounded-full hover:bg-muted/50 transition-colors">
              <ArrowLeft className="h-5 w-5 text-foreground" />
            </Link>
            <h1 className="text-base font-medium text-foreground">发布行程</h1>
            <div className="w-9" />
          </div>
        </header>

        {/* Form Container */}
        <div className="max-w-2xl mx-auto px-4 pt-6">
          {/* Header Card */}
          <div className="bg-gradient-to-br from-amber-50 via-orange-50 to-rose-50 dark:from-amber-950/30 dark:via-orange-950/30 dark:to-rose-950/30 rounded-2xl p-6 mb-6 border border-amber-100/50 dark:border-amber-900/30">
            <p className="text-xs font-medium text-amber-600 dark:text-amber-400 tracking-wider mb-1">TRIP POST</p>
            <h2 className="text-xl font-bold text-foreground mb-2">发布行程</h2>
            <p className="text-sm text-muted-foreground">支持明确日期，也支持只填写月份和大概出行时长。</p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Trip Title */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">行程标题</label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleChange}
                placeholder="例如：土耳其热气球日出摄影搭子招募"
                className="w-full h-11 px-4 bg-background/90 backdrop-blur-sm border border-border rounded-xl text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
              />
            </div>

            {/* Destination & Departure - Two columns */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">目的地</label>
                <input
                  type="text"
                  name="destination"
                  value={formData.destination}
                  onChange={handleChange}
                  placeholder="例如：首尔 / 土耳其 / 巴黎"
                  className="w-full h-11 px-4 bg-background/90 backdrop-blur-sm border border-border rounded-xl text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">出发地</label>
                <input
                  type="text"
                  name="departure"
                  value={formData.departure}
                  onChange={handleChange}
                  placeholder="例如：上海 / 北京 / 广州"
                  className="w-full h-11 px-4 bg-background/90 backdrop-blur-sm border border-border rounded-xl text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
                />
              </div>
            </div>

            {/* Budget & Departure Date - Two columns */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">预算（元）</label>
                <input
                  type="text"
                  name="budget"
                  value={formData.budget}
                  onChange={handleChange}
                  placeholder="2000"
                  className="w-full h-11 px-4 bg-background/90 backdrop-blur-sm border border-border rounded-xl text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">出发日期</label>
                <div className="relative">
                  <input
                    type="date"
                    name="departureDate"
                    value={formData.departureDate}
                    onChange={handleChange}
                    className="w-full h-11 px-4 bg-background/90 backdrop-blur-sm border border-border rounded-xl text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors appearance-none"
                  />
                  <Calendar className="absolute right-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                </div>
              </div>
            </div>

            {/* Travel Period & Return Date - Two columns */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">出行月份 / 时间段</label>
                <input
                  type="text"
                  name="travelPeriod"
                  value={formData.travelPeriod}
                  onChange={handleChange}
                  placeholder="例如：6月 / 6月上旬 / 五一前后"
                  className="w-full h-11 px-4 bg-background/90 backdrop-blur-sm border border-border rounded-xl text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">返程日期</label>
                <div className="relative">
                  <input
                    type="date"
                    name="returnDate"
                    value={formData.returnDate}
                    onChange={handleChange}
                    className="w-full h-11 px-4 bg-background/90 backdrop-blur-sm border border-border rounded-xl text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors appearance-none"
                  />
                  <Calendar className="absolute right-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                </div>
              </div>
            </div>

            {/* Approximate Return Time */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">大概返程时间</label>
              <input
                type="text"
                name="approximateReturn"
                value={formData.approximateReturn}
                onChange={handleChange}
                placeholder="例如：6月中旬 / 端午后"
                className="w-full h-11 px-4 bg-background/90 backdrop-blur-sm border border-border rounded-xl text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
              />
            </div>

            {/* Travel Days */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">大概出行天数</label>
              <input
                type="text"
                name="travelDays"
                value={formData.travelDays}
                onChange={handleChange}
                placeholder="例如：10天 / 7天左右 / 周末2-3天"
                className="w-full h-11 px-4 bg-background/90 backdrop-blur-sm border border-border rounded-xl text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
              />
            </div>

            {/* Tags */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">行程标签（逗号分隔）</label>
              <input
                type="text"
                name="tags"
                value={formData.tags}
                onChange={handleChange}
                placeholder="如：citywalk,美食,摄影"
                className="w-full h-11 px-4 bg-background/90 backdrop-blur-sm border border-border rounded-xl text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
              />
            </div>

            {/* Attractions */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">想去景点（逗号分隔）</label>
              <input
                type="text"
                name="attractions"
                value={formData.attractions}
                onChange={handleChange}
                placeholder="如：首尔塔,明洞"
                className="w-full h-11 px-4 bg-background/90 backdrop-blur-sm border border-border rounded-xl text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors"
              />
            </div>

            {/* Detailed Itinerary */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">详细行程</label>
              <textarea
                name="itinerary"
                value={formData.itinerary}
                onChange={handleChange}
                placeholder="例如：D1 上午明洞，D2 弘大 citywalk"
                rows={4}
                className="w-full px-4 py-3 bg-background/90 backdrop-blur-sm border border-border rounded-xl text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors resize-none"
              />
            </div>

            {/* AI Generate Button */}
            <button
              type="button"
              className="flex items-center gap-2 px-4 py-2.5 bg-background/90 backdrop-blur-sm border border-border rounded-xl text-sm text-foreground hover:bg-muted/50 transition-colors"
            >
              <Sparkles className="h-4 w-4 text-blue-500" />
              <span>AI自动生成行程（GPT-5.2）</span>
            </button>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full h-12 bg-foreground text-background rounded-xl text-base font-medium hover:bg-foreground/90 transition-colors"
            >
              发布
            </button>
          </form>

          {/* Bottom spacing */}
          <div className="h-8" />
        </div>
      </div>
    </div>
  )
}
