"use client"

import { useState, useRef, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Plus, MessageSquarePlus, X, Check } from "lucide-react"
import { BottomTabBar } from "@/components/bottom-tab-bar"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Mock data for chat messages
const chatMessages = [
  {
    id: "1",
    title: "韩国BTS演唱会搭子账单协商群",
    owner: "HYM",
    lastMessage: "HYM 邀请 LYS 加入了账单协商群",
    timestamp: "2026/4/7 14:15:17",
    isOwner: true,
  },
  {
    id: "2",
    title: "挪威旅行沟通群",
    owner: "Luna",
    lastMessage: "LYS 退出了群聊",
    timestamp: "2026/3/20 16:00:05",
    isOwner: false,
  },
  {
    id: "3",
    title: "日本京都赏樱团",
    owner: "小雨",
    lastMessage: "小雨: 大家酒店订好了吗？",
    timestamp: "2026/3/15 10:30:22",
    isOwner: false,
  },
  {
    id: "4",
    title: "泰国清迈深度游",
    owner: "Emma",
    lastMessage: "Emma: 我整理了一份攻略分享给大家",
    timestamp: "2026/3/10 18:45:33",
    isOwner: false,
  },
]

// Mock data for mutual follow users (can be invited to group)
const mutualFollowUsers = [
  { id: "1", name: "WSH", avatar: "" },
  { id: "2", name: "LYS", avatar: "" },
  { id: "3", name: "Luna", avatar: "" },
  { id: "4", name: "guoguoer", avatar: "" },
  { id: "5", name: "小明", avatar: "" },
]

// Mock data for system messages
const systemMessages = [
  {
    id: "1",
    type: "follow",
    user: "LYS",
    content: "关注了你",
    timestamp: "2026/4/7 14:14:38",
  },
  {
    id: "2",
    type: "follow",
    user: "WSH",
    content: "关注了你",
    timestamp: "2026/4/6 14:42:02",
  },
  {
    id: "3",
    type: "like",
    user: "guoguoer",
    content: "赞了你的行程「秘鲁智利13天旅行计划」",
    timestamp: "2026/4/5 09:20:15",
  },
  {
    id: "4",
    type: "comment",
    user: "Luna",
    content: "评论了你的行程「京都和服体验之旅」",
    timestamp: "2026/4/4 16:33:41",
  },
  {
    id: "5",
    type: "join",
    user: "小明",
    content: "申请加入你的行程「首尔美食购物3日游」",
    timestamp: "2026/4/3 11:05:28",
  },
]

export default function MessagesPage() {
  const [activeTab, setActiveTab] = useState<"chat" | "system" | "bills">("chat")
  const [showDropdown, setShowDropdown] = useState(false)
  const [mounted, setMounted] = useState(false)
  const [showCreateGroup, setShowCreateGroup] = useState(false)
  const [groupName, setGroupName] = useState("")
  const [selectedMembers, setSelectedMembers] = useState<string[]>([])
  const dropdownRef = useRef<HTMLDivElement>(null)

  // Ensure client-side only rendering for dropdown
  useEffect(() => {
    setMounted(true)
  }, [])

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  const toggleMemberSelection = (userId: string) => {
    setSelectedMembers(prev => 
      prev.includes(userId) 
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    )
  }

  const handleCreateGroup = () => {
    if (groupName.trim() && selectedMembers.length > 0) {
      // Here you would create the group via API
      console.log("Creating group:", groupName, selectedMembers)
      setShowCreateGroup(false)
      setGroupName("")
      setSelectedMembers([])
    }
  }

  // Mock data for bills
  const myBills = [
    {
      id: "1",
      title: "韩国BTS演唱会搭子账单",
      tripTitle: "韩国BTS演唱会搭子",
      currency: "CNY",
      participants: 3,
      updatedAt: "2026/4/7 00:08:41",
    },
    {
      id: "2",
      title: "秘鲁智利旅行搭子账单",
      tripTitle: "秘鲁智利13天旅行计划",
      currency: "USD",
      participants: 4,
      updatedAt: "2026/3/25 14:30:00",
    },
  ]

  return (
    <div className="min-h-screen relative">
      {/* Background image */}
      <div className="fixed inset-0 -z-10">
        <Image
          src="/images/messages-bg.jpg"
          alt="Background"
          fill
          className="object-cover"
          priority
        />
      </div>

      {/* Content */}
      <div className="min-h-screen pt-6 pb-24 px-4">
        <div className="max-w-lg mx-auto">
          {/* Header card */}
          <div className="bg-background/95 backdrop-blur-sm rounded-2xl shadow-sm overflow-hidden">
            {/* Header */}
            <div className="px-5 py-4 flex items-center justify-between">
              <h1 className="text-xl font-bold text-foreground">消息中心</h1>
              <div className="relative" ref={dropdownRef}>
                <button 
                  onClick={() => setShowDropdown(!showDropdown)}
                  className="p-2 rounded-full hover:bg-muted/50 transition-colors"
                >
                  <Plus className="h-5 w-5 text-foreground" />
                </button>
                
                {/* Dropdown menu */}
                {mounted && showDropdown && (
                  <div className="absolute right-0 top-full mt-2 w-40 bg-background rounded-xl shadow-lg border border-border overflow-hidden z-50">
                    <button
                      className="flex items-center gap-3 w-full px-4 py-3 text-sm text-foreground hover:bg-muted/50 transition-colors"
                      onClick={() => {
                        setShowDropdown(false)
                        setShowCreateGroup(true)
                      }}
                    >
                      <MessageSquarePlus className="h-4 w-4" />
                      <span>创建群聊</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Tabs */}
            <div className="px-5 pb-4">
              <div className="flex gap-2">
                <button
                  onClick={() => setActiveTab("chat")}
                  className={`px-4 py-2 text-sm font-medium rounded-full transition-colors ${
                    activeTab === "chat"
                      ? "bg-foreground text-background"
                      : "bg-muted/50 text-muted-foreground hover:bg-muted"
                  }`}
                >
                  聊天消息
                </button>
                <button
                  onClick={() => setActiveTab("system")}
                  className={`px-4 py-2 text-sm font-medium rounded-full transition-colors ${
                    activeTab === "system"
                      ? "bg-foreground text-background"
                      : "bg-muted/50 text-muted-foreground hover:bg-muted"
                  }`}
                >
                  系统消息
                </button>
                <button
                  onClick={() => setActiveTab("bills")}
                  className={`px-4 py-2 text-sm font-medium rounded-full transition-colors ${
                    activeTab === "bills"
                      ? "bg-foreground text-background"
                      : "bg-muted/50 text-muted-foreground hover:bg-muted"
                  }`}
                >
                  我的账单
                </button>
              </div>
            </div>

            {/* Message List */}
            <div className="divide-y divide-border">
              {activeTab === "chat" ? (
                // Chat messages
                chatMessages.map((message) => (
                  <Link 
                    key={message.id} 
                    href={`/chat/${message.id}`}
                    className="block px-5 py-4 hover:bg-muted/30 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-foreground truncate">
                          {message.title}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-0.5">
                          群主: {message.owner}
                        </p>
                        <p className="text-sm text-muted-foreground mt-1 truncate">
                          {message.lastMessage}
                        </p>
                      </div>
                      <div className="flex flex-col items-end gap-2 shrink-0">
                        <span className="text-xs text-muted-foreground whitespace-nowrap">
                          {message.timestamp}
                        </span>
                        {message.isOwner && (
                          <button 
                            onClick={(e) => e.preventDefault()}
                            className="px-3 py-1 text-xs border border-border rounded-lg hover:bg-muted/50 transition-colors"
                          >
                            删除群聊
                          </button>
                        )}
                      </div>
                    </div>
                  </Link>
                ))
              ) : activeTab === "system" ? (
                // System messages
                systemMessages.map((message) => (
                  <div key={message.id} className="px-5 py-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-muted-foreground">系统提醒</p>
                        <p className="font-medium text-foreground mt-1">
                          <span className="font-semibold">{message.user}</span>{" "}
                          {message.content}
                        </p>
                      </div>
                      <span className="text-xs text-muted-foreground whitespace-nowrap shrink-0">
                        {message.timestamp}
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                // My bills
                myBills.map((bill) => (
                  <div key={bill.id} className="px-5 py-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-foreground">{bill.title}</h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          关联行程: {bill.tripTitle} · 主币种 {bill.currency} · {bill.participants} 人参与
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          更新时间: {bill.updatedAt}
                        </p>
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <Link
                          href={`/bill/${bill.id}`}
                          className="px-3 py-1.5 text-xs bg-foreground text-background rounded-lg hover:bg-foreground/90 transition-colors"
                        >
                          打开账单
                        </Link>
                      </div>
                    </div>
                  </div>
                ))
              )}

              {/* Empty state */}
              {((activeTab === "chat" && chatMessages.length === 0) ||
                (activeTab === "system" && systemMessages.length === 0) ||
                (activeTab === "bills" && myBills.length === 0)) && (
                <div className="px-5 py-12 text-center">
                  <p className="text-muted-foreground">
                    {activeTab === "bills" ? "暂无账单" : "暂无消息"}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom tab bar */}
      <BottomTabBar activeTab="messages" />

      {/* Create group modal */}
      {showCreateGroup && (
        <>
          <div 
            className="fixed inset-0 bg-black/40 z-50"
            onClick={() => setShowCreateGroup(false)}
          />
          <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90%] max-w-md bg-background rounded-2xl shadow-xl z-50 overflow-hidden">
            {/* Modal header */}
            <div className="px-5 py-4 flex items-center justify-between border-b border-border">
              <h2 className="text-lg font-bold text-foreground">选择群聊成员（仅互相关注）</h2>
              <button 
                onClick={() => setShowCreateGroup(false)}
                className="p-1 rounded-full hover:bg-muted/50 transition-colors"
              >
                <X className="h-5 w-5 text-muted-foreground" />
              </button>
            </div>

            {/* Group name input */}
            <div className="px-5 py-4">
              <input
                type="text"
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                placeholder="输入群聊名称"
                className="w-full px-4 py-3 bg-muted/50 rounded-xl text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-border"
              />
            </div>

            {/* User list */}
            <div className="px-5 pb-4 max-h-64 overflow-y-auto">
              <div className="space-y-3">
                {mutualFollowUsers.map((user) => (
                  <button
                    key={user.id}
                    onClick={() => toggleMemberSelection(user.id)}
                    className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-muted/30 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={user.avatar} />
                        <AvatarFallback className="bg-muted">
                          {user.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <span className="font-medium text-foreground">{user.name}</span>
                    </div>
                    <div className={`w-6 h-6 rounded border-2 flex items-center justify-center transition-colors ${
                      selectedMembers.includes(user.id) 
                        ? "bg-primary border-primary" 
                        : "border-border"
                    }`}>
                      {selectedMembers.includes(user.id) && (
                        <Check className="h-4 w-4 text-primary-foreground" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Modal footer */}
            <div className="px-5 py-4 border-t border-border flex items-center justify-between">
              <button
                onClick={() => {
                  setShowCreateGroup(false)
                  setGroupName("")
                  setSelectedMembers([])
                }}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                删除群聊
              </button>
              <button
                onClick={handleCreateGroup}
                disabled={!groupName.trim() || selectedMembers.length === 0}
                className="px-6 py-2.5 bg-foreground text-background rounded-full text-sm font-medium hover:bg-foreground/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                创建群聊
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
