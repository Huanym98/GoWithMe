"use client"

import { useState, useRef, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Users, Send, X, Receipt, UserPlus } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Mock data for chat messages
const chatData = {
  id: "1",
  name: "挪威旅行沟通群",
  members: [
    { id: "1", name: "98年的小可乐", avatar: "", role: "群主" },
    { id: "2", name: "HYM", avatar: "", role: "成员" },
    { id: "3", name: "WSH", avatar: "", role: "成员" },
    { id: "4", name: "LYS", avatar: "", role: "成员" },
  ],
  messages: [
    {
      id: "1",
      type: "system",
      content: "98年的小可乐 创建了群聊，并邀请 HYM、WSH 加入",
      timestamp: "2026/3/20 15:55:00",
    },
    {
      id: "2",
      type: "message",
      userId: "1",
      userName: "98年的小可乐",
      userAvatar: "",
      content: "Hello 今年想去看极光，你们有兴趣么?",
      timestamp: "2026/3/20 15:58:39",
      isMine: false,
    },
    {
      id: "3",
      type: "system",
      content: "98年的小可乐 邀请 LYS 加入了群聊",
      timestamp: "2026/3/20 15:59:00",
    },
    {
      id: "4",
      type: "message",
      userId: "4",
      userName: "LYS",
      userAvatar: "",
      content: "我今年没空",
      timestamp: "2026/3/20 16:00:02",
      isMine: true,
    },
    {
      id: "5",
      type: "system",
      content: "LYS 退出了群聊",
      timestamp: "2026/3/20 16:01:00",
    },
  ],
}

const inviteList = [
  { id: "5", name: "Luna", avatar: "" },
  { id: "6", name: "小明", avatar: "" },
  { id: "7", name: "guoguoer", avatar: "" },
]

export default function ChatDetailPage() {
  const [message, setMessage] = useState("")
  const [showMemberPanel, setShowMemberPanel] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [])

  const handleSend = () => {
    if (message.trim()) {
      // Handle send message
      setMessage("")
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  return (
    <div className="min-h-screen relative">
      {/* Background image */}
      <div className="fixed inset-0 -z-10">
        <Image
          src="/images/messages-bg.jpg"
          alt="Background"
          fill
          className="object-cover"
          priority
        />
      </div>

      {/* Content */}
      <div className="min-h-screen pt-6 pb-6 px-4">
        <div className="max-w-3xl mx-auto">
          {/* Chat card */}
          <div className="bg-background/95 backdrop-blur-sm rounded-2xl shadow-sm overflow-hidden flex flex-col" style={{ minHeight: "calc(100vh - 48px)" }}>
            {/* Header */}
            <div className="px-4 py-4 border-b border-border">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <Link href="/messages" className="p-1.5 rounded-full hover:bg-muted/50 transition-colors">
                    <ArrowLeft className="h-5 w-5 text-foreground" />
                  </Link>
                  <h1 className="text-lg font-bold text-foreground">{chatData.name}</h1>
                </div>
              </div>
              {/* Action buttons */}
              <div className="flex items-center gap-2 flex-wrap">
                <Link
                  href="/bill/1"
                  className="px-3 py-1.5 text-sm border border-border rounded-lg hover:bg-muted/50 transition-colors flex items-center gap-1.5"
                >
                  <Receipt className="h-4 w-4" />
                  账单
                </Link>
                <button 
                  onClick={() => setShowMemberPanel(true)}
                  className="px-3 py-1.5 text-sm border border-border rounded-lg hover:bg-muted/50 transition-colors flex items-center gap-1.5"
                >
                  <Users className="h-4 w-4" />
                  群成员
                </button>
                <button 
                  onClick={() => setShowMemberPanel(true)}
                  className="px-3 py-1.5 text-sm border border-border rounded-lg hover:bg-muted/50 transition-colors flex items-center gap-1.5"
                >
                  <UserPlus className="h-4 w-4" />
                  +邀请成员
                </button>
              </div>
            </div>

            {/* Messages area */}
            <div className="flex-1 overflow-y-auto px-4 py-4">
              <div className="space-y-4">
                {chatData.messages.map((msg) => {
                  if (msg.type === "system") {
                    return (
                      <div key={msg.id} className="flex justify-center">
                        <span className="px-3 py-1.5 bg-muted/50 rounded-full text-xs text-muted-foreground">
                          {msg.content}
                        </span>
                      </div>
                    )
                  }

                  const isMe = msg.isMine

                  return (
                    <div
                      key={msg.id}
                      className={`flex gap-3 ${isMe ? "flex-row" : "flex-row-reverse"}`}
                    >
                      <div className={`max-w-[70%] ${isMe ? "" : "text-right"}`}>
                        <div className={`inline-block bg-card border border-border rounded-2xl px-4 py-3 ${isMe ? "rounded-tl-sm" : "rounded-tr-sm"}`}>
                          <div className="flex items-center gap-2 mb-1">
                            <Avatar className="h-6 w-6">
                              <AvatarImage src={msg.userAvatar} />
                              <AvatarFallback className="text-xs bg-muted">
                                {msg.userName?.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                            <span className="text-sm font-medium text-foreground">{msg.userName}</span>
                          </div>
                          <p className="text-sm text-foreground">{msg.content}</p>
                          <p className="text-xs text-muted-foreground mt-1">{msg.timestamp}</p>
                        </div>
                      </div>
                    </div>
                  )
                })}
                <div ref={messagesEndRef} />
              </div>
            </div>

            {/* Input area */}
            <div className="px-4 py-3 border-t border-border">
              <div className="flex items-center gap-3">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="输入消息，回车发送"
                  className="flex-1 h-10 px-4 bg-muted/50 rounded-xl text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-border"
                />
                <button
                  onClick={handleSend}
                  className="px-4 py-2 bg-foreground text-background rounded-lg text-sm font-medium hover:bg-foreground/90 transition-colors"
                >
                  发送
                </button>
                <Link
                  href="/messages"
                  className="px-4 py-2 border border-border rounded-lg text-sm font-medium hover:bg-muted/50 transition-colors"
                >
                  返回首页
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Member panel overlay */}
      {showMemberPanel && (
        <div 
          className="fixed inset-0 bg-black/20 z-40"
          onClick={() => setShowMemberPanel(false)}
        />
      )}

      {/* Member panel */}
      <div className={`fixed top-0 right-0 h-full w-72 bg-background shadow-xl z-50 transform transition-transform duration-300 ${showMemberPanel ? "translate-x-0" : "translate-x-full"}`}>
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h2 className="font-semibold text-foreground">{chatData.name} · 邀请成员</h2>
          <button 
            onClick={() => setShowMemberPanel(false)}
            className="p-1 rounded-full hover:bg-muted/50 transition-colors"
          >
            <X className="h-4 w-4 text-muted-foreground" />
          </button>
        </div>

        {/* Current members */}
        <div className="p-4">
          <h3 className="text-sm text-muted-foreground mb-3">群成员 ({chatData.members.length})</h3>
          <div className="space-y-3">
            {chatData.members.map((member) => (
              <div key={member.id} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={member.avatar} />
                    <AvatarFallback className="bg-muted text-sm">
                      {member.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium text-foreground">{member.name}</p>
                    <p className="text-xs text-muted-foreground">{member.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Invite list */}
        <div className="p-4 border-t border-border">
          <h3 className="text-sm text-muted-foreground mb-3">邀请好友</h3>
          <div className="space-y-3">
            {inviteList.map((user) => (
              <div key={user.id} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={user.avatar} />
                    <AvatarFallback className="bg-muted text-sm">
                      {user.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-sm font-medium text-foreground">{user.name}</span>
                </div>
                <button className="px-3 py-1 text-xs border border-border rounded-lg hover:bg-muted/50 transition-colors">
                  邀请
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Action buttons */}
        <div className="p-4 border-t border-border mt-auto">
          <div className="space-y-3">
            <button 
              onClick={() => {
                if (confirm("确定要删除并退出该群聊吗？")) {
                  window.location.href = "/messages"
                }
              }}
              className="w-full py-3 text-red-500 border border-red-200 rounded-xl text-sm font-medium hover:bg-red-50 transition-colors"
            >
              删除并退出
            </button>
            <button 
              onClick={() => {
                if (confirm("确定要解散该群聊吗？此操作不可恢复。")) {
                  window.location.href = "/messages"
                }
              }}
              className="w-full py-3 bg-red-500 text-white rounded-xl text-sm font-medium hover:bg-red-600 transition-colors"
            >
              解散群聊
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
