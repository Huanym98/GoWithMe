"use client"

import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, RefreshCw } from "lucide-react"
import { BottomTabBar } from "@/components/bottom-tab-bar"

// Mock data for user's bills
const myBills = [
  {
    id: "1",
    title: "韩国BTS演唱会搭子账单",
    tripTitle: "韩国BTS演唱会搭子",
    currency: "CNY",
    participants: 3,
    updatedAt: "2026/4/7 00:08:41",
    chatId: "1",
  },
  {
    id: "2",
    title: "秘鲁智利旅行搭子账单",
    tripTitle: "秘鲁智利13天旅行",
    currency: "USD",
    participants: 4,
    updatedAt: "2026/4/5 14:22:15",
    chatId: "2",
  },
  {
    id: "3",
    title: "日本京都赏樱账单",
    tripTitle: "日本京都赏樱团",
    currency: "JPY",
    participants: 5,
    updatedAt: "2026/3/28 09:15:33",
    chatId: "3",
  },
]

export default function MyBillsPage() {
  return (
    <div className="min-h-screen relative">
      {/* Background image */}
      <div className="fixed inset-0 -z-10">
        <Image
          src="/images/messages-bg.jpg"
          alt="Background"
          fill
          className="object-cover"
          priority
        />
      </div>

      {/* Content */}
      <div className="min-h-screen pt-6 pb-24 px-4">
        <div className="max-w-lg mx-auto">
          {/* Header card */}
          <div className="bg-background/95 backdrop-blur-sm rounded-2xl shadow-sm overflow-hidden">
            {/* Header */}
            <div className="px-5 py-4 flex items-center justify-between border-b border-border">
              <div className="flex items-center gap-3">
                <Link href="/messages" className="p-1 -ml-1">
                  <ArrowLeft className="h-5 w-5 text-foreground" />
                </Link>
                <h1 className="text-xl font-bold text-foreground">我的账单</h1>
              </div>
              <button className="px-3 py-1.5 text-sm border border-border rounded-lg hover:bg-muted/50 transition-colors flex items-center gap-1.5">
                <RefreshCw className="h-4 w-4" />
                刷新
              </button>
            </div>

            {/* Description */}
            <div className="px-5 py-3 bg-muted/30">
              <p className="text-sm text-muted-foreground">快速查看我发起或参与的账单</p>
            </div>

            {/* Bills list */}
            <div className="divide-y divide-border">
              {myBills.map((bill) => (
                <div key={bill.id} className="px-5 py-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-foreground">{bill.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        关联行程: {bill.tripTitle} · 主币种 {bill.currency} · {bill.participants} 人参与
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        更新时间: {bill.updatedAt}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Link 
                        href={`/bill/${bill.id}`}
                        className="px-3 py-1.5 text-sm border border-border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        打开账单
                      </Link>
                      <Link 
                        href={`/chat/${bill.chatId}`}
                        className="px-3 py-1.5 text-sm border border-border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        去群聊
                      </Link>
                    </div>
                  </div>
                </div>
              ))}

              {myBills.length === 0 && (
                <div className="px-5 py-12 text-center">
                  <p className="text-muted-foreground">暂无账单</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    发起或加入行程账单后将在这里显示
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom tab bar */}
      <BottomTabBar activeTab="messages" />
    </div>
  )
}
