"use client"

import { ChevronLeft } from "lucide-react"
import Link from "next/link"

export default function ChildProtectionPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-border z-10">
        <div className="flex items-center h-14 px-4">
          <Link href="/login" className="p-2 -ml-2">
            <ChevronLeft className="h-6 w-6" />
          </Link>
          <h1 className="flex-1 text-center font-medium pr-8">儿童/青少年个人信息保护规则</h1>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-6">
        <Link href="#" className="text-primary text-sm">English Version</Link>
        
        <h2 className="text-xl font-bold text-center my-8">歌觅未成年人个人信息保护规则</h2>
        
        <p className="text-sm text-muted-foreground mb-6">更新日期：2026年4月1日</p>
        
        <p className="text-sm leading-relaxed mb-4">
          我们重视未成年人（在中国指未满十八周岁的人士，其他国家地区从其法律）和儿童（在中国指未满十四周岁的人士，其他国家地区从其法律）的个人信息安全和隐私保护。在
          <Link href="/privacy" className="text-primary">《歌觅用户隐私政策》</Link>
          的基础上，我们通过《歌觅未成年人个人信息保护规则》（以下简称"本政策"）说明我们在收集和使用儿童/未成年人（以下可统称为"未成年人"）个人信息时对应的处理规则和相关事宜。当本政策与《歌觅用户隐私政策》正文存在不一致的，本政策将优先适用。本政策未载明之处，则参照适用《歌觅用户隐私政策》。通过线上界面点击同意本政策，您及您的监护人表示同意我们按照本政策提供歌觅平台和歌觅平台服务，并处理个人信息。
        </p>
        
        <p className="text-sm leading-relaxed mb-6">
          "用户"、"您"、"您的"、"我们"、"我们的"、"歌觅平台"、"歌觅平台服务"、"账号"具有
          <Link href="/agreement" className="text-primary">《歌觅用户服务协议》</Link>
          中所定义之含义。
        </p>

        <h3 className="font-bold mb-4">监护人特别说明：</h3>
        
        <p className="text-sm leading-relaxed mb-6">
          为了维护您孩子的合法权益，我们希望您可以确保您的孩子在您的同意和指导下使用歌觅平台和歌觅平台服务并向我们提交个人信息，如适用法律允许。为了向您告知未成年人个人信息处理规则并征得您的同意，您同意我们可能向您的孩子收集您的联系信息。我们不会将您的联系信息用于除前述以外的任何目的，如在向您通知后的合理时间内未征得您的同意，我们将立即删除您的联系信息。我们将根据本政策采取特殊措施保护相关信息。如果您不同意本政策的内容，请您要求您的孩子立即停止访问/使用歌觅平台和歌觅平台服务。
        </p>

        <h3 className="font-bold mb-4">未成年人特别说明：</h3>
        
        <p className="text-sm leading-relaxed mb-6">
          如果您是未成年人，请通知您的监护人共同阅读本政策，并在您使用歌觅平台或歌觅平台服务、提交个人信息之前，寻求您的监护人的指导。若您未满足使用我们的歌觅平台和歌觅平台服务的法定年龄要求，或您对前述法定年龄要求有疑问，请与您监护人讨论并在获其明确同意后再使用歌觅平台和歌觅平台服务、提交个人信息。
        </p>

        <h3 className="font-bold mb-4">一、我们如何收集和使用未成年人的个人信息</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          1.1 我们会严格履行法律法规规定的未成年人个人信息保护义务，在取得监护人同意或在法律允许的范围内收集、使用未成年人的个人信息。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          1.2 如我们发现在未事先获得可证实的监护人同意的情况下收集了未成年人的个人信息，则会设法尽快删除相关数据。
        </p>

        <h3 className="font-bold mb-4">二、我们如何存储和保护未成年人的个人信息</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          2.1 我们会采取加密等技术措施存储未成年人个人信息，确保信息安全。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          2.2 我们会制定严格的未成年人信息访问权限管理制度和技术措施。只有为了履行职责所必需的工作人员才能访问未成年人个人信息，并且访问记录会被详细记录。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          2.3 我们会对存储未成年人个人信息的系统进行定期安全评估和审计，及时发现并处理潜在的安全风险。
        </p>

        <h3 className="font-bold mb-4">三、未成年人及其监护人的权利</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          3.1 监护人有权了解我们收集、存储、使用其被监护人的个人信息的情况。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          3.2 监护人有权要求我们更正或补充不准确或不完整的未成年人个人信息。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          3.3 监护人有权要求我们删除未成年人的个人信息，我们将在收到请求后的合理时间内处理。
        </p>

        <h3 className="font-bold mb-4">四、联系我们</h3>
        
        <p className="text-sm leading-relaxed mb-8">
          如您对本政策或相关事宜有任何问题或需要行使相关权利，您可以通过歌觅平台的在线客服或者发送邮件至 children@gomi.com 与我们联系。我们将在收到请求后的十五个工作日内回复您的请求。
        </p>
      </div>
    </div>
  )
}
