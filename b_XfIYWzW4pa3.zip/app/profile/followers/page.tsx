"use client"

import { useState } from "react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { ChevronLeft, Search, Settings, MoreHorizontal } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Mock data
const mockUsers = {
  mutual: [
    { id: "1", name: "偏爱自由", avatar: "", desc: "", isMutual: true },
    { id: "2", name: "Aik", avatar: "", desc: "", isMutual: true },
    { id: "3", name: "Dream", avatar: "", desc: "今天在线", isMutual: true },
    { id: "4", name: "Luna", avatar: "", desc: "旅行达人", isMutual: true },
  ],
  following: [
    { id: "1", name: "偏爱自由", avatar: "", desc: "", isMutual: true },
    { id: "2", name: "Aik", avatar: "", desc: "", isMutual: true },
    { id: "3", name: "Dream", avatar: "", desc: "今天在线", isMutual: true },
    { id: "4", name: "旅行摄影师", avatar: "", desc: "专业旅拍", isMutual: false },
    { id: "5", name: "美食探店", avatar: "", desc: "吃遍全球", isMutual: false },
  ],
  followers: [
    { id: "1", name: "mmh洪", avatar: "", desc: "可能认识的人", isMutual: false },
    { id: "2", name: "~开心每一天~", avatar: "", desc: "可能认识的人", isMutual: false },
    { id: "3", name: "偏爱自由", avatar: "", desc: "", isMutual: true },
    { id: "4", name: "上海奉贤金山驾校", avatar: "", desc: "", isMutual: false },
    { id: "5", name: "上海驾校金教练", avatar: "", desc: "精心施教 诚信为本", isMutual: false },
    { id: "6", name: "Aik", avatar: "", desc: "", isMutual: true },
    { id: "7", name: "2046309717", avatar: "", desc: "", isMutual: false },
    { id: "8", name: "Dream", avatar: "", desc: "今天在线", isMutual: true },
    { id: "9", name: "平哥", avatar: "", desc: "", isMutual: false },
  ],
}

const tabs = [
  { id: "mutual", label: "互关" },
  { id: "following", label: "关注" },
  { id: "followers", label: "粉丝" },
]

export default function FollowersPage() {
  const searchParams = useSearchParams()
  const initialTab = searchParams.get("tab") || "followers"
  const [activeTab, setActiveTab] = useState<string>(initialTab)
  const [searchQuery, setSearchQuery] = useState("")

  const currentUsers = mockUsers[activeTab as keyof typeof mockUsers] || []
  const filteredUsers = currentUsers.filter(user => 
    user.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const getCount = (tab: string) => {
    return mockUsers[tab as keyof typeof mockUsers]?.length || 0
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 bg-background border-b border-border z-10">
        <div className="flex items-center justify-between px-4 py-3">
          <Link href="/profile" className="p-1">
            <ChevronLeft className="h-6 w-6" />
          </Link>
          <div className="flex gap-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`text-base font-medium pb-2 border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? "text-foreground border-foreground"
                    : "text-muted-foreground border-transparent"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
          <button className="p-1">
            <Settings className="h-5 w-5 text-muted-foreground" />
          </button>
        </div>
      </header>

      {/* Search bar */}
      <div className="px-4 py-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="搜索用户备注或名字"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-10 pl-10 pr-4 bg-muted/50 rounded-lg text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-border"
          />
        </div>
      </div>

      {/* List header */}
      <div className="px-4 py-2">
        <p className="text-sm text-muted-foreground">
          {activeTab === "mutual" && `互相关注 (${getCount("mutual")} 人)`}
          {activeTab === "following" && `我的关注 (${getCount("following")} 人)`}
          {activeTab === "followers" && `我的粉丝 (${getCount("followers")} 人)`}
        </p>
      </div>

      {/* User list */}
      <div className="divide-y divide-border">
        {filteredUsers.map((user) => (
          <div key={user.id} className="flex items-center gap-3 px-4 py-3">
            <Avatar className="h-12 w-12">
              <AvatarImage src={user.avatar} />
              <AvatarFallback className="bg-muted text-muted-foreground">
                {user.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-foreground truncate">{user.name}</h3>
              {user.desc && (
                <p className="text-sm text-muted-foreground truncate">{user.desc}</p>
              )}
            </div>
            <div className="flex items-center gap-2">
              {user.isMutual ? (
                <button className="px-4 py-1.5 text-sm border border-border rounded-lg hover:bg-muted/50 transition-colors">
                  互相关注
                </button>
              ) : (
                <button className="px-4 py-1.5 text-sm bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors">
                  回关
                </button>
              )}
              <button className="p-1">
                <MoreHorizontal className="h-5 w-5 text-muted-foreground" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Empty state */}
      {filteredUsers.length === 0 && (
        <div className="px-4 py-12 text-center">
          <p className="text-muted-foreground">暂无数据</p>
        </div>
      )}
    </div>
  )
}
