"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { 
  Menu, 
  X, 
  Settings, 
  Shield,
  Trash2,
  SwitchCamera,
  ChevronRight,
  MapPin,
  Search,
  Trophy,
  LogOut
} from "lucide-react"
import { useRouter } from "next/navigation"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { BottomTabBar } from "@/components/bottom-tab-bar"

// User profile data
const userData = {
  name: "旅行者小鱼",
  avatar: "",
  bio: "热爱旅行，喜欢探索世界各地的美食和风景",
  location: "上海",
  age: 28,
  gender: "女",
  stats: {
    likes: 128,
    mutual: 32,
    following: 156,
    followers: 89
  },
  travelStyle: "平衡",
  budget: "舒适",
  schedule: "自然醒"
}

// City trophies data
const cityTrophies = [
  {
    id: "hangzhou",
    name: "杭州",
    total: 36,
    obtained: 12,
    trophies: {
      diamond: 0,
      gold: 2,
      silver: 4,
      bronze: 6
    }
  },
  {
    id: "tokyo",
    name: "东京",
    total: 42,
    obtained: 8,
    trophies: {
      diamond: 0,
      gold: 1,
      silver: 2,
      bronze: 5
    }
  }
]

// Trophy summary
const trophySummary = {
  diamond: 0,
  gold: 3,
  silver: 6,
  bronze: 11,
  total: 20
}

// Menu items for drawer
const menuItems = [
  { icon: Shield, label: "隐私设置", href: "#" },
  { icon: Trash2, label: "清理缓存", href: "#" },
  { icon: SwitchCamera, label: "切换账号", href: "#" },
  { divider: true },
  { icon: LogOut, label: "退出登录", href: "/login", isLogout: true },
]

// Content tabs
const contentTabs = ["行程", "日记", "喜欢", "成就"]

// Trophy icon component
function TrophyIcon({ type, size = "md" }: { type: "diamond" | "gold" | "silver" | "bronze", size?: "sm" | "md" | "lg" }) {
  const colors = {
    diamond: "text-cyan-400",
    gold: "text-amber-500",
    silver: "text-gray-400",
    bronze: "text-orange-600"
  }
  
  const sizes = {
    sm: "h-4 w-4",
    md: "h-6 w-6",
    lg: "h-8 w-8"
  }
  
  return <Trophy className={`${sizes[size]} ${colors[type]}`} />
}

export default function ProfilePage() {
  const router = useRouter()
  const [showDrawer, setShowDrawer] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [activeTab, setActiveTab] = useState("行程")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  // Prevent body scroll when drawer is open
  useEffect(() => {
    if (showDrawer || showEditModal) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'unset'
    }
    return () => {
      document.body.style.overflow = 'unset'
    }
  }, [showDrawer, showEditModal])

  const completionRate = Math.round((trophySummary.total / 78) * 100)

  return (
    <div className="min-h-screen bg-background">
      {/* Header with cover image */}
      <div className="relative h-48">
        <Image
          src="/images/profile-cover.jpg"
          alt="Cover"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 to-transparent" />
        
        {/* Header actions */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-end">
          <div className="flex items-center gap-3">
            <Link href="/search" className="p-2 rounded-full bg-white/20 backdrop-blur-sm">
              <Search className="h-5 w-5 text-white" />
            </Link>
            <button 
              onClick={() => setShowDrawer(true)}
              className="p-2 rounded-full bg-white/20 backdrop-blur-sm"
            >
              <Menu className="h-5 w-5 text-white" />
            </button>
          </div>
        </div>

        {/* Avatar */}
        <div className="absolute -bottom-12 left-6">
          <Avatar className="h-24 w-24 border-4 border-background">
            <AvatarImage src={userData.avatar} />
            <AvatarFallback className="text-2xl bg-primary/10 text-primary">
              {userData.name.slice(0, 1)}
            </AvatarFallback>
          </Avatar>
        </div>
      </div>

      {/* Profile info */}
      <div className="pt-14 px-5">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h1 className="text-xl font-bold text-foreground">{userData.name}</h1>
            <p className="text-sm text-muted-foreground mt-1">ID: 12345678</p>
          </div>
          <button 
            onClick={() => setShowEditModal(true)}
            className="px-4 py-2 bg-muted rounded-full text-sm font-medium"
          >
            编辑主页
          </button>
        </div>

        {/* Stats */}
        <div className="flex gap-6 mb-4">
          <div className="text-center">
            <p className="font-bold text-foreground">{userData.stats.likes}</p>
            <p className="text-xs text-muted-foreground">获赞</p>
          </div>
          <Link href="/profile/followers?tab=mutual" className="text-center hover:opacity-70 transition-opacity">
            <p className="font-bold text-foreground">{userData.stats.mutual}</p>
            <p className="text-xs text-muted-foreground">互关</p>
          </Link>
          <Link href="/profile/followers?tab=following" className="text-center hover:opacity-70 transition-opacity">
            <p className="font-bold text-foreground">{userData.stats.following}</p>
            <p className="text-xs text-muted-foreground">关注</p>
          </Link>
          <Link href="/profile/followers?tab=followers" className="text-center hover:opacity-70 transition-opacity">
            <p className="font-bold text-foreground">{userData.stats.followers}</p>
            <p className="text-xs text-muted-foreground">粉丝</p>
          </Link>
        </div>

        {/* Bio */}
        <p className="text-sm text-foreground mb-2">{userData.bio}</p>
        <div className="flex gap-2 flex-wrap mb-6">
          <span className={`px-2 py-1 rounded text-xs flex items-center gap-1 ${
            userData.gender === "女" 
              ? "bg-pink-100 text-pink-600" 
              : userData.gender === "男" 
                ? "bg-blue-100 text-blue-600" 
                : "bg-muted text-muted-foreground"
          }`}>
            {userData.gender === "女" ? "♀" : userData.gender === "男" ? "♂" : "⚧"} · {userData.age}岁
          </span>
          <span className="px-2 py-1 bg-muted rounded text-xs text-muted-foreground flex items-center gap-1">
            <MapPin className="h-3 w-3" />
            {userData.location}
          </span>
        </div>

        {/* Content tabs */}
        <div className="flex border-b border-border">
          {contentTabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-3 text-sm font-medium transition-colors relative ${
                activeTab === tab 
                  ? "text-foreground" 
                  : "text-muted-foreground"
              }`}
            >
              {tab}
              {activeTab === tab && (
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-6 h-0.5 bg-foreground rounded-full" />
              )}
            </button>
          ))}
        </div>

        {/* Content area */}
        <div className="py-8 pb-32">
          {activeTab === "成就" ? (
            <div className="space-y-4">
              {/* Trophy summary */}
              <div className="bg-amber-50/50 rounded-2xl p-4">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-xs text-amber-600 mb-1">城市成就</p>
                    <h3 className="font-bold text-foreground">城市奖杯</h3>
                  </div>
                  <div className="flex items-center gap-4 bg-white rounded-xl px-4 py-2">
                    <div className="flex flex-col items-center">
                      <TrophyIcon type="diamond" size="sm" />
                      <span className="text-xs mt-1">{trophySummary.diamond}</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <TrophyIcon type="gold" size="sm" />
                      <span className="text-xs mt-1">{trophySummary.gold}</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <TrophyIcon type="silver" size="sm" />
                      <span className="text-xs mt-1">{trophySummary.silver}</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <TrophyIcon type="bronze" size="sm" />
                      <span className="text-xs mt-1">{trophySummary.bronze}</span>
                    </div>
                  </div>
                </div>

                {/* City trophy cards */}
                {cityTrophies.map((city) => (
                  <Link
                    key={city.id}
                    href={`/profile/trophies/${city.id}`}
                    className="block bg-white rounded-xl p-4 mb-3 last:mb-0"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-foreground">{city.name}</h4>
                      <span className="text-sm text-muted-foreground">{city.obtained} / {city.total}</span>
                    </div>
                    <div className="flex items-center gap-4 mb-3">
                      <div className="flex items-center gap-1">
                        <TrophyIcon type="diamond" size="sm" />
                        <span className="text-sm">{city.trophies.diamond}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <TrophyIcon type="gold" size="sm" />
                        <span className="text-sm">{city.trophies.gold}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <TrophyIcon type="silver" size="sm" />
                        <span className="text-sm">{city.trophies.silver}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <TrophyIcon type="bronze" size="sm" />
                        <span className="text-sm">{city.trophies.bronze}</span>
                      </div>
                    </div>
                    <p className="text-xs text-primary">查看该城市奖杯详情</p>
                  </Link>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground text-sm">暂无内容</p>
            </div>
          )}
        </div>
      </div>

      {/* Bottom tab bar */}
      <BottomTabBar activeTab="profile" />

      {/* Drawer overlay */}
      {mounted && showDrawer && (
        <div 
          className="fixed inset-0 bg-black/50 z-50"
          onClick={() => setShowDrawer(false)}
        >
          {/* Drawer panel */}
          <div 
            className="absolute top-0 right-0 bottom-0 w-72 bg-background shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Drawer header */}
            <div className="flex items-center justify-end px-4 py-4 border-b border-border">
              <button 
                onClick={() => setShowDrawer(false)}
                className="p-1"
              >
                <X className="h-5 w-5 text-muted-foreground" />
              </button>
            </div>

            {/* Drawer content */}
            <div className="overflow-y-auto h-[calc(100%-60px)]">
              {menuItems.map((item, index) => (
                item.divider ? (
                  <div key={index} className="h-2 bg-muted/30" />
                ) : (
                  <button
                    key={item.label}
                    onClick={() => {
                      if (item.isLogout) {
                        router.push("/login")
                      }
                    }}
                    className={`flex items-center justify-between w-full px-4 py-3.5 hover:bg-muted/30 transition-colors ${
                      item.isLogout ? "text-red-500" : ""
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {item.icon && <item.icon className={`h-5 w-5 ${item.isLogout ? "text-red-500" : "text-foreground"}`} />}
                      <span className={`text-sm ${item.isLogout ? "text-red-500" : "text-foreground"}`}>{item.label}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {item.value && (
                        <span className="text-sm text-muted-foreground">{item.value}</span>
                      )}
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </button>
                )
              ))}

              {/* More features button */}
              <div className="p-4 mt-4">
                <button className="w-full py-3 bg-muted/50 rounded-xl text-sm text-foreground flex items-center justify-center gap-2">
                  <Settings className="h-4 w-4" />
                  更多功能
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit profile modal */}
      {mounted && showEditModal && (
        <div 
          className="fixed inset-0 bg-black/50 z-50 flex items-end justify-center"
          onClick={() => setShowEditModal(false)}
        >
          <div 
            className="w-full max-w-lg bg-background rounded-t-2xl max-h-[85vh] overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <h2 className="text-lg font-bold">个人资料</h2>
              <button 
                onClick={() => setShowEditModal(false)}
                className="px-3 py-1 text-sm text-muted-foreground hover:text-foreground"
              >
                关闭
              </button>
            </div>

            {/* Modal content */}
            <div className="p-5 overflow-y-auto max-h-[calc(85vh-140px)]">
              {/* Avatar section */}
              <div className="mb-6">
                <label className="block text-sm font-medium mb-3">头像</label>
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={userData.avatar} />
                    <AvatarFallback className="text-xl bg-primary/10 text-primary">
                      {userData.name.slice(0, 1)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex gap-2">
                    <button className="px-4 py-2 bg-muted rounded-lg text-sm">
                      选择文件
                    </button>
                    <span className="text-sm text-muted-foreground self-center">
                      未选��任何文件
                    </span>
                  </div>
                </div>
              </div>

              {/* Bio */}
              <div className="mb-6">
                <label className="block text-sm font-medium mb-2">个人简介 / 介绍</label>
                <textarea
                  className="w-full h-24 px-3 py-2 bg-muted/50 rounded-xl text-sm resize-none focus:outline-none focus:ring-1 focus:ring-border"
                  placeholder="介绍一下你自己、旅行偏好、想找什么样的搭子（可输入较长文本）"
                  defaultValue={userData.bio}
                />
              </div>

              {/* Birthday & Gender */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium mb-2">生日（年月）</label>
                  <div className="relative">
                    <input
                      type="month"
                      className="w-full px-3 py-2.5 bg-muted/50 rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-border"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">性别</label>
                  <select className="w-full px-3 py-2.5 bg-muted/50 rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-border appearance-none">
                    <option>请选择</option>
                    <option>男</option>
                    <option>女</option>
                    <option>其他</option>
                  </select>
                </div>
              </div>

              {/* Travel style & Budget */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-medium mb-2">旅行节奏</label>
                  <select className="w-full px-3 py-2.5 bg-muted/50 rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-border appearance-none">
                    <option>平衡</option>
                    <option>紧凑</option>
                    <option>悠闲</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">预算偏好</label>
                  <select className="w-full px-3 py-2.5 bg-muted/50 rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-border appearance-none">
                    <option>舒适</option>
                    <option>经济</option>
                    <option>豪华</option>
                  </select>
                </div>
              </div>

              {/* Schedule */}
              <div className="mb-6">
                <label className="block text-sm font-medium mb-2">作息</label>
                <select className="w-1/2 px-3 py-2.5 bg-muted/50 rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-border appearance-none">
                  <option>自然醒</option>
                  <option>早起</option>
                  <option>夜猫子</option>
                </select>
              </div>

              {/* Account security link */}
              <div className="flex justify-end mb-4">
                <button className="text-sm text-muted-foreground hover:text-foreground">
                  前往账号与安全
                </button>
              </div>
            </div>

            {/* Save button */}
            <div className="px-5 py-4 border-t border-border">
              <button 
                onClick={() => setShowEditModal(false)}
                className="w-full py-3 bg-foreground text-background rounded-xl font-medium"
              >
                保存资料
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
