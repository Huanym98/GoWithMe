"use client"

import { use } from "react"
import Link from "next/link"
import { ArrowLeft, Trophy } from "lucide-react"

// Trophy data for cities
const cityTrophyData: Record<string, {
  name: string
  total: number
  obtained: number
  trophies: {
    diamond: { count: number; available: number }
    gold: { count: number; available: number }
    silver: { count: number; available: number }
    bronze: { count: number; available: number }
  }
  achievements: Array<{
    id: string
    name: string
    description: string
    type: "diamond" | "gold" | "silver" | "bronze"
    category: string
    obtained: boolean
    obtainedAt?: string
  }>
}> = {
  hangzhou: {
    name: "杭州",
    total: 36,
    obtained: 12,
    trophies: {
      diamond: { count: 0, available: 2 },
      gold: { count: 2, available: 11 },
      silver: { count: 4, available: 17 },
      bronze: { count: 6, available: 6 }
    },
    achievements: [
      {
        id: "1",
        name: "初见西湖",
        description: "每个杭州故事，都该从西湖开始。",
        type: "bronze",
        category: "地标",
        obtained: true,
        obtainedAt: "2024/3/15"
      },
      {
        id: "2",
        name: "断桥留影",
        description: "来过断桥，才算真正按下杭州的开始键。",
        type: "bronze",
        category: "地标",
        obtained: true,
        obtainedAt: "2024/3/15"
      },
      {
        id: "3",
        name: "雷峰夕照",
        description: "在黄昏里，看一眼杭州最经典的天色。",
        type: "silver",
        category: "时间",
        obtained: false
      },
      {
        id: "4",
        name: "南宋夜行",
        description: "夜色一落下，老杭州就开始说话了。",
        type: "silver",
        category: "时间",
        obtained: false
      },
      {
        id: "5",
        name: "运河夜色",
        description: "换一片水面，看到另一种杭州。",
        type: "silver",
        category: "时间",
        obtained: false
      },
      {
        id: "6",
        name: "钱江新城观灯",
        description: "现代杭州的夜晚，也值得专程去一次。",
        type: "silver",
        category: "时间",
        obtained: false
      },
      {
        id: "7",
        name: "城市双面",
        description: "一天之内，看见杭州的两种性格。",
        type: "gold",
        category: "组合",
        obtained: true,
        obtainedAt: "2024/3/16"
      },
      {
        id: "8",
        name: "白堤慢行",
        description: "慢一点，杭州的美才会出现。",
        type: "silver",
        category: "路线",
        obtained: true,
        obtainedAt: "2024/3/15"
      },
      {
        id: "9",
        name: "西湖醋鱼品鉴",
        description: "杭帮菜的第一课，从这道菜开始。",
        type: "bronze",
        category: "美食",
        obtained: true,
        obtainedAt: "2024/3/15"
      },
      {
        id: "10",
        name: "龙井问茶",
        description: "在龙井村喝一杯正宗的明前龙井。",
        type: "gold",
        category: "体验",
        obtained: true,
        obtainedAt: "2024/3/16"
      },
      {
        id: "11",
        name: "杭州白金玩家",
        description: "解锁杭州所有成就，成为杭州白金玩家。",
        type: "diamond",
        category: "终极",
        obtained: false
      },
      {
        id: "12",
        name: "东坡肉传承",
        description: "品尝正宗东坡肉，感受千年美食文化。",
        type: "bronze",
        category: "美食",
        obtained: true,
        obtainedAt: "2024/3/15"
      }
    ]
  },
  tokyo: {
    name: "东京",
    total: 42,
    obtained: 8,
    trophies: {
      diamond: { count: 0, available: 2 },
      gold: { count: 1, available: 12 },
      silver: { count: 2, available: 18 },
      bronze: { count: 5, available: 10 }
    },
    achievements: [
      {
        id: "1",
        name: "初见东京塔",
        description: "东京的第一眼，从这里开始。",
        type: "bronze",
        category: "地标",
        obtained: true,
        obtainedAt: "2024/5/20"
      },
      {
        id: "2",
        name: "涩谷十字路口",
        description: "站在世界最繁忙的十字路口，感受东京的脉搏。",
        type: "bronze",
        category: "地标",
        obtained: true,
        obtainedAt: "2024/5/20"
      },
      {
        id: "3",
        name: "浅草寺祈愿",
        description: "在千年古刹许下心愿。",
        type: "bronze",
        category: "地标",
        obtained: true,
        obtainedAt: "2024/5/21"
      },
      {
        id: "4",
        name: "筑地美味",
        description: "在筑地市场品尝最新鲜的海鲜。",
        type: "silver",
        category: "美食",
        obtained: true,
        obtainedAt: "2024/5/21"
      },
      {
        id: "5",
        name: "秋叶原探索",
        description: "在二次元圣地感受御宅文化。",
        type: "bronze",
        category: "文化",
        obtained: true,
        obtainedAt: "2024/5/22"
      }
    ]
  }
}

// Trophy icon component
function TrophyIcon({ type, size = "md" }: { type: "diamond" | "gold" | "silver" | "bronze", size?: "sm" | "md" | "lg" }) {
  const colors = {
    diamond: "text-cyan-400",
    gold: "text-amber-500",
    silver: "text-gray-400",
    bronze: "text-orange-600"
  }
  
  const bgColors = {
    diamond: "bg-cyan-50",
    gold: "bg-amber-50",
    silver: "bg-gray-100",
    bronze: "bg-orange-50"
  }
  
  const sizes = {
    sm: "h-4 w-4",
    md: "h-6 w-6",
    lg: "h-8 w-8"
  }
  
  const containerSizes = {
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-14 h-14"
  }
  
  return (
    <div className={`${containerSizes[size]} ${bgColors[type]} rounded-full flex items-center justify-center`}>
      <Trophy className={`${sizes[size]} ${colors[type]}`} />
    </div>
  )
}

// Progress circle component
function ProgressCircle({ percentage }: { percentage: number }) {
  const circumference = 2 * Math.PI * 45
  const strokeDashoffset = circumference - (percentage / 100) * circumference
  
  return (
    <div className="relative w-32 h-32">
      <svg className="w-full h-full transform -rotate-90">
        <circle
          cx="64"
          cy="64"
          r="45"
          fill="none"
          stroke="#e5e7eb"
          strokeWidth="8"
        />
        <circle
          cx="64"
          cy="64"
          r="45"
          fill="none"
          stroke="#3b82f6"
          strokeWidth="8"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-2xl font-bold">{percentage}%</span>
        <span className="text-xs text-muted-foreground">完成度</span>
      </div>
    </div>
  )
}

export default function CityTrophiesPage({ params }: { params: Promise<{ cityId: string }> }) {
  const { cityId } = use(params)
  const cityData = cityTrophyData[cityId] || cityTrophyData.hangzhou
  const completionRate = Math.round((cityData.obtained / cityData.total) * 100)
  
  const typeLabels = {
    diamond: "钻石奖杯",
    gold: "黄金奖杯",
    silver: "白银奖杯",
    bronze: "青铜奖杯"
  }
  
  return (
    <div className="min-h-screen bg-amber-50/30">
      {/* Header */}
      <div className="bg-background px-4 py-4">
        <div className="flex items-center gap-3 mb-4">
          <Link href="/profile" className="p-2 -ml-2 rounded-full hover:bg-muted/50">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <div>
            <p className="text-xs text-primary">城市奖杯</p>
            <h1 className="text-xl font-bold">{cityData.name} 奖杯详情</h1>
          </div>
        </div>
        
        <Link 
          href="/profile"
          className="inline-block px-4 py-2 bg-muted rounded-lg text-sm mb-4"
        >
          返回我的主页
        </Link>
      </div>

      {/* Stats section */}
      <div className="bg-background mx-4 mt-4 rounded-2xl p-6">
        <div className="flex items-center gap-6">
          {/* Progress circle */}
          <ProgressCircle percentage={completionRate} />
          
          {/* Stats text */}
          <div className="flex-1">
            <h2 className="text-2xl font-bold mb-2">{cityData.obtained} / {cityData.total}</h2>
            <p className="text-sm text-muted-foreground mb-2">
              已解锁 {cityData.name} 奖杯，继续探索就能更接近白金。
            </p>
            <p className="text-xs text-muted-foreground">
              完成主线成就 12 个以上、进阶成就 8 个以上、隐藏成就 4 个以上、挑战成就 2 个以上，覆盖至少 3 个核心区域，并发布 1 篇完整攻略后，可解锁{cityData.name}白金玩家。
            </p>
          </div>
        </div>

        {/* Trophy type cards */}
        <div className="grid grid-cols-2 gap-3 mt-6">
          {(["diamond", "gold", "silver", "bronze"] as const).map((type) => (
            <div key={type} className="bg-muted/30 rounded-xl p-4">
              <TrophyIcon type={type} size="md" />
              <p className="text-2xl font-bold mt-2">{cityData.trophies[type].count}</p>
              <p className="text-sm text-foreground">{typeLabels[type]}</p>
              <p className="text-xs text-muted-foreground">{cityData.trophies[type].available} 可获得</p>
            </div>
          ))}
        </div>
      </div>

      {/* Achievements list */}
      <div className="px-4 py-6">
        <h3 className="text-lg font-bold mb-4">所有奖杯</h3>
        <div className="grid grid-cols-2 gap-3">
          {cityData.achievements.map((achievement) => (
            <div 
              key={achievement.id}
              className={`bg-background rounded-xl p-4 ${!achievement.obtained ? 'opacity-60' : ''}`}
            >
              <div className="flex items-start justify-between mb-3">
                <TrophyIcon type={achievement.type} size="sm" />
                <span className={`text-xs px-2 py-0.5 rounded ${
                  achievement.type === 'diamond' ? 'bg-cyan-100 text-cyan-700' :
                  achievement.type === 'gold' ? 'bg-amber-100 text-amber-700' :
                  achievement.type === 'silver' ? 'bg-gray-200 text-gray-700' :
                  'bg-orange-100 text-orange-700'
                }`}>
                  {achievement.type === 'diamond' ? '钻石' :
                   achievement.type === 'gold' ? '黄金' :
                   achievement.type === 'silver' ? '白银' : '青铜'}
                </span>
              </div>
              <h4 className="font-semibold text-foreground mb-1">{achievement.name}</h4>
              <p className="text-xs text-muted-foreground mb-3">{achievement.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">{achievement.category}</span>
                <span className={`text-xs ${achievement.obtained ? 'text-primary' : 'text-muted-foreground'}`}>
                  {achievement.obtained ? achievement.obtainedAt : '未获得'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
