"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { 
  ArrowLeft, 
  Heart, 
  Share2, 
  MessageCircle, 
  Edit3,
  MapPin,
  Calendar,
  Clock,
  Wallet,
  Tag,
  Navigation,
  ChevronRight,
  ThumbsUp
} from "lucide-react"

// Mock trip data
const tripData = {
  id: "1",
  title: "秘鲁、智利 13天12晚旅行计划",
  coverImage: "/images/bali.jpg",
  author: {
    name: "guoguoer",
    avatar: "",
    initials: "G",
  },
  publishedAt: "2026/3/25 19:40:14",
  location: "秘鲁、智利",
  likes: 12,
  departureDate: "2026-09-25",
  returnDate: "2026-10-07",
  duration: "13天12晚",
  departureCity: "上海",
  budget: 40000,
  tags: ["摄影", "特种兵", "平衡节奏", "舒适预算", "自然醒", "高海拔适应", "星空摄影"],
  destinations: "利马米拉弗洛雷斯海岸、巴兰科、帕拉卡斯国家保护区、瓦卡奇纳（Huacachina）、库斯科老城、萨克塞华曼、圣谷（皮萨克、欧雁台）、热水镇（Aguas Calientes）、马丘比丘、的的喀喀湖、圣地亚哥圣母山、瓦尔帕莱索、阿塔卡马沙漠（月亮谷、盐湖）",
  itinerary: [
    {
      day: 1,
      date: "9/25",
      description: "利马：抵达后自然醒+轻松适应。下午米拉弗洛雷斯海岸步道日落摄影；晚餐推荐海鲜/塞维切。夜宿利马。",
    },
    {
      day: 2,
      date: "9/26",
      description: "利马：上午巴兰科街区（涂鸦、桥、咖啡馆）人文摄影；下午前往帕拉卡斯。傍晚帕拉卡斯国家保护区海岸线与沙漠地貌拍摄。夜宿帕拉卡斯/伊卡。",
    },
    {
      day: 3,
      date: "9/27",
      description: "伊卡：上午瓦卡奇纳沙漠（沙丘线条、滑沙/沙滩车，注意防尘护目）；傍晚黄金时刻与星空摄影（避光点位）。夜宿伊卡或返回利马（视交通）。",
    },
    {
      day: 4,
      date: "9/28",
      description: "库斯科：早班飞机前往库斯科（海拔3400m，注意高反）。下午轻度活动：武器广场、太阳神殿周边适应性漫步。夜宿库斯科。",
    },
    {
      day: 5,
      date: "9/29",
      description: "库斯科：上午萨克塞华曼遗址日出摄影；下午圣谷（皮萨克市场、欧雁台梯田）。夜宿圣谷或热水镇。",
    },
  ],
  bill: {
    title: "秘鲁智利旅行搭子账单",
    participants: [
      { name: "guoguoer", role: "发起人", avatar: "", initials: "G" },
      { name: "Luna", role: "成员", avatar: "", initials: "L" },
      { name: "小明", role: "成员", avatar: "", initials: "明" },
    ],
    pendingCount: 2,
    totalExpenses: 35600,
  },
  comments: [
    {
      id: "1",
      user: { name: "旅行达人", initials: "旅" },
      content: "这个行程安排得很棒！高海拔适应时间留得很充足。",
      time: "2小时前",
    },
    {
      id: "2", 
      user: { name: "摄影爱好者", initials: "摄" },
      content: "星空摄影点位能分享一下吗？",
      time: "5小时前",
    },
  ],
}

export default function TripDetailPage() {
  const [isLiked, setIsLiked] = useState(false)
  const [likeCount, setLikeCount] = useState(tripData.likes)
  const [comment, setComment] = useState("")

  const handleLike = () => {
    setIsLiked(!isLiked)
    setLikeCount(isLiked ? likeCount - 1 : likeCount + 1)
  }

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="flex items-center justify-between px-4 h-14 max-w-2xl mx-auto">
          <Link href="/" className="p-2 -ml-2 rounded-full hover:bg-muted/50 transition-colors">
            <ArrowLeft className="h-5 w-5 text-foreground" />
          </Link>
          <h1 className="text-base font-medium text-foreground truncate max-w-[200px]">行程详情</h1>
          <button className="p-2 -mr-2 rounded-full hover:bg-muted/50 transition-colors">
            <Share2 className="h-5 w-5 text-foreground" />
          </button>
        </div>
      </header>

      <main className="max-w-2xl mx-auto">
        {/* Cover Image */}
        <div className="relative aspect-[2/1] w-full">
          <Image
            src={tripData.coverImage}
            alt={tripData.title}
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          <div className="absolute bottom-4 left-4 right-4">
            <h2 className="text-xl font-bold text-white text-balance">{tripData.title}</h2>
          </div>
        </div>

        {/* Author Info */}
        <div className="px-4 py-4 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-sm font-medium text-muted-foreground">
              {tripData.author.initials}
            </div>
            <div className="flex-1">
              <p className="font-medium text-foreground">{tripData.author.name}</p>
              <p className="text-xs text-muted-foreground">
                发布于 {tripData.publishedAt} · <MapPin className="inline h-3 w-3" /> {tripData.location} · <Heart className="inline h-3 w-3" /> {likeCount}
              </p>
            </div>
          </div>
        </div>

        {/* Trip Info Grid */}
        <div className="px-4 py-4">
          <div className="grid grid-cols-2 gap-3">
            {/* Departure Date */}
            <div className="bg-muted/30 rounded-xl p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Calendar className="h-4 w-4" />
                <span className="text-xs">出发日期</span>
              </div>
              <p className="font-semibold text-foreground">{tripData.departureDate}</p>
            </div>

            {/* Return Date */}
            <div className="bg-muted/30 rounded-xl p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Calendar className="h-4 w-4" />
                <span className="text-xs">返程日期</span>
              </div>
              <p className="font-semibold text-foreground">{tripData.returnDate}</p>
            </div>

            {/* Duration */}
            <div className="bg-muted/30 rounded-xl p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Clock className="h-4 w-4" />
                <span className="text-xs">出行时长</span>
              </div>
              <p className="font-semibold text-foreground">{tripData.duration}</p>
            </div>

            {/* Budget */}
            <div className="bg-muted/30 rounded-xl p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Wallet className="h-4 w-4" />
                <span className="text-xs">预算</span>
              </div>
              <p className="font-semibold text-foreground">¥{tripData.budget.toLocaleString()}</p>
            </div>

            {/* Departure City */}
            <div className="bg-muted/30 rounded-xl p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Navigation className="h-4 w-4" />
                <span className="text-xs">出发地</span>
              </div>
              <p className="font-semibold text-foreground">{tripData.departureCity}</p>
            </div>

            {/* Tags */}
            <div className="bg-muted/30 rounded-xl p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-1">
                <Tag className="h-4 w-4" />
                <span className="text-xs">行程标签</span>
              </div>
              <p className="font-semibold text-foreground text-sm truncate">{tripData.tags.slice(0, 3).join(" / ")}</p>
            </div>
          </div>

          {/* Tags Full */}
          <div className="mt-3 flex gap-2 flex-wrap">
            {tripData.tags.map((tag) => (
              <span
                key={tag}
                className="px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-medium"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Destinations */}
        <div className="px-4 py-4 border-t border-border">
          <div className="bg-muted/30 rounded-xl p-4">
            <div className="flex items-center gap-2 text-muted-foreground mb-2">
              <MapPin className="h-4 w-4" />
              <span className="text-xs">想去景点</span>
            </div>
            <p className="text-sm text-foreground leading-relaxed">{tripData.destinations}</p>
          </div>
        </div>

        {/* Daily Itinerary */}
        <div className="px-4 py-4 border-t border-border">
          <h3 className="text-base font-semibold text-foreground mb-4">每日行程</h3>
          <div className="space-y-3">
            {tripData.itinerary.map((item) => (
              <div key={item.day} className="flex gap-3">
                <div className="flex-shrink-0 w-12 h-7 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-xs font-bold text-primary-foreground">D{item.day}</span>
                </div>
                <div className="flex-1 pb-3 border-b border-border last:border-0">
                  <p className="text-sm text-foreground leading-relaxed">
                    <span className="font-medium">({item.date})</span> {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="px-4 py-4 border-t border-border">
          <div className="flex items-center justify-center gap-6">
            <button
              onClick={handleLike}
              className={`flex flex-col items-center gap-1 transition-colors ${
                isLiked ? "text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <div className={`w-11 h-11 rounded-full flex items-center justify-center ${
                isLiked ? "bg-primary/10" : "bg-muted/50"
              }`}>
                <ThumbsUp className="h-5 w-5" />
              </div>
              <span className="text-xs">{likeCount}</span>
            </button>
            <button className="flex flex-col items-center gap-1 text-background">
              <div className="w-11 h-11 rounded-full bg-foreground flex items-center justify-center">
                <Share2 className="h-5 w-5" />
              </div>
            </button>
            <button className="flex flex-col items-center gap-1 text-muted-foreground hover:text-foreground transition-colors">
              <div className="w-11 h-11 rounded-full bg-muted/50 flex items-center justify-center">
                <MessageCircle className="h-5 w-5" />
              </div>
            </button>
            <button className="flex flex-col items-center gap-1 text-muted-foreground hover:text-foreground transition-colors">
              <div className="w-11 h-11 rounded-full bg-muted/50 flex items-center justify-center">
                <Edit3 className="h-5 w-5" />
              </div>
            </button>
          </div>
        </div>

        {/* Bill Section */}
        <div className="px-4 py-4 border-t border-border">
          <Link 
            href={tripData.bill ? `/bill/${tripData.id}` : `/bill/create?tripId=${tripData.id}`}
            className="block bg-muted/20 rounded-2xl p-4 hover:bg-muted/30 transition-colors"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-primary font-medium">行程账单</span>
              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                {tripData.bill ? "进入账单" : "发起账单"}
                <ChevronRight className="h-4 w-4" />
              </div>
            </div>
            {tripData.bill ? (
              <>
                <h4 className="font-semibold text-foreground mb-3">{tripData.bill.title}</h4>
                <div className="flex items-center gap-2 mb-4">
                  <span className="px-2 py-1 bg-muted/50 rounded text-xs text-muted-foreground">
                    {tripData.bill.participants.length} 人协作
                  </span>
                  <span className="px-2 py-1 bg-muted/50 rounded text-xs text-muted-foreground">
                    {tripData.bill.pendingCount} 笔待确认
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  {tripData.bill.participants.map((participant) => (
                    <div key={participant.name} className="flex flex-col items-center gap-1">
                      <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-sm font-medium text-muted-foreground">
                        {participant.initials}
                      </div>
                      <span className="text-xs font-medium text-foreground">{participant.name}</span>
                      <span className="text-[10px] text-muted-foreground">{participant.role}</span>
                    </div>
                  ))}
                </div>
                <p className="mt-4 text-xs text-muted-foreground">
                  账单用于透明记录多人出行费用，方便协商和结算，不强制立即付款。
                </p>
              </>
            ) : (
              <div className="py-4 text-center">
                <p className="text-sm text-muted-foreground mb-2">暂无账单</p>
                <p className="text-xs text-muted-foreground">点击发起账单，记录多人出行费用</p>
              </div>
            )}
          </Link>
        </div>

        {/* Comments Section */}
        <div className="px-4 py-4 border-t border-border">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-foreground">评论</h3>
            <select className="text-sm text-muted-foreground bg-transparent border-none outline-none">
              <option>最新</option>
              <option>最热</option>
            </select>
          </div>

          {/* Comment Input */}
          <div className="flex items-center gap-3 mb-6">
            <input
              type="text"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="写评论，按发送发布"
              className="flex-1 h-10 px-4 bg-muted/50 rounded-full text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-border"
            />
            <button className="h-10 px-5 bg-foreground text-background rounded-full text-sm font-medium flex items-center gap-1.5">
              发送
            </button>
          </div>

          {/* Comments List */}
          {tripData.comments.length > 0 ? (
            <div className="space-y-4">
              {tripData.comments.map((c) => (
                <div key={c.id} className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-xs font-medium text-muted-foreground flex-shrink-0">
                    {c.user.initials}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-medium text-foreground">{c.user.name}</span>
                      <span className="text-xs text-muted-foreground">{c.time}</span>
                    </div>
                    <p className="text-sm text-foreground">{c.content}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-8">暂无评论</p>
          )}
        </div>
      </main>
    </div>
  )
}
