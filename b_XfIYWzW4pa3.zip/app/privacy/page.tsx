"use client"

import { ChevronLeft } from "lucide-react"
import Link from "next/link"

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-border z-10">
        <div className="flex items-center h-14 px-4">
          <Link href="/login" className="p-2 -ml-2">
            <ChevronLeft className="h-6 w-6" />
          </Link>
          <h1 className="flex-1 text-center font-medium pr-8">在线协议</h1>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-6">
        <Link href="#" className="text-primary text-sm">English Version</Link>
        
        <h2 className="text-xl font-bold text-center my-8">歌觅用户隐私政策</h2>
        
        <Link href="#" className="text-primary text-sm block mb-4">歌觅用户隐私权政策（简明版）</Link>
        
        <p className="text-sm text-muted-foreground mb-6">更新日期：2026年4月1日</p>
        
        <h3 className="font-bold mb-4">引言</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          名称为"歌觅"和/或"Go With Me"的网站、小程序、客户端应用程序以及我们不时提供的其他形式（统称"歌觅平台"）由歌觅科技有限公司及其关联公司（以下简称"歌觅公司"或"我们"）合法拥有并运营。"我们的"应相应地进行理解。为免疑义，我们亦保留调整歌觅平台名称的所有权利。本政策中的"歌觅"是与其在中国境外运营版本即"Go With Me"相区别的产品。本政策适用于歌觅用户，即注册于中国境内的用户。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          如果您注册于中国境外，则您是Go With Me用户，适用
          <Link href="#" className="text-primary">Go With Me Privacy Policy</Link>。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          "用户"或"您"指歌觅平台的使用人。"您的"应相应地进行理解。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          在本政策中，我们描述了我们依据相关法律法规和技术规范收集/使用/对外提供个人信息的做法，进一步阐述了您的个人信息相关权利。
        </p>
        
        <p className="text-sm leading-relaxed mb-6">
          本政策与您所使用的我们的歌觅平台服务息息相关，您在下载、安装、启动、浏览、注册、登录、使用我们的歌觅平台服务时，我们将按照本政策的约定处理和保护您的个人信息。"歌觅平台服务"具有
          <Link href="/agreement" className="text-primary">《歌觅用户服务协议》</Link>
          中所定义之含义。如您使用歌觅平台购物时，本隐私政策将适用于您使用购物功能时的行为，同时您将适用
          <Link href="#" className="text-primary">《歌觅出海电商业务个人信息处理知情同意书》</Link>。
        </p>

        <p className="text-sm leading-relaxed mb-4 font-bold">
          如您未满18周岁或未满您居住所在地要求可使用歌觅平台的年龄，或存在其他不具备与用户行为相适应的法定要求的情形，请您依照当地法律要求，不要使用歌觅平台。
        </p>

        <h3 className="font-bold mb-4">一、我们如何收集和使用您的个人信息</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          1.1 在您使用歌觅平台服务的过程中，我们会按照如下方式收集您在使用服务时主动提供或因为使用服务而产生的信息，用以向您提供服务、优化我们的服务以及保障您的账户安全。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          1.2 当您注册歌觅平台账户时，我们会收集您的手机号码、密码。如果您选择使用第三方账号登录，我们会从第三方获取您授权共享的账户信息（头像、昵称），用于创建歌觅平台账户。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          1.3 当您使用歌觅平台的功能或服务时，我们会收集您的设备信息、日志信息、位置信息等，以便为您提供更好的服务体验。
        </p>

        <h3 className="font-bold mb-4">二、我们如何使用Cookie和同类技术</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          2.1 为使您获得更轻松的访问体验，您使用歌觅平台服务时，我们可能会通过小型数据文件识别您的身份，这么做是帮您省去重复输入注册信息的步骤，或者帮助判断您的账户安全状态。这些数据文件可能是Cookie、Flash Cookie，或您的浏览器或关联应用程序提供的其他本地存储（以下统称"Cookie"）。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          2.2 请您理解，我们的某些服务只能通过使用Cookie才可得到实现。如果您的浏览器或浏览器附加服务允许，您可以修改对Cookie的接受程度或者拒绝我们的Cookie，但拒绝我们的Cookie在某些情况下可能会影响您安全访问网站和使用我们提供的服务。
        </p>

        <h3 className="font-bold mb-4">三、我们如何共享、转让、公开披露您的个人信息</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          3.1 共享：我们不会与歌觅公司以外的任何公司、组织和个人共享您的个人信息，但以下情况除外：
        </p>
        
        <p className="text-sm leading-relaxed mb-4 pl-4">
          （1）事先获得您明确的同意或授权；<br/>
          （2）根据适用的法律法规、法律程序的要求、强制性的行政或司法要求所必须的情况下进行提供；<br/>
          （3）在法律法规允许的范围内，为维护歌觅公司、歌觅公司的关联方或合作伙伴、您或其他歌觅用户或社会公众利益、财产或安全免遭损害而有必要提供。
        </p>

        <h3 className="font-bold mb-4">四、我们如何保护您的个人信息</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          4.1 我们已采取符合业界标准、合理可行的安全防护措施保护您的信息，防止个人信息遭到未经授权访问、公开披露、使用、修改、损坏或丢失。
        </p>
        
        <p className="text-sm leading-relaxed mb-4">
          4.2 我们会采取合理可行的措施，尽力避免收集无关的个人信息。我们只会在达成本政策所述目的所需的期限内保留您的个人信息，除非法律有强制的存留要求。
        </p>

        <h3 className="font-bold mb-4">五、您的权利</h3>
        
        <p className="text-sm leading-relaxed mb-4">
          5.1 您可以在使用我们服务的过程中，访问、修改和删除您提供的注册信息和其他个人信息，也可按照通知指引与我们联系。您访问、修改和删除个人信息的范围和方式将取决于您使用的具体服务。
        </p>
        
        <p className="text-sm leading-relaxed mb-8">
          5.2 如您对本政策或相关事宜有任何问题，您可以通过歌觅平台的在线客服或者发送邮件至 privacy@gomi.com 与我们联系。
        </p>
      </div>
    </div>
  )
}
