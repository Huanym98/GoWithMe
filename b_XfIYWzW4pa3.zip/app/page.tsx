"use client"

import { useState } from "react"
import { Search } from "lucide-react"
import Link from "next/link"
import { TravelCard } from "@/components/travel-card"
import { BottomTabBar } from "@/components/bottom-tab-bar"

const travelPlans = [
  {
    id: "1",
    image: "/images/kyoto.jpg",
    destination: "京都",
    country: "日本",
    dateRange: "5月1日 - 5月5日",
    budget: "¥8,000",
    tags: ["和服体验", "寺庙", "五一"],
    userName: "小雨",
    userAvatar: "",
  },
  {
    id: "2",
    image: "/images/seoul.jpg",
    destination: "首尔",
    country: "韩国",
    dateRange: "5月3日 - 5月7日",
    budget: "¥6,500",
    tags: ["美食", "购物", "五一"],
    userName: "Luna",
    userAvatar: "",
  },
  {
    id: "3",
    image: "/images/paris.jpg",
    destination: "巴黎",
    country: "法国",
    dateRange: "6月10日 - 6月18日",
    budget: "¥15,000",
    tags: ["艺术", "浪漫", "Citywalk"],
    userName: "Mia",
    userAvatar: "",
  },
  {
    id: "4",
    image: "/images/bali.jpg",
    destination: "巴厘岛",
    country: "印度尼西亚",
    dateRange: "5月20日 - 5月26日",
    budget: "¥7,500",
    tags: ["度假", "瑜伽", "摄影"],
    userName: "芸芸",
    userAvatar: "",
  },
]

const filterChips = ["热门", "五一", "韩国", "日本", "Citywalk", "摄影", "美食"]

export default function HomePage() {
  const [activeFilter, setActiveFilter] = useState("热门")

  // Filter travel plans based on active filter
  const filteredPlans = activeFilter === "热门" 
    ? travelPlans 
    : travelPlans.filter(plan => 
        plan.country === activeFilter || 
        plan.tags.includes(activeFilter) ||
        plan.destination.includes(activeFilter)
      )

  return (
    <div className="min-h-screen bg-background max-w-md mx-auto pb-24">
      {/* Status bar spacer */}
      <div className="h-12" />

      {/* Header */}
      <header className="px-5 pb-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-foreground tracking-tight">Go With Me</h1>
          <Link href="/search" className="p-2 rounded-full hover:bg-muted/50 transition-colors">
            <Search className="h-5 w-5 text-muted-foreground" />
          </Link>
        </div>
      </header>

      {/* Filter chips */}
      <div className="px-5 mb-6">
        <div className="flex gap-2 overflow-x-auto pb-2 -mx-5 px-5 scrollbar-hide">
          {filterChips.map((chip) => (
            <button
              key={chip}
              onClick={() => setActiveFilter(chip)}
              className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                activeFilter === chip
                  ? "bg-foreground text-background"
                  : "bg-muted/50 text-muted-foreground hover:bg-muted"
              }`}
            >
              {chip}
            </button>
          ))}
        </div>
      </div>

      {/* Travel plans */}
      <section className="px-5 mb-8">
        <div className="grid grid-cols-2 gap-3">
          {filteredPlans.length > 0 ? (
            filteredPlans.map((plan) => (
              <TravelCard key={plan.id} {...plan} />
            ))
          ) : (
            <div className="col-span-2 py-12 text-center">
              <p className="text-muted-foreground">暂无相关行程</p>
            </div>
          )}
        </div>
      </section>

      {/* Bottom tab bar */}
      <BottomTabBar activeTab="home" />
    </div>
  )
}
