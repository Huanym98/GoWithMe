"use client"

import Image from "next/image"
import { Eye, Heart, Bookmark } from "lucide-react"

interface GuideCardProps {
  image: string
  title: string
  description: string
  author: string
  authorAvatar?: string
  views: string
  likes: string
  bookmarked?: boolean
  tags?: string[]
}

export function GuideCard({
  image,
  title,
  description,
  author,
  authorAvatar,
  views,
  likes,
  bookmarked = false,
  tags = [],
}: GuideCardProps) {
  return (
    <div className="bg-card rounded-2xl overflow-hidden shadow-sm border border-border/30">
      {/* Image */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <Image
          src={image}
          alt={title}
          fill
          className="object-cover"
        />
        {/* Tags overlay */}
        {tags.length > 0 && (
          <div className="absolute top-2 left-2 flex gap-1.5">
            {tags.slice(0, 2).map((tag) => (
              <span
                key={tag}
                className="px-2 py-0.5 bg-background/80 backdrop-blur-sm rounded-full text-[10px] font-medium text-foreground"
              >
                {tag}
              </span>
            ))}
          </div>
        )}
        {/* Bookmark button */}
        <button className="absolute top-2 right-2 p-1.5 bg-background/80 backdrop-blur-sm rounded-full">
          <Bookmark
            className={`h-3.5 w-3.5 ${bookmarked ? "fill-foreground text-foreground" : "text-muted-foreground"}`}
          />
        </button>
      </div>

      {/* Content */}
      <div className="p-3">
        <h3 className="font-semibold text-sm text-foreground mb-1 line-clamp-1">
          {title}
        </h3>
        <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
          {description}
        </p>

        {/* Author and stats */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <div className="h-5 w-5 rounded-full bg-muted flex items-center justify-center overflow-hidden">
              {authorAvatar ? (
                <Image
                  src={authorAvatar}
                  alt={author}
                  width={20}
                  height={20}
                  className="object-cover"
                />
              ) : (
                <span className="text-[10px] font-medium text-muted-foreground">
                  {author.charAt(0)}
                </span>
              )}
            </div>
            <span className="text-[11px] text-muted-foreground">{author}</span>
          </div>
          <div className="flex items-center gap-2.5 text-muted-foreground">
            <div className="flex items-center gap-0.5">
              <Eye className="h-3 w-3" />
              <span className="text-[10px]">{views}</span>
            </div>
            <div className="flex items-center gap-0.5">
              <Heart className="h-3 w-3" />
              <span className="text-[10px]">{likes}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
