"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface CompanionCardProps {
  name: string
  avatar: string
  location: string
  interests: string[]
  trips: number
}

export function CompanionCard({
  name,
  avatar,
  location,
  interests,
  trips,
}: CompanionCardProps) {
  return (
    <div className="flex-shrink-0 w-32 bg-card rounded-2xl p-4 border border-border/50 shadow-sm">
      <div className="flex flex-col items-center text-center">
        <Avatar className="h-14 w-14 mb-3">
          <AvatarImage src={avatar} alt={name} />
          <AvatarFallback className="bg-muted text-base">{name[0]}</AvatarFallback>
        </Avatar>
        <h4 className="text-sm font-medium text-foreground mb-0.5">{name}</h4>
        <p className="text-xs text-muted-foreground mb-2">{location}</p>
        <p className="text-xs text-muted-foreground">{trips} 次旅行</p>
        <div className="flex flex-wrap gap-1 mt-2 justify-center">
          {interests.slice(0, 2).map((interest) => (
            <span
              key={interest}
              className="px-2 py-0.5 bg-muted text-muted-foreground text-[10px] rounded-full"
            >
              {interest}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
