"use client"

import Image from "next/image"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface TravelCardProps {
  id?: string
  image: string
  destination: string
  country: string
  dateRange: string
  budget: string
  tags: string[]
  userName: string
  userAvatar: string
}

export function TravelCard({
  id = "1",
  image,
  destination,
  country,
  dateRange,
  budget,
  tags,
  userName,
  userAvatar,
}: TravelCardProps) {
  return (
    <Link href={`/trip/${id}`} className="block bg-card rounded-2xl overflow-hidden shadow-sm border border-border/50 hover:shadow-md transition-shadow">
      <div className="relative aspect-[4/3]">
        <Image
          src={image}
          alt={destination}
          fill
          className="object-cover"
        />
        <div className="absolute top-3 left-3 flex gap-1.5">
          {tags.slice(0, 2).map((tag) => (
            <span
              key={tag}
              className="px-2.5 py-1 bg-foreground/80 text-background text-xs font-medium rounded-full backdrop-blur-sm"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <div>
            <h3 className="text-base font-semibold text-foreground">{destination}</h3>
            <p className="text-sm text-muted-foreground">{country}</p>
          </div>
          <span className="text-sm font-medium text-foreground">{budget}</span>
        </div>
        <p className="text-sm text-muted-foreground mb-3">{dateRange}</p>
        <div className="flex items-center gap-2 pt-3 border-t border-border/50">
          <Avatar className="h-7 w-7">
            <AvatarImage src={userAvatar} alt={userName} />
            <AvatarFallback className="text-xs bg-muted">{userName[0]}</AvatarFallback>
          </Avatar>
          <span className="text-sm text-muted-foreground">{userName}</span>
        </div>
      </div>
    </Link>
  )
}
