"use client"

import { useEffect, useRef, useState, useCallback } from "react"

interface Particle {
  x: number
  y: number
  startX: number
  startY: number
  endX: number
  endY: number
}

const phrases = [
  "Go With Me",
  "歌觅",
  "一緒に行こう",
  "함께 가자",
  "Vieni con me",
  "Allons-y",
]

export function ParticleText() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const particlesRef = useRef<Particle[]>([])
  const progressRef = useRef(1) // 1 means animation complete
  const animationRef = useRef<number>(0)
  const [currentIndex, setCurrentIndex] = useState(0)

  const width = 360
  const height = 100
  const darkBlue = "#1a1f36"

  // Get particle positions from text
  const getTextParticles = useCallback((text: string): { x: number; y: number }[] => {
    const tempCanvas = document.createElement("canvas")
    const tempCtx = tempCanvas.getContext("2d")
    if (!tempCtx) return []

    tempCanvas.width = width
    tempCanvas.height = height

    // Adjust font size based on text length
    let fontSize = 48
    if (text.length > 10) fontSize = 32
    else if (text.length > 6) fontSize = 40
    else if (text.length <= 3) fontSize = 56

    tempCtx.font = `900 ${fontSize}px -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif`
    tempCtx.fillStyle = "#000"
    tempCtx.textAlign = "center"
    tempCtx.textBaseline = "middle"
    tempCtx.fillText(text, width / 2, height / 2)

    const imageData = tempCtx.getImageData(0, 0, width, height)
    const positions: { x: number; y: number }[] = []
    const gap = 2

    for (let y = 0; y < height; y += gap) {
      for (let x = 0; x < width; x += gap) {
        const index = (y * width + x) * 4
        const alpha = imageData.data[index + 3]
        if (alpha > 128) {
          positions.push({ x, y })
        }
      }
    }

    return positions
  }, [])

  // Initialize on mount
  useEffect(() => {
    const positions = getTextParticles(phrases[0])
    particlesRef.current = positions.map((pos) => ({
      x: pos.x,
      y: pos.y,
      startX: pos.x,
      startY: pos.y,
      endX: pos.x,
      endY: pos.y,
    }))
  }, [getTextParticles])

  // Handle text change
  useEffect(() => {
    if (currentIndex === 0 && particlesRef.current.length === 0) return

    const newPositions = getTextParticles(phrases[currentIndex])
    const particles = particlesRef.current

    // Store current positions as start points
    particles.forEach((p) => {
      p.startX = p.x
      p.startY = p.y
    })

    const targetCount = newPositions.length
    const currentCount = particles.length

    // Adjust particle count
    if (targetCount > currentCount) {
      for (let i = currentCount; i < targetCount; i++) {
        const sourceIdx = i % currentCount
        particles.push({
          x: particles[sourceIdx]?.x ?? width / 2,
          y: particles[sourceIdx]?.y ?? height / 2,
          startX: particles[sourceIdx]?.x ?? width / 2,
          startY: particles[sourceIdx]?.y ?? height / 2,
          endX: newPositions[i].x,
          endY: newPositions[i].y,
        })
      }
    } else if (targetCount < currentCount) {
      // Move extra particles to merge with existing targets
      particles.splice(targetCount)
    }

    // Assign end positions - sort by distance for smoother morph
    const assignments: { particleIdx: number; targetIdx: number; dist: number }[] = []
    
    particles.forEach((p, pIdx) => {
      newPositions.forEach((t, tIdx) => {
        const dist = Math.sqrt((p.x - t.x) ** 2 + (p.y - t.y) ** 2)
        assignments.push({ particleIdx: pIdx, targetIdx: tIdx, dist })
      })
    })

    // Sort by distance and assign greedily
    assignments.sort((a, b) => a.dist - b.dist)
    const usedParticles = new Set<number>()
    const usedTargets = new Set<number>()

    for (const { particleIdx, targetIdx } of assignments) {
      if (usedParticles.has(particleIdx) || usedTargets.has(targetIdx)) continue
      if (particles[particleIdx]) {
        particles[particleIdx].endX = newPositions[targetIdx].x
        particles[particleIdx].endY = newPositions[targetIdx].y
        usedParticles.add(particleIdx)
        usedTargets.add(targetIdx)
      }
      if (usedParticles.size >= particles.length) break
    }

    // Start morph animation
    progressRef.current = 0
  }, [currentIndex, getTextParticles])

  // Animation loop
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const dpr = window.devicePixelRatio || 1
    canvas.width = width * dpr
    canvas.height = height * dpr
    ctx.scale(dpr, dpr)

    const animate = () => {
      ctx.clearRect(0, 0, width, height)

      // Very slow progress increment for smooth morphing
      if (progressRef.current < 1) {
        progressRef.current += 0.004 // ~4 seconds for full transition
        if (progressRef.current > 1) progressRef.current = 1
      }

      // Ease-in-out cubic for smooth morphing
      const t = progressRef.current
      const ease = t < 0.5
        ? 4 * t * t * t
        : 1 - Math.pow(-2 * t + 2, 3) / 2

      // Update and draw particles
      particlesRef.current.forEach((p) => {
        p.x = p.startX + (p.endX - p.startX) * ease
        p.y = p.startY + (p.endY - p.startY) * ease

        ctx.beginPath()
        ctx.arc(p.x, p.y, 1.2, 0, Math.PI * 2)
        ctx.fillStyle = darkBlue
        ctx.fill()
      })

      animationRef.current = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      cancelAnimationFrame(animationRef.current)
    }
  }, [])

  // Auto switch text every 6 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % phrases.length)
    }, 6000)
    return () => clearInterval(interval)
  }, [])

  return (
    <canvas
      ref={canvasRef}
      style={{
        width: width,
        height: height,
      }}
    />
  )
}
