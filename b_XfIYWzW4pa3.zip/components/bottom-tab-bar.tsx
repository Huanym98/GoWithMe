"use client"

import { Home, BookOpen, MessageCircle, User, Plus } from "lucide-react"
import Link from "next/link"

interface BottomTabBarProps {
  activeTab?: "home" | "guides" | "messages" | "profile"
}

export function BottomTabBar({ activeTab = "home" }: BottomTabBarProps) {
  const tabs = [
    { id: "home", label: "首页", icon: Home, href: "/" },
    { id: "guides", label: "查攻略", icon: BookOpen, href: "/guides" },
    { id: "messages", label: "消息", icon: MessageCircle, href: "/messages" },
    { id: "profile", label: "我的", icon: User, href: "/profile" },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-background/95 backdrop-blur-lg border-t border-border/50 pb-safe">
      <div className="flex items-center justify-around py-2 max-w-md mx-auto">
        {/* Left tabs */}
        {tabs.slice(0, 2).map((tab) => (
          <Link
            key={tab.id}
            href={tab.href}
            className={`flex flex-col items-center gap-0.5 px-3 py-1.5 transition-colors ${
              activeTab === tab.id ? "text-foreground" : "text-muted-foreground"
            }`}
          >
            <tab.icon className="h-5 w-5" />
            <span className="text-[10px]">{tab.label}</span>
          </Link>
        ))}

        {/* Center publish button */}
        <Link 
          href="/publish"
          className="flex items-center justify-center w-12 h-12 -mt-5 bg-foreground text-background rounded-full shadow-lg transition-transform active:scale-95"
        >
          <Plus className="h-6 w-6" />
        </Link>

        {/* Right tabs */}
        {tabs.slice(2).map((tab) => (
          <Link
            key={tab.id}
            href={tab.href}
            className={`flex flex-col items-center gap-0.5 px-3 py-1.5 transition-colors ${
              activeTab === tab.id ? "text-foreground" : "text-muted-foreground"
            }`}
          >
            <tab.icon className="h-5 w-5" />
            <span className="text-[10px]">{tab.label}</span>
          </Link>
        ))}
      </div>
    </div>
  )
}
