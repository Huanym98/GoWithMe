#!/usr/bin/env python3
import sys
from pathlib import Path
import geopandas as gpd

src = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/www/romanticjourney/assets/vendor/world-countries.geojson')
out = Path(sys.argv[2]) if len(sys.argv) > 2 else src.with_name('world-countries-lite.geojson')
tolerance = float(sys.argv[3]) if len(sys.argv) > 3 else 0.15

if not src.exists():
    raise SystemExit(f'source not found: {src}')

print(f'loading {src} ...')
gdf = gpd.read_file(src)
# simplify on EPSG:4326 degrees. tolerance 0.1~0.2 is usually enough for world map.
gdf['geometry'] = gdf.geometry.simplify(tolerance, preserve_topology=True)
out.parent.mkdir(parents=True, exist_ok=True)
gdf.to_file(out, driver='GeoJSON')
print(f'written {out} ({out.stat().st_size/1024/1024:.2f} MB)')
