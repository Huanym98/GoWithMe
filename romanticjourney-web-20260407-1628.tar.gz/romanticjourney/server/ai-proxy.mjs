import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));

const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const SUPABASE_URL = String(process.env.SUPABASE_URL || '').trim();
const SUPABASE_SERVICE_ROLE_KEY = String(process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SERVICE_KEY || '').trim();
const STORAGE_BUCKET = String(process.env.STORAGE_BUCKET || 'Trip_Photos').trim() || 'Trip_Photos';
const PORT = process.env.PORT || 8787;

function buildAuthEmailFromNickname(nickname) {
  const raw = String(nickname || '').trim();
  if (!raw) return 'unknown@romanticjourney.app';
  const bytes = Array.from(new TextEncoder().encode(raw));
  const hex = bytes.map((b) => b.toString(16).padStart(2, '0')).join('').slice(0, 48) || 'unknown';
  return `u_${hex}@romanticjourney.app`;
}

function uniq(values = []) {
  return [...new Set((Array.isArray(values) ? values : []).map((value) => String(value || '').trim()).filter(Boolean))];
}

function chunk(values = [], size = 100) {
  const out = [];
  for (let i = 0; i < values.length; i += size) out.push(values.slice(i, i + size));
  return out;
}

function encodeIdList(values = []) {
  return values.map((value) => encodeURIComponent(String(value))).join(',');
}

function parseStorageObjectPath(rawUrl, bucket = STORAGE_BUCKET) {
  const raw = String(rawUrl || '').trim();
  if (!raw) return '';
  const patterns = [
    `/storage/v1/object/public/${encodeURIComponent(bucket)}/`,
    `/storage/v1/render/image/public/${encodeURIComponent(bucket)}/`,
    `/storage/v1/object/public/${bucket}/`,
    `/storage/v1/render/image/public/${bucket}/`
  ];
  const matched = patterns.find((pattern) => raw.includes(pattern));
  if (!matched) return '';
  const idx = raw.indexOf(matched);
  if (idx < 0) return '';
  const pathPart = raw.slice(idx + matched.length).split('?')[0].replace(/^\/+/, '');
  try {
    return decodeURIComponent(pathPart);
  } catch {
    return pathPart;
  }
}

async function supabaseAdminFetch(pathname, options = {}) {
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error('SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY is not configured on server');
  }
  const response = await fetch(`${SUPABASE_URL}${pathname}`, {
    ...options,
    headers: {
      apikey: SUPABASE_SERVICE_ROLE_KEY,
      Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });
  return response;
}

async function supabaseAdminJson(pathname, options = {}) {
  const response = await supabaseAdminFetch(pathname, options);
  const text = await response.text();
  const data = text ? JSON.parse(text) : null;
  if (!response.ok) {
    throw new Error(typeof data?.error === 'string' ? data.error : text || `${options.method || 'GET'} ${pathname} failed (${response.status})`);
  }
  return data;
}

async function getUserFromAccessToken(accessToken) {
  if (!SUPABASE_URL) throw new Error('SUPABASE_URL is not configured on server');
  const response = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    method: 'GET',
    headers: {
      apikey: SUPABASE_SERVICE_ROLE_KEY || 'missing-service-role-key',
      Authorization: `Bearer ${accessToken}`
    }
  });
  const text = await response.text();
  if (!response.ok) {
    throw new Error(`Auth session invalid: ${text || response.status}`);
  }
  return text ? JSON.parse(text) : null;
}

async function fetchAllAdminEvents() {
  const pageSize = 1000;
  const rows = [];
  for (let offset = 0; offset < 10000; offset += pageSize) {
    const batch = await supabaseAdminJson(`/rest/v1/admin_events?select=id,payload,user_nickname&order=created_at.desc&limit=${pageSize}&offset=${offset}`, { method: 'GET' });
    if (!Array.isArray(batch) || !batch.length) break;
    rows.push(...batch);
    if (batch.length < pageSize) break;
  }
  return rows;
}

function shouldDeleteAdminEvent(event, nickname) {
  const target = String(nickname || '').trim();
  const payload = event?.payload && typeof event.payload === 'object' ? event.payload : {};
  if (String(event?.user_nickname || '').trim() === target) return true;
  if ([payload.user, payload.from, payload.to, payload.actor].some((value) => String(value || '').trim() === target)) return true;
  if (Array.isArray(payload.members) && payload.members.some((value) => String(value || '').trim() === target)) return true;
  return false;
}

async function deleteAdminEventsByNickname(nickname) {
  const events = await fetchAllAdminEvents();
  const ids = uniq(events.filter((event) => shouldDeleteAdminEvent(event, nickname)).map((event) => event.id));
  for (const batch of chunk(ids, 100)) {
    await supabaseAdminFetch(`/rest/v1/admin_events?id=in.(${encodeIdList(batch)})`, {
      method: 'DELETE',
      headers: { Prefer: 'return=minimal' }
    });
  }
  return ids.length;
}

async function collectUserStoragePaths(appUserId) {
  if (!appUserId) return [];
  const paths = [];
  const profileRows = await supabaseAdminJson(`/rest/v1/user_profiles?user_id=eq.${encodeURIComponent(appUserId)}&select=avatar&limit=1`, { method: 'GET' }).catch(() => []);
  const profile = Array.isArray(profileRows) && profileRows.length ? profileRows[0] : null;
  if (profile?.avatar) paths.push(parseStorageObjectPath(profile.avatar));

  const mediaRows = await supabaseAdminJson(`/rest/v1/media_posts?user_id=eq.${encodeURIComponent(appUserId)}&select=cover`, { method: 'GET' }).catch(() => []);
  (Array.isArray(mediaRows) ? mediaRows : []).forEach((row) => {
    if (row?.cover) paths.push(parseStorageObjectPath(row.cover));
  });
  return uniq(paths);
}

async function deleteStorageObjects(paths = []) {
  const valid = uniq(paths);
  if (!valid.length) return 0;
  let deleted = 0;
  for (const batch of chunk(valid, 100)) {
    const response = await supabaseAdminFetch(`/storage/v1/object/remove/${encodeURIComponent(STORAGE_BUCKET)}`, {
      method: 'POST',
      body: JSON.stringify({ prefixes: batch })
    });
    const text = await response.text();
    if (!response.ok) {
      throw new Error(text || `Failed to delete storage objects (${response.status})`);
    }
    deleted += batch.length;
  }
  return deleted;
}

async function fetchAffectedTripIdsForLikeRecount(userId) {
  if (!userId) return [];
  const rows = await supabaseAdminJson(`/rest/v1/trip_likes?user_id=eq.${encodeURIComponent(userId)}&select=trip_id`, { method: 'GET' }).catch(() => []);
  return uniq((Array.isArray(rows) ? rows : []).map((row) => row.trip_id));
}

async function recountTripLikes(tripIds = []) {
  const ids = uniq(tripIds);
  for (const tripId of ids) {
    const rows = await supabaseAdminJson(`/rest/v1/trip_likes?trip_id=eq.${encodeURIComponent(tripId)}&select=user_id`, { method: 'GET' }).catch(() => []);
    const likeCount = Array.isArray(rows) ? rows.length : 0;
    await supabaseAdminFetch(`/rest/v1/trips?id=eq.${encodeURIComponent(tripId)}`, {
      method: 'PATCH',
      body: JSON.stringify({ like_count: likeCount }),
      headers: { Prefer: 'return=minimal' }
    });
  }
  return ids.length;
}

async function deleteOrphanChats() {
  const chats = await supabaseAdminJson('/rest/v1/chats?select=id,chat_type,name', { method: 'GET' }).catch(() => []);
  const members = await supabaseAdminJson('/rest/v1/chat_members?select=chat_id,user_id', { method: 'GET' }).catch(() => []);
  const memberCountByChat = new Map();
  (Array.isArray(members) ? members : []).forEach((row) => {
    const key = String(row?.chat_id || '').trim();
    if (!key) return;
    memberCountByChat.set(key, (memberCountByChat.get(key) || 0) + 1);
  });
  const orphanIds = uniq((Array.isArray(chats) ? chats : []).filter((chat) => {
    const count = Number(memberCountByChat.get(String(chat?.id || '').trim()) || 0);
    if (String(chat?.chat_type || '') === 'dm') return count < 2;
    return count === 0;
  }).map((chat) => chat.id));
  for (const batch of chunk(orphanIds, 100)) {
    await supabaseAdminFetch(`/rest/v1/chats?id=in.(${encodeIdList(batch)})`, {
      method: 'DELETE',
      headers: { Prefer: 'return=minimal' }
    });
  }
  return orphanIds.length;
}

app.post('/api/ai/chat', async (req, res) => {
  try {
    if (!OPENAI_API_KEY) {
      return res.status(500).json({ error: 'OPENAI_API_KEY is not configured on server' });
    }
    const payload = req.body || {};
    const upstream = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify(payload)
    });
    const data = await upstream.json();
    res.status(upstream.status).json(data);
  } catch (err) {
    res.status(500).json({ error: err?.message || 'proxy failed' });
  }
});

app.post('/api/account/delete', async (req, res) => {
  try {
    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      return res.status(500).json({ error: 'SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY is not configured on server' });
    }

    const authHeader = String(req.headers.authorization || '');
    const accessToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
    if (!accessToken) {
      return res.status(401).json({ error: 'Missing access token' });
    }

    const nickname = String(req.body?.nickname || '').trim();
    const reason = String(req.body?.reason || '').trim();
    if (!nickname) {
      return res.status(400).json({ error: 'nickname is required' });
    }

    const authUser = await getUserFromAccessToken(accessToken);
    if (!authUser?.id) {
      return res.status(401).json({ error: 'Invalid auth session' });
    }

    const expectedEmail = buildAuthEmailFromNickname(nickname);
    const currentEmail = String(authUser.email || '').trim().toLowerCase();
    if (currentEmail !== expectedEmail.toLowerCase()) {
      return res.status(403).json({ error: '当前登录账号与待删除账号不匹配' });
    }

    const userRows = await supabaseAdminJson(`/rest/v1/app_users?nickname=eq.${encodeURIComponent(nickname)}&select=id,nickname&limit=1`, {
      method: 'GET',
      headers: { Prefer: 'return=representation' }
    }).catch(() => []);
    const appUser = Array.isArray(userRows) && userRows.length ? userRows[0] : null;

    const appUserId = String(appUser?.id || '').trim();
    const storagePaths = await collectUserStoragePaths(appUserId);
    const affectedTripIds = await fetchAffectedTripIdsForLikeRecount(appUserId);
    const deletedAdminEvents = await deleteAdminEventsByNickname(nickname);

    if (appUserId) {
      const deleteBusinessResp = await supabaseAdminFetch(`/rest/v1/app_users?id=eq.${encodeURIComponent(appUserId)}`, {
        method: 'DELETE',
        headers: { Prefer: 'return=minimal' }
      });
      if (!deleteBusinessResp.ok) {
        const deleteBusinessText = await deleteBusinessResp.text();
        return res.status(deleteBusinessResp.status).json({ error: deleteBusinessText || 'Failed to delete app user data' });
      }
    }

    const recountedTrips = await recountTripLikes(affectedTripIds).catch(() => 0);
    const deletedStorageObjects = await deleteStorageObjects(storagePaths).catch(() => 0);
    const deletedOrphanChatCount = await deleteOrphanChats().catch(() => 0);

    const deleteAuthResp = await supabaseAdminFetch(`/auth/v1/admin/users/${encodeURIComponent(authUser.id)}`, {
      method: 'DELETE'
    });
    if (!deleteAuthResp.ok) {
      const deleteAuthText = await deleteAuthResp.text();
      return res.status(deleteAuthResp.status).json({ error: deleteAuthText || 'Failed to delete auth user' });
    }

    const summary = {
      nickname,
      authUserId: authUser.id,
      deletedBusinessUser: Boolean(appUserId),
      deletedAuthUser: true,
      deletedAdminEvents,
      deletedStorageObjects,
      recountedTrips,
      deletedOrphanChatCount,
      storageBucket: STORAGE_BUCKET
    };
    console.log('[account-delete]', JSON.stringify({ ...summary, reason }));
    return res.json({ success: true, ...summary });
  } catch (err) {
    return res.status(500).json({ error: err?.message || 'account delete failed' });
  }
});

app.listen(PORT, () => {
  console.log(`AI proxy listening on :${PORT}`);
});
