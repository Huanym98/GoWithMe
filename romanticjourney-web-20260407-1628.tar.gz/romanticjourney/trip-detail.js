const STORAGE_KEY = 'romanticJourneyState';

const params = new URLSearchParams(window.location.search);
const id = params.get('id') || '';
const user = params.get('user') || '';
const card = document.querySelector('#tripCard');
const personDialog = document.querySelector('#personDialog');
const personDialogClose = document.querySelector('#personDialogClose');
const personAvatar = document.querySelector('#personAvatar');
const personMeta = document.querySelector('#personMeta');
const personRelation = document.querySelector('#personRelation');
const personSkills = document.querySelector('#personSkills');
const personHomeBtn = document.querySelector('#personHomeBtn');
const shareCardDialog = document.querySelector('#shareCardDialog');
const shareCardDialogClose = document.querySelector('#shareCardDialogClose');
const shareCardDownloadBtn = document.querySelector('#shareCardDownloadBtn');
const shareCardPreview = document.querySelector('#shareCardPreview');
const defaultAvatar = 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=80&q=80';

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function findTrip() {
  if (user) {
    try {
      const parsed = JSON.parse(localStorage.getItem(`${STORAGE_KEY}:${user}`) || '{}');
      const list = Array.isArray(parsed.trips) ? parsed.trips : [];
      const found = list.find((trip) => String(trip.id || '') === id);
      if (found) return found;
    } catch {
      // ignore
    }
  }
  for (let i = 0; i < localStorage.length; i += 1) {
    const key = localStorage.key(i) || '';
    if (!key.startsWith(`${STORAGE_KEY}:`)) continue;
    try {
      const parsed = JSON.parse(localStorage.getItem(key) || '{}');
      const list = Array.isArray(parsed.trips) ? parsed.trips : [];
      const found = list.find((trip) => String(trip.id || '') === id);
      if (found) return found;
    } catch {
      // ignore
    }
  }
  return null;
}

function getUserState(nickname) {
  if (!nickname) return null;
  try {
    const parsed = JSON.parse(localStorage.getItem(`${STORAGE_KEY}:${nickname}`) || '{}');
    return parsed && typeof parsed === 'object' ? parsed : null;
  } catch {
    return null;
  }
}

function formatTime(iso) {
  if (!iso) return '未知';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '未知';
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hour = String(date.getHours()).padStart(2, '0');
  const minute = String(date.getMinutes()).padStart(2, '0');
  return `${date.getFullYear()}-${month}-${day} ${hour}:${minute}`;
}

function openPersonDialog(nickname) {
  if (!personDialog) return;
  const state = getUserState(nickname) || {};
  const profile = state.profile || {};
  if (personAvatar) personAvatar.src = profile.avatar || defaultAvatar;
  if (personMeta) personMeta.textContent = `${nickname || '未知用户'} ｜ MBTI: ${profile.mbti || '未知'} ｜ 星座: ${profile.zodiac || '未知'}`;
  if (personRelation) personRelation.textContent = `旅行节奏：${profile.pace || '未知'} ｜ 作息：${profile.wakeUp || '未知'}`;
  if (personSkills) personSkills.textContent = `技能标签：${Array.isArray(profile.skills) && profile.skills.length ? profile.skills.join('、') : '暂无'}`;
  if (personHomeBtn) personHomeBtn.onclick = () => { window.location.href = `account.html?user=${encodeURIComponent(nickname)}`; };
  if (typeof personDialog.showModal === 'function') personDialog.showModal();
}

function normalizeList(input) {
  if (Array.isArray(input)) return input.map((item) => String(item || '').trim()).filter(Boolean);
  return String(input || '')
    .split(/[,，、\/]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function mapCountryCode(destination) {
  const value = String(destination || '').trim().toLowerCase();
  const mapping = {
    norway: 'norway',
    挪威: 'norway',
    france: 'france',
    法国: 'france',
    japan: 'japan',
    日本: 'japan',
    korea: 'korea',
    韩国: 'korea',
    china: 'china',
    中国: 'china',
    usa: 'usa',
    us: 'usa',
    美国: 'usa'
  };
  return mapping[value] || value || 'generic';
}

async function fetchBackgroundAsset(destination, tags) {
  const supa = window.RJSupabase;
  if (!supa?.normalizeConfig) return null;
  const { url, anonKey } = supa.normalizeConfig();
  if (!url || !anonKey) return null;

  const countryCode = mapCountryCode(destination);
  const endpoint = new URL(`${url}/rest/v1/background_assets`);
  endpoint.searchParams.set('select', '*');
  endpoint.searchParams.set('country_code', `eq.${countryCode}`);
  endpoint.searchParams.set('is_active', 'eq.true');
  endpoint.searchParams.set('order', 'priority.asc,created_at.desc');

  const res = await fetch(endpoint.toString(), {
    headers: {
      apikey: anonKey,
      Authorization: `Bearer ${anonKey}`,
      Accept: 'application/json'
    }
  });
  if (!res.ok) return null;
  const rows = await res.json();
  if (!Array.isArray(rows) || !rows.length) return null;

  const normalizedTags = normalizeList(tags);
  const scored = rows.map((row) => {
    const rowTags = Array.isArray(row.tags) ? row.tags : [];
    const score = normalizedTags.filter((tag) => rowTags.includes(tag)).length;
    return { ...row, __score: score };
  }).sort((a, b) => (b.__score - a.__score) || ((a.priority || 999) - (b.priority || 999)));

  return scored[0] || rows[0];
}

function makeTitle(trip) {
  const destination = trip.destination || '旅行';
  const depart = trip.departDate ? new Date(trip.departDate) : null;
  const ret = trip.returnDate ? new Date(trip.returnDate) : null;
  let durationText = '';
  if (depart instanceof Date && !Number.isNaN(depart) && ret instanceof Date && !Number.isNaN(ret)) {
    const days = Math.round((ret - depart) / 86400000) + 1;
    if (days > 1) durationText = `${days}天${days - 1}晚`;
  }
  return `${destination}${durationText ? ` ${durationText}` : ''}旅行计划`;
}

function buildShareCardMarkup(trip, profile, backgroundUrl) {
  const tagList = normalizeList(trip.tags);
  const spots = normalizeList(trip.spots);
  const destination = escapeHtml(trip.destination || '未知');
  const budget = escapeHtml(trip.budget || '0');
  const departDate = escapeHtml(trip.departDate || '未知');
  const returnDate = escapeHtml(trip.returnDate || '未知');
  const nickname = escapeHtml(trip.user || '匿名用户');
  const avatar = escapeHtml(profile.avatar || trip.avatar || defaultAvatar);
  const title = escapeHtml(makeTitle(trip));
  const tagsText = tagList.length ? tagList.join(' / ') : '暂无';
  const spotsText = spots.length ? spots.join('、') : '暂无';
  const birthday = escapeHtml(profile.birthday || '未知');
  const zodiac = escapeHtml(profile.zodiac || '未知');
  const mbti = escapeHtml(profile.mbti || '未知');
  const pace = escapeHtml(profile.pace || trip.pace || '未知');
  const budgetLevel = escapeHtml(profile.budgetLevel || '未知');
  const wakeUp = escapeHtml(profile.wakeUp || trip.wakeUp || '未知');
  const social = escapeHtml(profile.social || trip.social || '未知');

  return `
    <div class="share-card-canvas" style="background-image: linear-gradient(180deg, rgba(8,15,30,.10) 0%, rgba(8,15,30,.26) 100%), url('${escapeHtml(backgroundUrl || '')}');">
      <div class="share-card-top">
        <img class="share-card-logo" src="assets/nav-logo.svg" alt="歌觅 Go With Me" />
        <p class="share-card-slogan">寻找同频旅行搭子</p>
      </div>
      <h2 class="share-card-title">${title}</h2>

      <section class="share-card-panel">
        <div class="share-field-row"><span class="share-field-label">目的地</span><span class="share-field-value">${destination}</span></div>
        <div class="share-field-row"><span class="share-field-label">预算（元）</span><span class="share-field-value">${budget}</span></div>
        <div class="share-field-row"><span class="share-field-label">出发日期</span><span class="share-field-value">${departDate}</span></div>
        <div class="share-field-row"><span class="share-field-label">返程日期</span><span class="share-field-value">${returnDate}</span></div>
        <div class="share-field-row"><span class="share-field-label">行程标签</span><span class="share-field-value">${escapeHtml(tagsText)}</span></div>
        <div class="share-field-row"><span class="share-field-label">想去景点</span><span class="share-field-value">${escapeHtml(spotsText)}</span></div>
      </section>

      <section class="share-profile-panel">
        <div class="share-profile-head">
          <img class="share-profile-avatar" src="${avatar}" alt="${nickname}头像" />
          <div>
            <h3 class="share-profile-name">${nickname}</h3>
          </div>
        </div>
        <div class="share-profile-grid">
          <div><span>生日</span><strong>${birthday}</strong></div>
          <div><span>星座</span><strong>${zodiac}</strong></div>
          <div><span>MBTI</span><strong>${mbti}</strong></div>
          <div><span>旅行节奏</span><strong>${pace}</strong></div>
          <div><span>预算偏好</span><strong>${budgetLevel}</strong></div>
          <div><span>作息</span><strong>${wakeUp}</strong></div>
          <div><span>社交偏好</span><strong>${social}</strong></div>
        </div>
      </section>

      <div class="share-card-footer">
        <div class="share-card-cta">更多旅行计划，见歌觅 Go With Me</div>
        <div class="share-card-url">https://romanticjourney.cn/</div>
      </div>
    </div>
  `;
}

async function openShareCard(trip) {
  if (!shareCardDialog || !shareCardPreview) return;
  const state = getUserState(trip.user || user) || {};
  const profile = state.profile || {};
  const background = await fetchBackgroundAsset(trip.destination, trip.tags);
  const backgroundUrl = background?.public_url || '';

  shareCardPreview.innerHTML = buildShareCardMarkup(trip, profile, backgroundUrl);
  if (typeof shareCardDialog.showModal === 'function') shareCardDialog.showModal();
}

async function downloadShareCard() {
  const canvasNode = shareCardPreview?.querySelector('.share-card-canvas');
  if (!canvasNode || typeof window.html2canvas !== 'function') return;
  const canvas = await window.html2canvas(canvasNode, {
    useCORS: true,
    allowTaint: false,
    backgroundColor: null,
    scale: 2
  });
  const link = document.createElement('a');
  link.download = 'trip-share-card.png';
  link.href = canvas.toDataURL('image/png');
  link.click();
}

function render() {
  const trip = findTrip();
  if (!trip) {
    card.innerHTML = '<h2>行程不存在</h2>';
    return;
  }

  const tags = Array.isArray(trip.tags) ? trip.tags.map((tag) => `#${escapeHtml(tag)}`).join(' ') : '';
  const spots = Array.isArray(trip.spots) ? trip.spots.map((spot) => escapeHtml(spot)).join('、') : escapeHtml(normalizeList(trip.spots).join('、') || '暂无');
  const comments = Array.isArray(trip.comments) ? trip.comments : [];
  const likeCount = Number(trip.likeCount || 0);
  const shareUrl = `${window.location.origin}${window.location.pathname}?id=${encodeURIComponent(trip.id)}&user=${encodeURIComponent(trip.user || user)}`;

  card.innerHTML = `
    <h2>${escapeHtml(trip.destination || '未知目的地')}</h2>
    <div class="author-row" style="margin:.4rem 0 .65rem;">
      <img class="author-avatar" id="tripAuthorAvatar" src="${escapeHtml(trip.avatar || defaultAvatar)}" alt="${escapeHtml(trip.user || '匿名')}头像" />
      <button id="tripAuthorHomeBtn" type="button" class="ghost">${escapeHtml(trip.user || '匿名')}</button>
    </div>
    <p class="hint">发布用户：${escapeHtml(trip.user || '匿名')} ｜ 点赞：${likeCount} ｜ 评论：${comments.length}</p>
    <p class="hint">时间：${escapeHtml(trip.departDate || '未知')} → ${escapeHtml(trip.returnDate || '未知')} ｜ 预算：¥${escapeHtml(trip.budget || '0')}</p>
    <p>${escapeHtml(trip.itinerary || '暂无详细安排')}</p>
    <p class="hint">标签：${tags || '暂无'}</p>
    <p class="hint">景点：${spots}</p>
    <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin:.75rem 0;">
      <button id="shareTripBtn" class="share-pill" type="button">生成分享卡片</button>
      <button id="copyTripLinkBtn" class="ghost" type="button">复制链接</button>
    </div>
    <p id="shareResult" class="hint" style="word-break:break-all;"></p>
    <h3>所有评论</h3>
    <div class="msg-list">
      ${comments.length
    ? comments.map((comment) => `<article class="msg-item trip-comment-item"><img class="comment-avatar" data-user="${escapeHtml(comment.user || '')}" src="${escapeHtml(comment.avatar || defaultAvatar)}" alt="${escapeHtml(comment.user || '匿名')}头像" /><div><p><strong>${escapeHtml(comment.user || '匿名')}</strong></p><p>${escapeHtml(comment.text || '')}</p><small>${formatTime(comment.createdAt)}</small></div></article>`).join('')
    : '<p class="hint">暂无评论。</p>'}
    </div>
  `;

  const goAuthorHome = () => {
    const owner = trip.user || user;
    if (!owner) return;
    window.location.href = `account.html?user=${encodeURIComponent(owner)}`;
  };
  document.querySelector('#tripAuthorAvatar')?.addEventListener('click', goAuthorHome);
  document.querySelector('#tripAuthorHomeBtn')?.addEventListener('click', goAuthorHome);

  const shareResult = document.querySelector('#shareResult');
  document.querySelector('#shareTripBtn')?.addEventListener('click', async () => {
    shareResult.textContent = '';
    try {
      await openShareCard(trip);
    } catch (error) {
      console.error(error);
      shareResult.textContent = '生成分享卡片失败，请稍后重试。';
    }
  });

  document.querySelector('#copyTripLinkBtn')?.addEventListener('click', async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(shareUrl);
        shareResult.textContent = `转发链接已复制：${shareUrl}`;
        return;
      }
    } catch {
      // ignore
    }
    shareResult.textContent = `转发链接：${shareUrl}`;
  });

  card.querySelectorAll('.comment-avatar[data-user]').forEach((el) => {
    el.style.cursor = 'pointer';
    el.title = '查看用户主页';
    el.addEventListener('click', () => {
      const nickname = el.dataset.user || '';
      if (!nickname) return;
      window.location.href = `account.html?user=${encodeURIComponent(nickname)}`;
    });
  });
}

personDialogClose?.addEventListener('click', () => personDialog.close());
shareCardDialogClose?.addEventListener('click', () => shareCardDialog.close());
shareCardDownloadBtn?.addEventListener('click', downloadShareCard);

render();
