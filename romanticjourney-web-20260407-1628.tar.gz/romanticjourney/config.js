window.APP_CONFIG = {
  SUPABASE_URL: 'https://yhidxvctvxacoxlmxluu.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_LWqfudFulZwZH16EdZwHQQ_DXrmwnGq',
  STORAGE_BUCKET: 'Trip_Photos',
  // AI 功能不要把 OpenAI key 放前端，这里只配置你服务器上的代理接口地址
  AI_ENDPOINT: 'https://romanticjourney.cn/api/ai/chat',
  AI_MODEL: 'gpt-5.2'
};
