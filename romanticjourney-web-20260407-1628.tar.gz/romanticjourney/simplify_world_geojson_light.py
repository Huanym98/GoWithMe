import json, sys

def simplify_ring(points, step):
    if len(points) <= 8:
        return points
    out = points[::step]
    if out[0] != points[0]:
        out.insert(0, points[0])
    if out[-1] != points[-1]:
        out.append(points[-1])
    return out

def simplify_coords(coords, step):
    if not coords:
        return coords
    if isinstance(coords[0][0], (int, float)):
        return simplify_ring(coords, step)
    return [simplify_coords(c, step) for c in coords]

src = sys.argv[1]
dst = sys.argv[2]
step = int(sys.argv[3]) if len(sys.argv) > 3 else 6

with open(src, "r", encoding="utf-8") as f:
    data = json.load(f)

for feat in data.get("features", []):
    geom = feat.get("geometry") or {}
    coords = geom.get("coordinates")
    if coords:
        geom["coordinates"] = simplify_coords(coords, step)

with open(dst, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, separators=(",", ":"))

print(f"written: {dst}")
