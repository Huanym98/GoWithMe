/* integrated base patch: prefer lite geojson, keep 2D default, preserve current app behavior */
const { createApp, reactive, computed, onMounted, onUnmounted, ref, watch, nextTick } = Vue;

const KEYS = {
  USERS: 'romanticJourneyUsers',
  CURRENT: 'romanticJourneyCurrentUser',
  SOCIAL: 'romanticJourneySocial',
  ADMIN: 'romanticJourneyAdminEvents',
  NOTICE: 'romanticJourneyNoticeState',
  NOTICE_PREFIX: 'romanticJourneyNoticeState:',
  SUPPORT: 'romanticJourneySupportCount',
  LANG: 'romanticJourneyLang',
  STATE_PREFIX: 'romanticJourneyState:',
  OPENAI_KEY: 'romanticJourneyOpenAIKey'
};// Canvas dot-text morph component (no fade/flip). Requires dot-morph.js -> window.DotMorph
const DotTextMorph = {
  props: {
    text: { type: String, required: true },
    kind: { type: String, default: 'hero' }, // 'hero' | 'inline'
  },
  template: `<div :class="['dottext-host', 'dottext-' + kind]" ref="host" aria-hidden="true"></div>`,
  setup(props){
    const host = ref(null);
    let inst = null;
    let ro = null;
    let resizeTimer = null;

    const getMetrics = () => {
      const el = host.value;
      const isHero = props.kind === 'hero';
      const vw = typeof window !== 'undefined' ? window.innerWidth || 0 : 0;
      const hostWidth = Math.max(0, Math.round(el?.clientWidth || 0));
      const width = isHero
        ? Math.max(220, Math.min(860, hostWidth || (vw > 0 ? Math.min(vw - 64, 860) : 860)))
        : Math.max(180, Math.min(320, hostWidth || 320));
      const mobileHero = isHero && vw <= 768;
      const height = isHero ? (mobileHero ? 96 : 160) : 48;
      const fontSize = isHero ? (mobileHero ? Math.max(34, Math.min(72, Math.round(width * 0.17))) : 118) : 26;
      const particleCount = isHero ? (mobileHero ? 3400 : 6200) : 1700;
      const dotRadius = isHero ? (mobileHero ? 1.08 : 1.32) : 1.15;
      return { isHero, width, height, fontSize, particleCount, dotRadius };
    };

    const destroy = () => {
      try { inst && inst.stop(); } catch (e) {}
      inst = null;
    };

    const mountMorph = (immediate=true) => {
      const el = host.value;
      if (!el || !window.DotMorph) return;
      const m = getMetrics();
      destroy();
      inst = new window.DotMorph(el, {
        width: m.width,
        height: m.height,
        particleCount: m.particleCount,
        dotRadius: m.dotRadius,
        cluster: 1,
        clusterSpread: m.isHero ? 1.0 : 0.9,
        fontSize: m.fontSize,
        fontWeight: 420,
        morphMs: 2200,
        holdMs: 2800,
        spring: 0.060,
        damping: 0.86,
        maxSpeed: 5.5,
        color: '#0f172a',
        bg: 'transparent',
        threshold: 16,
        supersample: 3.0,
        debug: false,
        text: props.text,
      });
      inst.start([props.text]);
      if (props.text) inst.setText(props.text, { immediate });
    };

    const scheduleRemount = () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => mountMorph(true), 80);
    };

    onMounted(()=>{
      mountMorph(true);
      if (typeof ResizeObserver !== 'undefined' && host.value) {
        ro = new ResizeObserver(() => scheduleRemount());
        ro.observe(host.value);
      }
      if (typeof window !== 'undefined') window.addEventListener('resize', scheduleRemount, { passive: true });
    });

    onUnmounted(()=>{
      clearTimeout(resizeTimer);
      if (ro) ro.disconnect();
      if (typeof window !== 'undefined') window.removeEventListener('resize', scheduleRemount);
      destroy();
    });

    watch(()=>props.text, (v)=>{
      if (!inst || !v) return;
      inst.setText(v, { immediate: false });
    });

    return { host };
  }
};

const AI_DEFAULT_MODEL = 'gpt-5.2';
const defaultAvatar = 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=160&q=80';
const HERO_CAROUSEL = [
  { lang: 'zh-CN', text: '歌觅' },
  { lang: 'en', text: 'Go With Me' },
  { lang: 'ja', text: '一緒に行こう' },
  { lang: 'ko', text: '함께 가요' },
  { lang: 'fr', text: 'Viens avec moi' },
  { lang: 'es', text: 'Ven conmigo' },
  { lang: 'de', text: 'Komm mit mir' },
  { lang: 'it', text: 'Vieni con me' }
];

const read = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k) || 'null'); return v ?? d; } catch { return d; } };
const write = (k, v) => localStorage.setItem(k, JSON.stringify(v));
const uid = () => crypto.randomUUID();
const now = () => new Date().toISOString();
const fmt = (t) => new Date(t || Date.now()).toLocaleString('zh-CN', { hour12: false });
function calcAgeFromBirthday(birthday) {
  const raw = String(birthday || '').trim();
  if (!raw) return '';
  let birth = null;
  if (/^\d{4}-\d{2}$/.test(raw)) {
    birth = new Date(`${raw}-01`);
  } else {
    birth = new Date(raw);
  }
  if (!birth || Number.isNaN(birth.getTime())) return '';
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  const dayDiff = today.getDate() - birth.getDate();
  if (monthDiff < 0 || (monthDiff === 0 && dayDiff < 0)) age -= 1;
  return age >= 0 ? String(age) : '';
}

function normalizeMonthValue(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  if (/^\d{4}-\d{2}$/.test(raw)) return raw;
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw.slice(0, 7);
  const match = raw.match(/^(\d{4}-\d{2})/);
  return match ? match[1] : '';
}
const list = (s) => String(s || '').split(',').map((x) => x.trim()).filter(Boolean);
async function optimizeImageFile(file, { maxEdge = 1600, quality = 0.82, targetBytes = 1200 * 1024 } = {}) {
  if (!(file instanceof File) || !file.type.startsWith('image/')) return file;
  if (Number(file.size || 0) <= targetBytes && !/png|bmp|tiff|heic|heif/i.test(file.type)) return file;

  const objectUrl = URL.createObjectURL(file);
  try {
    const bitmap = typeof createImageBitmap === 'function'
      ? await createImageBitmap(file).catch(() => null)
      : null;
    const image = bitmap || await new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => resolve(null);
      img.src = objectUrl;
    });
    const width = image?.width || image?.naturalWidth || 0;
    const height = image?.height || image?.naturalHeight || 0;
    if (!width || !height) return file;

    const scale = Math.min(1, maxEdge / Math.max(width, height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(width * scale));
    canvas.height = Math.max(1, Math.round(height * scale));
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return file;
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);

    const attemptBlob = (q) => new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', q));
    let blob = await attemptBlob(quality);
    if (!blob) return file;
    if (blob.size > targetBytes) blob = await attemptBlob(0.72) || blob;
    if (blob.size > targetBytes) blob = await attemptBlob(0.64) || blob;
    if (blob.size >= file.size * 0.95) return file;
    const baseName = String(file.name || `img-${Date.now()}`).replace(/\.[^.]+$/, '');
    return new File([blob], `${baseName}.jpg`, { type: 'image/jpeg', lastModified: Date.now() });
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

function toDisplayImageUrl(url, width = 900, quality = 72) {
  const raw = String(url || '').trim();
  if (!raw) return '';
  if (!/\/storage\/v1\/object\/public\//.test(raw)) return raw;
  const transformed = raw.replace('/storage/v1/object/public/', '/storage/v1/render/image/public/');
  const sep = transformed.includes('?') ? '&' : '?';
  return `${transformed}${sep}width=${Math.max(120, Number(width || 900))}&quality=${Math.max(30, Number(quality || 72))}&resize=contain`;
}

function revokePreviewList(items) {
  (Array.isArray(items) ? items : []).forEach((item) => {
    if (item?.previewUrl && String(item.previewUrl).startsWith('blob:')) {
      try { URL.revokeObjectURL(item.previewUrl); } catch {}
    }
  });
}

const MAX_DIARY_UPLOAD_COUNT = 18;
const MAX_DIARY_TOTAL_MB = 500;
const ADMIN_UID = '6e21e1a2-6256-40ab-8a91-e337efaa4521';
function isAdminAuthUserId(id) { return !!id && id === ADMIN_UID; }
const MAX_DIARY_TOTAL_BYTES = MAX_DIARY_TOTAL_MB * 1024 * 1024;

const WORLD_MAP_DEMO_DESTINATIONS = [
  { id: 'tokyo', country: '日本', city: '东京', name: '东京', lat: 35.6762, lng: 139.6503, tone: 'rgba(255,196,82,.95)', badges: ['🍜', '🌸', '🚶'], summary: '樱花、拉面、citywalk、人气展览', users: [{ name: '98年的小可乐', avatar: defaultAvatar }, { name: 'lion', avatar: defaultAvatar }] },
  { id: 'seoul', country: '韩国', city: '首尔', name: '首尔', lat: 37.5665, lng: 126.9780, tone: 'rgba(255,140,92,.95)', badges: ['🍗', '🛍️', '🌃'], summary: '美食、购物、夜生活', users: [{ name: 'guoguoer', avatar: defaultAvatar }] },
  { id: 'paris', country: '法国', city: '巴黎', name: '巴黎', lat: 48.8566, lng: 2.3522, tone: 'rgba(255,126,172,.95)', badges: ['🥐', '🗼', '🎨'], summary: '面包、铁塔、艺术博物馆', users: [{ name: '15948880099', avatar: defaultAvatar }] },
  { id: 'nairobi', country: '肯尼亚', city: '内罗毕', name: '内罗毕', lat: -1.2921, lng: 36.8219, tone: 'rgba(118,213,129,.95)', badges: ['🦒', '🦁', '🌿'], summary: '野生动物、草原日落、自然探索', users: [] },
  { id: 'sydney', country: '澳大利亚', city: '悉尼', name: '悉尼', lat: -33.8688, lng: 151.2093, tone: 'rgba(99,210,255,.95)', badges: ['🐨', '🏄', '☕'], summary: '考拉、冲浪、海边生活方式', users: [{ name: '1620725218@qq.com', avatar: defaultAvatar }] },
  { id: 'istanbul', country: '土耳其', city: '伊斯坦布尔', name: '伊斯坦布尔', lat: 41.0082, lng: 28.9784, tone: 'rgba(195,153,255,.95)', badges: ['☕', '🕌', '🐈'], summary: '咖啡、清真寺、街头猫咪', users: [] }
];


const WORLD_COORDS = {
  '日本': { lat: 35.6762, lng: 139.6503, country: '日本', city: '东京', name: '东京', badges: ['🍜','🌸'] },
  '东京': { lat: 35.6762, lng: 139.6503, country: '日本', city: '东京', name: '东京', badges: ['🍜','🌸'] },
  '韩国': { lat: 37.5665, lng: 126.9780, country: '韩国', city: '首尔', name: '首尔', badges: ['🍗','🛍️'] },
  '首尔': { lat: 37.5665, lng: 126.9780, country: '韩国', city: '首尔', name: '首尔', badges: ['🍗','🛍️'] },
  '香港': { lat: 22.3193, lng: 114.1694, country: '中国香港', city: '香港', name: '香港', badges: ['🌃','🍜'] },
  '美国': { lat: 39.8283, lng: -98.5795, country: '美国', city: '美国', name: '美国', badges: ['🗽','🎬'] },
  '纽约': { lat: 40.7128, lng: -74.0060, country: '美国', city: '纽约', name: '纽约', badges: ['🗽','🍔'] },
  '法国': { lat: 48.8566, lng: 2.3522, country: '法国', city: '巴黎', name: '巴黎', badges: ['🥐','🗼'] },
  '巴黎': { lat: 48.8566, lng: 2.3522, country: '法国', city: '巴黎', name: '巴黎', badges: ['🥐','🗼'] },
  '意大利': { lat: 41.9028, lng: 12.4964, country: '意大利', city: '罗马', name: '罗马', badges: ['🍝','🏛️'] },
  '罗马': { lat: 41.9028, lng: 12.4964, country: '意大利', city: '罗马', name: '罗马', badges: ['🍝','🏛️'] },
  '土耳其': { lat: 41.0082, lng: 28.9784, country: '土耳其', city: '伊斯坦布尔', name: '伊斯坦布尔', badges: ['☕','🕌'] },
  '伊斯坦布尔': { lat: 41.0082, lng: 28.9784, country: '土耳其', city: '伊斯坦布尔', name: '伊斯坦布尔', badges: ['☕','🕌'] },
  '澳大利亚': { lat: -33.8688, lng: 151.2093, country: '澳大利亚', city: '悉尼', name: '悉尼', badges: ['🐨','🏄'] },
  '悉尼': { lat: -33.8688, lng: 151.2093, country: '澳大利亚', city: '悉尼', name: '悉尼', badges: ['🐨','🏄'] },
  '秘鲁': { lat: -13.5319, lng: -71.9675, country: '秘鲁', city: '库斯科', name: '秘鲁', badges: ['⛰️','📷'] },
  '智利': { lat: -33.4489, lng: -70.6693, country: '智利', city: '圣地亚哥', name: '智利', badges: ['🌄','🍷'] }
};

function normalizeWorldLocationKey(value) {
  return String(value || '').trim().toLowerCase().replace(/\s+/g, '');
}
function resolveWorldCoordByText(value) {
  const raw = String(value || '').trim();
  if (!raw) return null;
  const parts = raw.split(/[、,，\/|\s]+/).filter(Boolean);
  const candidates = [raw, ...parts];
  for (const item of candidates) {
    if (WORLD_COORDS[item]) return { ...WORLD_COORDS[item] };
  }
  const meta = resolveCountryMeta(raw);
  if (meta) {
    const aliases = COUNTRY_META?.[meta.code]?.aliases || [];
    for (const alias of aliases) {
      if (WORLD_COORDS[alias]) return { ...WORLD_COORDS[alias] };
    }
  }
  return null;
}

function resolveWorldCoordsFromTrip(trip) {
  const source = trip && typeof trip === 'object' ? trip : {};
  const textPool = [
    source.destination,
    source.title,
    Array.isArray(source.spots) ? source.spots.join('、') : source.spots,
    Array.isArray(source.tags) ? source.tags.join('、') : source.tags
  ].filter(Boolean);

  const seen = new Map();
  textPool.forEach((text) => {
    const raw = String(text || '').trim();
    if (!raw) return;
    const normalized = raw
      .replace(/和|及|与|跟|&|and/gi, '、')
      .replace(/->|→|－|—|~|～/g, '、');
    const parts = normalized.split(/[、,，\/|\s]+/).filter(Boolean);
    const candidates = [raw, normalized, ...parts];
    candidates.forEach((item) => {
      const coord = resolveWorldCoordByText(item);
      if (!coord) return;
      const key = `${coord.country || ''}|${coord.city || ''}`;
      if (!seen.has(key)) seen.set(key, coord);
    });
  });

  return Array.from(seen.values());
}
function normalizeTripDateForCompare(value) {
  const raw = String(value || '').trim();
  if (!raw) return null;
  const date = new Date(raw);
  if (Number.isNaN(date.getTime())) return null;
  date.setHours(0,0,0,0);
  return date;
}
function isFutureTripDate(value) {
  const date = normalizeTripDateForCompare(value);
  if (!date) return false;
  const today = new Date();
  today.setHours(0,0,0,0);
  return date.getTime() >= today.getTime();
}
function worldPointStyle(item) {
  const left = Math.max(4, Math.min(94, ((Number(item?.lng || 0) + 180) / 360) * 100));
  const top = Math.max(8, Math.min(90, ((90 - Number(item?.lat || 0)) / 180) * 100));
  return { left: `${left}%`, top: `${top}%` };
}

const WORLD_CONTINENT_VIEW = {
  global: { center: [18, 18], zoom: 1.55, lat: 18, lng: 18, altitude: 2.05 },
  asia: { center: [100, 28], zoom: 2.25, lat: 28, lng: 100, altitude: 1.85 },
  europe: { center: [15, 50], zoom: 2.45, lat: 50, lng: 15, altitude: 1.8 },
  'north-america': { center: [-102, 42], zoom: 2.15, lat: 42, lng: -102, altitude: 1.88 },
  'south-america': { center: [-60, -18], zoom: 2.25, lat: -18, lng: -60, altitude: 1.88 },
  africa: { center: [20, 6], zoom: 2.1, lat: 6, lng: 20, altitude: 1.9 },
  oceania: { center: [142, -24], zoom: 2.3, lat: -24, lng: 142, altitude: 1.88 },
  antarctica: { center: [0, -78], zoom: 2.2, lat: -78, lng: 0, altitude: 1.92 }
};

function focusWorldContinent(continent = 'global') { return; }

function syncWorldContinentView(continent = 'global', selected = null) { return; }


let __worldMapCssLoaded = false;
let __worldMapSdkPromise = null;
let __worldGlobeSdkPromise = null;
let __worldGeoJsonPromise = null;
let __worldGeoJsonData = null;


function ensureWorldMapStyles() {
  if (document.getElementById('gemi-world-map-style')) return;
  const style = document.createElement('style');
  style.id = 'gemi-world-map-style';
  style.textContent = `
    .gemi-map-wrap {
      position:relative;
      min-height: 640px;
      border-radius: 28px;
      overflow:hidden;
      border:1px solid rgba(255,255,255,.08);
      box-shadow: inset 0 0 0 1px rgba(255,255,255,.03);
      background:
        radial-gradient(circle at 16% 14%, rgba(71,148,255,.18), transparent 24%),
        radial-gradient(circle at 78% 16%, rgba(255,174,199,.16), transparent 24%),
        radial-gradient(circle at 66% 78%, rgba(255,214,110,.14), transparent 26%),
        linear-gradient(180deg, rgba(5,14,22,.96), rgba(7,13,23,.98));
      isolation: isolate;
    }
    .gemi-map-canvas {
      position:absolute;
      inset:0;
    }
    .gemi-globe-canvas {
      position:absolute;
      inset:0;
      z-index:1;
      display:none;
    }
    .gemi-globe-canvas.is-active {
      display:block;
    }
    .gemi-globe-canvas canvas {
      width:100% !important;
      height:100% !important;
      outline:none;
    }
    .gemi-map-wrap .maplibregl-canvas-container,
    .gemi-map-wrap .maplibregl-canvas {
      width:100% !important;
      height:100% !important;
    }
    .gemi-map-wrap .maplibregl-canvas {
      filter: saturate(.70) contrast(1.08) brightness(.74) hue-rotate(175deg);
    }
    .gemi-map-wrap .maplibregl-ctrl-bottom-right,
    .gemi-map-wrap .maplibregl-ctrl-bottom-left { display:none !important; }
    .gemi-map-wrap .maplibregl-ctrl-top-right { top: 14px; right: 14px; }
    .gemi-map-wrap .maplibregl-ctrl-group {
      border-radius: 16px !important;
      overflow: hidden;
      box-shadow: 0 10px 28px rgba(0,0,0,.24) !important;
      border: 1px solid rgba(255,255,255,.12) !important;
      background: rgba(9, 18, 31, .86) !important;
      backdrop-filter: blur(10px);
    }
    .gemi-map-wrap .maplibregl-ctrl button {
      background: transparent !important;
      color: #fff !important;
    }
    .gemi-map-wrap .maplibregl-marker { z-index: 4; }
    .gemi-map-overlay {
      position:absolute;
      inset:0;
      pointer-events:none;
      z-index:2;
      background:
        linear-gradient(180deg, rgba(6,13,24,.10), rgba(6,13,24,.24)),
        radial-gradient(circle at 20% 18%, rgba(89,164,255,.10), transparent 24%),
        radial-gradient(circle at 80% 18%, rgba(255,150,197,.10), transparent 22%),
        radial-gradient(circle at 68% 75%, rgba(255,205,107,.08), transparent 24%);
      mix-blend-mode: multiply;
    }
    .gemi-map-frame {
      position:absolute;
      inset:18px;
      border-radius:22px;
      border:1px solid rgba(255,255,255,.06);
      pointer-events:none;
      z-index:3;
    }

    .gemi-country-hover { z-index: 9 !important; }
    .gemi-country-hover .maplibregl-popup-content {
      background: rgba(9,18,31,.94);
      color: #fff;
      border: 1px solid rgba(255,255,255,.12);
      border-radius: 12px;
      padding: 6px 10px;
      font-size: 12px;
      line-height: 1.2;
      box-shadow: 0 10px 22px rgba(0,0,0,.24);
      backdrop-filter: blur(8px);
    }
    .gemi-country-hover .maplibregl-popup-tip {
      border-top-color: rgba(9,18,31,.94) !important;
      border-bottom-color: rgba(9,18,31,.94) !important;
    }
    .gemi-map-hint {
      position:absolute;
      right:18px;
      bottom:58px;
      z-index:5;
      padding:8px 12px;
      border-radius:999px;
      background:rgba(9,18,31,.72);
      border:1px solid rgba(255,255,255,.08);
      color:rgba(255,255,255,.76);
      font-size:12px;
      backdrop-filter: blur(8px);
    }
    .gemi-map-chipbar {
      position:absolute; left:18px; bottom:18px;
      display:flex; gap:8px; flex-wrap:wrap;
      pointer-events:none;
      z-index:5;
    }
    .gemi-map-chipbar span {
      padding:8px 12px;
      border-radius:999px;
      background:rgba(255,255,255,.08);
      border:1px solid rgba(255,255,255,.08);
      font-size:12px;
      color:rgba(255,255,255,.78);
      backdrop-filter: blur(6px);
    }
    .gemi-world-marker {
      position: relative;
      transform: translate(-50%, -100%);
      cursor: pointer;
      user-select: none;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .gemi-world-marker__card {
      min-width: 138px;
      max-width: 176px;
      color: #fff;
      border-radius: 18px;
      border: 1px solid rgba(255,255,255,.12);
      backdrop-filter: blur(12px);
      padding: 10px 12px;
      box-shadow: 0 16px 28px rgba(0,0,0,.28);
      transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease;
    }
    .gemi-world-marker:hover .gemi-world-marker__card {
      transform: translateY(-2px);
      box-shadow: 0 20px 34px rgba(0,0,0,.32);
      border-color: rgba(255,255,255,.18);
    }
    .gemi-world-marker.is-active .gemi-world-marker__card {
      border-color: rgba(255,255,255,.24);
      box-shadow: 0 22px 38px rgba(0,0,0,.36);
    }
    .gemi-world-marker__top {
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:8px;
      font-size: 13px;
      font-weight: 800;
      margin-bottom: 4px;
    }
    .gemi-world-marker__top strong {
      font-size: 14px;
      line-height: 1.2;
      color: #fff;
    }
    .gemi-world-marker__badges {
      font-size: 12px;
      opacity: .95;
      white-space: nowrap;
    }
    .gemi-world-marker__meta {
      font-size: 12px;
      color: rgba(255,255,255,.78);
      line-height: 1.3;
    }
    .gemi-world-marker__stem {
      width: 2px;
      height: 16px;
      background: linear-gradient(180deg, rgba(255,255,255,.55), rgba(255,255,255,.08));
      margin-top: 2px;
    }
    .gemi-world-marker__dot {
      width: 16px;
      height: 16px;
      border-radius: 999px;
      margin-top: 0;
      border: 2px solid rgba(255,244,214,.7);
    }
    .gemi-world-pulse { animation: worldPulseSoft 1.9s ease-out infinite; opacity:.95; }
    .gemi-world-pulse.is-strong { animation: worldPulseStrong 1.35s ease-out infinite; }
    .gemi-world-marker.is-planned-soft .gemi-world-marker__dot,
    .gemi-world-marker.is-planned-strong .gemi-world-marker__dot { animation: worldDotBlink 1.4s ease-in-out infinite; }
    @keyframes worldPulseSoft {
      0% { transform:translateX(-50%) scale(.78); opacity:.8; }
      100% { transform:translateX(-50%) scale(1.8); opacity:0; }
    }
    @keyframes worldPulseStrong {
      0% { transform:translateX(-50%) scale(.72); opacity:.95; }
      100% { transform:translateX(-50%) scale(2.15); opacity:0; }
    }
    @keyframes worldDotBlink { 0%,100% { opacity:1; } 50% { opacity:.35; } }
    .gemi-world-panel {
      display:block;
    }
    .gemi-world-full {
      position: relative;
      min-height: calc(100vh - 220px);
      border-radius: 28px;
      overflow: hidden;
      border:1px solid rgba(255,255,255,.08);
      background: linear-gradient(180deg, rgba(7,18,30,.92), rgba(8,16,28,.98));
      box-shadow: 0 24px 64px rgba(0,0,0,.18);
    }
    .gemi-world-topbar {
      position:absolute;
      left:18px;
      right:18px;
      top:18px;
      z-index:6;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      flex-wrap:wrap;
      pointer-events:none;
    }
    .gemi-world-topbar > * { pointer-events:auto; }
    .gemi-world-searchbar {
      margin-left:auto;
      display:flex;
      gap:10px;
      align-items:center;
      flex-wrap:wrap;
    }
    .gemi-world-searchbar input,
    .gemi-world-searchbar select {
      background: rgba(9,18,31,.78);
      color:#fff;
      border:1px solid rgba(255,255,255,.1);
      border-radius:14px;
      padding:12px 14px;
      min-width:220px;
      backdrop-filter: blur(10px);
    }
    .gemi-world-toggle {
      display:inline-flex;
      gap:6px;
      padding:4px;
      border-radius:14px;
      background:rgba(9,18,31,.78);
      border:1px solid rgba(255,255,255,.08);
      backdrop-filter: blur(10px);
      box-shadow: 0 10px 28px rgba(0,0,0,.22);
    }
    .gemi-world-toggle button {
      appearance:none;
      border:0;
      border-radius:12px;
      padding:10px 16px;
      background:transparent;
      color:rgba(255,255,255,.76);
      font-weight:800;
      cursor:pointer;
    }
    .gemi-world-toggle button.active {
      background:rgba(63,255,141,.92);
      color:#09111f;
      box-shadow:0 8px 18px rgba(0,0,0,.18);
    }
    .gemi-map-wrap {
      position:absolute;
      inset:0;
      min-height:unset;
      border:none;
      border-radius:0;
      box-shadow:none;
      background:
        radial-gradient(circle at 16% 14%, rgba(71,148,255,.18), transparent 24%),
        radial-gradient(circle at 78% 16%, rgba(255,174,199,.16), transparent 24%),
        radial-gradient(circle at 66% 78%, rgba(255,214,110,.14), transparent 26%),
        linear-gradient(180deg, rgba(5,14,22,.96), rgba(7,13,23,.98));
      isolation: isolate;
    }
    .gemi-world-floating-card {
      position:absolute;
      left:18px;
      top:88px;
      z-index:6;
      width:min(330px, calc(100vw - 72px));
      padding:16px 16px 14px;
      border-radius:22px;
      border:1px solid rgba(255,255,255,.08);
      background:rgba(14,24,39,.78);
      backdrop-filter: blur(14px);
      box-shadow:0 18px 38px rgba(0,0,0,.26);
      resize: both;
      overflow:auto;
      min-width:260px;
      min-height:120px;
      max-width:560px;
      max-height:70vh;
    }
    .gemi-world-floating-card.is-collapsed {
      width:240px;
      min-height:auto;
      resize:none;
      overflow:hidden;
    }
    .gemi-world-floating-card .chip {
      display:inline-flex;
      margin-bottom:12px;
    }
    .gemi-world-floating-card h3 {
      margin:0 0 8px;
      font-size:28px;
      line-height:1.04;
    }
    .gemi-world-floating-card p {
      margin:0 0 14px;
      color:rgba(255,255,255,.76);
      line-height:1.7;
    }
    .gemi-world-badges {
      display:flex;
      flex-wrap:wrap;
      gap:8px;
      margin-bottom:16px;
    }
    .gemi-world-badges span {
      padding:8px 10px;
      border-radius:14px;
      background:rgba(255,255,255,.07);
      border:1px solid rgba(255,255,255,.08);
      font-size:15px;
    }
    .gemi-world-stats {
      display:grid;
      grid-template-columns:1fr 1fr;
      gap:12px;
      padding:14px;
      border-radius:20px;
      background:rgba(255,255,255,.05);
      margin-bottom:12px;
    }
    .gemi-world-stats strong {
      display:block;
      font-size:32px;
      margin-top:4px;
    }
    .gemi-map-hint {
      right:18px;
      bottom:18px;
      z-index:6;
    }
    .gemi-map-chipbar { bottom:18px; left:18px; z-index:6; }
    .gemi-map-wrap .maplibregl-ctrl-top-right { top: 84px; right: 18px; z-index: 6; }
    @media (max-width: 980px) {
      .gemi-world-topbar {
        position:static;
        padding:18px 18px 0;
      }
      .gemi-world-full { min-height: calc(100vh - 180px); }
      .gemi-world-floating-card {
        position:static;
        margin:86px 18px 0;
        width:auto;
      }
      .gemi-map-wrap { inset:0; }
    }
  `;
  document.head.appendChild(style);
}


try { if (typeof document !== 'undefined') ensureWorldMapStyles(); } catch {}

function loadWorldMapSdk() {
  if (window.maplibregl) {
    ensureWorldMapStyles();
    return Promise.resolve(window.maplibregl);
  }
  if (window.__gemiBootMapLibre && typeof window.__gemiBootMapLibre.then === 'function') {
    return window.__gemiBootMapLibre.then((maplibre) => {
      ensureWorldMapStyles();
      return maplibre || window.maplibregl;
    });
  }
  if (__worldMapSdkPromise) return __worldMapSdkPromise;
  __worldMapSdkPromise = new Promise((resolve, reject) => {
    if (!__worldMapCssLoaded) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = '/assets/vendor/maplibre-gl.min.css';
      link.onload = () => { __worldMapCssLoaded = true; };
      link.onerror = () => { console.warn('[world-map] local css missing /assets/vendor/maplibre-gl.min.css'); };
      document.head.appendChild(link);
    }
    ensureWorldMapStyles();
    const script = document.createElement('script');
    script.src = '/assets/vendor/maplibre-gl.min.js';
    script.async = false;
    script.defer = false;
    script.onload = () => window.maplibregl ? resolve(window.maplibregl) : reject(new Error('MapLibre loaded but window.maplibregl missing'));
    script.onerror = () => reject(new Error('MapLibre 本地静态资源加载失败：/assets/vendor/maplibre-gl.min.js 未找到或无法访问'));
    document.head.appendChild(script);
  });
  return __worldMapSdkPromise;
}

async function loadScriptOnce(src, globalKey) {
  if (globalKey && window[globalKey]) return window[globalKey];
  const existing = Array.from(document.querySelectorAll('script')).find((node) => node.src === src);
  await new Promise((resolve, reject) => {
    const script = existing || document.createElement('script');
    script.src = src;
    script.async = false;
    script.defer = false;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error(`脚本加载失败：${src}`));
    if (!existing) document.head.appendChild(script);
  });
  if (globalKey && !window[globalKey]) throw new Error(`脚本已加载，但未找到 ${globalKey}`);
  return globalKey ? window[globalKey] : true;
}

function loadWorldGlobeSdk() {
  if (window.Globe) return Promise.resolve(window.Globe);
  if (__worldGlobeSdkPromise) return __worldGlobeSdkPromise;
  __worldGlobeSdkPromise = (async () => {
    // globe.gl 的 UMD 包本身会带上所需的 Three 依赖。
    // 这里如果再手动加载 three.min.js，会触发 Multiple instances of Three.js being imported，
    // 导致 3D 地球仪初始化异常或按钮点击后无反应。
    await loadScriptOnce('/assets/vendor/globe.gl.min.js', 'Globe');
    return window.Globe;
  })();
  return __worldGlobeSdkPromise;
}


async function loadWorldGeoJson() {
  if (__worldGeoJsonData) return __worldGeoJsonData;
  if (__worldGeoJsonPromise) return __worldGeoJsonPromise;
  __worldGeoJsonPromise = fetch('/assets/vendor/world-countries-lite.geojson', { cache: 'force-cache' })
    .then((res) => {
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.json();
    })
    .then((geojson) => {
      __worldGeoJsonData = geojson;
      return geojson;
    })
    .catch((err) => {
      __worldGeoJsonPromise = null;
      throw err;
    });
  return __worldGeoJsonPromise;
}

function preloadWorldAssets() {
  try {
    loadWorldMapSdk().catch(() => {});
    loadWorldGeoJson().catch(() => {});
  } catch {}
}

function makeWorldMarkerHtml(point, active = false) {
  const tone = String(point?.tone || 'rgba(255,196,82,.95)');
  const city = String(point?.city || point?.name || '未知地点');
  const visited = Number(point?.visitedCount || 0);
  const planned = Number(point?.plannedCount || 0);
  const badges = (Array.isArray(point?.badges) ? point.badges : []).slice(0, 2).join(' ');
  const activeCardBg = active
    ? 'linear-gradient(180deg, rgba(18,39,67,.98), rgba(10,28,52,.98))'
    : 'linear-gradient(180deg, rgba(17,29,45,.92), rgba(11,22,37,.92))';

  return `
    <div class="gemi-world-marker ${active ? 'is-active' : ''}">
      <div class="gemi-world-marker__card" style="background:${activeCardBg}">
        <div class="gemi-world-marker__top">
          <strong>${city}</strong>
          <span class="gemi-world-marker__badges">${badges}</span>
        </div>
        <div class="gemi-world-marker__meta">去过 ${visited} · 计划 ${planned}</div>
      </div>
      <div class="gemi-world-marker__stem"></div>
      <div class="gemi-world-marker__dot" style="background:${tone};box-shadow:0 0 0 6px rgba(255,196,82,.14), 0 0 18px ${tone};"></div>
    </div>
  `;
}
function formatBytesToMB(bytes) {
  const value = Number(bytes || 0) / (1024 * 1024);
  if (!Number.isFinite(value)) return '0.00';
  return (Math.ceil(value * 100) / 100).toFixed(2);
}

function safeSetState(user, state, failMessage = '保存失败：可能是图片过大/过多，或浏览器本地存储空间不足。请减少图片或清理旧数据后重试。') {
  try {
    setState(user, state);
    return true;
  } catch (error) {
    const msg = String(error?.name || error?.message || '');
    if (msg.includes('QuotaExceeded')) {
      alert(failMessage);
      return false;
    }
    throw error;
  }
}

const I18N = {
  'zh-CN': {
    appName: '歌觅 Go With Me', navHome: '首页', navMy: '我的主页', navMsg: '消息', navSearch: '查询', navAdmin: '后台',
    logout: '退出', notLogin: '未登录', profile: '个人资料', close: '关闭', saveProfile: '保存资料', gender: '性别', male: '男', female: '女', navPublish: '发布行程',
    loginTitle: '歌觅', loginHint: '请输入账户名与密码，系统将自动登录或注册。', nickname: '账户名', password: '密码', loginBtn: '登录 / 注册', registerBtn: '注册',
    publishTrip: '发布行程', destination: '目的地', budgetYuan: '预算（元）', departDate: '出发日期', returnDate: '返程日期',
    tripTags: '行程标签（逗号分隔）', spotsWant: '想去景点（逗号分隔）', itinerary: '详细行程', publish: '发布',
    messagePreview: '消息预览', noMessage: '暂无消息', viewAllMessages: '查看全部消息',
    tripSquare: '行程广场', searchAll: '搜索用户/目的地',
    myTrips: '我的行程', noTripYet: '还没有发布行程', viewDetail: '查看详情',
    myDiaries: '我的日记', myBadges: '我的勋章',
    globalSearch: '全站查询', searchPlaceholder: '搜索用户/行程/日记', account: '账户', trip: '行程', diary: '日记',
    accountHome: '的主页', recentTrips: '最近行程', profileInfo: '资料', badges: '勋章', taDiary: 'Ta 的日记', noDiary: '暂无日记', backSearch: '← 返回查询',
    messageCenter: '消息中心', markRead: '全部已读', chatMsg: '聊天消息', sysMsg: '系统消息', noChatMsg: '暂无聊天消息', noSysMsg: '暂无系统消息',
    admin: '管理后台', users: '用户', trips: '行程', diaries: '日记', recentEvents: '最近事件', kpiOverview: '活跃度速览', totalUsers: '总用户数', newUsers7d: '本周新增用户', newTrips7d: '本周新增行程', newDiaries7d: '本周新增日记', activeUsers7d: '近7天活跃用户',
    aiGenerate: '🤖 AI自动生成行程（GPT-5.2）', aiGenerating: 'AI 生成中...', aiWaiting: 'AI 正在生成中，请稍候…', aiKeyMissing: 'AI 功能未配置，请由管理员在服务器端配置 OPENAI_API_KEY 并设置 config.js 中的 AI_ENDPOINT', aiNeedDestination: '请先填写目的地', aiRequestFailed: 'AI请求失败', aiGenerateFailed: 'AI生成失败'
  },
  en: {
    appName: 'Go With Me', navHome: 'Home', navMy: 'My Home', navMsg: 'Messages', navSearch: 'Search', navAdmin: 'Admin', logout: 'Logout', notLogin: 'Guest',
    profile: 'Profile', close: 'Close', saveProfile: 'Save Profile', gender: 'Gender', male: 'Male', female: 'Female', navPublish: 'Publish Trip', loginTitle: 'Go With Me', loginHint: 'Enter account and password, system will auto login/register.', nickname: 'Nickname', password: 'Password', loginBtn: 'Login / Register', registerBtn: 'Register',
    publishTrip: 'Publish Trip', destination: 'Destination', budgetYuan: 'Budget (CNY)', departDate: 'Departure', returnDate: 'Return', tripTags: 'Tags (comma-separated)', spotsWant: 'Spots (comma-separated)', itinerary: 'Itinerary', publish: 'Publish',
    messagePreview: 'Message Preview', noMessage: 'No messages', viewAllMessages: 'View all messages', tripSquare: 'Trip Square', searchAll: 'Search user/destination',
    myTrips: 'My Trips', noTripYet: 'No trips yet', viewDetail: 'View', myDiaries: 'My Diaries', myBadges: 'My Badges',
    globalSearch: 'Global Search', searchPlaceholder: 'Search users/trips/diaries', account: 'Accounts', trip: 'Trips', diary: 'Diaries',
    accountHome: "'s Home", recentTrips: 'Recent Trips', profileInfo: 'Profile', badges: 'Badges', taDiary: 'Diaries', noDiary: 'No diaries', backSearch: '← Back to Search',
    messageCenter: 'Message Center', markRead: 'Mark all read', chatMsg: 'Chats', sysMsg: 'System', noChatMsg: 'No chat messages', noSysMsg: 'No system messages',
    admin: 'Admin Panel', users: 'Users', trips: 'Trips', diaries: 'Diaries', recentEvents: 'Recent Events', kpiOverview: 'Activity Snapshot', totalUsers: 'Total Users', newUsers7d: 'New Users (7d)', newTrips7d: 'New Trips (7d)', newDiaries7d: 'New Diaries (7d)', activeUsers7d: 'Active Users (7d)',
    aiGenerate: '🤖 Generate Itinerary (GPT-5.2)', aiGenerating: 'Generating...', aiWaiting: 'AI is generating, please wait…', aiKeyMissing: 'AI key is missing. Configure RJ_OPENAI_API_KEY or localStorage.romanticJourneyOpenAIKey.', aiNeedDestination: 'Please enter destination first', aiRequestFailed: 'AI request failed', aiGenerateFailed: 'AI generation failed'
  },
  ko: {
    appName: 'Go With Me', navHome: '홈', navMy: '내 홈', navMsg: '메시지', navSearch: '검색', navAdmin: '관리', logout: '로그아웃', notLogin: '게스트',
    profile: '프로필', close: '닫기', saveProfile: '저장', gender: '성별', male: '남', female: '여', navPublish: '여행 등록', loginTitle: 'Go With Me', loginHint: '계정/비밀번호 입력 시 자동으로 로그인 또는 회원가입됩니다.', nickname: '닉네임', password: '비밀번호', loginBtn: '로그인 / 가입', registerBtn: '회원가입',
    publishTrip: '여행 등록', destination: '목적지', budgetYuan: '예산', departDate: '출발일', returnDate: '복귀일', tripTags: '태그(쉼표)', spotsWant: '가고 싶은 곳(쉼표)', itinerary: '일정', publish: '등록',
    messagePreview: '메시지 미리보기', noMessage: '메시지 없음', viewAllMessages: '전체 메시지', tripSquare: '여행 광장', searchAll: '사용자/목적지 검색',
    myTrips: '내 여행', noTripYet: '등록한 여행이 없습니다', viewDetail: '상세보기', myDiaries: '내 다이어리', myBadges: '내 배지',
    globalSearch: '전체 검색', searchPlaceholder: '사용자/여행/다이어리 검색', account: '계정', trip: '여행', diary: '다이어리',
    accountHome: '님의 홈', recentTrips: '최근 여행', profileInfo: '프로필', badges: '배지', taDiary: '다이어리', noDiary: '다이어리 없음', backSearch: '← 검색으로',
    messageCenter: '메시지 센터', markRead: '모두 읽음', chatMsg: '채팅', sysMsg: '시스템', noChatMsg: '채팅 없음', noSysMsg: '시스템 메시지 없음',
    admin: '관리 패널', users: '사용자', trips: '여행', diaries: '다이어리', recentEvents: '최근 이벤트', kpiOverview: '활동 개요', totalUsers: '총 사용자', newUsers7d: '최근 7일 신규 사용자', newTrips7d: '최근 7일 신규 여행', newDiaries7d: '최근 7일 신규 다이어리', activeUsers7d: '최근 7일 활성 사용자',
    aiGenerate: '🤖 AI 일정 생성 (GPT-5.2)', aiGenerating: '생성 중...', aiWaiting: 'AI가 일정을 생성 중입니다. 잠시만 기다려 주세요…', aiKeyMissing: 'AI 키가 없습니다. RJ_OPENAI_API_KEY 또는 localStorage.romanticJourneyOpenAIKey를 설정하세요.', aiNeedDestination: '먼저 목적지를 입력해 주세요', aiRequestFailed: 'AI 요청 실패', aiGenerateFailed: 'AI 생성 실패'
  },
  ja: {
    appName: 'Go With Me', navHome: 'ホーム', navMy: 'マイページ', navMsg: 'メッセージ', navSearch: '検索', navAdmin: '管理', logout: 'ログアウト', notLogin: 'ゲスト',
    profile: 'プロフィール', close: '閉じる', saveProfile: '保存', gender: '性別', male: '男', female: '女', navPublish: '旅程を投稿', loginTitle: 'Go With Me', loginHint: 'アカウントとパスワード入力で自動ログイン/登録します。', nickname: 'ニックネーム', password: 'パスワード', loginBtn: 'ログイン / 登録', registerBtn: '登録',
    publishTrip: '旅程を投稿', destination: '目的地', budgetYuan: '予算', departDate: '出発日', returnDate: '帰着日', tripTags: 'タグ（カンマ）', spotsWant: '行きたい場所（カンマ）', itinerary: '詳細日程', publish: '投稿',
    messagePreview: 'メッセージプレビュー', noMessage: 'メッセージなし', viewAllMessages: 'すべて表示', tripSquare: '旅程広場', searchAll: 'ユーザー/目的地を検索',
    myTrips: '自分の旅程', noTripYet: 'まだ旅程がありません', viewDetail: '詳細を見る', myDiaries: '自分の日記', myBadges: '自分のバッジ',
    globalSearch: 'サイト内検索', searchPlaceholder: 'ユーザー/旅程/日記を検索', account: 'アカウント', trip: '旅程', diary: '日記',
    accountHome: 'のホーム', recentTrips: '最近の旅程', profileInfo: 'プロフィール', badges: 'バッジ', taDiary: '日記', noDiary: '日記なし', backSearch: '← 検索へ戻る',
    messageCenter: 'メッセージセンター', markRead: 'すべて既読', chatMsg: 'チャット', sysMsg: 'システム', noChatMsg: 'チャットなし', noSysMsg: 'システム通知なし',
    admin: '管理パネル', users: 'ユーザー', trips: '旅程', diaries: '日記', recentEvents: '最近のイベント', kpiOverview: 'アクティブ指標', totalUsers: '総ユーザー数', newUsers7d: '今週の新規ユーザー', newTrips7d: '今週の新規旅程', newDiaries7d: '今週の新規日記', activeUsers7d: '直近7日のアクティブユーザー',
    aiGenerate: '🤖 AIで旅程生成 (GPT-5.2)', aiGenerating: '生成中...', aiWaiting: 'AIが旅程を生成しています。しばらくお待ちください…', aiKeyMissing: 'AIキーが未設定です。RJ_OPENAI_API_KEY または localStorage.romanticJourneyOpenAIKey を設定してください。', aiNeedDestination: '先に目的地を入力してください', aiRequestFailed: 'AIリクエスト失敗', aiGenerateFailed: 'AI生成失敗'
  },
  fr: {
    appName: 'Go With Me', navHome: 'Accueil', navMy: 'Mon espace', navMsg: 'Messages', navSearch: 'Recherche', navAdmin: 'Admin', logout: 'Déconnexion', notLogin: 'Invité',
    profile: 'Profil', close: 'Fermer', saveProfile: 'Enregistrer', gender: 'Genre', male: 'Homme', female: 'Femme', navPublish: 'Publier un voyage', loginTitle: 'Go With Me', loginHint: 'Entrez compte et mot de passe, connexion/inscription auto.', nickname: 'Pseudo', password: 'Mot de passe', loginBtn: 'Connexion / Inscription', registerBtn: 'Inscription',
    publishTrip: 'Publier un voyage', destination: 'Destination', budgetYuan: 'Budget', departDate: 'Départ', returnDate: 'Retour', tripTags: 'Tags (virgule)', spotsWant: 'Lieux souhaités (virgule)', itinerary: 'Itinéraire', publish: 'Publier',
    messagePreview: 'Aperçu des messages', noMessage: 'Aucun message', viewAllMessages: 'Voir tous les messages', tripSquare: 'Place des voyages', searchAll: 'Rechercher utilisateur/destination',
    myTrips: 'Mes voyages', noTripYet: 'Aucun voyage publié', viewDetail: 'Voir détail', myDiaries: 'Mes journaux', myBadges: 'Mes badges',
    globalSearch: 'Recherche globale', searchPlaceholder: 'Rechercher utilisateurs/voyages/journaux', account: 'Comptes', trip: 'Voyages', diary: 'Journaux',
    accountHome: ' - profil', recentTrips: 'Voyages récents', profileInfo: 'Profil', badges: 'Badges', taDiary: 'Journaux', noDiary: 'Aucun journal', backSearch: '← Retour recherche',
    messageCenter: 'Centre de messages', markRead: 'Tout marquer lu', chatMsg: 'Chats', sysMsg: 'Système', noChatMsg: 'Aucun chat', noSysMsg: 'Aucun message système',
    admin: 'Console admin', users: 'Utilisateurs', trips: 'Voyages', diaries: 'Journaux', recentEvents: 'Événements récents', kpiOverview: "Aperçu d'activité", totalUsers: 'Utilisateurs totaux', newUsers7d: 'Nouveaux utilisateurs (7j)', newTrips7d: 'Nouveaux voyages (7j)', newDiaries7d: 'Nouveaux journaux (7j)', activeUsers7d: 'Utilisateurs actifs (7j)',
    aiGenerate: '🤖 Générer l’itinéraire (GPT-5.2)', aiGenerating: 'Génération…', aiWaiting: 'L’IA génère votre itinéraire, veuillez patienter…', aiKeyMissing: 'Clé IA manquante. Configurez RJ_OPENAI_API_KEY ou localStorage.romanticJourneyOpenAIKey.', aiNeedDestination: 'Veuillez saisir la destination d’abord', aiRequestFailed: 'Échec de la requête IA', aiGenerateFailed: 'Échec de génération IA'
  },
  es: {
    appName: 'Go With Me', navHome: 'Inicio', navMy: 'Mi perfil', navMsg: 'Mensajes', navSearch: 'Buscar', navAdmin: 'Admin', logout: 'Cerrar sesión', notLogin: 'Invitado',
    profile: 'Perfil', close: 'Cerrar', saveProfile: 'Guardar perfil', loginTitle: 'Go With Me', loginHint: 'Introduce tu cuenta y contraseña. El sistema iniciará sesión o te registrará automáticamente.', nickname: 'Cuenta', password: 'Contraseña', loginBtn: 'Entrar / Registrarse', registerBtn: 'Registrarse',
    publishTrip: 'Publicar viaje', destination: 'Destino', budgetYuan: 'Presupuesto', departDate: 'Salida', returnDate: 'Regreso', tripTags: 'Etiquetas (separadas por comas)', spotsWant: 'Lugares que quieres visitar (comas)', itinerary: 'Itinerario', publish: 'Publicar',
    messagePreview: 'Vista previa', noMessage: 'Sin mensajes', viewAllMessages: 'Ver todos', tripSquare: 'Plaza de viajes', searchAll: 'Buscar usuario/destino',
    myTrips: 'Mis viajes', noTripYet: 'Aún no hay viajes', viewDetail: 'Ver', myDiaries: 'Mis diarios', myBadges: 'Mis insignias',
    globalSearch: 'Búsqueda global', searchPlaceholder: 'Buscar usuarios/viajes/diarios', account: 'Cuentas', trip: 'Viajes', diary: 'Diarios',
    accountHome: ' - perfil', recentTrips: 'Viajes recientes', profileInfo: 'Perfil', badges: 'Insignias', taDiary: 'Diarios', noDiary: 'Sin diarios', backSearch: '← Volver',
    messageCenter: 'Centro de mensajes', markRead: 'Marcar todo leído', chatMsg: 'Chats', sysMsg: 'Sistema', noChatMsg: 'Sin chats', noSysMsg: 'Sin mensajes del sistema',
    admin: 'Panel admin', users: 'Usuarios', trips: 'Viajes', diaries: 'Diarios', recentEvents: 'Eventos recientes', kpiOverview: 'Resumen de actividad', totalUsers: 'Usuarios totales', newUsers7d: 'Nuevos usuarios (7d)', newTrips7d: 'Nuevos viajes (7d)', newDiaries7d: 'Nuevos diarios (7d)', activeUsers7d: 'Usuarios activos (7d)',
    aiGenerate: '🤖 Generar itinerario (GPT-5.2)', aiGenerating: 'Generando…', aiWaiting: 'La IA está generando el itinerario. Espera un momento…', aiKeyMissing: 'Falta la clave de IA. Configura RJ_OPENAI_API_KEY o localStorage.romanticJourneyOpenAIKey.', aiNeedDestination: 'Primero introduce el destino', aiRequestFailed: 'La solicitud de IA falló', aiGenerateFailed: 'La generación falló'
  },
  de: {
    appName: 'Go With Me', navHome: 'Start', navMy: 'Mein Profil', navMsg: 'Nachrichten', navSearch: 'Suche', navAdmin: 'Admin', logout: 'Abmelden', notLogin: 'Gast',
    profile: 'Profil', close: 'Schließen', saveProfile: 'Profil speichern', loginTitle: 'Go With Me', loginHint: 'Gib Konto und Passwort ein. Das System meldet dich automatisch an oder registriert dich.', nickname: 'Konto', password: 'Passwort', loginBtn: 'Anmelden / Registrieren', registerBtn: 'Registrieren',
    publishTrip: 'Reise veröffentlichen', destination: 'Ziel', budgetYuan: 'Budget', departDate: 'Abreise', returnDate: 'Rückkehr', tripTags: 'Tags (mit Komma)', spotsWant: 'Orte, die du besuchen möchtest (Komma)', itinerary: 'Reiseplan', publish: 'Veröffentlichen',
    messagePreview: 'Nachrichtenvorschau', noMessage: 'Keine Nachrichten', viewAllMessages: 'Alle anzeigen', tripSquare: 'Reiseplatz', searchAll: 'Benutzer/Ziel suchen',
    myTrips: 'Meine Reisen', noTripYet: 'Noch keine Reisen', viewDetail: 'Ansehen', myDiaries: 'Meine Tagebücher', myBadges: 'Meine Abzeichen',
    globalSearch: 'Globale Suche', searchPlaceholder: 'Benutzer/Reisen/Tagebücher suchen', account: 'Konten', trip: 'Reisen', diary: 'Tagebücher',
    accountHome: ' - Profil', recentTrips: 'Letzte Reisen', profileInfo: 'Profil', badges: 'Abzeichen', taDiary: 'Tagebücher', noDiary: 'Keine Tagebücher', backSearch: '← Zurück',
    messageCenter: 'Nachrichtenzentrum', markRead: 'Alles als gelesen markieren', chatMsg: 'Chats', sysMsg: 'System', noChatMsg: 'Keine Chats', noSysMsg: 'Keine Systemnachrichten',
    admin: 'Admin-Konsole', users: 'Benutzer', trips: 'Reisen', diaries: 'Tagebücher', recentEvents: 'Letzte Ereignisse', kpiOverview: 'Aktivitätsübersicht', totalUsers: 'Gesamtbenutzer', newUsers7d: 'Neue Benutzer (7d)', newTrips7d: 'Neue Reisen (7d)', newDiaries7d: 'Neue Tagebücher (7d)', activeUsers7d: 'Aktive Benutzer (7d)',
    aiGenerate: '🤖 Reiseplan erstellen (GPT-5.2)', aiGenerating: 'Wird erstellt…', aiWaiting: 'Die KI erstellt gerade den Reiseplan. Bitte kurz warten…', aiKeyMissing: 'KI-Schlüssel fehlt. Konfiguriere RJ_OPENAI_API_KEY oder localStorage.romanticJourneyOpenAIKey.', aiNeedDestination: 'Bitte zuerst das Ziel eingeben', aiRequestFailed: 'KI-Anfrage fehlgeschlagen', aiGenerateFailed: 'KI-Erstellung fehlgeschlagen'
  },
  it: {
    appName: 'Go With Me', navHome: 'Home', navMy: 'Il mio profilo', navMsg: 'Messaggi', navSearch: 'Cerca', navAdmin: 'Admin', logout: 'Esci', notLogin: 'Ospite',
    profile: 'Profilo', close: 'Chiudi', saveProfile: 'Salva profilo', gender: 'Genere', male: 'Uomo', female: 'Donna', navPublish: 'Pubblica viaggio', loginTitle: 'Go With Me', loginHint: 'Inserisci account e password. Il sistema effettuerà automaticamente l’accesso o la registrazione.', nickname: 'Account', password: 'Password', loginBtn: 'Accedi / Registrati', registerBtn: 'Registrati',
    publishTrip: 'Pubblica viaggio', destination: 'Destinazione', budgetYuan: 'Budget', departDate: 'Partenza', returnDate: 'Rientro', tripTags: 'Tag (separati da virgole)', spotsWant: 'Luoghi da visitare (virgole)', itinerary: 'Itinerario', publish: 'Pubblica',
    messagePreview: 'Anteprima messaggi', noMessage: 'Nessun messaggio', viewAllMessages: 'Vedi tutti', tripSquare: 'Piazza viaggi', searchAll: 'Cerca utente/destinazione',
    myTrips: 'I miei viaggi', noTripYet: 'Nessun viaggio ancora', viewDetail: 'Vedi', myDiaries: 'I miei diari', myBadges: 'I miei badge',
    globalSearch: 'Ricerca globale', searchPlaceholder: 'Cerca utenti/viaggi/diari', account: 'Account', trip: 'Viaggi', diary: 'Diari',
    accountHome: ' - profilo', recentTrips: 'Viaggi recenti', profileInfo: 'Profilo', badges: 'Badge', taDiary: 'Diari', noDiary: 'Nessun diario', backSearch: '← Indietro',
    messageCenter: 'Centro messaggi', markRead: 'Segna tutto come letto', chatMsg: 'Chat', sysMsg: 'Sistema', noChatMsg: 'Nessuna chat', noSysMsg: 'Nessun messaggio di sistema',
    admin: 'Console admin', users: 'Utenti', trips: 'Viaggi', diaries: 'Diari', recentEvents: 'Eventi recenti', kpiOverview: 'Panoramica attività', totalUsers: 'Utenti totali', newUsers7d: 'Nuovi utenti (7g)', newTrips7d: 'Nuovi viaggi (7g)', newDiaries7d: 'Nuovi diari (7g)', activeUsers7d: 'Utenti attivi (7g)',
    aiGenerate: '🤖 Genera itinerario (GPT-5.2)', aiGenerating: 'Generazione…', aiWaiting: 'L’IA sta generando l’itinerario. Attendi un momento…', aiKeyMissing: 'Chiave IA mancante. Configura RJ_OPENAI_API_KEY o localStorage.romanticJourneyOpenAIKey.', aiNeedDestination: 'Inserisci prima la destinazione', aiRequestFailed: 'Richiesta IA non riuscita', aiGenerateFailed: 'Generazione IA non riuscita'
  }
};

function getUsers() {
  const users = read(KEYS.USERS, []);
  return users.map((u) => (typeof u === 'string' ? { nickname: u, firstLogin: false } : u)).filter((u) => u.nickname);
}
function saveUsers(users) { write(KEYS.USERS, users); }
function normalizeState(parsed) {
  const s = parsed && typeof parsed === 'object' ? parsed : {};
  const profile = s.profile && typeof s.profile === 'object' ? s.profile : {};
  return {
    profile: {
      avatar: profile.avatar || defaultAvatar,
      birthday: profile.birthday || '',
      gender: profile.gender || '',
      mbti: profile.mbti || '',
      zodiac: profile.zodiac || '',
      pace: profile.pace || '平衡',
      budgetLevel: profile.budgetLevel || '舒适',
      wakeUp: profile.wakeUp || '自然醒',
      social: profile.social || '适中',
      bio: profile.bio || '',
      skills: Array.isArray(profile.skills) ? profile.skills : list(profile.skills)
    },
    trips: Array.isArray(s.trips) ? s.trips : [],
    mediaPosts: Array.isArray(s.mediaPosts) ? s.mediaPosts : [],
    tripBills: Array.isArray(s.tripBills) ? s.tripBills : [],
    actions: s.actions && typeof s.actions === 'object' ? s.actions : { like: [], dislike: [], save: [] }
  };
}
function getState(user) { return normalizeState(read(`${KEYS.STATE_PREFIX}${user}`, {})); }
function setState(user, state) { write(`${KEYS.STATE_PREFIX}${user}`, normalizeState(state)); }


const BILL_CURRENCY_OPTIONS = ['CNY', 'KRW', 'JPY', 'USD', 'EUR', 'GBP', 'HKD', 'TWD', 'SGD', 'THB'];
const BILL_FX_API_BASE = 'https://api.frankfurter.dev/v2';

function getBillSettlementFieldLabel(baseCurrency = 'CNY', mode = 'actual') {
  const normalized = String(baseCurrency || 'CNY').toUpperCase();
  const prefix = mode === 'estimated' ? '估算' : '实际';
  return `${prefix}${normalized}结算金额（可选）`;
}

function syncBillItemParticipantsForType(form, memberNames = []) {
  if (!form) return;
  const members = [...new Set((Array.isArray(memberNames) ? memberNames : []).filter(Boolean))];
  const current = [...new Set((Array.isArray(form.participants) ? form.participants : []).filter(Boolean))];
  const paidBy = String(form.paidBy || '').trim();
  const type = String(form.expenseType || 'public').toLowerCase();
  if (type === 'public') {
    form.participants = members.slice();
    return;
  }
  if (type === 'personal' || type === 'daigou') {
    form.participants = paidBy ? [paidBy] : [];
    return;
  }
  const filtered = current.filter((name) => members.includes(name));
  if (filtered.length) {
    form.participants = filtered;
    return;
  }
  form.participants = paidBy && members.includes(paidBy) ? [paidBy] : (members[0] ? [members[0]] : []);
}

function isBillParticipantEditable(form) {
  return String(form?.expenseType || 'public').toLowerCase() === 'partial';
}

const BILL_RECEIPT_MAX_FILES = 6;
const BILL_RECEIPT_MAX_FILE_SIZE = 10 * 1024 * 1024;

function parseBillReceiptUrls(value) {
  if (Array.isArray(value)) return value.map((item) => String(item || '').trim()).filter(Boolean);
  const raw = String(value || '').trim();
  if (!raw) return [];
  if (raw.startsWith('[')) {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed.map((item) => String(item || '').trim()).filter(Boolean);
    } catch (error) {
      console.warn('[trip-bills] parse receipt urls failed', error);
    }
  }
  return [raw];
}

function serializeBillReceiptUrls(list) {
  const values = (Array.isArray(list) ? list : []).map((item) => String(item || '').trim()).filter(Boolean);
  if (!values.length) return '';
  if (values.length === 1) return values[0];
  return JSON.stringify(values);
}

function receiptFileNameFromUrl(url, fallback = '') {
  const raw = String(url || '').trim();
  if (!raw) return fallback || '';
  try {
    const pathname = new URL(raw).pathname || '';
    const segment = pathname.split('/').pop() || '';
    return decodeURIComponent(segment) || fallback || '已上传凭证';
  } catch (error) {
    const segment = raw.split('/').pop() || '';
    return decodeURIComponent(segment) || fallback || '已上传凭证';
  }
}

function defaultBillForm() {
  return {
    expenseType: 'public',
    category: 'food',
    amountOriginal: '',
    currencyOriginal: 'CNY',
    amountCnyActual: '',
    amountCnyEstimated: '',
    fxRate: '',
    fxRateDate: '',
    fxRateSource: 'Frankfurter',
    fxStatus: '',
    fxLoading: false,
    amountEstimatedManual: false,
    paidBy: '',
    expenseTime: '',
    note: '',
    receiptImageUrl: '',
    receiptImageUrls: [],
    receiptFileName: '',
    receiptFileNames: [],
    receiptUploading: false,
    participants: [],
    status: 'pending'
  };
}

function normalizeBillRecord(raw) {
  const source = raw && typeof raw === 'object' ? raw : {};
  const members = Array.isArray(source.members) ? source.members : [];
  const items = Array.isArray(source.items) ? source.items : [];
  const events = Array.isArray(source.events) ? source.events : [];
  return {
    id: source.id || uid(),
    tripId: source.tripId || '',
    title: source.title || '行程账单',
    baseCurrency: source.baseCurrency || 'CNY',
    linkedChatId: source.linkedChatId || '',
    linkedChatName: source.linkedChatName || '',
    status: source.status || 'active',
    createdBy: source.createdBy || '',
    createdAt: source.createdAt || now(),
    updatedAt: source.updatedAt || source.createdAt || now(),
    members: members.map((m) => typeof m === 'string' ? ({ nickname: m, role: 'member', status: 'active' }) : ({
      nickname: String(m?.nickname || '').trim(),
      role: m?.role || 'member',
      status: m?.status || 'active',
      joinedAt: m?.joinedAt || null
    })).filter((m) => m.nickname),
    items: items.map((item) => ({
      id: item?.id || uid(),
      billId: item?.billId || source.id || '',
      expenseType: item?.expenseType || 'public',
      category: item?.category || 'other',
      status: item?.status || 'pending',
      amountOriginal: Number(item?.amountOriginal || 0),
      currencyOriginal: item?.currencyOriginal || 'CNY',
      amountCnyActual: item?.amountCnyActual == null || item?.amountCnyActual === '' ? null : Number(item.amountCnyActual),
      amountCnyEstimated: item?.amountCnyEstimated == null || item?.amountCnyEstimated === '' ? null : Number(item.amountCnyEstimated),
      paidBy: item?.paidBy || '',
      expenseTime: item?.expenseTime || item?.createdAt || now(),
      note: item?.note || '',
      receiptImageUrl: item?.receiptImageUrl || '',
      receiptImageUrls: parseBillReceiptUrls(item?.receiptImageUrl || item?.receiptImageUrls || ''),
      splitMethod: item?.splitMethod || 'equal',
      createdBy: item?.createdBy || '',
      createdAt: item?.createdAt || now(),
      updatedAt: item?.updatedAt || item?.createdAt || now(),
      participants: (Array.isArray(item?.participants) ? item.participants : []).map((p) => typeof p === 'string' ? ({ nickname: p, shareRatio: 0, shareAmount: 0, isIncluded: true }) : ({
        nickname: String(p?.nickname || '').trim(),
        shareRatio: Number(p?.shareRatio || 0),
        shareAmount: Number(p?.shareAmount || 0),
        isIncluded: p?.isIncluded !== false
      })).filter((p) => p.nickname)
    })),
    events: events.map((e) => ({
      id: e?.id || uid(),
      billId: e?.billId || source.id || '',
      itemId: e?.itemId || '',
      actor: e?.actor || '系统',
      eventType: e?.eventType || 'bill_updated',
      payload: e?.payload && typeof e.payload === 'object' ? e.payload : {},
      createdAt: e?.createdAt || now()
    }))
  };
}

function billSettlementAmount(item) {
  if (!item) return 0;
  if (item.amountCnyActual != null && item.amountCnyActual !== '') return Number(item.amountCnyActual || 0);
  if (item.amountCnyEstimated != null && item.amountCnyEstimated !== '') return Number(item.amountCnyEstimated || 0);
  return Number(item.amountOriginal || 0);
}

function billStatusLabel(status) {
  const map = { pending: '待确认', confirmed: '已确认', disputed: '有争议' };
  return map[String(status || '').toLowerCase()] || '待确认';
}

function billEventText(event) {
  if (!event) return '';
  const actor = event.actor || '系统';
  const payload = event.payload && typeof event.payload === 'object' ? event.payload : {};
  const note = String(payload.note || '').trim();
  const participants = Array.isArray(payload.participants) ? payload.participants.filter(Boolean) : [];
  switch (event.eventType) {
    case 'bill_created':
      return `${actor} 发起了账单`; 
    case 'members_invited':
      return `${actor} 邀请 ${Array.isArray(payload.memberNicknames) ? payload.memberNicknames.join('、') : '新成员'} 加入账单`;
    case 'item_created':
      return `${actor} 新增了一笔${note ? `「${note}」` : '费用'}${participants.length ? `，由 ${participants.join('、')} 承担` : ''}`;
    case 'item_updated':
      return `${actor} 修改了${note ? `「${note}」` : '一笔费用'}`;
    case 'item_status_changed':
      return `${actor} 将一笔费用标记为${billStatusLabel(payload.status)}`;
    case 'bill_updated':
      return `${actor} 更新了账单设置`;
    default:
      return `${actor} 更新了账单`;
  }
}

function inferFlexibleTripDate(text, kind = 'depart') {
  const raw = String(text || '').trim();
  if (!raw) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
  if (/^\d{4}[./]\d{2}[./]\d{2}$/.test(raw)) return raw.replace(/[.\/]/g, '-');
  if (/^\d{4}-\d{2}$/.test(raw)) return `${raw}-${kind === 'return' ? '28' : '01'}`;
  if (/^\d{4}[./]\d{1,2}$/.test(raw)) {
    const parts = raw.split(/[./]/);
    const year = parts[0];
    const month = String(parts[1]).padStart(2, '0');
    return `${year}-${month}-${kind === 'return' ? '28' : '01'}`;
  }
  const monthMatch = raw.match(/(\d{1,2})月/);
  if (monthMatch) {
    const now = new Date();
    let year = now.getFullYear();
    const month = Number(monthMatch[1]);
    if (month < (now.getMonth() + 1) - 1) year += 1;
    let day = kind === 'return' ? '28' : '01';
    if (/上旬/.test(raw)) day = kind === 'return' ? '10' : '01';
    else if (/中旬/.test(raw)) day = '15';
    else if (/下旬/.test(raw)) day = kind === 'return' ? '28' : '21';
    return `${year}-${String(month).padStart(2, '0')}-${day}`;
  }
  return '';
}

function getTripSyncPayload(trip) {
  if (!trip || typeof trip !== 'object') return trip;
  const inferredDepartDate = trip.departDate || inferFlexibleTripDate(trip.departFlex, 'depart');
  const inferredReturnDate = trip.returnDate || inferFlexibleTripDate(trip.returnFlex, 'return');
  return {
    ...trip,
    departDate: inferredDepartDate || '',
    returnDate: inferredReturnDate || ''
  };
}
function parseMaybeObject(value) {
  if (!value) return {};
  if (typeof value === 'object') return value;
  if (typeof value !== 'string') return {};
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function socialStorageKey(user = '') {
  const who = String(user || localStorage.getItem(KEYS.CURRENT) || 'guest').trim() || 'guest';
  return `${KEYS.SOCIAL}:${who}`;
}
function getSocial(user = '') {
  const perUserKey = socialStorageKey(user);
  const scoped = read(perUserKey, null);
  const s = scoped && typeof scoped === 'object' ? scoped : {};
  return {
    follows: s.follows && typeof s.follows === 'object' ? s.follows : {},
    blocks: s.blocks && typeof s.blocks === 'object' ? s.blocks : {},
    chats: Array.isArray(s.chats) ? s.chats : []
  };
}
function setSocial(v, user = '') { write(socialStorageKey(user), v); }
function getNoticeState(user) {
  const key = `${KEYS.NOTICE_PREFIX}${user || 'guest'}`;
  const state = read(key, {});
  return {
    chatReadAt: state && typeof state.chatReadAt === 'object' ? state.chatReadAt : {},
    systemReadAt: state?.systemReadAt || ''
  };
}
function setNoticeState(state, user) {
  const key = `${KEYS.NOTICE_PREFIX}${user || 'guest'}`;
  write(key, {
    chatReadAt: state && typeof state.chatReadAt === 'object' ? state.chatReadAt : {},
    systemReadAt: state?.systemReadAt || ''
  });
}

function matchesNickname(value, nickname) {
  return String(value || '').trim() === String(nickname || '').trim();
}
function filterNicknameArray(values, nickname) {
  return (Array.isArray(values) ? values : []).filter((value) => !matchesNickname(value, nickname));
}
function isItemOwnedByNickname(item, nickname) {
  if (!item || typeof item !== 'object') return false;
  return ['user', 'nickname', 'author', 'from', 'sender', 'owner', 'createdBy'].some((field) => matchesNickname(item[field], nickname));
}
function purgeCommentsByNickname(comments, nickname) {
  return (Array.isArray(comments) ? comments : [])
    .filter((comment) => !isItemOwnedByNickname(comment, nickname))
    .map((comment) => {
      const likes = filterNicknameArray(comment.likes, nickname);
      const likers = filterNicknameArray(comment.likers, nickname);
      const replies = purgeCommentsByNickname(comment.replies, nickname);
      return {
        ...comment,
        likes,
        likers,
        likeCount: likes.length,
        replies
      };
    });
}
function purgeTripDataByNickname(trips, nickname) {
  return (Array.isArray(trips) ? trips : [])
    .filter((trip) => !matchesNickname(trip?.user, nickname))
    .map((trip) => {
      const likes = filterNicknameArray(trip.likes, nickname);
      const likers = filterNicknameArray(trip.likers, nickname);
      const comments = purgeCommentsByNickname(trip.comments, nickname);
      return {
        ...trip,
        likes,
        likers,
        likeCount: likes.length,
        comments
      };
    });
}
function purgeMediaDataByNickname(posts, nickname) {
  return (Array.isArray(posts) ? posts : [])
    .filter((post) => !matchesNickname(post?.user, nickname))
    .map((post) => {
      const likes = filterNicknameArray(post.likes, nickname);
      const likers = filterNicknameArray(post.likers, nickname);
      const comments = purgeCommentsByNickname(post.comments, nickname);
      return {
        ...post,
        likes,
        likers,
        likeCount: likes.length,
        comments
      };
    });
}
function purgeSocialDataByNickname(social, nickname) {
  const source = social && typeof social === 'object' ? social : {};
  const nextFollows = {};
  Object.entries(source.follows || {}).forEach(([user, targets]) => {
    if (matchesNickname(user, nickname)) return;
    nextFollows[user] = filterNicknameArray(targets, nickname);
  });
  const nextBlocks = {};
  Object.entries(source.blocks || {}).forEach(([user, targets]) => {
    if (matchesNickname(user, nickname)) return;
    nextBlocks[user] = filterNicknameArray(targets, nickname);
  });
  const nextChats = (Array.isArray(source.chats) ? source.chats : [])
    .map((chat) => {
      const members = filterNicknameArray(chat?.members, nickname);
      const messages = (Array.isArray(chat?.messages) ? chat.messages : []).filter((msg) => !matchesNickname(msg?.from, nickname) && !matchesNickname(msg?.sender, nickname));
      return { ...chat, members, messages };
    })
    .filter((chat) => {
      if (!chat) return false;
      const members = Array.isArray(chat.members) ? chat.members : [];
      const isGroup = members.length > 2 || String(chat.name || '').trim();
      if (isGroup) return members.length >= 2;
      return members.length === 2;
    });
  return { ...source, follows: nextFollows, blocks: nextBlocks, chats: nextChats };
}
function shouldRemoveAdminEventForNickname(event, nickname) {
  if (!event || typeof event !== 'object') return false;
  const payload = event.payload && typeof event.payload === 'object' ? event.payload : {};
  if (matchesNickname(event.user_nickname, nickname) || matchesNickname(payload.user, nickname) || matchesNickname(payload.from, nickname) || matchesNickname(payload.to, nickname) || matchesNickname(payload.actor, nickname)) {
    return true;
  }
  if (Array.isArray(payload.members) && payload.members.some((member) => matchesNickname(member, nickname))) return true;
  return false;
}
function purgeDeletedAccountLocalData(nickname) {
  const target = String(nickname || '').trim();
  if (!target) return;

  try {
    const users = getUsers().filter((user) => !matchesNickname(user?.nickname, target));
    saveUsers(users);
  } catch {}

  try {
    const adminEvents = read(KEYS.ADMIN, []).filter((event) => !shouldRemoveAdminEventForNickname(event, target));
    write(KEYS.ADMIN, adminEvents);
  } catch {}

  try { localStorage.removeItem(`${KEYS.STATE_PREFIX}${target}`); } catch {}
  try { localStorage.removeItem(socialStorageKey(target)); } catch {}
  try { localStorage.removeItem(`${KEYS.NOTICE_PREFIX}${target}`); } catch {}

  const keys = Object.keys(localStorage || {});
  keys.forEach((key) => {
    try {
      if (String(key).startsWith(KEYS.STATE_PREFIX)) {
        const owner = String(key).slice(KEYS.STATE_PREFIX.length);
        if (matchesNickname(owner, target)) {
          localStorage.removeItem(key);
          return;
        }
        const nextState = normalizeState(read(key, {}));
        nextState.trips = purgeTripDataByNickname(nextState.trips, target);
        nextState.mediaPosts = purgeMediaDataByNickname(nextState.mediaPosts, target);
        write(key, nextState);
        return;
      }
      if (String(key).startsWith(`${KEYS.SOCIAL}:`)) {
        const nextSocial = purgeSocialDataByNickname(read(key, {}), target);
        write(key, nextSocial);
        return;
      }
      if (String(key).startsWith(KEYS.NOTICE_PREFIX)) {
        const notice = read(key, {});
        const nextChatReadAt = {};
        Object.entries(notice?.chatReadAt || {}).forEach(([scope, value]) => {
          if (!String(scope || '').includes(target)) nextChatReadAt[scope] = value;
        });
        write(key, { ...notice, chatReadAt: nextChatReadAt });
      }
    } catch {}
  });
}
function addEvent(type, payload = {}) {
  const event = { id: uid(), type, payload, createdAt: now() };
  const events = read(KEYS.ADMIN, []);
  events.unshift(event);
  write(KEYS.ADMIN, events.slice(0, 500));
  const client = window.RJSupabase;
  if (client?.isEnabled?.() && typeof client.syncAdminEvent === 'function') {
    Promise.resolve(client.syncAdminEvent(type, payload, event.createdAt)).catch((err) => {
      console.warn('[RJSupabase.syncAdminEvent]', err?.message || err);
    });
  }
}
const COUNTRY_META = {
      cn: { flag: '🇨🇳', aliases: ['中国','china','prc','beijing','北京','shanghai','上海','guangzhou','广州','shenzhen','深圳','hangzhou','杭州','chengdu','成都','chongqing','重庆','xian','西安','kunming','昆明','sanya','三亚'] },
      hk: { flag: '🇭🇰', aliases: ['香港','hong kong'] },
      mo: { flag: '🇲🇴', aliases: ['澳门','macao','macau'] },
      tw: { flag: '🇹🇼', aliases: ['台湾','taiwan','台北','taipei','高雄','kaohsiung'] },
      jp: { flag: '🇯🇵', aliases: ['日本','japan','东京','tokyo','大阪','osaka','京都','kyoto','冲绳','okinawa','北海道','hokkaido','富士山','mt fuji'] },
      kr: { flag: '🇰🇷', aliases: ['韩国','korea','south korea','首尔','seoul','釜山','busan','济州','jeju'] },
      kp: { flag: '🇰🇵', aliases: ['朝鲜','north korea'] },
      us: { flag: '🇺🇸', aliases: ['美国','usa','u.s.a','united states','united states of america','纽约','new york','los angeles','洛杉矶','san francisco','旧金山','las vegas','拉斯维加斯','hawaii','夏威夷','miami','迈阿密','seattle','西雅图','chicago','芝加哥','boston','波士顿'] },
      ca: { flag: '🇨🇦', aliases: ['加拿大','canada','toronto','多伦多','vancouver','温哥华','montreal','蒙特利尔','banff'] },
      mx: { flag: '🇲🇽', aliases: ['墨西哥','mexico','cancun','坎昆','mexico city','墨西哥城'] },
      br: { flag: '🇧🇷', aliases: ['巴西','brazil','rio','里约','rio de janeiro','圣保罗','sao paulo'] },
      ar: { flag: '🇦🇷', aliases: ['阿根廷','argentina','buenos aires','布宜诺斯艾利斯','patagonia','巴塔哥尼亚'] },
      cl: { flag: '🇨🇱', aliases: ['智利','chile','santiago','圣地亚哥','atacama','阿塔卡马'] },
      pe: { flag: '🇵🇪', aliases: ['秘鲁','peru','lima','利马','cusco','库斯科','machu picchu','马丘比丘'] },
      co: { flag: '🇨🇴', aliases: ['哥伦比亚','colombia'] },
      ec: { flag: '🇪🇨', aliases: ['厄瓜多尔','ecuador','galapagos','加拉帕戈斯'] },
      gb: { flag: '🇬🇧', aliases: ['英国','united kingdom','uk','england','london','伦敦','manchester','曼彻斯特','edinburgh','爱丁堡','scotland','苏格兰'] },
      ie: { flag: '🇮🇪', aliases: ['爱尔兰','ireland','dublin','都柏林'] },
      fr: { flag: '🇫🇷', aliases: ['法国','france','paris','巴黎','nice','尼斯','lyon','里昂','marseille','马赛','provence','普罗旺斯'] },
      de: { flag: '🇩🇪', aliases: ['德国','germany','berlin','柏林','munich','慕尼黑','frankfurt','法兰克福','hamburg','汉堡','cologne','科隆'] },
      it: { flag: '🇮🇹', aliases: ['意大利','italy','rome','罗马','milan','米兰','venice','威尼斯','florence','佛罗伦萨','naples','那不勒斯','dolomites','多洛米蒂'] },
      es: { flag: '🇪🇸', aliases: ['西班牙','spain','madrid','马德里','barcelona','巴塞罗那','seville','塞维利亚','mallorca','马略卡'] },
      pt: { flag: '🇵🇹', aliases: ['葡萄牙','portugal','lisbon','里斯本','porto','波尔图','madeira','马德拉'] },
      nl: { flag: '🇳🇱', aliases: ['荷兰','netherlands','amsterdam','阿姆斯特丹','rotterdam','鹿特丹'] },
      be: { flag: '🇧🇪', aliases: ['比利时','belgium','brussels','布鲁塞尔','bruges','布鲁日'] },
      ch: { flag: '🇨🇭', aliases: ['瑞士','switzerland','zurich','苏黎世','geneva','日内瓦','interlaken','因特拉肯','zermatt','采尔马特','lucerne','琉森'] },
      at: { flag: '🇦🇹', aliases: ['奥地利','austria','vienna','维也纳','salzburg','萨尔茨堡','hallstatt','哈尔施塔特'] },
      cz: { flag: '🇨🇿', aliases: ['捷克','czech','czech republic','prague','布拉格'] },
      hu: { flag: '🇭🇺', aliases: ['匈牙利','hungary','budapest','布达佩斯'] },
      pl: { flag: '🇵🇱', aliases: ['波兰','poland','warsaw','华沙','krakow','克拉科夫'] },
      gr: { flag: '🇬🇷', aliases: ['希腊','greece','athens','雅典','santorini','圣托里尼','mykonos','米克诺斯','crete','克里特'] },
      tr: { flag: '🇹🇷', aliases: ['土耳其','turkey','istanbul','伊斯坦布尔','cappadocia','卡帕多奇亚','antalya','安塔利亚','izmir','伊兹密尔'] },
      no: { flag: '🇳🇴', aliases: ['挪威','norway','oslo','奥斯陆','tromso','特罗姆瑟','lofoten','罗弗敦','bergen','卑尔根'] },
      se: { flag: '🇸🇪', aliases: ['瑞典','sweden','stockholm','斯德哥尔摩','gothenburg','哥德堡'] },
      fi: { flag: '🇫🇮', aliases: ['芬兰','finland','helsinki','赫尔辛基','rovaniemi','罗瓦涅米'] },
      dk: { flag: '🇩🇰', aliases: ['丹麦','denmark','copenhagen','哥本哈根'] },
      is: { flag: '🇮🇸', aliases: ['冰岛','iceland','reykjavik','雷克雅未克'] },
      au: { flag: '🇦🇺', aliases: ['澳大利亚','australia','sydney','悉尼','melbourne','墨尔本','brisbane','布里斯班','perth','珀斯','gold coast','黄金海岸'] },
      nz: { flag: '🇳🇿', aliases: ['新西兰','new zealand','auckland','奥克兰','queenstown','皇后镇'] },
      sg: { flag: '🇸🇬', aliases: ['新加坡','singapore'] },
      my: { flag: '🇲🇾', aliases: ['马来西亚','malaysia','kuala lumpur','吉隆坡','penang','槟城'] },
      th: { flag: '🇹🇭', aliases: ['泰国','thailand','bangkok','曼谷','chiang mai','清迈','phuket','普吉','krabi','甲米','pattaya','芭提雅'] },
      vn: { flag: '🇻🇳', aliases: ['越南','vietnam','hanoi','河内','ho chi minh','胡志明','da nang','岘港','phu quoc','富国岛'] },
      id: { flag: '🇮🇩', aliases: ['印度尼西亚','indonesia','bali','巴厘岛','jakarta','雅加达','yogyakarta','日惹','komodo','科莫多'] },
      ph: { flag: '🇵🇭', aliases: ['菲律宾','philippines','manila','马尼拉','cebu','宿务','boracay','长滩岛','palawan','巴拉望'] },
      kh: { flag: '🇰🇭', aliases: ['柬埔寨','cambodia','siem reap','暹粒'] },
      in: { flag: '🇮🇳', aliases: ['印度','india','new delhi','新德里','mumbai','孟买','goa','果阿','agra','阿格拉'] },
      lk: { flag: '🇱🇰', aliases: ['斯里兰卡','sri lanka','colombo','科伦坡'] },
      np: { flag: '🇳🇵', aliases: ['尼泊尔','nepal','kathmandu','加德满都'] },
      mv: { flag: '🇲🇻', aliases: ['马尔代夫','maldives'] },
      ae: { flag: '🇦🇪', aliases: ['阿联酋','united arab emirates','uae','dubai','迪拜','abu dhabi','阿布扎比'] },
      eg: { flag: '🇪🇬', aliases: ['埃及','egypt','cairo','开罗','luxor','卢克索'] },
      ma: { flag: '🇲🇦', aliases: ['摩洛哥','morocco','marrakech','马拉喀什','casablanca','卡萨布兰卡'] },
      za: { flag: '🇿🇦', aliases: ['南非','south africa','cape town','开普敦','johannesburg','约翰内斯堡'] },
      tz: { flag: '🇹🇿', aliases: ['坦桑尼亚','tanzania','zanzibar','桑给巴尔'] },
      ke: { flag: '🇰🇪', aliases: ['肯尼亚','kenya','nairobi','内罗毕'] },
      antarctica: { flag: '🐧', aliases: ['南极','antarctica'] }
    };

    function normalizeCountryLookupText(value) {
      return String(value || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[̀-ͯ]/g, '')
        .replace(/[()（）]/g, ' ')
        .replace(/[·•、,，/\|]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
    }

    function resolveCountryMeta(destination) {
      const text = normalizeCountryLookupText(destination);
      if (!text) return null;
      const parts = text.split(' ').filter(Boolean);
      let best = null;
      Object.entries(COUNTRY_META).forEach(([code, meta]) => {
        const aliases = Array.isArray(meta.aliases) ? meta.aliases : [];
        aliases.forEach((aliasRaw) => {
          const alias = normalizeCountryLookupText(aliasRaw);
          if (!alias) return;
          const matched = text === alias || text.includes(alias) || parts.includes(alias);
          if (!matched) return;
          const score = alias.length;
          if (!best || score > best.score) best = { code, flag: meta.flag, score };
        });
      });
      return best ? { code: best.code, flag: best.flag } : null;
    }

    
function resolveWorldContinent(destination) {
  const code = resolveCountryMeta(destination)?.code || '';
  const map = {
    cn:'asia', hk:'asia', mo:'asia', tw:'asia', jp:'asia', kr:'asia', kp:'asia', sg:'asia', my:'asia', th:'asia',
    vn:'asia', id:'asia', ph:'asia', kh:'asia', in:'asia', lk:'asia', np:'asia', mv:'asia', ae:'asia', tr:'asia',
    gb:'europe', ie:'europe', fr:'europe', de:'europe', it:'europe', es:'europe', pt:'europe', nl:'europe',
    be:'europe', ch:'europe', at:'europe', cz:'europe', hu:'europe', pl:'europe', gr:'europe', no:'europe',
    se:'europe', fi:'europe', dk:'europe', is:'europe',
    us:'north-america', ca:'north-america', mx:'north-america',
    br:'south-america', ar:'south-america', cl:'south-america', pe:'south-america', co:'south-america', ec:'south-america',
    eg:'africa', ma:'africa', za:'africa', tz:'africa', ke:'africa',
    au:'oceania', nz:'oceania',
    antarctica:'antarctica'
  };
  return map[code] || 'global';
}

function mapCountryCode(destination) {
      return resolveCountryMeta(destination)?.code || normalizeCountryLookupText(destination);
    }

    


const GUIDE_LIBRARY = [
  {
    cityCode: 'hangzhou',
    cityName: '杭州',
    guides: [
      {
        id: 'hangzhou-platinum-full',
        title: '《杭州》白金全成就攻略：主线 + 隐藏 + 路线 + 美食全收集',
        summary: '按白金路线思路，把杭州主线、隐藏、路线、美食与挑战成就串成一套 2～3 天可执行的城市奖杯攻略。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-02',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/guides/platinum-full.jpg.jpg',
        tags: ['白金攻略', '全成就', '2~3天', '官方推荐'],
        category: 'platinum',
        content: [
          { type: 'lead', text: '杭州这座城市很适合做“白金式探索”。它不像纯景点打卡那样只是一站一站到此一游，也不像特种兵行程那样只追求快速走完，而是很适合做成一套有主线、有支线、有时间限定、有隐藏收集的城市白金系统。' },
          { type: 'lead', text: '这篇攻略的目标，就是帮你把杭州城市成就按照最顺的顺序走一遍，尽量做到少走回头路、同一天串联多个成就、优先完成主线成就、顺手补齐美食与隐藏，最后冲击白金条件。' },
          { type: 'section', title: '一、杭州白金的整体思路' },
          { type: 'paragraph', text: '杭州白金不是要求你把所有成就全部刷满，而是要求你完成一套相对完整的探索闭环。建议优先做主线成就 12 个以上、进阶成就 8 个以上、隐藏成就 4 个以上、挑战成就 2 个以上，并覆盖至少 3 个核心区域，最后再发布 1 篇完整攻略或高质量打卡总结。真正刷白金时，不要从一开始就想着 36 个全清，而是应该优先做：主线 → 顺路时间限定 → 路线成就 → 美食收集 → 隐藏成就 → 挑战成就。' },
          { type: 'section', title: '二、推荐路线顺序' },
          { type: 'list', items: ['Day 1：西湖主线 + 湖滨夜游 —— 初见西湖、断桥留影、白堤慢行、西湖半日徒步者、雷峰夕照、入夜湖滨。','Day 2：灵隐线 + 龙井线 + 老城夜游 —— 灵隐寻禅、飞来峰初探、龙井问茶、河坊旧梦、南宋夜行，并顺手补杭州美食成就。','Day 3：钱江新城 + 运河 + 隐藏补全 —— 钱江新城观灯、运河夜色、城市双面、一湖两岸，以及隐藏成就和挑战成就收尾。'] },
          { type: 'section', title: '三、Day 1：西湖主线全成就路线' },
          { type: 'paragraph', text: '先从断桥附近进入西湖核心区，解锁“初见西湖”和“断桥留影”，随后沿白堤慢行，把“白堤慢行”和“西湖半日徒步者”串起来。傍晚把节奏留给“雷峰夕照”，晚上再去湖滨收下“入夜湖滨”。' },
          { type: 'section', title: '四、Day 2：灵隐 + 龙井 + 老城路线' },
          { type: 'paragraph', text: '第二天上午优先灵隐和飞来峰，完成“灵隐寻禅”“飞来峰初探”；下午去龙井，拿下“龙井问茶”；傍晚切到老城，完成“河坊旧梦”和“南宋夜行”，并顺手补齐杭州美食成就。' },
          { type: 'section', title: '五、Day 3：钱江新城 + 运河 + 隐藏补完' },
          { type: 'paragraph', text: '如果有第三天，不要继续只围绕西湖。建议去钱江新城和运河，完成“钱江新城观灯”“运河夜色”“城市双面”“一湖两岸”，再把隐藏成就和挑战成就补齐。' },
          { type: 'section', title: '六、挑战成就怎么冲' },
          { type: 'paragraph', text: '真正决定你能不能白金的，不是普通主线，而是挑战成就。优先冲“48小时杭州猎人”和“杭州通关计划”两枚。前者适合做白金挑战赛，后者更像最终身份认证。' },
          { type: 'section', title: '七、2 天白金入门版' },
          { type: 'list', items: ['Day 1：初见西湖、断桥留影、白堤慢行、西湖半日徒步者、雷峰夕照、入夜湖滨。','Day 2：灵隐寻禅、飞来峰初探、龙井问茶、河坊旧梦、南宋夜行，再补一个美食成就。'] },
          { type: 'section', title: '八、3 天白金推进版' },
          { type: 'list', items: ['Day 1：西湖主线 + 雷峰夕照 + 湖滨夜游。','Day 2：灵隐 + 飞来峰 + 龙井 + 河坊街 + 南宋御街。','Day 3：钱江新城 + 运河 + 隐藏成就 + 挑战成就收尾。'] },
          { type: 'section', title: '九、白金玩家最后最容易漏掉什么' },
          { type: 'list', items: ['时间窗成就没踩到。','夜游成就没安排。','隐藏成就拖着没补。','美食只吃了，但没记录。','路线成就拆得太散。','最后忘了发布总结攻略。'] },
          { type: 'paragraph', text: '真正冲白金时，最重要的不是“多玩”，而是“路线顺”。只要路线顺，杭州白金这件事就会比你想象中更轻松。' }
        ]
      },
      {
        id: 'hangzhou-2day-beginner',
        title: '《杭州》2 天白金入门路线：第一次刷城市奖杯怎么走',
        summary: '适合时间有限的新手玩家，两天内优先完成 10～12 个高价值杭州奖杯。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-02',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/guides/beginner-2day.jpg',
        tags: ['2天路线', '新手入门', '奖杯路线'],
        category: 'platinum',
        content: [
          { type: 'lead', text: '如果你只有 2 天时间，不要一上来就追求全清。最好的做法是先拿主线、再补夜游、顺手吃掉 1～2 个美食奖杯。' },
          { type: 'section', title: 'Day 1 推荐' },
          { type: 'list', items: ['初见西湖', '断桥留影', '白堤慢行', '西湖半日徒步者', '雷峰夕照', '入夜湖滨'] },
          { type: 'section', title: 'Day 2 推荐' },
          { type: 'list', items: ['灵隐寻禅', '飞来峰初探', '龙井问茶', '河坊旧梦', '南宋夜行', '补 1 个杭州美食奖杯'] }
        ]
      },
      {
        id: 'hangzhou-food-collection',
        title: '《杭州》美食收集攻略：杭帮菜、早餐、小馆与夜宵怎么吃',
        summary: '把杭州经典味道和本地人会去的小馆串成一套可直接照抄的吃喝路线，适合第一次来杭州的人。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&w=1600&q=80',
        tags: ['美食', '杭帮菜', '早餐', '夜宵'],
        category: 'food',
        content: [
          { type: 'lead', text: '杭州美食攻略不要理解成“必吃榜清单”，更好的思路是按时间段和区域来吃：早餐、午餐、下午茶、夜宵各有代表。' },
          { type: 'section', title: '一、早餐先拿“片儿川入门”' },
          { type: 'paragraph', text: '如果你想把杭州的第一口吃得稳，优先从片儿川开始。早餐段最适合顺手完成“片儿川入门”和“早餐本地通”两类美食奖杯。' },
          { type: 'section', title: '二、午餐重点放在杭帮菜' },
          { type: 'paragraph', text: '午餐建议专门留给杭帮菜正餐。龙井虾仁、东坡肉、西湖醋鱼、宋嫂鱼羹这类经典菜更适合作为正式用餐来体验。' },
          { type: 'section', title: '三、隐藏小馆怎么找' },
          { type: 'paragraph', text: '隐藏小馆不要追热门榜单，建议优先老城、社区边缘和本地居民区附近的小店。目标不是“吃最贵”，而是“吃到本地感”。' },
          { type: 'section', title: '四、夜宵路线推荐' },
          { type: 'paragraph', text: '如果晚上安排了河坊街或南宋御街，夜宵就放到这条线收尾。这样可以顺手完成“夜宵补给站”，同时给第二天节奏留出空间。' }
        ]
      },
      {
        id: 'hangzhou-westlake-vinegar-fish',
        shortTitle: '西湖醋鱼',
        title: '《杭州》西湖醋鱼详细介绍与点单攻略',
        summary: '西湖醋鱼到底值不值得吃、应该怎么点、适合和哪些菜搭配，这篇专门讲清楚。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/food/westlake-vinegar-fish.jpg',
        tags: ['西湖醋鱼', '详细介绍', '点单攻略'],
        category: 'food',
        content: [
          { type: 'lead', text: '西湖醋鱼是最有杭州辨识度的一道菜，但它也是最容易引发分歧的一道菜。问题往往不在“这道菜本身”，而在于点法和期待值。' },
          { type: 'section', title: '一、西湖醋鱼是什么' },
          { type: 'paragraph', text: '这是一道典型的杭州传统名菜，核心特征就是糖醋汁和鱼肉本身的鲜嫩口感。它不是重口型菜，更适合放在一桌杭帮菜里去理解。' },
          { type: 'section', title: '二、第一次点单怎么配' },
          { type: 'paragraph', text: '第一次吃西湖醋鱼，建议不要单点。更推荐和龙井虾仁、东坡肉、时令蔬菜或一份清爽汤品一起搭配，这样整体体验会更平衡。' },
          { type: 'section', title: '三、适合谁打卡' },
          { type: 'paragraph', text: '如果你是想完整体验杭州经典菜式，西湖醋鱼值得打卡；如果你偏爱辛辣或重油重盐口味，就不要把它当作“必然惊艳”的菜来期待。' },
          { type: 'section', title: '四、购买 / 点单建议' },
          { type: 'list', items: ['优先在正餐时间点，不建议当夜宵。','建议与 2～3 道杭帮菜一起搭配。','第一次打卡更适合半份或小份，降低试错成本。','吃完记得补一条真实感受，这类菜最适合做社区讨论。'] }
        ]
      },

      {
        id: 'hangzhou-longjing-shrimp',
        shortTitle: '龙井虾仁',
        title: '《杭州》龙井虾仁详细介绍与点单攻略',
        summary: '龙井虾仁应该怎么点、适合什么季节吃、和哪些菜搭配更稳，这篇一次讲清楚。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/food/longjing-shrimp.jpg',
        tags: ['龙井虾仁', '详细介绍', '点单攻略'],
        category: 'food',
        content: [
          { type: 'lead', text: '龙井虾仁是杭州最适合“第一次认真吃一顿杭帮菜”时点的一道菜，它比西湖醋鱼更稳，也更容易被大多数人接受。' },
          { type: 'section', title: '一、适合什么时候点' },
          { type: 'paragraph', text: '午餐或晚餐都适合，春季与初夏的体验感最好。' },
          { type: 'section', title: '二、搭配建议' },
          { type: 'list', items: ['适合和东坡肉、时蔬、汤羹一起点。','第一次来杭州更建议把它作为招牌菜，而不是配角。','如果预算有限，两人拼一份最合适。'] }
        ]
      },
      {
        id: 'hangzhou-pianerchuan',
        shortTitle: '片儿川',
        title: '《杭州》片儿川入门指南：第一次来杭州早餐怎么吃',
        summary: '片儿川适合什么时候吃、怎么点、怎么和早餐路线结合，这篇是杭州早餐系入门攻略。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/food/pianerchuan.jpg',
        tags: ['片儿川', '早餐', '入门指南'],
        category: 'food',
        content: [
          { type: 'lead', text: '如果你要给“杭州的第一口”选一个最稳的答案，片儿川通常比网红小吃更合适。' },
          { type: 'section', title: '一、最佳时间' },
          { type: 'paragraph', text: '早餐与早午餐时段最佳，适合和老城路线或西湖线串联。' },
          { type: 'section', title: '二、怎么点更稳' },
          { type: 'list', items: ['第一次先点基础版。','不要同时点太多重口味小吃。','适合搭配一杯热饮，作为开场早餐。'] }
        ]
      },
      {
        id: 'hangzhou-duanqiao-checkin',
        shortTitle: '断桥',
        title: '《杭州》断桥打卡攻略：什么时候去最适合拍照',
        summary: '断桥适合什么时间去、站在哪些位置更出片、怎么和白堤路线串联，这篇专讲断桥。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/spots/duanqiao.jpg',
        tags: ['断桥', '拍照', '打卡'],
        category: 'hotspots',
        content: [
          { type: 'lead', text: '断桥是杭州最经典也最容易拥挤的打卡点，所以关键不只是“去”，而是“什么时候去、站在哪里”。' },
          { type: 'section', title: '一、推荐时间' },
          { type: 'paragraph', text: '清晨和傍晚最佳，阴天与雨天也很有情绪感。' },
          { type: 'section', title: '二、串联路线' },
          { type: 'paragraph', text: '最推荐和“初见西湖”“白堤慢行”一起完成。' }
        ]
      },
      {
        id: 'hangzhou-leifeng-checkin',
        shortTitle: '雷峰塔',
        title: '《杭州》雷峰塔黄昏打卡攻略：日落前后最值得去',
        summary: '雷峰塔不适合随便去，最值得的是黄昏时间窗，这篇把时间和机位讲清楚。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/spots/leifeng-pagoda.jpg',
        tags: ['雷峰塔', '黄昏', '打卡'],
        category: 'hotspots',
        content: [
          { type: 'lead', text: '雷峰塔最好的玩法不是白天到此一游，而是把它当成 Day 1 的黄昏终点。' },
          { type: 'section', title: '一、推荐时间窗' },
          { type: 'paragraph', text: '建议日落前 30～50 分钟到达，等光线慢慢变化。' }
        ]
      },
      {
        id: 'hangzhou-hanfu-outfit',
        shortTitle: '汉服',
        title: '《杭州》汉服出片攻略：西湖与老城线怎么穿',
        summary: '想在杭州拍汉服，不同点位适合不同颜色和风格，这篇先给你一套稳妥方案。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/outfits/hanfu.jpg',
        tags: ['汉服', '出片', '穿搭'],
        category: 'outfits',
        content: [
          { type: 'lead', text: '杭州非常适合汉服，但重点不是“穿上就拍”，而是要让服装和场景匹配。' },
          { type: 'section', title: '一、西湖线怎么穿' },
          { type: 'paragraph', text: '西湖更适合浅色、轻盈、低饱和度的汉服。' },
          { type: 'section', title: '二、老城线怎么穿' },
          { type: 'paragraph', text: '河坊街和南宋御街可以适当提高色彩浓度，让画面更有层次。' }
        ]
      },
      {
        id: 'hangzhou-citywalk-outfit',
        shortTitle: 'citywalk 穿搭',
        title: '《杭州》citywalk 穿搭攻略：轻松走一整天也能好看',
        summary: '如果你不是拍汉服，而是日常 citywalk，这篇给你一套更轻便也更出片的搭配方案。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/outfits/citywalk.jpg',
        tags: ['citywalk', '穿搭', '轻松出片'],
        category: 'outfits',
        content: [
          { type: 'lead', text: 'citywalk 穿搭最重要的是可走、可拍、可全天使用。' },
          { type: 'list', items: ['鞋子优先舒适。','颜色不要太乱，适合浅灰、米白、雾蓝。','背包尽量简洁，别破坏画面。'] }
        ]
      },
      {
        id: 'hangzhou-sudongpo-story',
        shortTitle: '苏东坡',
        title: '《杭州》苏东坡与西湖：为什么他几乎定义了杭州气质',
        summary: '如果不了解苏东坡，你对杭州的理解会少掉很重要的一层。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/history/sudongpo.jpg',
        tags: ['苏东坡', '历史人物', '西湖'],
        category: 'history',
        content: [
          { type: 'lead', text: '苏东坡不是杭州的一块历史背景板，而是影响这座城市气质的重要人物。' },
          { type: 'section', title: '一、为什么一定要认识苏东坡' },
          { type: 'paragraph', text: '很多今天你在西湖看到的文化想象，背后都能追到苏东坡。' }
        ]
      },
      {
        id: 'hangzhou-baishe-legend',
        shortTitle: '白蛇传',
        title: '《杭州》白蛇传与雷峰塔：为什么这个故事会绑定杭州',
        summary: '白蛇传不只是民间故事，它几乎已经成为杭州文化想象的一部分。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/history/baishe.jpg',
        tags: ['白蛇传', '雷峰塔', '历史典故'],
        category: 'history',
        content: [
          { type: 'lead', text: '很多游客去雷峰塔，只知道“有名”，但不知道它为什么有名。白蛇传就是最直观的入口。' },
          { type: 'paragraph', text: '如果你想让杭州打卡不只是“拍到了”，那这类故事型攻略非常值得看。' }
        ]
      },

      {
        id: 'hangzhou-dongpo-pork',
        shortTitle: '东坡肉',
        title: '《杭州》东坡肉：来历、口味与点单建议',
        summary: '东坡肉为什么会和杭州强绑定、第一次该怎么点、适合搭配哪些菜，这篇一次讲清楚。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/food/dongpo-pork.jpg',
        tags: ['东坡肉', '杭帮菜', '点单建议'],
        category: 'food',
        content: [
          { type: 'lead', text: '东坡肉几乎是杭州最有辨识度的经典菜之一。它不只是“有名”，而是非常适合第一次认真吃一顿杭帮菜时点。' },
          { type: 'section', title: '一、为什么东坡肉和杭州强关联' },
          { type: 'paragraph', text: '东坡肉和苏东坡的故事绑定很深，所以它不仅是一道菜，也是一种杭州文化想象。' },
          { type: 'section', title: '二、口味特点' },
          { type: 'paragraph', text: '东坡肉的重点不是“肥”，而是酥、软、糯。真正做得好的版本入口会更偏绵密，而不是厚重。' },
          { type: 'section', title: '三、点单建议' },
          { type: 'list', items: ['建议放在正餐点，不适合单独当小吃。','适合搭配时蔬、汤羹、米饭一起吃。','第一次来杭州，两人拼一份会更稳。'] }
        ]
      },
      {
        id: 'hangzhou-rice-wine-balls',
        shortTitle: '酒酿圆子',
        title: '《杭州》酒酿圆子：历史、口味与购买攻略',
        summary: '酒酿圆子在杭州为什么常见、适合什么时候吃、在哪些区域更容易找到，这篇专门讲它。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/food/rice-wine-balls.webp',
        tags: ['酒酿圆子', '甜品', '购买攻略'],
        category: 'food',
        content: [
          { type: 'lead', text: '酒酿圆子属于那种“看起来很轻”，但非常能代表江南气质的小甜品。它适合做路线里的收尾，而不是开局重击。' },
          { type: 'section', title: '一、它在杭州是什么类型的小吃' },
          { type: 'paragraph', text: '酒酿圆子更像甜口收尾，适合在老城、美食街区或晚间慢逛后吃。' },
          { type: 'section', title: '二、适合什么时候吃' },
          { type: 'paragraph', text: '下午茶和夜间散步后最合适，天气偏凉的时候体验感更好。' },
          { type: 'section', title: '三、购买建议' },
          { type: 'list', items: ['优先在老城线或小吃集中区找。','第一次建议点经典版，不要加太多复杂配料。','适合与片儿川、夜宵路线分开吃，避免口味打架。'] }
        ]
      },
      {
        id: 'hangzhou-songsao-fish-soup',
        shortTitle: '宋嫂鱼羹',
        title: '《杭州》宋嫂鱼羹：适合谁吃、怎么点更稳',
        summary: '宋嫂鱼羹常被忽略，但它其实很适合作为杭州正餐里的温和型代表菜。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/food/songsao-fish-soup.jpeg',
        tags: ['宋嫂鱼羹', '杭帮菜', '汤羹'],
        category: 'food',
        content: [
          { type: 'lead', text: '宋嫂鱼羹比起西湖醋鱼更温和，也更容易被第一次接触杭帮菜的人接受。' },
          { type: 'section', title: '一、口味特点' },
          { type: 'paragraph', text: '鲜、滑、柔和，是很典型的汤羹型杭帮菜。' },
          { type: 'section', title: '二、搭配建议' },
          { type: 'list', items: ['适合和东坡肉、西湖醋鱼分开点。','更适合午餐和晚餐，不适合当小吃。'] }
        ]
      },
      {
        id: 'hangzhou-westlake-spot',
        shortTitle: '西湖',
        title: '《杭州》西湖打卡指南：第一次来杭州应该怎么逛',
        summary: '西湖不只是“去过”，更关键的是怎么走、从哪开始、和哪些成就串联。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/spots/westlake.jpg',
        tags: ['西湖', '打卡', '路线'],
        category: 'hotspots',
        content: [
          { type: 'lead', text: '西湖不是一个单点，它是一整套城市体验。你如果只是拍一张照就走，很容易错过它真正的节奏。' },
          { type: 'section', title: '一、最稳起点' },
          { type: 'paragraph', text: '第一次建议从断桥附近开始，方便串联断桥、白堤与西湖半日徒步路线。' },
          { type: 'section', title: '二、适合搭配的成就' },
          { type: 'list', items: ['初见西湖','白堤慢行','西湖半日徒步者'] }
        ]
      },
      {
        id: 'hangzhou-qiantang-night',
        shortTitle: '钱江新城夜景',
        title: '《杭州》钱江新城夜景打卡：现代杭州最值得看的那一面',
        summary: '如果你想看杭州更现代的一面，钱江新城夜景几乎是最稳的一站。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/spots/qiantang-night.jpg',
        tags: ['钱江新城', '夜景', '打卡'],
        category: 'hotspots',
        content: [
          { type: 'lead', text: '钱江新城和西湖是杭州两种截然不同的城市表情。白天看自然，晚上看这里，反差会很强。' },
          { type: 'section', title: '一、最佳时间' },
          { type: 'paragraph', text: '入夜后最适合，建议和城市双面路线一起安排。' }
        ]
      },
      {
        id: 'hangzhou-rainy-westlake-outfit',
        shortTitle: '雨天西湖穿搭',
        title: '《杭州》雨天西湖穿搭：想拍出氛围感该怎么穿',
        summary: '雨天西湖不一定狼狈，穿对了反而最有情绪感。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/outfits/rainy-westlake.jpg',
        tags: ['雨天', '西湖', '穿搭'],
        category: 'outfits',
        content: [
          { type: 'lead', text: '雨天西湖最适合做低饱和度、层次感强的穿搭。关键是颜色和防水性都要在线。' },
          { type: 'section', title: '一、配色建议' },
          { type: 'paragraph', text: '米白、灰蓝、浅咖都比高饱和度颜色更稳。' }
        ]
      },
      {
        id: 'hangzhou-lingyin-story',
        shortTitle: '灵隐寺',
        title: '《杭州》灵隐寺的由来：为什么它是杭州最重要的文化入口之一',
        summary: '灵隐寺不只是一个景点，它是理解杭州文化和山寺气质的重要入口。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://yhidxvctvxacoxlmxluu.supabase.co/storage/v1/object/public/guide-assets/hangzhou/history/lingyin.jpg',
        tags: ['灵隐寺', '历史名胜', '典故'],
        category: 'history',
        content: [
          { type: 'lead', text: '灵隐寺是杭州非常重要的文化入口。很多人只是打卡，其实它背后承载的是山寺、隐逸与城市精神之间的关系。' },
          { type: 'section', title: '一、为什么值得单独看一篇' },
          { type: 'paragraph', text: '如果你想让灵隐线不只是“到此一游”，那了解它的背景会让你整个路线体验更完整。' }
        ]
      },
      {
        id: 'hangzhou-photo-hotspots',
        title: '《杭州》网红景点打卡攻略：西湖、断桥、雷峰塔、龙井与钱江新城夜景',
        summary: '把游客最想去、最容易出片、最适合做打卡成就的杭州点位整理成一条高效路线。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1600&q=80',
        tags: ['网红景点', '打卡', '出片'],
        category: 'hotspots',
        content: [
          { type: 'lead', text: '杭州的网红景点不只是“有名”，更关键的是它们非常适合与城市奖杯系统结合，形成可执行的打卡路线。' },
          { type: 'section', title: '一、西湖与断桥' },
          { type: 'paragraph', text: '断桥适合做第一站，既能完成基础打卡，也更适合作为拍照起点。白堤、西湖核心区和断桥是最容易串联的一组。' },
          { type: 'section', title: '二、雷峰塔黄昏' },
          { type: 'paragraph', text: '雷峰塔最推荐放在傍晚，景色和情绪价值都更完整。它适合作为 Day 1 的黄昏收束点。' },
          { type: 'section', title: '三、龙井村与钱江新城夜景' },
          { type: 'paragraph', text: '如果你想在同一趟行程里感受杭州的“自然感”和“现代感”，龙井村与钱江新城这两个点非常适合配对安排。' }
        ]
      },
      {
        id: 'hangzhou-style-outfits',
        title: '《杭州》特色衣服 / 出片攻略：汉服、citywalk、雨天西湖怎么穿',
        summary: '从汉服、轻户外到 citywalk 穿搭，帮你把杭州不同场景下的出片风格搭出来。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1600&q=80',
        tags: ['穿搭', '汉服', 'citywalk', '出片'],
        category: 'outfits',
        content: [
          { type: 'lead', text: '杭州很适合做“按场景穿搭”的城市：西湖适合轻松、龙井适合松弛、雨天适合带一点氛围感，夜景则适合更城市化的搭配。' },
          { type: 'section', title: '一、汉服适合哪里' },
          { type: 'paragraph', text: '如果你想拍更有古典氛围的内容，西湖、雷峰塔、南宋御街这几条线更适合汉服或偏中式的搭配。' },
          { type: 'section', title: '二、citywalk 穿搭怎么做' },
          { type: 'paragraph', text: '白堤、北山街、河坊街这类路线更适合轻便、舒适、带一点层次感的 citywalk 穿搭，鞋子一定要优先舒适。' },
          { type: 'section', title: '三、雨天西湖怎么出片' },
          { type: 'paragraph', text: '雨天西湖最重要的是色彩克制。建议用浅卡其、灰蓝、米白这类颜色，氛围会比高饱和度服装更贴杭州。' }
        ]
      },
      {
        id: 'hangzhou-figures-history',
        title: '《杭州》历史名胜人物介绍：苏东坡、白蛇传、灵隐寺、南宋御街与城市典故',
        summary: '把杭州最值得知道的城市背景、人物与传说整理成一篇可快速读懂的导览。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-03',
        cover: 'https://images.unsplash.com/photo-1518546305927-5a555bb7020d?auto=format&fit=crop&w=1600&q=80',
        tags: ['历史', '人物', '名胜', '城市故事'],
        category: 'history',
        content: [
          { type: 'lead', text: '杭州之所以好玩，不只是因为风景密度高，还因为它的景点几乎都有故事。苏东坡、白蛇传、灵隐寺、南宋遗韵，都是理解这座城市的入口。' },
          { type: 'section', title: '一、苏东坡与西湖' },
          { type: 'paragraph', text: '苏东坡几乎是理解杭州城市气质绕不开的人物。很多人走西湖时只看风景，但如果知道东坡与西湖的关系，你会对这座城多一层理解。' },
          { type: 'section', title: '二、白蛇传与雷峰塔' },
          { type: 'paragraph', text: '雷峰塔不只是地标，它也承载着最广为人知的杭州传说之一。游客对这里的情感记忆，往往来自故事，而不只是建筑本身。' },
          { type: 'section', title: '三、灵隐寺与南宋御街' },
          { type: 'paragraph', text: '一个代表宗教与山林气质，一个代表城市旧脉络与人间烟火，它们共同构成了杭州很重要的文化层。' }
        ]
      }
    ]
  },
  {
    cityCode: 'paris',
    cityName: '巴黎',
    guides: [
      {
        id: 'paris-coming-soon',
        title: '《巴黎》城市奖杯攻略集（筹备中）',
        summary: '巴黎城市奖杯攻略正在整理中，后续会补充白金路线、夜游路线和摄影路线。',
        author: '歌觅官方攻略组',
        updatedAt: '2026-04-02',
        cover: 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?auto=format&fit=crop&w=1600&q=80',
        tags: ['筹备中'],
        content: [{ type: 'lead', text: '巴黎城市奖杯攻略正在整理中，后续会上线白金主线、情侣路线与摄影路线。' }]
      }
    ]
  }
];


const CITY_GUIDE_HUBS = {
  hangzhou: {
    cityCode: 'hangzhou',
    cityName: '杭州',
    subtitle: '白金路线 / 美食打卡 / 网红景点 / 出片穿搭 / 历史名胜',
    days: '2~3 天',
    heroButtons: [
      { label: '白金全成就', guideId: 'hangzhou-platinum-full' },
      { label: '2天入门路线', guideId: 'hangzhou-2day-beginner' },
      { label: '美食打卡', guideId: 'hangzhou-westlake-vinegar-fish' },
      { label: '网红景点', guideId: 'hangzhou-westlake-spot' }
    ],
    sections: [
      { key: 'platinum', title: '白金路线', subtitle: '主线、隐藏、挑战与 2~3 天奖杯路线', guideIds: ['hangzhou-platinum-full','hangzhou-2day-beginner'] },
      { key: 'food', title: '美食攻略', subtitle: '杭帮菜、早餐、小馆与夜宵打卡', guideIds: ['hangzhou-westlake-vinegar-fish','hangzhou-dongpo-pork','hangzhou-rice-wine-balls','hangzhou-longjing-shrimp','hangzhou-pianerchuan','hangzhou-songsao-fish-soup'] },
      { key: 'hotspots', title: '网红景点打卡', subtitle: '西湖、断桥、雷峰塔、龙井与钱江新城夜景', guideIds: ['hangzhou-westlake-spot','hangzhou-duanqiao-checkin','hangzhou-leifeng-checkin','hangzhou-qiantang-night'] },
      { key: 'outfits', title: '特色衣服 / 出片攻略', subtitle: '汉服、citywalk、雨天西湖与季节穿搭', guideIds: ['hangzhou-hanfu-outfit'] },
      { key: 'history', title: '历史名胜人物介绍', subtitle: '苏东坡、白蛇传、灵隐寺、南宋御街与城市典故', guideIds: ['hangzhou-sudongpo-story'] }
    ]
  },
  paris: {
    cityCode: 'paris',
    cityName: '巴黎',
    subtitle: '城市攻略正在整理中',
    days: '3~4 天',
    heroButtons: [],
    sections: [
      { key: 'platinum', title: '白金路线', subtitle: '巴黎城市奖杯攻略正在筹备中', guideIds: ['paris-coming-soon'] }
    ]
  }
};

createApp({
  components: {
    DotTextMorph,
  },
  setup() {
    const app = reactive({
      route: location.hash.replace('#/', '') || 'register',
      current: localStorage.getItem(KEYS.CURRENT) || '',
      currentAuthUserId: '',
      users: getUsers(),
      social: getSocial(localStorage.getItem(KEYS.CURRENT) || ''),
      state: normalizeState({}),
      auth: { nickname: '', password: '' },
      authError: '',
      profileAvatarStatus: '',
      shareCard: { show: false, loading: false, downloading: false, error: '', data: null },
      profileForm: { birthday: '', gender: '', mbti: '', zodiac: '', pace: '平衡', budgetLevel: '舒适', wakeUp: '自然醒', social: '适中', bio: '', skillsText: '' },
      tripForm: { title: '', origin: '', destination: '', departDate: '', departFlex: '', returnDate: '', returnFlex: '', durationText: '', budget: 2000, tags: '', spots: '', itinerary: '', pace: '平衡', wakeUp: '自然醒', social: '适中' },
      mediaForm: { location: '', caption: '', checkin: '' },
      tripSquareSearch: '',
      userSearch: '',
      commentDraft: {},
      tripReplyTarget: null,
      diaryReplyTarget: null,
      tripCommentExpanded: {},
      diaryCommentExpanded: {},
      selectedUser: '',
      selectedTripId: '',
      selectedDiaryId: '',
      selectedDiaryRecord: null,
      selectedChatId: '',
      selectedBillId: '',
      previewSrc: '',
      previewList: [],
      previewIndex: 0,
      chatPeer: '',
      chatDraft: '',
      isChatComposing: false,
      activeMsgTab: 'chats',
      tripCommentSort: 'newest',
      diaryCommentSort: 'newest',
      tripSquareSort: 'comprehensive',
      tripPage: 1,
      tripPageSize: 10,
      publicTrips: [],
      publicTripsLoading: false,
      publicTripsLoaded: false,
      publicTripsError: '',
      publicDiaries: [],
      publicDiariesLoading: false,
      publicDiariesLoaded: false,
      publicDiariesError: '',
      lang: localStorage.getItem(KEYS.LANG) || 'zh-CN',
      heroIndex: 0,
      stateVersion: 0,
      fromSearch: { account: false, trip: false, diary: false },
      showProfilePanel: false,
      showAccountSecurityPanel: false,
      worldViewMode: 'global',
      worldContinent: 'global',
      worldKeyword: '',
      worldDimension: '2d',
      worldIsFullscreen: false,
      worldCardCollapsed: false,
      worldDestinations: WORLD_MAP_DEMO_DESTINATIONS,
      worldSelectedId: WORLD_MAP_DEMO_DESTINATIONS[0]?.id || '',
      worldMapLoading: false,
      worldMapError: '',
      worldGeocodeLoading: false,
      worldSearchResult: null,
      worldTripDrawer: { show: false, title: '', type: '', rows: [] },
      deletingAccount: false,
      accountDeleteForm: { confirmText: '', reason: '' },
      accountDeleteStatus: '',
      supportCount: Number(localStorage.getItem(KEYS.SUPPORT) || 0),
      feedback: { content: '', email: '' },
      followDialog: { show: false, title: '', users: [], mode: 'list', groupId: '' },
      groupDialog: { show: false, members: [] },
      billCreateDialog: { show: false, status: '', title: '', baseCurrency: 'CNY', members: [], createChat: true },
      billInviteDialog: { show: false, billId: '', users: [] },
      billItemDialog: { show: false, mode: 'create', billId: '', itemId: '', status: '', form: null },
      tripBillsByTrip: {},
      billDetails: {},
      billLoadingByTrip: {},
      billDetailLoading: false,
      billEventsPage: 1,
      billEventsPageSize: 10,
      myBillsLoading: false,
      myBillsLoaded: false,
      myBillsError: '',
      myBillsPage: 1,
      myBillsPageSize: 10,
      myBillsList: [],
      groupMemberDialog: { show: false, groupId: '', title: '', users: [] },
      groupName: '',
      tripEditMode: false,
      diaryEditMode: false,
      tripEditForm: { title: '', origin: '', destination: '', departDate: '', departFlex: '', returnDate: '', returnFlex: '', durationText: '', budget: 0, tags: '', spots: '', itinerary: '', pace: '平衡', wakeUp: '自然醒', social: '适中' },
      diaryEditForm: { caption: '', location: '', checkin: '' },
      diaryEditImages: [],
      diaryEditEstimatedBytes: 0,
      diaryEditUploadedBytes: {},
      diaryDraftFiles: [],
      diaryDraftPreviews: [],
      ai: {
        generating: false,
        error: ''
      },
      feedbackSuccessVisible: false,
      noticeModal: { show: false, title: '提示', message: '' },
      confirmModal: { show: false, title: '提示', message: '', confirmText: '确认', cancelText: '取消', resolver: null },
      feedbackPage: 1,
      feedbackPageSize: 10,
      achievementCenter: {
        loading: false,
        loaded: false,
        error: '',
        cityCode: 'hangzhou',
        cityName: '杭州',
        achievements: [],
        citySummaries: [],
        unlockMap: {},
        latestUnlock: null,
        platinumRule: null,
        overviewOpen: false,
        detailOpen: false,
        selectedAchievementCode: ''
      },
      guideCenter: {
        cityCode: 'hangzhou',
        selectedGuideId: 'hangzhou-platinum-full'
      }
    });
    if (app.route === 'world') app.worldMapLoading = true;
    const noticeState = reactive(getNoticeState(app.current));
    const chatHistoryRef = ref(null);
    const worldMapRef = ref(null);
    const worldGlobeRef = ref(null);
    const worldFullRef = ref(null);
    let worldMap = null;
    let worldMapResizeObserver = null;
    let worldGlobe = null;

    let worldMarkers = [];
    let worldMapReady = false;
    let worldHoverPopup = null;
    let worldGlobeCountriesData = null;
    let worldGlobeHoveredCountry = null;
    let worldGlobeResizeHandler = null;

    function focusWorldContinent(continent = 'global') {
      const preset = WORLD_CONTINENT_VIEW[continent] || WORLD_CONTINENT_VIEW.global;
      if (app.worldDimension === '3d' && worldGlobe) {
        try { worldGlobe.pointOfView({ lat: preset.lat, lng: preset.lng, altitude: preset.altitude }, 900); } catch {}
        return;
      }
      if (worldMap && worldMapReady) {
        try {
          worldMap.flyTo({ center: preset.center, zoom: preset.zoom, speed: 0.75, curve: 1.12, essential: true });
        } catch {}
      }
    }

    function syncWorldContinentView(continent = 'global', selected = null) {
      const target = selected || null;

      if (app.worldDimension === '3d' && worldGlobe) {
        if (target) {
          focusWorldGlobe(target, true);
        } else {
          const preset = WORLD_CONTINENT_VIEW[continent] || WORLD_CONTINENT_VIEW.global;
          try {
            worldGlobe.pointOfView({ lat: preset.lat, lng: preset.lng, altitude: preset.altitude }, 900);
          } catch {}
        }
        return;
      }

      if (worldMap && worldMapReady) {
        if (target) {
          try {
            worldMap.flyTo({
              center: [Number(target.lng || 0), Number(target.lat || 0)],
              zoom: continent && continent !== 'global' ? 3.05 : 2.2,
              speed: 0.75,
              curve: 1.12,
              essential: true
            });
          } catch {}
        } else {
          focusWorldContinent(continent || 'global');
        }
      }
    }

    function scrollChatToBottom(force = false) {
      nextTick(() => {
        const el = chatHistoryRef.value;
        if (!el) return;
        const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
        if (force || nearBottom) el.scrollTop = el.scrollHeight;
      });
    }

    async function hydrateCurrentAuthUser() {
      const client = window.RJSupabase;
      try {
        const session = await client?.getSupabaseAuthSession?.();
        app.currentAuthUserId = session?.user?.id || '';
        if (app.route === 'admin' && !isAdminAuthUserId(app.currentAuthUserId)) {
          app.route = 'home';
          location.hash = '/home';
        }
      } catch (_) {
        app.currentAuthUserId = '';
      }
    }

    const isAdmin = computed(() => isAdminAuthUserId(app.currentAuthUserId));


    
    const worldSyncedDestinations = computed(() => {
      const rows = [];
      const rawTrips = [];

      const tryResolveCoord = (trip) => {
        const candidates = [
          trip?.destination,
          trip?.title,
          Array.isArray(trip?.spots) ? trip.spots.join(' ') : trip?.spots,
          Array.isArray(trip?.tags) ? trip.tags.join(' ') : trip?.tags
        ].filter(Boolean);

        for (const text of candidates) {
          const coord = resolveWorldCoordByText(text);
          if (coord) return coord;
        }
        return null;
      };

      const stableTripKey = (trip) => {
        const id = String(trip?.id || trip?.dbId || trip?.tripId || '').trim();
        if (id) return `id:${id}`;

        return [
          String(trip?.user || '').trim(),
          String(trip?.title || '').trim(),
          String(trip?.destination || '').trim(),
          String(trip?.departDate || trip?.departFlex || '').trim(),
          String(trip?.returnDate || trip?.returnFlex || '').trim(),
          String(trip?.budget || '').trim()
        ].join('|');
      };

      try {
        (getUsers() || []).forEach((user) => {
          const state = getState(user.nickname);
          (state.trips || []).forEach((trip) => {
            rawTrips.push({
              ...trip,
              user: trip.user || user.nickname,
              __source: 'local'
            });
          });
        });

        (Array.isArray(app.publicTrips) ? app.publicTrips : []).forEach((trip) => {
          rawTrips.push({
            ...trip,
            user: trip.user || '',
            __source: 'public'
          });
        });
      } catch (err) {
        console.warn('[world] aggregate raw trips failed', err);
      }

      const dedupedTrips = Array.from(
        new Map(
          rawTrips.map((trip) => {
            const key = stableTripKey(trip);
            return [key, trip];
          })
        ).values()
      );

      const tripRows = dedupedTrips
        .map((trip) => {
          const coord = tryResolveCoord(trip);
          if (!coord) return null;
          return { ...trip, coord };
        })
        .filter(Boolean);

      const grouped = new Map();

      tripRows.forEach((trip) => {
        const key = `${trip.coord.country}|${trip.coord.city}`;
        const bucket = grouped.get(key) || {
          id: key,
          country: trip.coord.country,
          city: trip.coord.city,
          name: trip.coord.name || trip.coord.city || trip.coord.country,
          lat: trip.coord.lat,
          lng: trip.coord.lng,
          badges: trip.coord.badges || [],
          tone: 'rgba(99,210,255,.95)',
          summary: '',
          users: [],
          visitedCount: 0,
          plannedCount: 0,
          visitedTrips: [],
          plannedTrips: [],
          continent: resolveWorldContinent(trip.destination || trip.coord.country || trip.coord.city)
        };

        const isPlanned = isFutureTripDate(trip.departDate || trip.departFlex);

        if (isPlanned) {
          bucket.plannedCount += 1;
          bucket.plannedTrips.push(trip);
        } else {
          bucket.visitedCount += 1;
          bucket.visitedTrips.push(trip);
        }

        const avatarUser = String(trip.user || '').trim();
        bucket.users.push({
          name: avatarUser,
          avatar: getState(avatarUser).profile?.avatar || defaultAvatar
        });

        grouped.set(key, bucket);
      });

      grouped.forEach((bucket) => {
        const uniqueUsers = Array.from(
          new Map((bucket.users || []).map((u) => [u.name, u])).values()
        );
        bucket.users = uniqueUsers.slice(0, 5);
        bucket.summary = `去过 ${bucket.visitedCount} 人 · 计划 ${bucket.plannedCount} 人`;

        if (bucket.plannedCount > 1) bucket.tone = 'rgba(255,140,92,.95)';
        else if (bucket.plannedCount >= 1) bucket.tone = 'rgba(255,196,82,.95)';
        else if (bucket.visitedCount > 0) bucket.tone = 'rgba(99,210,255,.95)';

        rows.push(bucket);
      });

      return rows.length ? rows : WORLD_MAP_DEMO_DESTINATIONS;
    });

    const worldDestinations = computed(() => {
      const keyword = String(app.worldKeyword || '').trim().toLowerCase();
      let source = Array.isArray(worldSyncedDestinations.value) ? [...worldSyncedDestinations.value] : [];
      if (app.worldSearchResult && !source.some((item) => item.id === app.worldSearchResult.id)) source.unshift(app.worldSearchResult);
      if (app.worldContinent && app.worldContinent !== 'global') {
        source = source.filter((item) => (item.continent || resolveWorldContinent(item.country || item.city || item.name)) === app.worldContinent);
      }
      if (!keyword) return source;
      return source.filter((item) => [item.country, item.city, item.name, item.summary, ...(item.badges || [])].join('|').toLowerCase().includes(keyword));
    });
    const selectedWorldDestination = computed(() => {
      const source = Array.isArray(worldDestinations.value) ? worldDestinations.value : [];
      return source.find((item) => item.id === app.worldSelectedId) || source[0] || null;
    });

function syncWorldCanvasVisibility() {
      const mapEl = worldMapRef.value;
      const globeEl = worldGlobeRef.value;
      const is3d = app.worldDimension === '3d';
      if (mapEl) mapEl.style.visibility = is3d ? 'hidden' : 'visible';
      if (mapEl) mapEl.style.pointerEvents = is3d ? 'none' : 'auto';
      if (globeEl) globeEl.classList.toggle('is-active', is3d);
      if (globeEl) globeEl.style.pointerEvents = is3d ? 'auto' : 'none';
    }

    function worldPointPayloads() {
      return (Array.isArray(worldDestinations.value) ? worldDestinations.value : []).map((point) => ({
        ...point,
        size: point.id === app.worldSelectedId ? 1.2 : 0.8,
        color: point.tone || 'rgba(255,196,82,.95)',
        pulseLevel: Number(point.plannedCount || 0) > 1 ? 'strong' : (Number(point.plannedCount || 0) >= 1 ? 'soft' : 'none')
      }));
    }

    function focusWorldGlobe(point, animate = true) {
      if (!worldGlobe || !point) return;
      const lat = Number(point.lat || 0);
      const lng = Number(point.lng || 0);
      try {
        worldGlobe.pointOfView({ lat, lng, altitude: 1.9 }, animate ? 900 : 0);
      } catch (err) {
        console.warn('[world-globe] pointOfView failed', err);
      }
    }

    async function loadWorldGlobeCountries() {
      if (worldGlobeCountriesData) return worldGlobeCountriesData;
      try {
        const geojson = await loadWorldGeoJson();
        worldGlobeCountriesData = Array.isArray(geojson?.features) ? geojson.features : [];
      } catch (err) {
        console.warn('[world-globe] countries geojson load failed', err);
        worldGlobeCountriesData = [];
      }
      return worldGlobeCountriesData;
    }

    function getWorldCountryName(feature) {
      const props = feature?.properties || {};
      return String(props.ADMIN || props.name || props.NAME || '').trim();
    }

    async function renderWorldGlobePolygons() {
      if (!worldGlobe) return;
      const features = await loadWorldGlobeCountries();
      worldGlobe
        .polygonsTransitionDuration(120)
        .polygonsData(features)
        .polygonCapColor((feat) => {
          const hovered = feat === worldGlobeHoveredCountry;
          return hovered ? 'rgba(76,201,255,0.12)' : 'rgba(0,0,0,0)';
        })
        .polygonSideColor(() => 'rgba(0,0,0,0)')
        .polygonStrokeColor((feat) => feat === worldGlobeHoveredCountry ? 'rgba(120,220,255,0.96)' : 'rgba(178,198,224,0.48)')
        .polygonAltitude((feat) => feat === worldGlobeHoveredCountry ? 0.004 : 0.0001)
        .polygonLabel((feat) => {
          const name = getWorldCountryName(feat);
          if (!name) return '';
          return `<div style="padding:6px 10px;border-radius:12px;background:rgba(9,18,31,.94);color:#fff;border:1px solid rgba(255,255,255,.12);font-size:12px;box-shadow:0 10px 22px rgba(0,0,0,.24);">${name}</div>`;
        })
        .onPolygonHover((feat) => {
          if (worldGlobeHoveredCountry === feat) return;
          worldGlobeHoveredCountry = feat || null;
          renderWorldGlobePolygons();
        });
    }

    async function renderWorldGlobeMarkers() {
      if (!worldGlobe) return;
      const rows = worldPointPayloads();
      worldGlobe
        .htmlElementsData(rows)
        .htmlLat((d) => Number(d.lat || 0))
        .htmlLng((d) => Number(d.lng || 0))
        .htmlAltitude((d) => d.id === app.worldSelectedId ? 0.035 : 0.02)
        .htmlElement((point) => {
          const el = document.createElement('div');
          el.innerHTML = makeWorldMarkerHtml(point, point.id === app.worldSelectedId, defaultAvatar);
          const node = el.firstElementChild || el;
          node.style.transform = 'translate(-50%, -100%) scale(0.82)';
          node.style.pointerEvents = 'auto';
          if (Number(point.plannedCount || 0) >= 1) {
            node.classList.add(Number(point.plannedCount || 0) > 1 ? 'is-planned-strong' : 'is-planned-soft');
          }
          node.addEventListener('click', (evt) => {
            evt.stopPropagation();
            selectWorldDestination(point.id, true);
          });
          return node;
        });
    }

    async function ensureWorldGlobe(forceFly = false) {
      if (app.route !== 'world') return;
      if (!worldGlobeRef.value) await nextTick();
      if (!worldGlobeRef.value) return;
      try {
        const Globe = await loadWorldGlobeSdk();
        if (!worldGlobe) {
          worldGlobe = Globe()(worldGlobeRef.value)
            .globeImageUrl('/assets/vendor/earth-dark.jpg')
            .bumpImageUrl('/assets/vendor/earth-topology.png')
            .backgroundColor('rgba(0,0,0,0)')
            .showAtmosphere(true)
            .atmosphereColor('#4cc9ff')
            .atmosphereAltitude(0.11)
            .pointOfView({ lat: 26, lng: 20, altitude: 1.95 }, 0);
          worldGlobe.controls().enablePan = false;
          worldGlobe.controls().autoRotate = true;
          worldGlobe.controls().autoRotateSpeed = 0.18;
          worldGlobe.controls().enableDamping = true;
          worldGlobe.controls().dampingFactor = 0.08;
          worldGlobe.controls().minDistance = 160;
          worldGlobe.controls().maxDistance = 420;
          worldGlobe.width(worldGlobeRef.value.clientWidth || 1200);
          worldGlobe.height(worldGlobeRef.value.clientHeight || 680);
          if (!worldGlobeResizeHandler) {
            worldGlobeResizeHandler = () => {
              if (!worldGlobe || !worldGlobeRef.value) return;
              worldGlobe.width(worldGlobeRef.value.clientWidth || 1200);
              worldGlobe.height(worldGlobeRef.value.clientHeight || 680);
            };
            window.addEventListener('resize', worldGlobeResizeHandler, { passive: true });
          }
        }
        syncWorldCanvasVisibility();
        try {
          const globeCanvas = worldGlobeRef.value?.querySelector('canvas');
          if (globeCanvas && !globeCanvas.dataset.rotateBound) {
            globeCanvas.dataset.rotateBound = '1';
            globeCanvas.addEventListener('pointerdown', () => {
              try { if (worldGlobe?.controls()) worldGlobe.controls().autoRotate = false; } catch {}
            });
            globeCanvas.addEventListener('pointerup', () => {
              try { if (worldGlobe?.controls()) worldGlobe.controls().autoRotate = true; } catch {}
            });
            globeCanvas.addEventListener('pointerleave', () => {
              try { if (worldGlobe?.controls()) worldGlobe.controls().autoRotate = true; } catch {}
            });
          }
        } catch {}
        await renderWorldGlobePolygons();
        await renderWorldGlobeMarkers();
        if (forceFly) {
          const selected = selectedWorldDestination.value;
          if (selected) focusWorldGlobe(selected, true);
        }
      } catch (error) {
        console.error('[world-globe] init failed', error);
        app.worldMapError = `3D 地球仪加载失败：${error?.message || error}`;
      }
    }

    
    async function geocodeWorldKeyword(keyword) {
      const query = String(keyword || '').trim();
      if (!query) return null;
      const local = resolveWorldCoordByText(query);
      if (local) {
        return {
          id: `search-${normalizeWorldLocationKey(query)}`,
          country: local.country,
          city: local.city,
          name: local.name || local.city || query,
          lat: Number(local.lat || 0),
          lng: Number(local.lng || 0),
          tone: 'rgba(99,210,255,.95)',
          badges: local.badges || ['🔎','📍'],
          summary: query,
          users: [],
          visitedCount: 0,
          plannedCount: 0,
          visitedTrips: [],
          plannedTrips: []
        };
      }
      app.worldGeocodeLoading = true;
      try {
        const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=${encodeURIComponent(query)}`;
        const res = await fetch(url, { headers: { Accept: 'application/json' } });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const rows = await res.json();
        const item = Array.isArray(rows) ? rows[0] : null;
        if (!item) return null;
        const parts = String(item.display_name || '').split(',').map((x) => x.trim()).filter(Boolean);
        const city = parts[0] || query;
        const country = parts[parts.length - 1] || query;
        return {
          id: `search-${Date.now()}`,
          country, city, name: city,
          lat: Number(item.lat || 0), lng: Number(item.lon || 0),
          tone: 'rgba(99,210,255,.95)', badges: ['🔎','📍'],
          summary: String(item.display_name || query), users: [],
          visitedCount: 0, plannedCount: 0, visitedTrips: [], plannedTrips: []
        };
      } finally {
        app.worldGeocodeLoading = false;
      }
    }

async function renderWorldMapMarkers() {
  if (!worldMap || !window.maplibregl) return;
  worldMarkers.forEach((marker) => {
    try { marker.remove(); } catch {}
  });
  worldMarkers = [];
  const points = Array.isArray(worldDestinations.value) ? worldDestinations.value : [];
  points.forEach((point) => {
    const active = point.id === app.worldSelectedId;
    const el = document.createElement('div');
    el.innerHTML = makeWorldMarkerHtml(point, active, defaultAvatar);
    const node = el.firstElementChild;
    if (!node) return;
    if (Number(point.plannedCount || 0) >= 1) {
      const pulse = document.createElement('span');
      pulse.className = `gemi-world-pulse ${Number(point.plannedCount || 0) > 1 ? 'is-strong' : 'is-soft'}`;
      pulse.style.cssText = `position:absolute;left:50%;bottom:8px;transform:translateX(-50%);width:${Number(point.plannedCount || 0) > 1 ? 46 : 34}px;height:${Number(point.plannedCount || 0) > 1 ? 46 : 34}px;border-radius:999px;border:2px solid ${point.tone || 'rgba(255,196,82,.95)'};pointer-events:none;`;
      node.appendChild(pulse);
    }
    node.addEventListener('click', (evt) => {
      evt.stopPropagation();
      selectWorldDestination(point.id, true);
    });
    const marker = new window.maplibregl.Marker({ element: node, anchor: 'bottom' })
      .setLngLat([Number(point.lng || 0), Number(point.lat || 0)])
      .addTo(worldMap);
    worldMarkers.push(marker);
  });
}

function applyWorldDimensionMode(mode = '2d', animate = true) {
  app.worldDimension = mode === '3d' ? '3d' : '2d';
  closeWorldTripDrawer();

  if (app.worldDimension === '3d') {
    syncWorldCanvasVisibility();
    ensureWorldGlobe(true);
  } else {
    destroyWorldGlobe();
    syncWorldCanvasVisibility();
  }

  if (worldMap) {
    try { worldMap.resize(); } catch {}
    const is3d = app.worldDimension === '3d';
    try {
      if (typeof worldMap.setProjection === 'function') {
        worldMap.setProjection({ type: is3d ? 'globe' : 'mercator' });
      }
    } catch (err) {
      console.warn('[world-map] setProjection failed', err);
    }
    try {
      worldMap.easeTo({
        pitch: is3d ? 48 : 0,
        bearing: is3d ? -18 : 0,
        duration: animate ? 900 : 0,
        essential: true
      });
    } catch {}
  }
  if (app.worldDimension === '2d') {
    setTimeout(() => { renderWorldMapMarkers(); }, animate ? 180 : 0);
  } else {
    setTimeout(() => {
      if (worldGlobe) renderWorldGlobeMarkers();
    }, animate ? 180 : 0);
  }
}

async function submitWorldSearch() {
  const keyword = String(app.worldKeyword || '').trim().toLowerCase();
  if (!keyword) return;

  // 搜索城市/国家时，自动清空大洲筛选，避免“当前筛选=美洲，但搜索=亚洲城市”导致结果被过滤掉。
  if (app.worldContinent !== 'global') {
    app.worldContinent = 'global';
    await nextTick();
  }

  const fullSource = Array.isArray(worldSyncedDestinations.value) ? worldSyncedDestinations.value : [];
  const localMatch = fullSource.find((item) =>
    [item.country, item.city, item.name, item.summary, ...(item.badges || [])].join('|').toLowerCase().includes(keyword)
  );
  if (localMatch) {
    app.worldSearchResult = null;
    selectWorldDestination(localMatch.id, true);
    return;
  }
  const geo = await geocodeWorldKeyword(app.worldKeyword);
  if (!geo) {
    app.worldMapError = `没有找到“${app.worldKeyword}”对应的城市/国家坐标`;
    return;
  }
  app.worldMapError = '';
  app.worldSearchResult = {
    ...geo,
    continent: resolveWorldContinent(geo.country || geo.city || geo.name)
  };
  app.worldSelectedId = geo.id;
  await nextTick();
  if (app.worldDimension === '3d') {
    await ensureWorldGlobe(true);
    focusWorldGlobe(geo, true);
  } else if (worldMap && worldMapReady) {
    worldMap.flyTo({ center: [geo.lng, geo.lat], zoom: 4.2, speed: 0.82, curve: 1.12, essential: true });
  }
}

function toggleWorldCard() {
  app.worldCardCollapsed = !app.worldCardCollapsed;
  setTimeout(() => { try { worldMap && worldMap.resize(); } catch {} }, 120);
}

let worldMapInitTimer = null;
function scheduleEnsureWorldMap(delay = 0, forceFly = false) {
  clearTimeout(worldMapInitTimer);
  worldMapInitTimer = setTimeout(() => {
    ensureWorldMap(forceFly);
  }, Math.max(0, Number(delay || 0)));
}

function scheduleWorldMapResize() {
  requestAnimationFrame(() => {
    try { worldMap && worldMap.resize(); } catch {}
    requestAnimationFrame(() => {
      try { worldMap && worldMap.resize(); } catch {}
      setTimeout(() => { try { worldMap && worldMap.resize(); } catch {} }, 120);
    });
  });
}

async function ensureWorldMap(forceFly = false) {
  if (app.route !== 'world') return;
  if (!worldMapRef.value) await nextTick();
  if (!worldMapRef.value) return;
  app.worldMapError = '';
  app.worldMapLoading = true;
  const timeout = setTimeout(() => {
    if (!worldMapReady) {
      app.worldMapError = '地图资源加载较慢或被浏览器/网络拦截。';
      app.worldMapLoading = false;
    }
  }, 20000);
  try {
    const maplibregl = await loadWorldMapSdk();
    if (!worldMap) {
      worldMap = new maplibregl.Map({
        container: worldMapRef.value,
        style: {
          version: 8,
          projection: { type: 'mercator' },
          sources: {
            world: {
              type: 'geojson',
              data: '/assets/vendor/world-countries-lite.geojson'
            }
          },
          layers: [
            { id: 'world-fill', type: 'fill', source: 'world', paint: { 'fill-color': '#1f2937', 'fill-opacity': 0.88 } },
            { id: 'world-line', type: 'line', source: 'world', paint: { 'line-color': 'rgba(255,255,255,0.18)', 'line-width': 1 } }
          ]
        },
        center: [40, 24],
        zoom: 1.35,
        minZoom: 1.1,
        maxZoom: 5.8,
        pitch: 0,
        bearing: 0,
        antialias: true,
        attributionControl: false
      });
      worldMap.addControl(new maplibregl.NavigationControl({ visualizePitch: true, showCompass: true }), 'top-right');
      try { worldMap.dragRotate.enable(); } catch {}
      try { worldMap.touchZoomRotate.enable(); } catch {}
      try { worldMap.touchZoomRotate.enableRotation(); } catch {}
      try { if (worldMap.touchPitch && typeof worldMap.touchPitch.enable === 'function') worldMap.touchPitch.enable(); } catch {}
      if (worldMapRef.value) {
        worldMapRef.value.addEventListener('contextmenu', (e) => e.preventDefault());
      }

      worldMap.on('load', async () => {
        worldMapReady = true;
        clearTimeout(timeout);
        app.worldMapLoading = false;
        try { worldMap.setMaxPitch(70); } catch {}
        syncWorldCanvasVisibility();
        applyWorldDimensionMode(app.worldDimension || '2d', false);
        await renderWorldMapMarkers();
        if (app.worldDimension === '3d') await ensureWorldGlobe(false);
        const selected = selectedWorldDestination.value;
        if (selected) {
          worldMap.flyTo({ center: [Number(selected.lng || 0), Number(selected.lat || 0)], zoom: 2.15, speed: 0.7, curve: 1.12, essential: true });
        }
        scheduleWorldMapResize();
      });
      worldMap.on('error', (evt) => {
        console.error('[world-map] map error', evt?.error || evt);
        app.worldMapError = `地图加载失败：${evt?.error?.message || '底图资源不可用'}`;
        app.worldMapLoading = false;
      });
      worldHoverPopup = new maplibregl.Popup({ closeButton: false, closeOnClick: false, offset: 12, className: 'gemi-country-hover' });
      worldMap.on('mousemove', 'world-fill', (e) => {
        try {
          const feat = e?.features?.[0];
          const props = feat?.properties || {};
          const name = props.ADMIN || props.name || props.NAME || '';
          if (!name) return;
          worldHoverPopup.setLngLat(e.lngLat).setHTML(`<div style="padding:4px 8px;color:#fff;font-size:12px;">${name}</div>`).addTo(worldMap);
        } catch {}
      });
      worldMap.on('mouseleave', 'world-fill', () => {
        try { worldHoverPopup && worldHoverPopup.remove(); } catch {}
      });
    }
    scheduleWorldMapResize();
    if (worldMapReady) {
      clearTimeout(timeout);
      app.worldMapLoading = false;
      applyWorldDimensionMode(app.worldDimension || '2d', false);
      await renderWorldMapMarkers();
      if (forceFly) {
        const selected = selectedWorldDestination.value;
        if (selected) {
          worldMap.flyTo({ center: [Number(selected.lng || 0), Number(selected.lat || 0)], zoom: 2.15, speed: 0.7, curve: 1.12, essential: true });
        }
      }
    }
  } catch (error) {
    clearTimeout(timeout);
    console.error('[world-map] init failed', error);
    app.worldMapError = `地图加载失败：${error?.message || error}`;
    app.worldMapLoading = false;
  }
}

function destroyWorldGlobe() {
  try {
    if (worldGlobe?.controls?.()) {
      worldGlobe.controls().autoRotate = false;
    }
  } catch {}
  try {
    const globeCanvas = worldGlobeRef.value?.querySelector('canvas');
    const loseCtx = globeCanvas?.getContext('webgl') || globeCanvas?.getContext('webgl2');
    const ext = loseCtx?.getExtension && loseCtx.getExtension('WEBGL_lose_context');
    if (ext && typeof ext.loseContext === 'function') ext.loseContext();
  } catch {}
  try {
    if (worldGlobeRef.value) worldGlobeRef.value.innerHTML = '';
  } catch {}
  if (worldGlobeResizeHandler) {
    try { window.removeEventListener('resize', worldGlobeResizeHandler); } catch {}
    worldGlobeResizeHandler = null;
  }
  worldGlobe = null;
  worldGlobeHoveredCountry = null;
}

function destroyWorldMap() {
  worldMarkers.forEach((marker) => {
    try { marker.remove(); } catch {}
  });
  worldMarkers = [];
  if (worldMap) {
    try { worldMap.remove(); } catch {}
  }
  worldMap = null;
  destroyWorldGlobe();
  worldMapReady = false;
}
function openWorldMap() {
  if (app.route !== 'world') {
    destroyWorldMap();
  }
  goto('world');
  nextTick(() => { scheduleEnsureWorldMap(0, true); scheduleWorldMapResize(); });
}
    function selectWorldDestination(id, flyTo = false) {
      closeWorldTripDrawer();
      if (!id) return;

      app.worldSelectedId = id;
      const selected = (Array.isArray(worldDestinations.value) ? worldDestinations.value : []).find((item) => item.id === id);
      if (!selected) return;

      if (flyTo) {
        syncWorldContinentView(app.worldContinent || 'global', selected);
      }
    }

    watch(() => app.current, (user) => {
      const next = getNoticeState(user);
      Object.keys(noticeState).forEach((key) => { delete noticeState[key]; });
      noticeState.chatReadAt = next.chatReadAt;
      noticeState.systemReadAt = next.systemReadAt;
      app.social = getSocial(user || '');
      if (user) {
        Promise.resolve(refreshSocialGraphFromDb()).catch(() => {});
        Promise.resolve(refreshChatsFromDb()).catch(() => {});
      }
    });

    watch(() => app.tripSquareSearch, () => {
      app.tripPage = 1;
    });

    watch(() => app.tripSquareSort, () => {
      app.tripPage = 1;
    });

    watch(() => app.route, async (route, prevRoute) => {
      if (prevRoute === 'world' && route !== 'world') {
        destroyWorldMap();
      }
      if (route === 'world') {
        await nextTick();
        scheduleEnsureWorldMap(0, false);
        scheduleWorldMapResize();
      }
      if (route === 'my' && app.currentAuthUserId) {
        Promise.resolve(loadAchievementCenter(app.achievementCenter.cityCode || 'hangzhou')).catch(() => {});
      }
    }, { immediate: true });

    watch(() => app.currentAuthUserId, (value) => {
      if (!value) return;
      if (app.route === 'my') {
        Promise.resolve(loadAchievementCenter(app.achievementCenter.cityCode || 'hangzhou')).catch(() => {});
      }
    });

    watch(worldDestinations, async (rows) => {
      const list = Array.isArray(rows) ? rows : [];
      if (!list.length) return;
      if (!list.some((item) => item.id === app.worldSelectedId)) {
        app.worldSelectedId = list[0].id;
      }
      if (app.route === 'world') {
        await nextTick();
        renderWorldMapMarkers();
      }
    });


    watch(() => app.worldContinent, async (continent) => {
      closeWorldTripDrawer();
      if (app.route !== 'world') return;

      await nextTick();

      const list = Array.isArray(worldDestinations.value) ? worldDestinations.value : [];
      const selectedVisible = list.find((item) => item.id === app.worldSelectedId);
      const nextSelected = selectedVisible || list[0] || null;

      if (nextSelected && nextSelected.id !== app.worldSelectedId) {
        app.worldSelectedId = nextSelected.id;
      }

      await renderWorldMapMarkers();

      if (app.worldDimension === '3d') {
        await ensureWorldGlobe(false);
        await renderWorldGlobeMarkers();
      }

      syncWorldContinentView(continent || 'global', nextSelected);
    });

    watch(() => app.worldSelectedId, async () => {
      if (app.route !== 'world') return;
      await nextTick();
      renderWorldMapMarkers();
      if (app.worldDimension === '3d' && worldGlobe) renderWorldGlobeMarkers();
    });

    watch(() => app.worldDimension, (mode) => {
      if (app.route !== 'world') return;
      applyWorldDimensionMode(mode, true);
    });

    onMounted(() => {
      try { ensureWorldMapStyles(); } catch {}
      document.addEventListener('fullscreenchange', handleWorldFullscreenChange);
      if (typeof ResizeObserver !== 'undefined') {
        worldMapResizeObserver = new ResizeObserver(() => {
          scheduleWorldMapResize();
          try {
            if (app.worldDimension === '3d' && worldGlobe && worldGlobeRef.value) {
              worldGlobe.width(worldGlobeRef.value.clientWidth || 1200);
              worldGlobe.height(worldGlobeRef.value.clientHeight || 680);
            }
          } catch {}
        });
        if (worldMapRef.value) worldMapResizeObserver.observe(worldMapRef.value);
        if (worldFullRef.value) worldMapResizeObserver.observe(worldFullRef.value);
      }
      if (app.route === 'world') {
        nextTick(() => {
          scheduleEnsureWorldMap(0, false);
          scheduleWorldMapResize();
        });
      }
    });

    onUnmounted(() => {
      document.removeEventListener('fullscreenchange', handleWorldFullscreenChange);
      if (worldMapResizeObserver) {
        try { worldMapResizeObserver.disconnect(); } catch {}
        worldMapResizeObserver = null;
      }
      destroyWorldMap();
    });

    
    function openWorldTripDrawer(type) {
      const selected = selectedWorldDestination.value;
      if (!selected) return;
      const rows = type === 'visited' ? (selected.visitedTrips || []) : (selected.plannedTrips || []);
      app.worldTripDrawer = {
        show: true,
        title: `${selected.name} · ${type === 'visited' ? '已经去过' : '未来计划去'}`,
        type,
        rows: rows
      };
    }
    function closeWorldTripDrawer() {
      app.worldTripDrawer = { show: false, title: '', type: '', rows: [] };
    }
    function openWorldTripDetail(trip) {
      closeWorldTripDrawer();
      if (trip?.id) openTrip(trip.id);
    }
    async function toggleWorldFullscreen() {
      const el = worldFullRef.value;
      if (!el) return;

      try {
        if (document.fullscreenElement) {
          await document.exitFullscreen();
        } else if (el.requestFullscreen) {
          await el.requestFullscreen();
        }
      } catch (err) {
        console.warn('[world] fullscreen failed', err);
      } finally {
        app.worldIsFullscreen = !!document.fullscreenElement;
        setTimeout(() => {
          try { worldMap && worldMap.resize(); } catch {}
          try {
            if (app.worldDimension === '3d' && worldGlobe && worldGlobeRef.value) {
              worldGlobe.width(worldGlobeRef.value.clientWidth || 1200);
              worldGlobe.height(worldGlobeRef.value.clientHeight || 680);
            }
          } catch {}
        }, 80);
      }
    }

    function handleWorldFullscreenChange() {
      app.worldIsFullscreen = !!document.fullscreenElement;
      setTimeout(() => {
        scheduleWorldMapResize();
        try {
          if (worldGlobe && worldGlobeRef.value) {
            worldGlobe.width(worldGlobeRef.value.clientWidth || 1200);
            worldGlobe.height(worldGlobeRef.value.clientHeight || 680);
          }
        } catch {}
      }, 80);
    }

function t(key) {
      return I18N[app.lang]?.[key] || I18N['zh-CN']?.[key] || key;
    }
    function setLang() {
      localStorage.setItem(KEYS.LANG, app.lang);
    }
    function shortName(name) {
      return String(name || '');
    }

    function showCenterNotice(message, title = '提示') {
      app.noticeModal.title = title;
      app.noticeModal.message = String(message || '');
      app.noticeModal.show = true;
    }
    function closeCenterNotice() {
      app.noticeModal.show = false;
    }
    function showCenterConfirm(message, title = '提示', options = {}) {
      const confirmText = String(options.confirmText || '确认');
      const cancelText = String(options.cancelText || '取消');
      return new Promise((resolve) => {
        app.confirmModal.title = title;
        app.confirmModal.message = String(message || '');
        app.confirmModal.confirmText = confirmText;
        app.confirmModal.cancelText = cancelText;
        app.confirmModal.resolver = resolve;
        app.confirmModal.show = true;
      });
    }
    function resolveCenterConfirm(result) {
      const resolver = typeof app.confirmModal.resolver === 'function' ? app.confirmModal.resolver : null;
      app.confirmModal.show = false;
      app.confirmModal.resolver = null;
      if (resolver) resolver(Boolean(result));
    }

    function groupDiaryRows(rows) {
      const source = Array.isArray(rows) ? rows : [];
      const map = new Map();
      source.forEach((item) => {
        const key = item.batchId || item.id;
        const list = map.get(key) || [];
        list.push(item);
        map.set(key, list);
      });
      return Array.from(map.values())
        .map((list) => list.sort((a, b) => new Date(a.createdAt || 0) - new Date(b.createdAt || 0)))
        .sort((a, b) => new Date(b[0]?.createdAt || 0) - new Date(a[0]?.createdAt || 0));
    }

    function diaryGroupImages(group) {
      if (!group) return [];
      if (!Array.isArray(group)) {
        const direct = Array.isArray(group.images) && group.images.length
          ? group.images
          : (Array.isArray(group.covers) && group.covers.length ? group.covers : [group.cover]);
        return direct.filter(Boolean);
      }
      return group.map((row) => row.cover).filter(Boolean);
    }

    function diaryGroupItems(group) {
      if (Array.isArray(group)) return group.filter(Boolean);
      const images = diaryGroupImages(group);
      const batchId = group?.batchId || group?.id || '';
      return images.map((cover, index) => ({
        id: `${batchId || 'diary'}-${index}`,
        cover,
        batchId,
        createdAt: group?.createdAt || group?.updatedAt || now(),
        caption: group?.caption || '',
        location: group?.location || '',
        checkin: group?.checkin || ''
      }));
    }

    function diaryGroupPrimary(group) {
      return Array.isArray(group) ? (group[0] || null) : (group || null);
    }

    function diaryGroupLength(group) {
      return diaryGroupImages(group).length;
    }

    function diaryThumb(url, width = 820) {
      return toDisplayImageUrl(url, width, 70);
    }

    function avatarThumb(url, size = 96) {
      return toDisplayImageUrl(url, Math.max(48, Number(size || 96)), 58);
    }

    function callSupabase(method, ...args) {
      const client = window.RJSupabase;
      if (!client || typeof client[method] !== 'function' || !client.isEnabled?.()) return;
      Promise.resolve(client[method](...args)).catch((err) => {
        console.warn(`[RJSupabase.${method}]`, err?.message || err);
      });
    }

    
    async function refreshSocialGraphFromDb() {
      const client = window.RJSupabase;
      if (!app.current || !client?.isEnabled?.() || typeof client.fetchPublicSocialGraph !== 'function') return;
      try {
        const graph = await client.fetchPublicSocialGraph();
        app.social.follows = graph?.follows && typeof graph.follows === 'object' ? graph.follows : {};
        app.social.blocks = graph?.blocks && typeof graph.blocks === 'object' ? graph.blocks : {};
        setSocial(app.social, app.current);
      } catch (err) {
        console.warn('[vue-social] refresh social graph failed', err?.message || err);
      }
    }

    async function refreshChatsFromDb() {
      const client = window.RJSupabase;
      if (!app.current || !client?.isEnabled?.() || typeof client.fetchChatsForUser !== 'function') return;
      try {
        const rows = await client.fetchChatsForUser(app.current);
        app.social.chats = dedupeChats(rows);
        setSocial(app.social, app.current);
      } catch (err) {
        console.warn('[vue-chat] refresh chats failed', err?.message || err);
      }
    }


    function dedupeChats(rows) {
      const source = Array.isArray(rows) ? rows : [];
      const bySig = new Map();

      source.forEach((row) => {
        const id = String(row?.id || '').trim();
        const members = [...new Set((Array.isArray(row?.members) ? row.members : []).filter(Boolean))].sort();
        const isGroup = isGroupChatRecord(row);

        if (!isGroup && members.length !== 2) return;

        const sig = isGroup
          ? `group:${id || String(row?.name || '').trim()}`
          : `dm:${members.join('|')}`;

        const prev = bySig.get(sig);
        if (!prev) {
          bySig.set(sig, row);
          return;
        }

        const prevMsgs = Array.isArray(prev.messages) ? prev.messages.length : 0;
        const nextMsgs = Array.isArray(row.messages) ? row.messages.length : 0;

        const prevTime = new Date(
          prev.messages?.[prevMsgs - 1]?.createdAt || prev.updatedAt || prev.createdAt || 0
        ).getTime();

        const nextTime = new Date(
          row.messages?.[nextMsgs - 1]?.createdAt || row.updatedAt || row.createdAt || 0
        ).getTime();

        if (nextMsgs > prevMsgs || nextTime >= prevTime) {
          bySig.set(sig, { ...prev, ...row });
        }
      });

      return [...bySig.values()];
    }

function getSupabaseClient() {
      const client = window.RJSupabase;
      if (!client || !client.isEnabled?.() || typeof client.uploadDiaryImage !== 'function') return null;
      return client;
    }

    async function uploadDiaryFileToStorage(file, batchId, index) {
      const client = getSupabaseClient();
      if (!client) throw new Error('Supabase Storage 未配置，请先配置并创建公开 bucket。');
      const uploadFile = await optimizeImageFile(file);
      const result = await client.uploadDiaryImage(uploadFile, {
        nickname: app.current,
        batchId,
        index
      });
      return {
        url: result?.url,
        thumbUrl: toDisplayImageUrl(result?.url, 720, 70),
        size: Number(result?.size || uploadFile.size || file.size || 0)
      };
    }

    async function runUploadsWithConcurrency(files, batchId, startIndex = 0, concurrency = 3) {
      const source = Array.isArray(files) ? files : [];
      const results = new Array(source.length);
      let cursor = 0;
      async function worker() {
        while (cursor < source.length) {
          const current = cursor;
          cursor += 1;
          results[current] = await uploadDiaryFileToStorage(source[current], batchId, startIndex + current);
        }
      }
      const count = Math.max(1, Math.min(concurrency, source.length || 1));
      await Promise.all(Array.from({ length: count }, () => worker()));
      return results;
    }

    function resolveAIConfig() {
      const cfg = window.APP_CONFIG || {};
      return {
        endpoint: String(cfg.AI_ENDPOINT || '/api/ai/chat').trim(),
        model: String(cfg.AI_MODEL || AI_DEFAULT_MODEL).trim()
      };
    }

    function extractJson(text) {
      const raw = String(text || '').trim();
      const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
      const source = fenced ? fenced[1] : raw;
      return JSON.parse(source);
    }

    function normalizeStructuredItinerary(parsed) {
      if (!parsed || typeof parsed !== 'object') return '';
      if (typeof parsed.itineraryText === 'string' && parsed.itineraryText.trim()) {
        return parsed.itineraryText.trim();
      }

      const days = Array.isArray(parsed.itinerary) ? parsed.itinerary : [];
      const sections = [];

      if (parsed.summary && typeof parsed.summary === 'object') {
        const summaryBits = [];
        if (parsed.summary.dateRange) summaryBits.push(String(parsed.summary.dateRange));
        if (parsed.summary.days) summaryBits.push(`${parsed.summary.days}天`);
        if (parsed.summary.style) summaryBits.push(String(parsed.summary.style));
        if (parsed.summary.note) summaryBits.push(String(parsed.summary.note));
        if (summaryBits.length) {
          sections.push(`行程概览\n- ${summaryBits.join('｜')}`);
        }
      }

      days.forEach((day, idx) => {
        const dayLabel = String(day?.day || `D${idx + 1}`).trim();
        const title = String(day?.title || '').trim();
        const header = title ? `${dayLabel}｜${title}` : dayLabel;
        const items = Array.isArray(day?.items) ? day.items : [];
        const lines = items
          .map((item) => {
            const time = String(item?.time || '').trim();
            const content = String(item?.text || item?.content || '').trim();
            if (!content) return '';
            return time ? `- ${time}：${content}` : `- ${content}`;
          })
          .filter(Boolean);

        if (lines.length) {
          sections.push(`${header}\n${lines.join('\n')}`);
        }
      });

      return sections.join('\n\n').trim();
    }


    function escapeHtml(s) {
      return String(s || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
    }

    function formatTripItineraryHtml(raw, compact = false) {
      const text = String(raw || '').trim();
      if (!text) return '<div class="trip-itinerary-empty">暂无详细行程</div>';

      const lines = text
        .replace(/\r\n/g, '\n')
        .replace(/\r/g, '\n')
        .split('\n')
        .map(line => line.trim())
        .filter(Boolean);

      const summary = [];
      const days = [];
      let currentDay = null;
      let sawDayHeader = false;

      const pushCurrentDay = () => {
        if (currentDay) {
          currentDay.items = currentDay.items.filter(Boolean);
          days.push(currentDay);
          currentDay = null;
        }
      };

      for (const line of lines) {
        const dayMatch = line.match(/^(D\d{1,2}|Day\s*\d{1,2})\s*[｜|:：-]?\s*(.*)$/i);
        if (dayMatch) {
          sawDayHeader = true;
          pushCurrentDay();
          currentDay = {
            label: dayMatch[1].replace(/\s+/g, ''),
            title: dayMatch[2] || '',
            items: []
          };
          continue;
        }

        const bulletMatch = line.match(/^[-•●·]\s*(.*)$/);
        const content = bulletMatch ? bulletMatch[1] : line;

        if (currentDay) {
          currentDay.items.push(content);
        } else {
          summary.push(content);
        }
      }
      pushCurrentDay();

      if (!sawDayHeader) {
        const bulletParts = text
          .split(/\n+|(?<=[。；;])/)
          .map(s => s.trim())
          .filter(Boolean)
          .slice(0, compact ? 8 : 999);

        const itemsHtml = bulletParts.map(part => `<li>${escapeHtml(part)}</li>`).join('');
        return `<div class="trip-itinerary rich ${compact ? 'compact' : ''}">
          <div class="trip-itinerary-overview">
            <ul class="trip-itinerary-list">${itemsHtml}</ul>
          </div>
        </div>`;
      }

      const summaryHtml = summary.length
        ? `<section class="trip-itinerary-overview">
             <div class="trip-itinerary-overview-title">行程概览</div>
             <ul class="trip-itinerary-list">
               ${summary.slice(0, compact ? 3 : 8).map(item => `<li>${escapeHtml(item)}</li>`).join('')}
             </ul>
           </section>`
        : '';

      const maxDays = compact ? 2 : days.length;
      const dayHtml = days.slice(0, maxDays).map(day => {
        const items = (day.items || []).slice(0, compact ? 3 : 10).map(item => {
          const timeMatch = String(item).match(/^(上午|中午|下午|傍晚|晚上|凌晨|早上|午后|全天)\s*[：:]\s*(.*)$/);
          if (timeMatch) {
            return `<li><span class="trip-itinerary-time">${escapeHtml(timeMatch[1])}</span><span>${escapeHtml(timeMatch[2])}</span></li>`;
          }
          return `<li>${escapeHtml(item)}</li>`;
        }).join('');

        return `<section class="trip-itinerary-day">
          <div class="trip-itinerary-day-header">
            <span class="trip-itinerary-day-badge">${escapeHtml(day.label)}</span>
            ${day.title ? `<span class="trip-itinerary-day-title">${escapeHtml(day.title)}</span>` : ''}
          </div>
          <ul class="trip-itinerary-list">${items}</ul>
        </section>`;
      }).join('');

      const moreHtml = compact && days.length > maxDays
        ? `<div class="trip-itinerary-more">还有 ${days.length - maxDays} 天内容，点击查看详情</div>`
        : '';

      return `<div class="trip-itinerary rich ${compact ? 'compact' : ''}">
        ${summaryHtml}
        ${dayHtml}
        ${moreHtml}
      </div>`;
    }

    async function generateTripByAI() {
      if (!ensureLogin()) return;
      const aiCfg = resolveAIConfig();
      if (!aiCfg.endpoint) {
        app.ai.error = t('aiKeyMissing');
        return;
      }
      if (!app.tripForm.destination.trim()) {
        app.ai.error = t('aiNeedDestination');
        return;
      }
      app.ai.error = '';
      app.ai.generating = true;
      const profile = app.state.profile || {};
      const payload = {
        destination: app.tripForm.destination,
        budget: Number(app.tripForm.budget || 0),
        departDate: app.tripForm.departDate,
        returnDate: app.tripForm.returnDate,
        tags: list(app.tripForm.tags),
        spots: list(app.tripForm.spots),
        userPreference: {
          bio: profile.bio || '',
          mbti: profile.mbti || '',
          zodiac: profile.zodiac || '',
          pace: profile.pace || app.tripForm.pace,
          budgetLevel: profile.budgetLevel || '',
          wakeUp: profile.wakeUp || app.tripForm.wakeUp,
          social: profile.social || app.tripForm.social,
          skills: Array.isArray(profile.skills) ? profile.skills : []
        }
      };
      const prompt = `请基于以下信息生成中文旅行计划，并严格返回 JSON（不要额外解释）。

返回字段要求：
{
  "itineraryText": "字符串，必须是结构化文本",
  "itinerary": [
    {
      "day": "D1",
      "title": "当天标题",
      "items": [
        { "time": "上午", "text": "安排内容" },
        { "time": "下午", "text": "安排内容" },
        { "time": "晚上", "text": "安排内容" }
      ]
    }
  ],
  "summary": {
    "days": 数字,
    "style": "特种兵式/平衡/慢游",
    "note": "一句话概览"
  },
  "tags": ["标签"],
  "spots": ["景点"],
  "budget": 数字
}

硬性要求：
1. 必须输出合法 JSON，不要 markdown，不要额外解释
2. itineraryText 必须按以下格式组织，方便前端展示：
行程概览
- xxx

D1｜当天标题
- 上午：xxx
- 下午：xxx
- 晚上：xxx

D2｜当天标题
- 上午：xxx
...
3. 每天最多 3-5 条，不要大段散文
4. 全部使用简体中文
5. 如果用户给了想去景点，优先覆盖进去
6. tags、spots、budget 也要一并返回

输入：${JSON.stringify(payload)}`;
      try {
        const res = await fetch(aiCfg.endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            model: aiCfg.model || AI_DEFAULT_MODEL,
            messages: [
              { role: 'system', content: '你是旅行规划助手，输出必须是合法 JSON。' },
              { role: 'user', content: prompt }
            ],
            temperature: 0.7
          })
        });
        if (!res.ok) throw new Error(`${t('aiRequestFailed')}: ${res.status}`);
        const data = await res.json();
        const content = data?.choices?.[0]?.message?.content || '';
        const parsed = extractJson(content);
        const structuredItinerary = normalizeStructuredItinerary(parsed);
        if (structuredItinerary) app.tripForm.itinerary = structuredItinerary;
        if (Array.isArray(parsed.tags) && parsed.tags.length) app.tripForm.tags = parsed.tags.join(',');
        if (Array.isArray(parsed.spots) && parsed.spots.length) app.tripForm.spots = parsed.spots.join(',');
        if (Number.isFinite(Number(parsed.budget)) && Number(parsed.budget) > 0) app.tripForm.budget = Number(parsed.budget);
      } catch (err) {
        app.ai.error = err?.message || t('aiGenerateFailed');
      } finally {
        app.ai.generating = false;
      }
    }

    function goto(route) {
      if (route === 'admin' && !isAdminAuthUserId(app.currentAuthUserId)) {
        showNotice('提示', '无权限访问后台');
        app.route = 'home';
        location.hash = '/home';
        return;
      }
      app.showProfilePanel = false;
      app.showAccountSecurityPanel = false;
      app.confirmModal.show = false;
      app.noticeModal.show = false;
      app.route = route;
      location.hash = `/${route}`;
    }
    function ensureLogin() { if (!app.current) { goto('register'); return false; } return true; }
    async function loadPublicTrips() {
      const client = window.RJSupabase;
      if (!client?.isEnabled?.() || typeof client.fetchPublicTrips !== 'function') {
        app.publicTrips = [];
        app.publicTripsLoaded = true;
        app.publicTripsError = '';
        return [];
      }
      app.publicTripsLoading = true;
      app.publicTripsError = '';
      try {
        const rows = await client.fetchPublicTrips();
        app.publicTrips = Array.isArray(rows) ? rows : [];
        app.publicTripsLoaded = true;
        return app.publicTrips;
      } catch (error) {
        console.error('[vue-trips] load public trips failed', error);
        app.publicTripsError = error?.message || '加载行程广场失败';
        app.publicTripsLoaded = true;
        return [];
      } finally {
        app.publicTripsLoading = false;
      }
    }

    async function loadPublicDiaries() {
      const client = window.RJSupabase;
      if (!client?.isEnabled?.() || typeof client.fetchPublicDiaries !== 'function') {
        app.publicDiaries = [];
        app.publicDiariesLoaded = true;
        app.publicDiariesError = '';
        return [];
      }
      app.publicDiariesLoading = true;
      app.publicDiariesError = '';
      try {
        const rows = await client.fetchPublicDiaries();
        app.publicDiaries = Array.isArray(rows) ? rows : [];
        app.publicDiariesLoaded = true;
        return app.publicDiaries;
      } catch (error) {
        console.error('[vue-diaries] load public diaries failed', error);
        app.publicDiariesError = error?.message || '加载日记失败';
        app.publicDiariesLoaded = true;
        return [];
      } finally {
        app.publicDiariesLoading = false;
      }
    }


    function getAchievementSupabaseClient() {
      if (window.__gemiAchievementClient) return window.__gemiAchievementClient;
      const cfg = window.RJSupabase?.normalizeConfig?.();
      const createClient = window.supabase?.createClient || window.supabasejs?.createClient;
      if (!cfg?.url || !cfg?.anonKey || !createClient) return null;
      window.__gemiAchievementClient = createClient(cfg.url, cfg.anonKey, {
        auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
      });
      return window.__gemiAchievementClient;
    }

    function buildAchievementUnlockMap(rows) {
      const map = {};
      (Array.isArray(rows) ? rows : []).forEach((row) => {
        const achievementId = String(row?.achievement_id || '').trim();
        if (!achievementId) return;
        map[achievementId] = {
          unlockedAt: row?.unlocked_at || '',
          triggerEventType: row?.trigger_event_type || '',
          unlockMethod: row?.unlock_method || ''
        };
      });
      return map;
    }

    async function loadAchievementCenter(cityCode = 'hangzhou') {
      const client = getAchievementSupabaseClient();
      const authUserId = String(app.currentAuthUserId || '').trim();
      app.achievementCenter.loading = true;
      app.achievementCenter.error = '';
      app.achievementCenter.cityCode = cityCode || app.achievementCenter.cityCode || 'hangzhou';
      if (!client) {
        app.achievementCenter.loading = false;
        app.achievementCenter.loaded = true;
        app.achievementCenter.error = 'Supabase 未配置，暂时无法加载城市成就';
        return;
      }
      if (!authUserId) {
        app.achievementCenter.loading = false;
        app.achievementCenter.loaded = true;
        app.achievementCenter.error = '请先登录后查看我的城市成就';
        app.achievementCenter.achievements = [];
        app.achievementCenter.citySummaries = [];
        app.achievementCenter.unlockMap = {};
        app.achievementCenter.latestUnlock = null;
        return;
      }
      try {
        const [{ data: achievements, error: achievementsError }, { data: unlocks, error: unlocksError }, { data: rules, error: rulesError }] = await Promise.all([
          client.from('achievements')
            .select('id, city_code, city_name, achievement_code, title, subtitle, description, level, level_name, category, category_name, unlock_rule, share_text, sort_order, status')
            .eq('status', 'published')
            .order('city_code', { ascending: true })
            .order('sort_order', { ascending: true }),
          client.from('user_achievement_unlocks')
            .select('achievement_id, unlocked_at, trigger_event_type, unlock_method')
            .eq('user_id', authUserId),
          client.from('city_platinum_rules')
            .select('*')
        ]);
        if (achievementsError) throw achievementsError;
        if (unlocksError) throw unlocksError;
        if (rulesError) throw rulesError;

        const unlockMap = buildAchievementUnlockMap(unlocks || []);
        const normalizedAll = (Array.isArray(achievements) ? achievements : []).map((item) => {
          const unlock = unlockMap[item.id] || null;
          return {
            ...item,
            isUnlocked: Boolean(unlock),
            unlockedAt: unlock?.unlockedAt || '',
            triggerEventType: unlock?.triggerEventType || '',
            unlockMethod: unlock?.unlockMethod || ''
          };
        });
        const grouped = normalizedAll.reduce((acc, item) => {
          const code = item.city_code || 'unknown';
          if (!acc[code]) acc[code] = [];
          acc[code].push(item);
          return acc;
        }, {});
        const ruleMap = new Map((Array.isArray(rules) ? rules : []).map((row) => [row.city_code, row]));
        const summaries = Object.entries(grouped).map(([code, rows]) => {
          const latestUnlockItem = rows
            .filter((item) => item.isUnlocked && item.unlockedAt)
            .sort((a, b) => String(b.unlockedAt || '').localeCompare(String(a.unlockedAt || '')))[0] || null;
          const counts = {
            platinum: { unlocked: 0, total: 0 },
            gold: { unlocked: 0, total: 0 },
            silver: { unlocked: 0, total: 0 },
            bronze: { unlocked: 0, total: 0 }
          };
          rows.forEach((item) => {
            const key = String(item.level || '').toLowerCase();
            if (!counts[key]) return;
            counts[key].total += 1;
            if (item.isUnlocked) counts[key].unlocked += 1;
          });
          return {
            cityCode: code,
            cityName: rows[0]?.city_name || ruleMap.get(code)?.city_name || code,
            total: rows.length,
            unlocked: rows.filter((item) => item.isUnlocked).length,
            latestUnlockAt: latestUnlockItem?.unlockedAt || '',
            latestUnlockTitle: latestUnlockItem?.title || '',
            counts,
            platinumRule: ruleMap.get(code) || null
          };
        }).sort((a, b) => {
          const ta = String(a.latestUnlockAt || '');
          const tb = String(b.latestUnlockAt || '');
          if (ta && tb && ta !== tb) return tb.localeCompare(ta);
          if (ta && !tb) return -1;
          if (!ta && tb) return 1;
          return String(a.cityName || '').localeCompare(String(b.cityName || ''), 'zh-CN');
        });

        const activeCityCode = summaries.find((item) => item.cityCode === app.achievementCenter.cityCode)?.cityCode || summaries[0]?.cityCode || cityCode || 'hangzhou';
        const activeRows = (grouped[activeCityCode] || []).slice().sort((a, b) => {
          if (a.isUnlocked !== b.isUnlocked) return a.isUnlocked ? -1 : 1;
          const ta = String(a.unlockedAt || '');
          const tb = String(b.unlockedAt || '');
          if (ta && tb && ta !== tb) return tb.localeCompare(ta);
          if (ta && !tb) return -1;
          if (!ta && tb) return 1;
          return Number(a.sort_order || 0) - Number(b.sort_order || 0);
        });
        const latestUnlock = activeRows
          .filter((item) => item.isUnlocked && item.unlockedAt)
          .sort((a, b) => String(b.unlockedAt || '').localeCompare(String(a.unlockedAt || '')))[0] || null;

        app.achievementCenter.cityCode = activeCityCode;
        app.achievementCenter.cityName = activeRows[0]?.city_name || ruleMap.get(activeCityCode)?.city_name || summaries[0]?.cityName || '杭州';
        app.achievementCenter.achievements = activeRows;
        app.achievementCenter.citySummaries = summaries;
        app.achievementCenter.unlockMap = unlockMap;
        app.achievementCenter.latestUnlock = latestUnlock;
        app.achievementCenter.platinumRule = ruleMap.get(activeCityCode) || null;
        app.achievementCenter.loaded = true;
        if ((!app.achievementCenter.selectedAchievementCode || !activeRows.find((item) => item.achievement_code === app.achievementCenter.selectedAchievementCode)) && activeRows.length) {
          app.achievementCenter.selectedAchievementCode = activeRows[0].achievement_code;
        }
      } catch (error) {
        console.error('[achievement-center] load failed', error);
        app.achievementCenter.error = error?.message || '城市成就加载失败';
        app.achievementCenter.loaded = true;
      } finally {
        app.achievementCenter.loading = false;
      }
    }

    function selectAchievementCity(cityCode) {
      if (!cityCode) return;
      app.achievementCenter.selectedAchievementCode = '';
      loadAchievementCenter(cityCode);
    }

    async function gotoAchievementCity(cityCode = '') {
      if (cityCode && cityCode !== app.achievementCenter.cityCode) {
        app.achievementCenter.selectedAchievementCode = '';
        await loadAchievementCenter(cityCode);
      }
      app.route = 'achievement-city';
      location.hash = '/achievement-city';
    }

    function backFromAchievementCity() {
      app.route = 'my';
      location.hash = '/my';
    }

    async function openAchievementOverview(cityCode = '') {
      if (cityCode && cityCode !== app.achievementCenter.cityCode) {
        app.achievementCenter.selectedAchievementCode = '';
        await loadAchievementCenter(cityCode);
      }
      app.achievementCenter.overviewOpen = true;
    }

    function closeAchievementOverview() {
      app.achievementCenter.overviewOpen = false;
    }

    function openAchievementDetail(item) {
      if (!item) return;
      app.achievementCenter.selectedAchievementCode = item.achievement_code || '';
      app.achievementCenter.overviewOpen = false;
      app.achievementCenter.detailOpen = true;
    }

    function closeAchievementDetail() {
      app.achievementCenter.detailOpen = false;
    }

    function openAchievementDetailFromCode(code) {
      const target = (app.achievementCenter.achievements || []).find((item) => item.achievement_code === code);
      if (target) openAchievementDetail(target);
    }

    const guideCities = computed(() => GUIDE_LIBRARY.map((city) => ({
      cityCode: city.cityCode,
      cityName: city.cityName,
      guides: Array.isArray(city.guides) ? city.guides : []
    })));

    const selectedGuideCity = computed(() => {
      return guideCities.value.find((item) => item.cityCode === app.guideCenter.cityCode) || guideCities.value[0] || null;
    });

    const selectedGuide = computed(() => {
      const city = selectedGuideCity.value;
      if (!city) return null;
      return city.guides.find((item) => item.id === app.guideCenter.selectedGuideId) || city.guides[0] || null;
    });

    const selectedGuideHub = computed(() => {
      const code = app.guideCenter.cityCode || 'hangzhou';
      const hub = CITY_GUIDE_HUBS[code] || CITY_GUIDE_HUBS.hangzhou || null;
      if (!hub) return null;
      const city = guideCities.value.find((item) => item.cityCode === hub.cityCode) || null;
      const buildGuide = (id) => city?.guides?.find((item) => item.id === id) || null;
      return {
        ...hub,
        guides: city?.guides || [],
        sectionEntries: (hub.sections || []).map((section) => ({
          ...section,
          guides: (section.guideIds || []).map(buildGuide).filter(Boolean)
        }))
      };
    });

    function gotoGuides() {
      app.route = 'guides';
      location.hash = '/guides';
    }

    function gotoCityGuideHub(cityCode = 'hangzhou') {
      app.guideCenter.cityCode = cityCode || 'hangzhou';
      app.route = 'city-guide-hub';
      location.hash = '/city-guide-hub';
    }

    function goBackFromCityGuideHub() {
      app.route = 'guides';
      location.hash = '/guides';
    }

    function gotoGuideDetail(guideId, cityCode = 'hangzhou') {
      app.guideCenter.cityCode = cityCode || 'hangzhou';
      app.guideCenter.selectedGuideId = guideId || 'hangzhou-platinum-full';
      app.route = 'guide-detail';
      location.hash = '/guide-detail';
    }

    function goBackFromGuide() {
      app.route = 'city-guide-hub';
      location.hash = '/city-guide-hub';
    }

    function getAchievementLevelIconSvg(level) {
      const key = String(level || '').toLowerCase();
      const icons = {
        platinum: `
          <svg viewBox="0 0 64 64" class="achievement-svg-icon is-platinum" aria-hidden="true">
            <defs>
              <linearGradient id="platStem" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#eef6ff"/>
                <stop offset="55%" stop-color="#8ac5ff"/>
                <stop offset="100%" stop-color="#3f7cff"/>
              </linearGradient>
            </defs>
            <path d="M20 22h24v6c0 7-5.6 12-12 12s-12-5-12-12z" fill="url(#platStem)" stroke="#2f5fe6" stroke-width="2.2" stroke-linejoin="round"/>
            <path d="M24 22c0-6 3.4-10 8-14 4.6 4 8 8 8 14" fill="none" stroke="#5aa5ff" stroke-width="2.4" stroke-linecap="round"/>
            <path d="M15 24c0 5 2.8 9 7 10M49 24c0 5-2.8 9-7 10" fill="none" stroke="#5aa5ff" stroke-width="2.2" stroke-linecap="round"/>
            <path d="M27 40h10v6H27z" fill="#dcecff"/>
            <path d="M22 48h20" stroke="#3768ec" stroke-width="3" stroke-linecap="round"/>
          </svg>`,
        gold: `
          <svg viewBox="0 0 64 64" class="achievement-svg-icon is-gold" aria-hidden="true">
            <defs>
              <linearGradient id="goldCup" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#fff1a8"/>
                <stop offset="50%" stop-color="#efbf33"/>
                <stop offset="100%" stop-color="#b77908"/>
              </linearGradient>
            </defs>
            <path d="M18 18h28v8c0 10-6.5 17-14 17S18 36 18 26z" fill="url(#goldCup)" stroke="#9a6400" stroke-width="2.2" stroke-linejoin="round"/>
            <path d="M18 20H11c0 9 4.2 14 11 15M46 20h7c0 9-4.2 14-11 15" fill="none" stroke="#c58a08" stroke-width="2.3" stroke-linecap="round"/>
            <path d="M28 43h8v6h-8z" fill="#f4d36a"/>
            <path d="M22 51h20" stroke="#9a6400" stroke-width="3" stroke-linecap="round"/>
          </svg>`,
        silver: `
          <svg viewBox="0 0 64 64" class="achievement-svg-icon is-silver" aria-hidden="true">
            <defs>
              <linearGradient id="silverCup" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#f8fafc"/>
                <stop offset="50%" stop-color="#cdd6e3"/>
                <stop offset="100%" stop-color="#7f8ca1"/>
              </linearGradient>
            </defs>
            <path d="M18 18h28v8c0 10-6.5 17-14 17S18 36 18 26z" fill="url(#silverCup)" stroke="#66758a" stroke-width="2.2" stroke-linejoin="round"/>
            <path d="M18 20H11c0 9 4.2 14 11 15M46 20h7c0 9-4.2 14-11 15" fill="none" stroke="#8794a7" stroke-width="2.3" stroke-linecap="round"/>
            <circle cx="32" cy="29" r="5.5" fill="#eef2f7" stroke="#90a0b6" stroke-width="1.6"/>
            <path d="M28 43h8v6h-8z" fill="#d9e1ec"/>
            <path d="M22 51h20" stroke="#66758a" stroke-width="3" stroke-linecap="round"/>
          </svg>`,
        bronze: `
          <svg viewBox="0 0 64 64" class="achievement-svg-icon is-bronze" aria-hidden="true">
            <defs>
              <linearGradient id="bronzeCup" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#f0c3a0"/>
                <stop offset="50%" stop-color="#c57a4e"/>
                <stop offset="100%" stop-color="#8b4f2e"/>
              </linearGradient>
            </defs>
            <path d="M18 18h28v8c0 10-6.5 17-14 17S18 36 18 26z" fill="url(#bronzeCup)" stroke="#8b4f2e" stroke-width="2.2" stroke-linejoin="round"/>
            <path d="M18 20H11c0 9 4.2 14 11 15M46 20h7c0 9-4.2 14-11 15" fill="none" stroke="#a8643d" stroke-width="2.3" stroke-linecap="round"/>
            <path d="M28 43h8v6h-8z" fill="#d99a70"/>
            <path d="M22 51h20" stroke="#8b4f2e" stroke-width="3" stroke-linecap="round"/>
          </svg>`
      };
      return icons[key] || icons.bronze;
    }

    function getAchievementLevelIcon(level) {
      return getAchievementLevelIconSvg(level);
    }

    function formatAchievementTime(value) {
      if (!value) return '未解锁';
      const d = new Date(value);
      if (!Number.isFinite(d.getTime())) return String(value);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      const hh = String(d.getHours()).padStart(2, '0');
      const mm = String(d.getMinutes()).padStart(2, '0');
      return `${y}.${m}.${day} ${hh}:${mm}`;
    }

    function getAchievementHint(item) {
      if (!item) return '';
      return String(item.subtitle || item.unlock_rule || item.description || '').trim();
    }

    function getAchievementTagLabel(item) {
      if (!item) return '';
      const category = String(item.category_name || '').trim();
      return category || '城市成就';
    }

    function getAchievementRouteTypeLabel(item) {
      const trigger = String(item?.triggerEventType || '').trim();
      if (!trigger) return '待解锁';
      if (trigger === 'photo_upload') return '拍照解锁';
      if (trigger === 'gps_checkin') return '定位解锁';
      return '自动解锁';
    }

    function refreshMine() {
      if (!app.current) return;
      app.state = getState(app.current);
      app.profileForm = {
        birthday: normalizeMonthValue(app.state.profile.birthday || ''),
        gender: app.state.profile.gender || '',
        mbti: app.state.profile.mbti || '',
        zodiac: app.state.profile.zodiac || '',
        pace: app.state.profile.pace || '平衡',
        budgetLevel: app.state.profile.budgetLevel || '舒适',
        wakeUp: app.state.profile.wakeUp || '自然醒',
        social: app.state.profile.social || '适中',
        bio: app.state.profile.bio || '',
        skillsText: Array.isArray(app.state.profile.skills) ? app.state.profile.skills.join(',') : ''
      };
    }

    function calcBadges(state) {
      const badges = [];
      if ((state.mediaPosts || []).length > 0) badges.push('📸 旅行记录官');
      if ((state.trips || []).length > 0) badges.push('🤝 初次结伴');
      if ((state.trips || []).length >= 3) badges.push('🧭 行程达人');
      return badges.length ? badges : ['🌱 新人旅行者'];
    }
    const stateByUser = computed(() => {
      void app.stateVersion;
      const map = {};
      app.users.forEach((u) => { map[u.nickname] = getState(u.nickname); });
      return map;
    });
    const allTrips = computed(() => {
      const rows = [];
      app.users.forEach((u) => {
        const s = stateByUser.value[u.nickname] || normalizeState({});
        s.trips.forEach((t) => rows.push({
          ...t,
          likes: Array.isArray(t.likes) ? t.likes : [],
          likeCount: Number(Array.isArray(t.likes) ? t.likes.length : (t.likeCount || 0)),
          user: t.user || u.nickname,
          avatar: t.avatar || s.profile.avatar || defaultAvatar,
          comments: Array.isArray(t.comments) ? t.comments.map((c) => ({
            ...c,
            likes: Array.isArray(c.likes) ? c.likes : []
          })) : [],
          ownerSkills: Array.isArray(s.profile.skills) ? s.profile.skills : [],
          ownerBadges: calcBadges(s)
        }));
      });
      return rows.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    });
    const allDiaries = computed(() => {
      const rows = [];
      app.users.forEach((u) => {
        const s = stateByUser.value[u.nickname] || normalizeState({});
        s.mediaPosts.forEach((d) => rows.push({ ...d, user: d.user || u.nickname, likes: Array.isArray(d.likes) ? d.likes : [], comments: Array.isArray(d.comments) ? d.comments.map((c) => ({...c, likes: Array.isArray(c.likes) ? c.likes : []})) : [] }));
      });
      return rows.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    });

    const hasSearchKeyword = computed(() => app.userSearch.trim().length > 0);

    function getSearchUserAvatar(nickname) {
      const tripAvatar = allTrips.value.find((t) => t.user === nickname && t.avatar)?.avatar;
      if (tripAvatar) return tripAvatar;
      const diaryAvatar = allDiaries.value.find((d) => d.user === nickname && d.avatar)?.avatar;
      if (diaryAvatar) return diaryAvatar;
      return getUserAvatar(nickname);
    }

    function getSearchUserTripCount(nickname) {
      const publicCount = allTrips.value.filter((t) => t.user === nickname).length;
      if (publicCount) return publicCount;
      const s = stateByUser.value[nickname] || normalizeState({});
      return Array.isArray(s.trips) ? s.trips.length : 0;
    }

    function getSearchUserDiaryCount(nickname) {
      const publicCount = allDiaries.value.filter((d) => d.user === nickname).length;
      if (publicCount) return groupDiaryRows(allDiaries.value.filter((d) => d.user === nickname)).length;
      return diaryGroupCountForUser(nickname);
    }

    const searchUsersPool = computed(() => {
      const map = new Map();
      const addUser = (name) => {
        const nickname = String(name || '').trim();
        if (!nickname) return;
        map.set(nickname, { nickname });
      };
      (Array.isArray(app.users) ? app.users : []).forEach((u) => addUser(u?.nickname));
      Object.keys(stateByUser.value || {}).forEach((nickname) => addUser(nickname));
      allTrips.value.forEach((t) => addUser(t?.user));
      allDiaries.value.forEach((d) => addUser(d?.user));
      (Array.isArray(app.publicTrips) ? app.publicTrips : []).forEach((t) => addUser(t?.user));
      (Array.isArray(app.publicDiaries) ? app.publicDiaries : []).forEach((d) => addUser(d?.user));
      return Array.from(map.values());
    });

    const filteredUsers = computed(() => {
      if (!hasSearchKeyword.value) return [];
      const keyword = app.userSearch.toLowerCase().trim();
      return searchUsersPool.value
        .filter((u) => {
          const nickname = String(u.nickname || '').toLowerCase();
          return nickname.includes(keyword) || keyword.includes(nickname);
        })
        .map((u) => ({
          ...u,
          avatar: getSearchUserAvatar(u.nickname),
          tripCount: getSearchUserTripCount(u.nickname),
          diaryCount: getSearchUserDiaryCount(u.nickname),
          badges: userBadges(u.nickname)
        }));
    });

    const filteredTrips = computed(() => hasSearchKeyword.value ? allTrips.value.filter((t) => [t.user, t.destination, t.itinerary, (t.tags || []).join(',')].join('|').toLowerCase().includes(app.userSearch.toLowerCase())) : []);
    const filteredDiaries = computed(() => {
      if (!hasSearchKeyword.value) return [];
      const keyword = app.userSearch.toLowerCase();
      const source = Array.isArray(app.publicDiaries) && app.publicDiaries.length ? app.publicDiaries : allDiaries.value;
      return groupDiaryRows(source)
        .map((group) => {
          const sorted = [...group].sort((a, b) => new Date(a.createdAt || 0) - new Date(b.createdAt || 0));
          const first = sorted[0] || {};
          return {
            ...first,
            dbPostId: first.dbPostId || first.basePostId || first.id,
            caption: normalizeDiaryCaption(first.caption),
            imageCount: sorted.length,
            images: sorted.map((item) => item.cover).filter(Boolean)
          };
        })
        .filter((d) => [d.user, d.caption, d.location, d.checkin].join('|').toLowerCase().includes(keyword));
    });
    function tripHeatScore(trip) {
      const likes = Number(trip?.likeCount || trip?.likes?.length || 0);
      const comments = Array.isArray(trip?.comments) ? trip.comments.length : 0;
      return likes * 2 + comments * 3;
    }
    function tripCompositeScore(trip) {
      const ageHours = Math.max(1, (Date.now() - new Date(trip?.createdAt || 0).getTime()) / 3600000);
      const recencyScore = 120 / ageHours;
      return tripHeatScore(trip) + recencyScore;
    }
    const homeTrips = computed(() => {
      const kw = app.tripSquareSearch.trim().toLowerCase();
      const tripSource = Array.isArray(app.publicTrips) ? app.publicTrips : [];
      const filtered = !kw
        ? tripSource
        : tripSource.filter((t) => [t.user, t.destination, t.itinerary, (t.tags || []).join(',')].join('|').toLowerCase().includes(kw));
      if (app.tripSquareSort === 'newest') return [...filtered].sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
      if (app.tripSquareSort === 'hottest') return [...filtered].sort((a, b) => tripHeatScore(b) - tripHeatScore(a) || new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
      return [...filtered].sort((a, b) => tripCompositeScore(b) - tripCompositeScore(a));
    });
    const homeTripTotalPages = computed(() => Math.max(1, Math.ceil(homeTrips.value.length / Number(app.tripPageSize || 10))));
    const homeTripsPaged = computed(() => {
      const safePage = Math.min(homeTripTotalPages.value, Math.max(1, Number(app.tripPage || 1)));
      const start = (safePage - 1) * Number(app.tripPageSize || 10);
      return homeTrips.value.slice(start, start + Number(app.tripPageSize || 10));
    });
    const myDiaryGroups = computed(() => {
      const publicSource = Array.isArray(app.publicDiaries) ? app.publicDiaries : [];
      if (!app.current) return [];
      if (app.publicDiariesLoading && !app.publicDiariesLoaded) return [];
      if (app.publicDiariesLoaded) return publicSource.filter((item) => item.user === app.current);
      return [];
    });
    function diaryGroupCountForUser(nickname) {
      const publicSource = Array.isArray(app.publicDiaries) ? app.publicDiaries : [];
      if (publicSource.length && nickname) return publicSource.filter((item) => item.user === nickname).length;
      const s = stateByUser.value[nickname] || normalizeState({});
      return groupDiaryRows(s.mediaPosts || []).length;
    }

    function upsertCurrentUser() {
      if (!app.current) return;
      let found = app.users.find((u) => u.nickname === app.current);
      if (!found) {
        found = { nickname: app.current, password: '', firstLogin: false };
        app.users.push(found);
      }
      saveUsers(app.users);
    }

    function isStrongPassword(password) {
      const text = String(password || '');
      return text.length >= 8 && /[A-Z]/.test(text) && /[a-z]/.test(text) && /\d/.test(text) && /[^A-Za-z0-9]/.test(text);
    }


    function normalizeDiaryCaption(caption) {
      return String(caption || '').replace(/\s·\s\d+(?:\s·\s\d+)*$/, '').trim();
    }

    function diaryKeyMatches(row, diary) {
      if (!row || !diary) return false;
      const candidateIds = [diary.id, diary.dbPostId, diary.basePostId].map((x) => String(x || '')).filter(Boolean);
      const rowIds = [row.id, row.dbPostId, row.basePostId].map((x) => String(x || '')).filter(Boolean);
      if (candidateIds.some((id) => rowIds.includes(id))) return true;
      if (diary.batchId && row.batchId && String(diary.batchId) === String(row.batchId)) return true;
      return false;
    }

    function isDbDiaryRecord(diary) {
      return Boolean(diary && (diary.dbPostId || diary.basePostId));
    }

    function isDbDiaryComment(comment) {
      return Boolean(comment && comment.dbCommentId);
    }

    function findPublicDiaryRecord(diary) {
      if (!diary) return null;
      const list = Array.isArray(app.publicDiaries) ? app.publicDiaries : [];
      return list.find((row) => diaryKeyMatches(row, diary)) || null;
    }

    async function refreshDiaryDetails(activeDiary = null) {
      await loadPublicDiaries();
      const source = activeDiary || app.selectedDiaryRecord || diaryData.value;
      if (!source) return;
      const matched = findPublicDiaryRecord(source);
      if (matched) app.selectedDiaryRecord = JSON.parse(JSON.stringify(matched));
      else if (isDbDiaryRecord(source)) app.selectedDiaryRecord = JSON.parse(JSON.stringify(source));
      else app.selectedDiaryRecord = null;
    }

    function buildDiaryCaption(caption, index, total) {
      const base = normalizeDiaryCaption(caption);
      return total > 1 ? `${base} · ${index + 1}` : base;
    }

    async function login() {
      const nickname = app.auth.nickname.trim();
      const password = app.auth.password;
      app.authError = '';
    
      if (!nickname || !password) {
        app.authError = '请输入账户名与密码';
        return;
      }
      if (!isStrongPassword(password)) {
        app.authError = '密码太简单：至少8位，且包含大小写字母、数字和特殊符号';
        return;
      }
    
      const client = window.RJSupabase;
      if (!client || !client.isEnabled?.()) {
        app.authError = 'Supabase 未配置';
        return;
      }
    
      let session = null;
    
      try {
        // 先直接尝试登录，不再依赖 localStorage 判断账号是否存在
        try {
          const signInResult = await client.signInWithLocalAccount(nickname, password);
          const sessionAfterAuth = await client.getSupabaseAuthSession();
    
          console.log('[vue-auth] signInWithPassword result', {
            hasAccessToken: Boolean(signInResult?.access_token),
            hasRefreshToken: Boolean(signInResult?.refresh_token)
          });
          console.log('[vue-auth] getSession after auth', {
            hasSession: Boolean(sessionAfterAuth),
            userId: sessionAfterAuth?.user?.id || null
          });
    
          if (!sessionAfterAuth?.access_token) {
            throw new Error('Supabase 登录失败：未获取有效 session');
          }
    
          session = sessionAfterAuth;
        } catch (signInErr) {
          const msg = String(signInErr?.message || '');
    
          // 只有在账号不存在/登录失败这类场景下，才尝试注册
          const shouldTrySignUp =
            /Invalid login credentials|invalid_credentials|Email not confirmed|登录失败/i.test(msg);
    
          if (!shouldTrySignUp) {
            throw signInErr;
          }
    
          const signUpResult = await client.signUpWithLocalAccount(nickname, password);
          console.log('[vue-auth] signUp result', {
            userId: signUpResult?.user?.id || null,
            hasSession: Boolean(signUpResult?.session)
          });
    
          // 注册成功后，再自动登录一次
          const retrySignInResult = await client.signInWithLocalAccount(nickname, password);
          const sessionAfterAuth = await client.getSupabaseAuthSession();
    
          console.log('[vue-auth] signInWithPassword result after signUp', {
            hasAccessToken: Boolean(retrySignInResult?.access_token),
            hasRefreshToken: Boolean(retrySignInResult?.refresh_token)
          });
          console.log('[vue-auth] getSession after auth', {
            hasSession: Boolean(sessionAfterAuth),
            userId: sessionAfterAuth?.user?.id || null
          });
    
          if (!sessionAfterAuth?.access_token) {
            throw new Error('Supabase 注册成功但未获取有效 session');
          }
    
          // 补用户资料表
          try {
            await client.createUserWithProfile({ nickname, password });
          } catch (profileErr) {
            console.warn('[vue-auth] create profile skipped', profileErr);
          }
    
          const exists = app.users.find((u) => u.nickname === nickname);
          if (!exists) {
            app.users.push({ nickname, password, firstLogin: true });
            saveUsers(app.users);
            addEvent('register', { user: nickname });
          }
    
          session = sessionAfterAuth;
        }
    
        // 登录成功后，同步本地 users，避免后续界面逻辑出问题
        let localUser = app.users.find((u) => u.nickname === nickname);
        if (!localUser) {
          localUser = { nickname, password, firstLogin: false };
          app.users.push(localUser);
        } else {
          localUser.password = password;
        }
        saveUsers(app.users);
    
        localStorage.setItem(KEYS.CURRENT, nickname);
        app.current = nickname;
        app.currentAuthUserId = session?.user?.id || '';
        app.showProfilePanel = false;
        app.showAccountSecurityPanel = false;
        app.tripSquareSearch = '';
        app.userSearch = '';
        refreshMine();
        await loadAchievementCenter(app.achievementCenter.cityCode || 'hangzhou');
        await refreshSocialGraphFromDb();
        await refreshChatsFromDb();
        goto('home');
      } catch (err) {
        console.error('[vue-auth] login/register failed', err);
        const msg = String(err?.message || '');
    
        if (/Invalid login credentials/i.test(msg)) {
          app.authError = '密码错误';
          return;
        }
    
        if (/User already registered/i.test(msg)) {
          app.authError = '账号已存在，请直接输入正确密码登录';
          return;
        }
    
        app.authError = err?.message || '登录 / 注册失败';
      }
    }

    function register() { return login(); }

    async function logout() {
      const client = window.RJSupabase;
      try { if (client?.signOutSupabaseSession) await client.signOutSupabaseSession(); } catch (err) { console.warn('[vue-auth] signOut failed', err?.message || err); }
      localStorage.removeItem(KEYS.CURRENT);
      app.current = '';
      app.currentAuthUserId = '';
      app.tripSquareSearch = '';
      app.userSearch = '';
      app.showProfilePanel = false;
      app.showAccountSecurityPanel = false;
      app.deletingAccount = false;
      app.accountDeleteForm = { confirmText: '', reason: '' };
      app.accountDeleteStatus = '';
      app.auth = { nickname: '', password: '' };
      app.authError = '';
      app.social = getSocial('');
      goto('register');
    }

    async function deleteAccount() {
      if (!ensureLogin()) return;
      const confirmText = String(app.accountDeleteForm?.confirmText || '').trim();
      const reason = String(app.accountDeleteForm?.reason || '').trim();

      if (confirmText !== '删除账号') {
        app.accountDeleteStatus = '请输入“删除账号”四个字后再继续';
        return;
      }

      const confirmed = await showCenterConfirm('账号删除后将清空你的个人资料、行程、日记、关注关系与聊天等数据，且通常无法恢复。确认继续吗？', '删除账号确认', {
        confirmText: '确认删除',
        cancelText: '取消'
      });
      if (!confirmed) return;

      const client = window.RJSupabase;
      if (!client?.deleteCurrentAccount) {
        app.accountDeleteStatus = '当前版本未接入账号删除接口，请先补充 supabase-client.js';
        return;
      }

      app.deletingAccount = true;
      app.accountDeleteStatus = '正在删除账号…';
      try {
        await client.deleteCurrentAccount({ nickname: app.current, reason });
        const current = app.current;
        localStorage.removeItem(KEYS.CURRENT);
        purgeDeletedAccountLocalData(current);

        const remainedUsers = getUsers();
        app.users = remainedUsers;
        app.publicTrips = purgeTripDataByNickname(app.publicTrips, current);
        app.publicDiaries = purgeMediaDataByNickname(app.publicDiaries, current);

        app.current = '';
        app.currentAuthUserId = '';
        app.showProfilePanel = false;
        app.showAccountSecurityPanel = false;
        app.deletingAccount = false;
        app.accountDeleteForm = { confirmText: '', reason: '' };
        app.accountDeleteStatus = '';
        app.auth = { nickname: '', password: '' };
        app.social = getSocial('');
        app.state = normalizeState({});
        goto('register');
        showCenterNotice('账号已删除成功。');
      } catch (err) {
        console.error('[vue-account] delete account failed', err);
        app.accountDeleteStatus = `删除账号失败：${err?.message || err}`;
      } finally {
        app.deletingAccount = false;
      }
    }

    function toggleProfilePanel() {
      if (!ensureLogin()) return;
      app.showProfilePanel = !app.showProfilePanel;
    }
    function closeProfilePanel() {
      app.showProfilePanel = false;
    }

    async function onAvatarChange(event) {
      const file = event.target.files?.[0];
      if (!file) return;
      if (!file.type.startsWith('image/')) {
        app.profileAvatarStatus = '请选择图片文件';
        if (event?.target) event.target.value = '';
        return;
      }
      const client = getSupabaseClient();
      if (!client) {
        app.profileAvatarStatus = 'Supabase 未配置，无法上传头像';
        return;
      }
      app.profileAvatarStatus = '头像上传中…';
      try {
        const localPreview = URL.createObjectURL(file);
        if (app.profileAvatarPreview && String(app.profileAvatarPreview).startsWith('blob:')) {
          try { URL.revokeObjectURL(app.profileAvatarPreview); } catch {}
        }
        app.profileAvatarPreview = localPreview;
        const optimizedAvatar = await optimizeImageFile(file, { maxEdge: 640, quality: 0.78, targetBytes: 220 * 1024 });
        const uploaded = await client.uploadUserAvatar(optimizedAvatar);
        app.state.profile.avatar = uploaded?.url || app.state.profile.avatar || defaultAvatar;
        if (client?.syncUserProfile && app.current) {
          await client.syncUserProfile(app.current, { avatar: app.state.profile.avatar });
        }
        if (app.profileAvatarPreview && String(app.profileAvatarPreview).startsWith('blob:')) {
          try { URL.revokeObjectURL(app.profileAvatarPreview); } catch {}
        }
        app.profileAvatarPreview = '';
        if (!safeSetState(app.current, app.state, '头像较大或本地空间不足，头像预览保存失败。')) {
          throw new Error('头像本地保存失败');
        }
        app.stateVersion += 1;
        app.profileAvatarStatus = '头像已上传并生效';
      } catch (error) {
        console.error('[vue-profile] avatar upload failed', error);
        app.profileAvatarStatus = `头像上传失败：${error?.message || error}`;
        alert(`头像上传失败：${error?.message || error}`);
      } finally {
        if (event?.target) event.target.value = '';
      }
    }

    async function saveProfile(event) {
      event?.preventDefault();
      if (!ensureLogin()) return;
      app.state.profile = {
        ...app.state.profile,
        birthday: normalizeMonthValue(app.profileForm.birthday),
        gender: app.profileForm.gender,
        mbti: app.profileForm.mbti,
        zodiac: app.profileForm.zodiac,
        pace: app.profileForm.pace,
        budgetLevel: app.profileForm.budgetLevel,
        wakeUp: app.profileForm.wakeUp,
        social: app.profileForm.social,
        bio: app.profileForm.bio,
        skills: list(app.profileForm.skillsText)
      };
      if (!safeSetState(app.current, app.state, '图片过多或过大，保存失败。请减少数量后重试。')) return;
      app.stateVersion += 1;
      addEvent('profile-save', { user: app.current });
      try {
        const client = getSupabaseClient();
        if (client?.syncUserProfile) {
          await client.syncUserProfile(app.current, app.state.profile);
        }
        app.profileAvatarStatus = app.state.profile.avatar ? '资料已保存' : '资料已保存';
        app.showProfilePanel = false;
      } catch (err) {
        console.error('[vue-profile] save profile failed', err);
        app.profileAvatarStatus = `资料保存失败：${err?.message || err}`;
        alert(`资料保存失败：${err?.message || err}`);
      }
    }

    function supportLike() {
      app.supportCount += 1;
      localStorage.setItem(KEYS.SUPPORT, String(app.supportCount));
      addEvent('support-like', { from: app.current || 'guest', count: app.supportCount });
    }

    function submitFeedback(event) {
      event?.preventDefault();
      const content = app.feedback.content.trim();
      const email = app.feedback.email.trim();
      if (!content || !email) return;
      addEvent('feedback-submit', { from: app.current || 'guest', content, email });
      app.feedback = { content: '', email: '' };
      app.feedbackSuccessVisible = true;
    }

    async function postTrip(event) {
      event?.preventDefault();
      if (!ensureLogin()) return;
      const f = app.tripForm;
      if (!String(f.title || '').trim()) {
        showCenterNotice('请先填写行程标题');
        return;
      }
      if (!String(f.destination || '').trim()) {
        showCenterNotice('请先填写目的地');
        return;
      }
      app.state.trips.unshift({
        id: uid(),
        user: app.current,
        avatar: app.state.profile.avatar || defaultAvatar,
        title: String(f.title || '').trim(),
        destination: String(f.destination || '').trim(),
        origin: String(f.origin || '').trim(),
        departDate: f.departDate,
        departFlex: String(f.departFlex || '').trim(),
        returnDate: f.returnDate,
        returnFlex: String(f.returnFlex || '').trim(),
        durationText: String(f.durationText || '').trim(),
        budget: Number(f.budget || 0),
        tags: list(f.tags),
        spots: list(f.spots),
        itinerary: f.itinerary,
        pace: f.pace,
        wakeUp: f.wakeUp,
        social: f.social,
        profile: { birthday: app.state.profile.birthday, gender: app.state.profile.gender, mbti: app.state.profile.mbti, zodiac: app.state.profile.zodiac, skills: app.state.profile.skills },
        likeCount: 0,
        comments: [],
        createdAt: now()
      });
      const createdTrip = app.state.trips[0];
      setState(app.current, app.state);
      app.stateVersion += 1;
      addEvent('publish-trip', { user: app.current, title: createdTrip.title, destination: createdTrip.destination });
      const client = window.RJSupabase;
      try {
        const tripForSync = getTripSyncPayload(createdTrip);
        if (client?.syncTrip) await client.syncTrip(tripForSync);
        await loadPublicTrips();
      } catch (err) {
        console.warn('[vue-trips] syncTrip failed', err?.message || err);
      }
      app.tripForm = { title: '', origin: '', destination: '', departDate: '', departFlex: '', returnDate: '', returnFlex: '', durationText: '', budget: 2000, tags: '', spots: '', itinerary: '', pace: '平衡', wakeUp: '自然醒', social: '适中' };
      goto('home');
    }

    async function postDiary(event) {
      event?.preventDefault();
      if (!ensureLogin()) return;
      const selected = Array.isArray(app.diaryDraftFiles) && app.diaryDraftFiles.length
        ? app.diaryDraftFiles
        : Array.from(document.querySelector('#diaryFiles')?.files || []);
      const files = selected.filter((f) => f.type.startsWith('image/'));
      if (!files.length) return;
      const client = getSupabaseClient();
      if (!client) {
        alert('请先配置 Supabase（URL / ANON KEY）并启用 Storage bucket，之后再上传图片。');
        return;
      }
      if (files.length > MAX_DIARY_UPLOAD_COUNT) {
        alert(`单次最多上传 ${MAX_DIARY_UPLOAD_COUNT} 张图片。`);
        return;
      }
      const totalBytes = files.reduce((sum, f) => sum + Number(f.size || 0), 0);
      if (totalBytes > MAX_DIARY_TOTAL_BYTES) {
        alert(`图片总体积不能超过 ${MAX_DIARY_TOTAL_MB}MB。`);
        return;
      }
      const batchId = uid();
      const createdAt = now();
      let uploaded = [];
      try {
        uploaded = await runUploadsWithConcurrency(files, batchId, 0, 3);
      } catch (error) {
        alert(`上传图片到 Storage 失败：${error?.message || error}`);
        return;
      }
      const postsToSave = uploaded.map((item, index) => ({
        id: uid(),
        user: app.current,
        type: '图片',
        location: app.mediaForm.location,
        caption: buildDiaryCaption(app.mediaForm.caption, index, uploaded.length),
        checkin: app.mediaForm.checkin || `${app.mediaForm.location} · ${fmt(createdAt)}`,
        cover: item?.url || '',
        coverSize: Number(item?.size || 0),
        batchId,
        createdAt,
        likes: [],
        comments: []
      })).filter((post) => post.cover);
      if (!postsToSave.length) {
        alert('图片上传结果为空，请重试。');
        return;
      }
      try {
        for (const post of postsToSave) {
          if (client?.syncMediaPost) await client.syncMediaPost(post);
        }
      } catch (error) {
        alert(`发布日记失败：${error?.message || error}`);
        return;
      }
      app.state.mediaPosts = Array.isArray(app.state.mediaPosts) ? app.state.mediaPosts : [];
      app.state.mediaPosts = [...postsToSave, ...app.state.mediaPosts].slice(0, 50);
      if (!safeSetState(app.current, app.state, '日记发布失败：请稍后重试。')) return;
      app.stateVersion += 1;
      addEvent('publish-diary', { user: app.current, count: postsToSave.length });
      try {
        await loadPublicDiaries();
        const created = (Array.isArray(app.publicDiaries) ? app.publicDiaries : []).find((row) => String(row.batchId || '') === String(batchId)) || null;
        if (created) {
          app.selectedDiaryId = created.id;
          app.selectedDiaryRecord = JSON.parse(JSON.stringify(created));
        }
      } catch (_) {}
      app.mediaForm = { location: '', caption: '', checkin: '' };
      revokePreviewList(app.diaryDraftPreviews);
      app.diaryDraftFiles = [];
      app.diaryDraftPreviews = [];
      const fileInput = document.querySelector('#diaryFiles');
      if (fileInput) fileInput.value = '';
    }

    function onDiaryFilesChange(event) {
      revokePreviewList(app.diaryDraftPreviews);
      app.diaryDraftFiles = Array.from(event?.target?.files || []).filter((f) => f.type.startsWith('image/'));
      app.diaryDraftPreviews = app.diaryDraftFiles.map((file) => ({
        name: file.name,
        previewUrl: URL.createObjectURL(file),
        size: Number(file.size || 0)
      }));
    }

    async function toggleRelation(type, target) {
      if (!ensureLogin() || !target || target === app.current) return;
      const key = type === 'follow' ? 'follows' : 'blocks';
      app.social[key][app.current] = app.social[key][app.current] || [];
      const set = new Set(app.social[key][app.current]);
      set.has(target) ? set.delete(target) : set.add(target);
      const active = !Array.from(set).includes(target) ? false : true;
      app.social[key][app.current] = [...set];
      setSocial(app.social, app.current);
      addEvent(type === 'follow' ? 'toggle-follow' : 'toggle-block', { from: app.current, to: target, active });
      const client = window.RJSupabase;
      try {
        if (type === 'follow' && client?.syncFollow) await client.syncFollow(app.current, target, active);
        else if (type !== 'follow' && client?.syncBlock) await client.syncBlock(app.current, target, active);
      } catch (err) {
        console.warn('[vue-social] toggle relation sync failed', err?.message || err);
      }
      await refreshSocialGraphFromDb();
    }
    function isFollowing(user) {
      const arr = app.social.follows?.[app.current] || [];
      return arr.includes(user);
    }

    async function likeTrip(trip) {
      if (!ensureLogin() || !trip) return;
      const publicTarget = (app.publicTrips || []).find((t) => t.id === trip.id) || null;
      if (publicTarget) {
        publicTarget.likes = Array.isArray(publicTarget.likes) ? publicTarget.likes : [];
        const idx = publicTarget.likes.indexOf(app.current);
        if (idx >= 0) publicTarget.likes.splice(idx, 1); else publicTarget.likes.push(app.current);
        publicTarget.likeCount = publicTarget.likes.length;
        addEvent('like-trip', { from: app.current, to: trip.user, tripId: trip.id });
        const client = window.RJSupabase;
        try {
          if (client?.syncTripLike) await client.syncTripLike(trip.id, app.current, idx < 0);
          if (client?.syncTrip) await client.syncTrip(publicTarget);
        } catch (err) {
          console.warn('[vue-trips] like trip sync failed', err?.message || err);
        }
        return;
      }
      const ownerState = getState(trip.user);
      const target = ownerState.trips.find((t) => t.id === trip.id);
      if (!target) return;
      target.likes = Array.isArray(target.likes) ? target.likes : [];
      const idx = target.likes.indexOf(app.current);
      if (idx >= 0) target.likes.splice(idx, 1); else target.likes.push(app.current);
      target.likeCount = target.likes.length;
      setState(trip.user, ownerState);
      app.stateVersion += 1;
      addEvent('like-trip', { from: app.current, to: trip.user, tripId: trip.id });
      callSupabase('syncTripLike', trip.id, app.current, idx < 0);
      const client = window.RJSupabase;
      try {
        const tripForSync = getTripSyncPayload(target);
        if (client?.syncTrip) await client.syncTrip(tripForSync);
        await loadPublicTrips();
      } catch (err) {
        console.warn('[vue-trips] save trip edit sync failed', err?.message || err);
      }
    }

    function startReplyTripComment(comment) {
      if (!ensureLogin() || !comment) return;
      app.tripReplyTarget = {
        dbCommentId: comment.dbCommentId || comment.id || '',
        user: comment.user || '',
        text: comment.text || ''
      };
      nextTick(() => {
        const key = String(app.tripReplyTarget?.dbCommentId || '');
        const selector = key ? `[data-trip-reply-for="${CSS.escape(key)}"]` : '.trip-comment-input';
        const input = document.querySelector(selector);
        if (input && typeof input.focus === 'function') input.focus();
      });
    }

    function cancelReplyTripComment() {
      app.tripReplyTarget = null;
    }

    async function addComment(trip) {
      if (!ensureLogin() || !trip) return;
      const text = (app.commentDraft[trip.id] || '').trim();
      if (!text) return;
      const client = window.RJSupabase;
      const newComment = {
        id: uid(),
        dbCommentId: '',
        user: app.current,
        avatar: app.state.profile.avatar || defaultAvatar,
        text,
        replyTo: app.tripReplyTarget?.user || '',
        parentCommentId: app.tripReplyTarget?.dbCommentId || '',
        createdAt: now(),
        likes: []
      };
      const publicTarget = (app.publicTrips || []).find((t) => t.id === trip.id) || null;
      if (publicTarget) {
        try {
          if (client?.syncTripComment) await client.syncTripComment(trip.id, newComment);
          app.commentDraft[trip.id] = '';
          app.tripReplyTarget = null;
          addEvent('comment-trip', { from: app.current, to: trip.user, tripId: trip.id });
          await loadPublicTrips();
        } catch (err) {
          console.warn('[vue-trips] add trip comment failed', err?.message || err);
          showCenterNotice(`发表评论失败：${err?.message || err}`, '行程评论');
        }
        return;
      }
      const ownerState = getState(trip.user);
      const target = ownerState.trips.find((t) => t.id === trip.id);
      if (!target) return;
      target.comments = Array.isArray(target.comments) ? target.comments : [];
      target.comments.unshift(newComment);
      setState(trip.user, ownerState);
      app.stateVersion += 1;
      app.commentDraft[trip.id] = '';
      app.tripReplyTarget = null;
      addEvent('comment-trip', { from: app.current, to: trip.user, tripId: trip.id });
      callSupabase('syncTripComment', trip.id, newComment);
    }

    async function toggleCommentLike(trip, comment) {
      if (!ensureLogin() || !trip || !comment) return;
      const dbCommentId = String(comment.dbCommentId || '').trim();
      const client = window.RJSupabase;
      if (dbCommentId && client?.syncTripCommentLike) {
        try {
          const currentLikes = Array.isArray(comment.likes) ? comment.likes : [];
          const liked = currentLikes.includes(app.current);
          await client.syncTripCommentLike(dbCommentId, app.current, !liked);
          addEvent('like-comment', { from: app.current, to: trip.user, tripId: trip.id, commentId: dbCommentId });
          await loadPublicTrips();
          return;
        } catch (err) {
          console.warn('[toggleCommentLike]', err?.message || err);
          showCenterNotice(`评论点赞失败：${err?.message || err}`, '评论点赞');
          return;
        }
      }

      const ownerState = getState(trip.user);
      const targetTrip = ownerState.trips.find((t) => t.id === trip.id);
      if (!targetTrip) return;
      targetTrip.comments = Array.isArray(targetTrip.comments) ? targetTrip.comments : [];
      const targetComment = targetTrip.comments.find((c) => c.id === comment.id);
      if (!targetComment) return;
      targetComment.likes = Array.isArray(targetComment.likes) ? targetComment.likes : [];
      const idx = targetComment.likes.indexOf(app.current);
      if (idx >= 0) targetComment.likes.splice(idx, 1); else targetComment.likes.push(app.current);
      setState(trip.user, ownerState);
      app.stateVersion += 1;
      addEvent('like-comment', { from: app.current, to: trip.user, tripId: trip.id, commentId: comment.id });
      callSupabase('syncTripCommentLike', comment.id, app.current, idx < 0);
    }

    function commentLikers(comment) {
      if (!comment || !Array.isArray(comment.likes)) return [];
      return comment.likes.slice(0, 100);
    }
    function commentLikeOverflow(comment) {
      if (!comment || !Array.isArray(comment.likes)) return 0;
      return Math.max(0, comment.likes.length - 100);
    }
    function isCommentLikedByMe(comment) {
      return Boolean(app.current && Array.isArray(comment?.likes) && comment.likes.includes(app.current));
    }
    function sortCommentRoots(list, sortMode) {
      const rows = [...list];
      if (sortMode === 'hottest') {
        rows.sort((a, b) => (b.likes?.length || 0) - (a.likes?.length || 0) || new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
      } else {
        rows.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
      }
      return rows;
    }

    function sortCommentChildren(list) {
      return [...list].sort((a, b) => new Date(a.createdAt || 0) - new Date(b.createdAt || 0));
    }

    function countCommentDescendants(nodes) {
      const list = Array.isArray(nodes) ? nodes : [];
      return list.reduce((sum, node) => sum + 1 + countCommentDescendants(node.replies || []), 0);
    }

    function collectCommentBranchIds(comment) {
      const ids = [];
      const walk = (node) => {
        if (!node) return;
        const id = String(node.dbCommentId || node.id || '').trim();
        if (id) ids.push(id);
        const replies = Array.isArray(node.replies) ? node.replies : [];
        replies.forEach(walk);
      };
      walk(comment);
      return ids;
    }

    function buildCommentForest(rawComments, sortMode) {
      const source = Array.isArray(rawComments) ? rawComments : [];
      if (!source.length) return [];

      const ordered = [...source].sort(
        (a, b) => new Date(a.createdAt || 0) - new Date(b.createdAt || 0)
      );

      const nodes = ordered.map((item, idx) => ({
        ...item,
        dbCommentId: item.dbCommentId || item.id || '',
        parentCommentId: item.parentCommentId || '',
        replies: [],
        __seq: idx
      }));

      const byId = new Map();
      nodes.forEach((node) => {
        const key = String(node.dbCommentId || node.id || '').trim();
        if (key) byId.set(key, node);
      });

      const roots = [];

      for (let i = 0; i < nodes.length; i += 1) {
        const node = nodes[i];
        let parent = null;

        const parentId = String(node.parentCommentId || '').trim();

        if (parentId && byId.has(parentId) && byId.get(parentId) !== node) {
          parent = byId.get(parentId);
        } else {
          const replyTo = String(node.replyTo || '').trim();
          if (replyTo) {
            for (let j = i - 1; j >= 0; j -= 1) {
              const candidate = nodes[j];
              if (String(candidate.user || '').trim() === replyTo) {
                parent = candidate;
                break;
              }
            }
          }
        }

        if (parent) parent.replies.push(node);
        else roots.push(node);
      }

      const normalize = (list, depth = 0) => {
        const sorted = depth === 0
          ? sortCommentRoots(list, sortMode)
          : sortCommentChildren(list);

        return sorted.map((node) => ({
          ...node,
          replies: normalize(node.replies || [], depth + 1)
        }));
      };

      return normalize(roots, 0);
    }

    function flattenCommentForest(nodes, expandedState, depth = 0, rows = []) {
      const list = Array.isArray(nodes) ? nodes : [];

      list.forEach((node) => {
        rows.push({
          kind: 'comment',
          key: `comment-${node.dbCommentId || node.id || node.__seq}`,
          node,
          depth
        });

        const replies = Array.isArray(node.replies) ? node.replies : [];
        if (!replies.length) return;

        const nodeKey = String(node.dbCommentId || node.id || '');
        const expanded = Boolean(expandedState?.[nodeKey]);

        if (depth >= 2 && !expanded) {
          rows.push({
            kind: 'expand',
            key: `expand-${nodeKey}`,
            parentId: nodeKey,
            parentNode: node,
            depth: 3,
            hiddenCount: countCommentDescendants(replies)
          });
          return;
        }

        flattenCommentForest(replies, expandedState, depth + 1, rows);
      });

      return rows;
    }

    function commentIndentStyle(depth) {
      const level = Math.max(0, Number(depth || 0));
      const indent = Math.min(level, 3) * 0.8;

      return {
        marginLeft: `${indent}rem`,
        width: level > 0 ? `calc(100% - ${indent}rem)` : '100%',
        borderLeft: level > 0 ? '2px solid rgba(148,163,184,.22)' : 'none',
        paddingLeft: level > 0 ? '.7rem' : '0',
        background: level > 0 ? 'rgba(255,255,255,.5)' : 'transparent',
        borderRadius: '.8rem'
      };
    }

    function toggleCommentThreadExpand(scope, commentId) {
      if (!scope || !commentId) return;
      scope[commentId] = !scope[commentId];
    }

    function commentDisplayText(comment) {
      if (!comment) return '';
      const replyTo = String(comment.replyTo || '').trim();
      const text = String(comment.text || '');
      return replyTo ? `回复 @${replyTo} ${text}` : text;
    }

    function isTripReplyTarget(comment) {
      return Boolean(
        comment &&
        app.tripReplyTarget &&
        String(app.tripReplyTarget.dbCommentId || '') === String(comment.dbCommentId || comment.id || '')
      );
    }

    function isDiaryReplyTarget(comment) {
      return Boolean(
        comment &&
        app.diaryReplyTarget &&
        String(app.diaryReplyTarget.dbCommentId || '') === String(comment.dbCommentId || comment.id || '')
      );
    }

    function tripCommentRows(trip) {
      const forest = buildCommentForest(Array.isArray(trip?.comments) ? trip.comments : [], app.tripCommentSort);
      return flattenCommentForest(forest, app.tripCommentExpanded, 0, []);
    }

    function diaryCommentRows(diary) {
      const forest = buildCommentForest(Array.isArray(diary?.comments) ? diary.comments : [], app.diaryCommentSort);
      return flattenCommentForest(forest, app.diaryCommentExpanded, 0, []);
    }

    function sortedTripComments(trip) {
      return Array.isArray(trip?.comments) ? [...trip.comments] : [];
    }

    function diaryLikers(diary) {
      if (!diary || !Array.isArray(diary.likes)) return [];
      return diary.likes.slice(0, 100);
    }
    function diaryLikeOverflow(diary) {
      if (!diary || !Array.isArray(diary.likes)) return 0;
      return Math.max(0, diary.likes.length - 100);
    }
    function isDiaryLikedByMe(diary) {
      return Boolean(app.current && Array.isArray(diary?.likes) && diary.likes.includes(app.current));
    }
function getDiaryPrimaryId(diary) {
      return diary?.dbPostId || diary?.basePostId || '';
    }
    function findDiaryTarget(ownerState, diary) {
      ownerState = ownerState || {};
      ownerState.mediaPosts = Array.isArray(ownerState.mediaPosts) ? ownerState.mediaPosts : [];
      const mediaPostId = getDiaryPrimaryId(diary);
      const batchId = diary?.batchId || diary?.selectedDiaryRecord?.batchId || '';
      return ownerState.mediaPosts.find((d) => d.id === mediaPostId || d.id === diary?.id || (batchId && d.batchId === batchId)) || null;
    }
    async function deleteDiaryComment(diary, comment) {
      if (!ensureLogin() || !diary || !comment) return;
      if (comment.user !== app.current) return;

      const client = window.RJSupabase;
      if (!client?.deleteMediaComment) {
        showCenterNotice('当前未连接数据库评论删除能力。', '日记评论');
        return;
      }

      const forest = buildCommentForest(
        Array.isArray(diary?.comments) ? diary.comments : [],
        app.diaryCommentSort
      );

      let targetNode = null;
      const findNode = (list) => {
        for (const node of list || []) {
          const idA = String(node.dbCommentId || node.id || '');
          const idB = String(comment.dbCommentId || comment.id || '');
          if (idA && idA === idB) {
            targetNode = node;
            return true;
          }
          if (findNode(node.replies || [])) return true;
        }
        return false;
      };
      findNode(forest);

      const branchIds = collectCommentBranchIds(targetNode || comment).filter(Boolean);

      if (!branchIds.length) {
        showCenterNotice('未找到可删除的评论记录，请刷新后重试。', '日记评论');
        return;
      }

      try {
        const idsToDelete = [...branchIds].reverse();
        for (const id of idsToDelete) {
          await client.deleteMediaComment(id);
        }

        const targetId = String(comment.dbCommentId || comment.id || '');
        if (String(app.diaryReplyTarget?.dbCommentId || '') === targetId) {
          app.diaryReplyTarget = null;
        }

        await refreshDiaryDetails(diary);
      } catch (err) {
        console.warn('[deleteDiaryComment]', err?.message || err);
        showCenterNotice(`删除评论失败：${err?.message || err}`, '日记评论');
      }
    }

    function startReplyDiaryComment(comment) {
      if (!ensureLogin() || !comment) return;
      app.diaryReplyTarget = {
        dbCommentId: comment.dbCommentId || comment.id || '',
        user: comment.user || '',
        text: comment.text || ''
      };
      const diary = diaryData.value;
      if (diary?.id && !app.commentDraft[diary.id]) app.commentDraft[diary.id] = '';

      nextTick(() => {
        const key = String(app.diaryReplyTarget?.dbCommentId || '');
        const selector = key ? `[data-diary-reply-for="${CSS.escape(key)}"]` : '.diary-comment-input';
        const input = document.querySelector(selector);
        if (input && typeof input.focus === 'function') input.focus();
      });
    }

    function cancelReplyDiaryComment() {
      app.diaryReplyTarget = null;
    }

    function renderDiaryCommentText(comment) {
      if (!comment) return '';
      const text = String(comment.text || '');
      const replyTo = String(comment.replyTo || '').trim();
      return replyTo ? `回复 @${replyTo}：${text}` : text;
    }
    async function toggleDiaryLike(diary) {
      if (!ensureLogin() || !diary) return;
      const mediaPostId = getDiaryPrimaryId(diary);
      if (!mediaPostId) {
        showCenterNotice('这篇日记还不是数据库版本，请刷新后从列表页重新打开。', '日记点赞');
        return;
      }
      const currentLikes = Array.isArray(diaryData.value?.likes) ? diaryData.value.likes : (Array.isArray(diary?.likes) ? diary.likes : []);
      const liked = currentLikes.includes(app.current);
      const client = window.RJSupabase;
      try {
        if (client?.syncMediaLike) await client.syncMediaLike(mediaPostId, app.current, !liked);
        addEvent('like-diary', { from: app.current, to: diary.user, diaryId: mediaPostId });
        await refreshDiaryDetails(diary);
      } catch (err) {
        console.warn('[toggleDiaryLike]', err?.message || err);
        showCenterNotice(`日记点赞失败：${err?.message || err}`, '日记点赞');
      }
    }
    async function addDiaryComment(diary) {
      if (!ensureLogin() || !diary) return;
      const text = (app.commentDraft[diary.id] || '').trim();
      if (!text) return;
      const mediaPostId = getDiaryPrimaryId(diary);
      if (!mediaPostId) {
        showCenterNotice('这篇日记还不是数据库版本，请刷新后从列表页重新打开。', '日记评论');
        return;
      }
      const newComment = {
        id: uid(),
        dbCommentId: '',
        user: app.current,
        avatar: app.state.profile.avatar || defaultAvatar,
        text,
        replyTo: app.diaryReplyTarget?.user || '',
        parentCommentId: app.diaryReplyTarget?.dbCommentId || '',
        createdAt: now(),
        likes: []
      };
      const client = window.RJSupabase;
      try {
        if (client?.syncMediaComment) await client.syncMediaComment(mediaPostId, newComment);
        app.commentDraft[diary.id] = '';
        app.diaryReplyTarget = null;
        addEvent('comment-diary', { from: app.current, to: diary.user, diaryId: mediaPostId });
        await refreshDiaryDetails(diary);
      } catch (err) {
        console.warn('[addDiaryComment]', err?.message || err);
        showCenterNotice(`发表评论失败：${err?.message || err}`, '日记评论');
      }
    }
    async function toggleDiaryCommentLike(diary, comment) {
      if (!ensureLogin() || !diary || !comment) return;
      const commentId = comment.dbCommentId || '';
      if (!commentId) {
        showCenterNotice('这条评论仍是本地缓存数据，请刷新后重试。', '评论点赞');
        return;
      }
      const currentLikes = Array.isArray(comment.likes) ? comment.likes : [];
      const liked = currentLikes.includes(app.current);
      const client = window.RJSupabase;
      try {
        if (client?.syncMediaCommentLike) await client.syncMediaCommentLike(commentId, app.current, !liked);
        addEvent('like-diary-comment', { from: app.current, to: diary.user, diaryId: getDiaryPrimaryId(diary) || diary.id, commentId });
        await refreshDiaryDetails(diary);
      } catch (err) {
        console.warn('[toggleDiaryCommentLike]', err?.message || err);
        showCenterNotice(`评论点赞失败：${err?.message || err}`, '评论点赞');
      }
    }
    function sortedDiaryComments(diary) {
      return Array.isArray(diary?.comments) ? [...diary.comments] : [];
    }

    function startEditTrip(trip) {
      if (!ensureLogin() || !trip) return;
      const ownerState = getState(app.current);
      const localTrip = (ownerState.trips || []).find((t) => t.id === trip.id);
      const source = localTrip || trip;
      app.selectedTripId = source.id;
      app.tripEditForm = {
        title: source.title || '',
        destination: source.destination || '',
        origin: source.origin || '',
        departDate: source.departDate || '',
        departFlex: source.departFlex || '',
        returnDate: source.returnDate || '',
        returnFlex: source.returnFlex || '',
        durationText: source.durationText || '',
        budget: Number(source.budget || 0),
        tags: Array.isArray(source.tags) ? source.tags.join(',') : '',
        spots: Array.isArray(source.spots) ? source.spots.join(',') : '',
        itinerary: source.itinerary || '',
        pace: source.pace || '平衡',
        wakeUp: source.wakeUp || '自然醒',
        social: source.social || '适中'
      };
      app.tripEditMode = true;
      goto('trip');
    }

    async function saveTripEdit() {
      if (!ensureLogin() || !app.selectedTripId) return;
      const ownerState = getState(app.current);
      const target = (ownerState.trips || []).find((t) => t.id === app.selectedTripId);
      if (!target) return;
      const f = app.tripEditForm;
      target.title = String(f.title || '').trim();
      target.destination = f.destination.trim();
      target.origin = String(f.origin || '').trim();
      target.departDate = f.departDate;
      target.departFlex = String(f.departFlex || '').trim();
      target.returnDate = f.returnDate;
      target.returnFlex = String(f.returnFlex || '').trim();
      target.durationText = String(f.durationText || '').trim();
      target.budget = Number(f.budget || 0);
      target.tags = list(f.tags);
      target.spots = list(f.spots);
      target.itinerary = f.itinerary;
      target.pace = f.pace;
      target.wakeUp = f.wakeUp;
      target.social = f.social;
      setState(app.current, ownerState);
      app.state = ownerState;
      app.stateVersion += 1;
      app.tripEditMode = false;
      addEvent('edit-trip', { user: app.current, tripId: target.id });
      const client = window.RJSupabase;
      try {
        const tripForSync = getTripSyncPayload(target);
        if (client?.syncTrip) await client.syncTrip(tripForSync);
        await loadPublicTrips();
      } catch (err) {
        console.warn('[vue-trips] save trip edit sync failed', err?.message || err);
      }
    }

    function cancelTripEdit() {
      app.tripEditMode = false;
    }

    async function deleteTrip(trip) {
      if (!ensureLogin() || !trip) return;
      if (!confirm('确认删除这个行程吗？')) return;
      app.state.trips = (app.state.trips || []).filter((t) => t.id !== trip.id);
      setState(app.current, app.state);
      app.stateVersion += 1;
      app.tripEditMode = false;
      addEvent('delete-trip', { user: app.current, tripId: trip.id });
      const client = window.RJSupabase;
      try {
        if (client?.deleteTrip) await client.deleteTrip(trip.id);
        await loadPublicTrips();
      } catch (err) {
        console.warn('[vue-trips] delete trip sync failed', err?.message || err);
      }
      goto('my');
    }

    function startEditDiary(diary) {
      if (!ensureLogin() || !diary) return;
      app.diaryReplyTarget = null;
      const ownerState = getState(app.current);
      const publicDiary = findPublicDiaryRecord(diary) || diaryData.value || null;
      const batchId = publicDiary?.batchId || diary?.batchId || diary?.id || '';
      const localRows = (ownerState.mediaPosts || []).filter((m) => (batchId && m.batchId === batchId) || m.id === diary.id);
      const base = publicDiary || localRows[0] || diary;
      app.selectedDiaryId = diary.id;
      app.selectedDiaryRecord = publicDiary ? JSON.parse(JSON.stringify(publicDiary)) : app.selectedDiaryRecord;
      app.diaryEditForm = {
        caption: normalizeDiaryCaption(base.caption || ''),
        location: base.location || '',
        checkin: base.checkin || ''
      };
      app.diaryEditImages = diaryGroupImages(publicDiary || localRows);
      if (!app.diaryEditImages.length && base.cover) app.diaryEditImages = [base.cover];
      app.diaryEditUploadedBytes = localRows.reduce((acc, row) => {
        if (row?.cover) acc[row.cover] = Number(row.coverSize || 0);
        return acc;
      }, {});
      refreshDiaryEditEstimate();
      app.diaryEditMode = true;
      goto('diary');
    }

    let diaryEditEstimateToken = 0;
    async function refreshDiaryEditEstimate() {
      const token = ++diaryEditEstimateToken;
      const images = Array.isArray(app.diaryEditImages) ? app.diaryEditImages.slice() : [];
      const knownBytes = app.diaryEditUploadedBytes && typeof app.diaryEditUploadedBytes === 'object'
        ? app.diaryEditUploadedBytes
        : {};
      if (!images.length) {
        app.diaryEditEstimatedBytes = 0;
        return;
      }
      const estimated = images.reduce((sum, url) => sum + Number(knownBytes[url] || 0), 0);
      if (token !== diaryEditEstimateToken) return;
      app.diaryEditEstimatedBytes = estimated;
    }

    async function addDiaryImages(event) {
      const files = Array.from(event?.target?.files || []).filter((f) => f.type.startsWith('image/'));
      if (!files.length) return;
      if (!getSupabaseClient()) {
        alert('请先配置 Supabase（URL / ANON KEY）并启用 Storage bucket，之后再上传图片。');
        event.target.value = '';
        return;
      }
      if (app.diaryEditImages.length + files.length > MAX_DIARY_UPLOAD_COUNT) {
        alert(`最多保留 ${MAX_DIARY_UPLOAD_COUNT} 张图片。`);
        event.target.value = '';
        return;
      }
      const existingBytes = Number(app.diaryEditEstimatedBytes || 0);
      const addRawBytes = files.reduce((sum, f) => sum + Number(f.size || 0), 0);
      if (existingBytes + addRawBytes > MAX_DIARY_TOTAL_BYTES) {
        alert(`图片总体积不能超过 ${MAX_DIARY_TOTAL_MB}MB。`);
        event.target.value = '';
        return;
      }
      const batchId = app.selectedDiaryId || uid();
      let uploaded = [];
      try {
        uploaded = await runUploadsWithConcurrency(files, batchId, app.diaryEditImages.length, 3);
      } catch (error) {
        alert(`上传图片到 Storage 失败：${error?.message || error}`);
        event.target.value = '';
        return;
      }
      uploaded.forEach((item) => {
        if (!item?.url) return;
        app.diaryEditImages.push(item.url);
        app.diaryEditUploadedBytes[item.url] = Number(item.size || 0);
      });
      refreshDiaryEditEstimate();
      event.target.value = '';
    }

    function removeDiaryImage(index) {
      const removed = app.diaryEditImages[index];
      app.diaryEditImages.splice(index, 1);
      if (removed && app.diaryEditUploadedBytes && typeof app.diaryEditUploadedBytes === 'object') delete app.diaryEditUploadedBytes[removed];
      refreshDiaryEditEstimate();
    }

    function openPreviewGallery(images, index = 0) {
      const list = Array.isArray(images) ? images.filter(Boolean) : [];
      if (!list.length) return;
      app.previewList = list;
      app.previewIndex = Math.max(0, Math.min(index, list.length - 1));
      app.previewSrc = list[app.previewIndex];
      if (typeof app.__openPreviewDialog === 'function') app.__openPreviewDialog();
    }
    function previewPrev() {
      if (!app.previewList.length) return;
      app.previewIndex = (app.previewIndex - 1 + app.previewList.length) % app.previewList.length;
      app.previewSrc = app.previewList[app.previewIndex];
    }
    function previewNext() {
      if (!app.previewList.length) return;
      app.previewIndex = (app.previewIndex + 1) % app.previewList.length;
      app.previewSrc = app.previewList[app.previewIndex];
    }

    async function saveDiaryEdit() {
      if (!ensureLogin() || !app.selectedDiaryId) return;
      if (!app.diaryEditImages.length) {
        alert('至少保留一张图片');
        return;
      }
      if (app.diaryEditImages.length > MAX_DIARY_UPLOAD_COUNT) {
        alert(`最多保留 ${MAX_DIARY_UPLOAD_COUNT} 张图片。`);
        return;
      }
      const client = window.RJSupabase;
      const optimizedImages = app.diaryEditImages.slice();
      const ownerState = getState(app.current);
      ownerState.mediaPosts = Array.isArray(ownerState.mediaPosts) ? ownerState.mediaPosts : [];

      const currentDiary = findPublicDiaryRecord(app.selectedDiaryRecord || { id: app.selectedDiaryId }) || diaryData.value || app.selectedDiaryRecord;
      const currentLocal = ownerState.mediaPosts.find((m) => m.id === app.selectedDiaryId) || null;
      const batchId = currentDiary?.batchId || currentLocal?.batchId || currentLocal?.id || app.selectedDiaryId;
      if (!batchId) return;

      const existingIds = Array.isArray(currentDiary?.mediaPostIds) && currentDiary.mediaPostIds.length
        ? currentDiary.mediaPostIds.slice()
        : ownerState.mediaPosts
            .filter((m) => (batchId && m.batchId === batchId) || m.id === app.selectedDiaryId)
            .map((m) => m.id);

      const localById = new Map((ownerState.mediaPosts || []).map((row) => [String(row.id), row]));
      const shared = {
        user: app.current,
        type: currentLocal?.type || currentDiary?.type || '图片',
        location: app.diaryEditForm.location,
        checkin: app.diaryEditForm.checkin,
        batchId,
      };

      for (let i = 0; i < optimizedImages.length; i += 1) {
        const caption = buildDiaryCaption(app.diaryEditForm.caption, i, optimizedImages.length);
        const reuseId = existingIds[i] || uid();
        const existing = localById.get(String(reuseId));
        const row = existing || {
          id: reuseId,
          createdAt: currentDiary?.createdAt || currentLocal?.createdAt || now(),
          likes: [],
          comments: []
        };
        Object.assign(row, shared, {
          caption,
          cover: optimizedImages[i],
          coverSize: Number(app.diaryEditUploadedBytes[optimizedImages[i]] || row.coverSize || 0)
        });
        if (!existing) {
          ownerState.mediaPosts.unshift(row);
          localById.set(String(reuseId), row);
        }
        if (client?.syncMediaPost) {
          await client.syncMediaPost(row);
        }
      }

      const deletedIds = existingIds.slice(optimizedImages.length).filter(Boolean);
      if (deletedIds.length) {
        ownerState.mediaPosts = ownerState.mediaPosts.filter((m) => !deletedIds.includes(m.id));
        if (client?.deleteMediaPost) {
          for (const deleteId of deletedIds) {
            await client.deleteMediaPost(deleteId);
          }
        }
      }

      if (!safeSetState(app.current, ownerState, '日记保存失败：图片可能过大，或浏览器本地存储空间不足。请减少图片或清理旧数据后重试。')) return;
      app.state = ownerState;
      app.stateVersion += 1;
      app.diaryEditMode = false;
      addEvent('edit-diary', { user: app.current, diaryId: currentDiary?.id || app.selectedDiaryId, batchId, imageCount: optimizedImages.length });
      try {
        await loadPublicDiaries();
        const refreshed = findPublicDiaryRecord({ id: currentDiary?.id || app.selectedDiaryId, batchId });
        if (refreshed) {
          app.selectedDiaryRecord = JSON.parse(JSON.stringify(refreshed));
          app.selectedDiaryId = refreshed.id;
        }
      } catch (_) {}
    }

    function cancelDiaryEdit() {
      app.diaryEditMode = false;
    }

    async function deleteDiary(diary) {
      if (!ensureLogin() || !diary) return;
      if (!confirm('确认删除这篇日记吗？')) return;
      const client = getSupabaseClient();
      const batchId = diary.batchId || diary.id;
      const targetIds = [
        ...(Array.isArray(diary.mediaPostIds) ? diary.mediaPostIds : []),
        ...(Array.isArray(diary.dbRows) ? diary.dbRows.map((row) => row?.id).filter(Boolean) : []),
        diary.dbPostId,
        diary.basePostId,
        diary.id
      ].map((id) => String(id || '')).filter(Boolean);
      const uniqueTargetIds = [...new Set(targetIds)];
      try {
        if (client?.deleteMediaPost && uniqueTargetIds.length) {
          for (const id of uniqueTargetIds) {
            await client.deleteMediaPost(id);
          }
        }
      } catch (error) {
        alert(`删除日记失败：${error?.message || error}`);
        return;
      }
      const ownerState = getState(app.current);
      ownerState.mediaPosts = (ownerState.mediaPosts || []).filter((m) => {
        if (batchId && m.batchId) return String(m.batchId) !== String(batchId);
        return !uniqueTargetIds.includes(String(m.id || ''));
      });
      if (!safeSetState(app.current, ownerState, '删除日记失败，请稍后重试。')) return;
      app.state = ownerState;
      app.stateVersion += 1;
      app.diaryEditMode = false;
      addEvent('delete-diary', { user: app.current, diaryId: diary.id, batchId });
      try { await loadPublicDiaries(); } catch (_) {}
      if (app.route === 'diary') goto('my');
    }

    function openAccount(user, source = '') { app.selectedUser = user; app.fromSearch.account = source === 'search'; goto('account'); }
    function openTrip(id, source = '') {
      app.tripReplyTarget = null;
      app.selectedTripId = id;
      app.fromSearch.trip = source === 'search';
      goto('trip');
      Promise.resolve(loadPublicTrips()).catch(() => {});
      Promise.resolve(loadTripBills(id)).catch(() => {});
    }
    function openDiary(id, source = '', record = null) {
      app.diaryReplyTarget = null;
      app.selectedDiaryId = id;
      const matched = findPublicDiaryRecord(record || { id });
      app.selectedDiaryRecord = matched
        ? JSON.parse(JSON.stringify(matched))
        : (record && isDbDiaryRecord(record) ? JSON.parse(JSON.stringify(record)) : null);
      app.fromSearch.diary = source === 'search';
      goto('diary');
      Promise.resolve(refreshDiaryDetails(record || { id })).catch(() => {});
    }
    function openChat(user, chatId = '') {
      if (!user || user === app.current) return;
      let resolvedChatId = chatId;
      if (!resolvedChatId) {
        const members = [app.current, user].sort();
        const existing = app.social.chats.find((c) =>
          !isGroupChatRecord(c) &&
          Array.isArray(c.members) &&
          c.members.length === 2 &&
          c.members.slice().sort().join('|') === members.join('|')
        );
        resolvedChatId = existing?.id || '';
      }
      if (resolvedChatId) {
        noticeState.chatReadAt[resolvedChatId] = now();
        setNoticeState(noticeState, app.current);
      }
      app.chatPeer = user;
      app.selectedChatId = resolvedChatId;
      goto('chat');
      Promise.resolve(refreshChatsFromDb()).catch(() => {});
      scrollChatToBottom(true);
    }
    function getUserAvatar(user) {
      return (stateByUser.value[user]?.profile?.avatar) || defaultAvatar;
    }
    function tripLikers(trip) {
      if (!trip) return [];
      return Array.isArray(trip.likes) ? trip.likes.slice(0, 100) : [];
    }
    function tripLikeOverflow(trip) {
      if (!trip || !Array.isArray(trip.likes)) return 0;
      return Math.max(0, trip.likes.length - 100);
    }
    function isTripLikedByMe(trip) {
      return Boolean(app.current && Array.isArray(trip?.likes) && trip.likes.includes(app.current));
    }

    function ensureChat() {
      if (!ensureLogin() || !app.chatPeer) return null;
      const chats = dedupeChats(Array.isArray(app.social.chats) ? app.social.chats : []);
      if (app.selectedChatId) {
        return chats.find((c) => c.id === app.selectedChatId) || null;
      }
      const peerName = String(app.chatPeer || '').trim();
      if (!peerName) return null;
      const looksLikeGroup = chats.some((c) => isGroupChatRecord(c) && String(c.name || '').trim() === peerName);
      if (looksLikeGroup) return null;
      const isKnownUser = Array.isArray(app.users) && app.users.some((u) => String(u?.nickname || '').trim() === peerName);
      if (!isKnownUser) return null;
      const members = [app.current, peerName].sort();
      let chat = chats.find((c) => !isGroupChatRecord(c) && Array.isArray(c.members) && c.members.length === 2 && c.members.slice().sort().join('|') === members.join('|'));
      if (!chat) {
        chat = { id: uid(), members, messages: [], type: 'dm', isGroup: false };
        app.social.chats = dedupeChats([chat, ...(app.social.chats || [])]);
        setSocial(app.social, app.current);
        callSupabase('syncChat', chat, app.current);
      }
      return chat;
    }
    function getChatSendRule(chat, sender) {
      if (!chat || !sender) return { ok: false, message: '请先登录后再发送消息。' };
      const rawMembers = Array.isArray(chat.members) ? chat.members.filter(Boolean) : [];
      const members = rawMembers.length ? rawMembers : [sender, app.chatPeer].filter(Boolean);
      const others = members.filter((name) => name && name !== sender);
      const blocks = app.social?.blocks || {};
      const blocked = others.some((name) => {
        const senderBlocks = Array.isArray(blocks[sender]) ? blocks[sender] : [];
        const peerBlocks = Array.isArray(blocks[name]) ? blocks[name] : [];
        return senderBlocks.includes(name) || peerBlocks.includes(sender);
      });
      if (blocked) return { ok: false, message: '存在拉黑关系，当前无法发送消息。' };
      const isGroup = Boolean(chat.isGroup) || members.length > 2;
      if (isGroup) {
        return { ok: true, message: '' };
      }
      const peer = others[0] || app.chatPeer;
      if (!peer) return { ok: false, message: '聊天对象不存在。' };
      if (isMutualFollow(peer)) return { ok: true, message: '' };
      const ownCount = (Array.isArray(chat.messages) ? chat.messages : []).filter((m) => m && m.from === sender).length;
      if (ownCount >= 3) return { ok: false, message: '未互相关注前，每人最多可发送 3 条消息，互相关注后可继续聊天。' };
      return { ok: true, message: '' };
    }

    function onChatInputEnter(event) {
      if (event?.isComposing || app.isChatComposing) return;
      sendChat();
    }

    function sendChat() {
      const text = app.chatDraft.trim();
      if (!text) return;
      const chat = ensureChat();
      if (!chat) return;
      const rule = getChatSendRule(chat, app.current);
      if (!rule.ok) {
        showCenterNotice(rule.message, '聊天限制');
        return;
      }
      const message = { id: uid(), from: app.current, text, createdAt: now() };
      chat.messages.push(message);
      app.chatDraft = '';
      setSocial(app.social, app.current);
      app.stateVersion += 1;
      scrollChatToBottom(true);
      addEvent('send-chat', { from: app.current, to: app.chatPeer, chatId: chat.id, messageId: message.id });
      callSupabase('syncChatMessage', chat.id, app.current, text, message.createdAt, message.id);
    }

    function isBlocked(target, source = app.current) {
      if (!source || !target || source === target) return false;
      const arr = app.social.blocks?.[source] || [];
      return Array.isArray(arr) && arr.includes(target);
    }

    function isBlockedEitherWay(a, b) {
      if (!a || !b || a === b) return false;
      const blocks = app.social.blocks || {};
      const aBlocks = Array.isArray(blocks[a]) ? blocks[a] : [];
      const bBlocks = Array.isArray(blocks[b]) ? blocks[b] : [];
      return aBlocks.includes(b) || bBlocks.includes(a);
    }

    function isMutualFollow(user) {
      if (!app.current || !user || user === app.current) return false;
      const mine = app.social.follows?.[app.current] || [];
      const theirs = app.social.follows?.[user] || [];
      return mine.includes(user) && theirs.includes(app.current);
    }

    const mutualFollowUsers = computed(() => {
      const names = new Set();
      Object.keys(app.social.follows || {}).forEach((name) => { if (name) names.add(name); });
      app.users.forEach((u) => { if (u?.nickname) names.add(u.nickname); });
      return [...names].filter((name) => name && isMutualFollow(name));
    });

    function toggleGroupMember(user) {
      if (!user) return;
      const idx = app.groupDialog.members.indexOf(user);
      if (idx >= 0) app.groupDialog.members.splice(idx, 1);
      else app.groupDialog.members.push(user);
    }

    function chatOwnerName(chat) {
      if (!chat) return '';
      const explicit = String(
        chat.owner ||
        chat.ownerNickname ||
        chat.createdByNickname ||
        chat.createdByName ||
        chat.createdBy ||
        ''
      ).trim();
      if (explicit) return explicit;
      const systemMessages = Array.isArray(chat.messages) ? chat.messages : [];
      const createMsg = systemMessages.find((m) => m && m.type === 'system' && typeof m.text === 'string' && m.text.includes('创建了群聊'));
      const inferred = createMsg?.text?.match(/^(.*?)\s*创建了群聊/);
      return String(inferred?.[1] || '').trim();
    }

    function isGroupChatRecord(chat) {
      if (!chat) return false;

      const type = String(chat.type || chat.chatType || chat.chat_type || '').toLowerCase();
      const members = Array.isArray(chat.members) ? chat.members.filter(Boolean) : [];
      const name = String(chat.name || '').trim();

      if (type === 'group') return true;
      if (chat.isGroup === true) return true;
      if (members.length > 2) return true;
      if (name && members.length !== 2) return true;

      return false;
    }

    function isChatOwner(chat) {
      return Boolean(chat && app.current && chatOwnerName(chat) === app.current);
    }

    function isSystemMessageUnread(item) {
      const readAt = new Date(noticeState.systemReadAt || 0).getTime();
      return new Date(item?.createdAt || 0).getTime() > readAt;
    }

    function markSystemMessagesAsRead() {
      noticeState.systemReadAt = now();
      setNoticeState(noticeState, app.current);
      callSupabase('syncNoticeState', app.current, noticeState, app.social.chats);
    }

    function openSystemTab() {
      app.activeMsgTab = 'system';
      markSystemMessagesAsRead();
    }

    async function createGroupChat() {
      const selected = [...app.groupDialog.members];
      const groupName = String(app.groupName || '').trim();
      if (!selected.length || !groupName) return;
      const members = [app.current, ...selected].sort();
      const invitedText = selected.join('、');
      const chat = {
        id: uid(),
        members,
        name: groupName,
        isGroup: true,
        owner: app.current,
        messages: [{
          id: uid(),
          type: 'system',
          from: app.current,
          text: `${app.current} 创建了群聊，并邀请 ${invitedText} 加入`,
          createdAt: now()
        }]
      };
      try {
        const client = window.RJSupabase;
        if (client?.isEnabled?.() && typeof client.syncChat === 'function') {
          await client.syncChat(chat, app.current);
          await refreshChatsFromDb();
        } else {
          app.social.chats = dedupeChats([chat, ...(app.social.chats || [])]);
          setSocial(app.social, app.current);
        }
      } catch (err) {
        console.warn('[createGroupChat]', err?.message || err);
        app.social.chats = dedupeChats([chat, ...(app.social.chats || [])]);
        setSocial(app.social, app.current);
      }
      app.groupDialog.show = false;
      app.groupDialog.members = [];
      app.groupName = '';
      const actual = dedupeChats(app.social.chats || []).find((c) => String(c.id || '') === String(chat.id || ''))
        || dedupeChats(app.social.chats || []).find((c) => isGroupChatRecord(c) && String(c.name || '') === groupName)
        || chat;
      app.chatPeer = actual.name || groupName;
      app.selectedChatId = actual.id;
      goto('chat');
    }

    function openGroupMembers(chat) {
      if (!chat || !Array.isArray(chat.members) || !chat.members.length) return;
      app.followDialog.title = `${chat.name || '群聊'} · 成员`;
      app.followDialog.users = [...chat.members];
      app.followDialog.mode = 'group';
      app.followDialog.groupId = chat.id || '';
      app.followDialog.show = true;
    }

    function getInvitableGroupUsers(chat) {
      if (!chat || !app.current) return [];
      const currentMembers = Array.isArray(chat.members) ? chat.members.filter(Boolean) : [];
      return mutualFollowUsers.value.filter((name) => name && name !== app.current && !currentMembers.includes(name));
    }

    function openGroupInviteDialog(chat) {
      if (!chat) return;
      app.groupMemberDialog.groupId = chat.id || '';
      app.groupMemberDialog.title = `${chat.name || '群聊'} · 邀请成员`;
      app.groupMemberDialog.users = getInvitableGroupUsers(chat);
      app.groupMemberDialog.show = true;
    }

    function closeGroupInviteDialog() {
      app.groupMemberDialog.show = false;
      app.groupMemberDialog.groupId = '';
      app.groupMemberDialog.title = '';
      app.groupMemberDialog.users = [];
    }

    function inviteMemberToGroup(name) {
      const chat = currentChatMeta.value;
      if (!chat || !name) return;
      chat.members = Array.isArray(chat.members) ? chat.members.filter(Boolean) : [];
      if (chat.members.includes(name)) return;
      chat.members.push(name);
      chat.messages = Array.isArray(chat.messages) ? chat.messages : [];
      chat.messages.push({
        id: uid(),
        type: 'system',
        text: `${app.current} 邀请 ${name} 加入了群聊`,
        createdAt: now()
      });
      setSocial(app.social, app.current);
      app.stateVersion += 1;
      addEvent('group-invite', { from: app.current, to: name, chatId: chat.id, groupName: chat.name || '群聊', invitedBy: app.current });
      callSupabase('syncChat', chat, app.current);
      closeGroupInviteDialog();
    }

    function quickFollowFromDialog(name) {
      if (!name || name === app.current || isFollowing(name)) return;
      toggleRelation('follow', name);
    }

    async function removeChat(chatId) {
      if (!chatId) return;

      const chat = (app.social.chats || []).find((c) => String(c.id || '') === String(chatId));
      if (!chat) return;

      const client = window.RJSupabase;
      try {
        if (client?.isEnabled?.() && typeof client.deleteChat === 'function') {
          await client.deleteChat(chatId);
        }
      } catch (err) {
        showCenterNotice(`删除聊天失败：${err?.message || err}`, '聊天');
        return;
      }

      app.social.chats = (app.social.chats || []).filter((c) => String(c.id || '') !== String(chatId));
      delete noticeState.chatReadAt[chatId];
      setNoticeState(noticeState, app.current);
      setSocial(app.social, app.current);
      if (app.selectedChatId === chatId) {
        app.selectedChatId = '';
        app.chatPeer = '';
      }
      if (app.route === 'chat') goto('messages');
    }

    function dissolveCurrentGroup() {
      const chat = currentChatMeta.value;
      if (!chat || !(chat.isGroup || (Array.isArray(chat.members) && chat.members.length > 2))) return;
      if (!isChatOwner(chat)) {
        showCenterNotice('只有群主可以解散群聊。', '群聊权限');
        return;
      }
      const groupName = chat.name || '群聊';
      (Array.isArray(chat.members) ? chat.members : []).forEach((name) => {
        if (!name || name === app.current) return;
        addEvent('group-dissolve', { from: app.current, to: name, chatId: chat.id, groupName });
      });
      removeChat(chat.id);
      markSystemMessagesAsRead();
    }

    async function leaveCurrentGroup() {
      const chat = currentChatMeta.value;
      if (!chat || !isGroupChatRecord(chat)) return;
      if (isChatOwner(chat)) {
        showCenterNotice('群主不能直接退出群聊，请先解散群聊。', '群聊权限');
        return;
      }
      const client = window.RJSupabase;
      try {
        if (client?.isEnabled?.() && typeof client.leaveChat === 'function') {
          await client.leaveChat(chat.id, app.current, `${app.current} 退出了群聊`);
          await refreshChatsFromDb();
        } else {
          app.social.chats = dedupeChats((app.social.chats || []).filter((c) => String(c.id || '') !== String(chat.id || '')));
          setSocial(app.social, app.current);
        }
      } catch (err) {
        console.warn('[leaveCurrentGroup]', err?.message || err);
        showCenterNotice(`退出群聊失败：${err?.message || err}`, '群聊');
        return;
      }
      app.selectedChatId = '';
      app.chatPeer = '';
      goto('messages');
      markSystemMessagesAsRead();
    }


    function getLocalTripBillsForTrip(tripId) {
      return (Array.isArray(app.state.tripBills) ? app.state.tripBills : []).filter((bill) => String(bill?.tripId || '') === String(tripId || '')).map(normalizeBillRecord);
    }

    function canCreateBillForTrip(trip) {
      return Boolean(trip && app.current && String(trip.user || '') === String(app.current || ''));
    }

    function canCurrentUserAccessBill(bill) {
      // Remote bill visibility is enforced by Supabase RLS. Avoid nickname-based
      // client-side filtering here because login hydration timing / nickname mapping
      // differences can incorrectly hide valid bills.
      return Boolean(bill && String(bill.id || '').trim());
    }

    const canViewTripBillSection = computed(() => {
      return Boolean(activeTripBill.value || canCreateBillForTrip(tripData.value));
    });

    function persistLocalBillDetail(detail) {
      const source = Array.isArray(app.state.tripBills) ? app.state.tripBills.slice() : [];
      const normalized = normalizeBillRecord(detail);
      const idx = source.findIndex((bill) => String(bill?.id || '') === String(normalized.id || ''));
      if (idx >= 0) source[idx] = normalized;
      else source.unshift(normalized);
      app.state.tripBills = source;
      setState(app.current, app.state);
      app.tripBillsByTrip[normalized.tripId] = source.filter((bill) => String(bill?.tripId || '') === String(normalized.tripId || '')).map(normalizeBillRecord);
      app.billDetails[normalized.id] = normalized;
    }

    async function loadTripBills(tripId, options = {}) {
      const targetTripId = String(tripId || '').trim();
      if (!targetTripId) return [];
      app.billLoadingByTrip[targetTripId] = true;
      try {
        const client = window.RJSupabase;
        let rows = [];
        if (client?.isEnabled?.() && typeof client.fetchTripBillsByTrip === 'function') {
          console.log('[trip-bills] loading bills for trip', targetTripId, 'current=', app.current || null);
          rows = await client.fetchTripBillsByTrip(targetTripId, app.current);
          console.log('[trip-bills] remote rows', Array.isArray(rows) ? rows.length : rows);
        } else {
          rows = getLocalTripBillsForTrip(targetTripId);
          console.log('[trip-bills] using local fallback', targetTripId, Array.isArray(rows) ? rows.length : rows);
        }
        const normalized = (Array.isArray(rows) ? rows : []).map(normalizeBillRecord).filter((bill) => canCurrentUserAccessBill(bill));
        app.tripBillsByTrip[targetTripId] = normalized;
        console.log('[trip-bills] stored bills', targetTripId, normalized.length, normalized);
        if (options.openFirst && normalized[0]) {
          app.selectedBillId = normalized[0].id;
          await loadBillDetail(normalized[0].id);
        }
        return normalized;
      } catch (err) {
        console.warn('[trip-bills] loadTripBills failed', err?.message || err);
        const fallback = getLocalTripBillsForTrip(targetTripId).filter((bill) => canCurrentUserAccessBill(bill));
        app.tripBillsByTrip[targetTripId] = fallback;
        return fallback;
      } finally {
        app.billLoadingByTrip[targetTripId] = false;
      }
    }

    async function loadBillDetail(billId) {
      const id = String(billId || '').trim();
      if (!id) return null;
      app.billDetailLoading = true;
      try {
        const client = window.RJSupabase;
        let detail = null;
        if (client?.isEnabled?.() && typeof client.fetchTripBillDetail === 'function') {
          detail = await client.fetchTripBillDetail(id, app.current);
        } else {
          detail = (Array.isArray(app.state.tripBills) ? app.state.tripBills : []).find((bill) => String(bill?.id || '') === id) || null;
        }
        if (!detail) return null;
        const normalized = normalizeBillRecord(detail);
        if (!canCurrentUserAccessBill(normalized)) return null;
        app.billDetails[id] = normalized;
        const tripId = normalized.tripId;
        const list = Array.isArray(app.tripBillsByTrip[tripId]) ? app.tripBillsByTrip[tripId].slice() : [];
        const index = list.findIndex((bill) => String(bill?.id || '') === id);
        if (index >= 0) list[index] = normalized;
        else list.unshift(normalized);
        app.tripBillsByTrip[tripId] = list.map(normalizeBillRecord);
        return normalized;
      } catch (err) {
        console.warn('[trip-bills] loadBillDetail failed', err?.message || err);
        return null;
      } finally {
        app.billDetailLoading = false;
      }
    }


    async function loadMyBills(options = {}) {
      if (!ensureLogin()) return [];
      app.myBillsLoading = true;
      app.myBillsError = '';
      try {
        const client = window.RJSupabase;
        let rows = [];
        if (client?.isEnabled?.() && typeof client.fetchAccessibleTripBills === 'function') {
          rows = await client.fetchAccessibleTripBills(app.current);
        } else {
          const local = Array.isArray(app.state.tripBills) ? app.state.tripBills : [];
          const remote = Object.values(app.tripBillsByTrip || {}).flatMap((items) => Array.isArray(items) ? items : []);
          rows = [...local, ...remote];
        }
        const merged = (Array.isArray(rows) ? rows : []).map(normalizeBillRecord).filter((bill) => canCurrentUserAccessBill(bill));
        const deduped = [];
        const seen = new Set();
        merged.sort((a, b) => new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0)).forEach((bill) => {
          const key = String(bill.id || '').trim();
          if (!key || seen.has(key)) return;
          seen.add(key);
          deduped.push(bill);
          if (bill.tripId) {
            const list = Array.isArray(app.tripBillsByTrip[bill.tripId]) ? app.tripBillsByTrip[bill.tripId].slice() : [];
            const idx = list.findIndex((entry) => String(entry?.id || '') === key);
            if (idx >= 0) list[idx] = bill; else list.unshift(bill);
            app.tripBillsByTrip[bill.tripId] = list;
          }
          app.billDetails[key] = app.billDetails[key] || bill;
        });
        app.myBillsList = deduped;
        app.myBillsLoaded = true;
        if (options.openFirst && deduped[0]) {
          app.selectedBillId = deduped[0].id;
        }
        return deduped;
      } catch (err) {
        console.warn('[trip-bills] loadMyBills failed', err?.message || err);
        app.myBillsError = err?.message || String(err);
        app.myBillsLoaded = true;
        return [];
      } finally {
        app.myBillsLoading = false;
      }
    }

    function billTripDisplayTitle(bill) {
      const tripId = String(bill?.tripId || '').trim();
      if (!tripId) return '关联行程';
      const hit = (allTrips.value || []).find((trip) => String(trip?.id || '') === tripId);
      return hit ? getTripDisplayTitle(hit) : `行程 ${tripId.slice(0, 8)}`;
    }

    function openBillFromList(bill) {
      if (!bill?.id) return;
      app.selectedBillId = bill.id;
      if (bill.tripId) app.selectedTripId = bill.tripId;
      void loadBillDetail(bill.id);
      goto('bill');
    }

    function openCreateBillDialog(trip) {
      if (!ensureLogin() || !trip) return;
      if (!canCreateBillForTrip(trip)) {
        showCenterNotice('只有行程作者可以发起账单。', '行程账单');
        return;
      }
      const existing = getExistingBillForTrip(trip.id);
      if (existing?.id) {
        app.selectedBillId = existing.id;
        void loadBillDetail(existing.id);
        showCenterNotice('这个行程已经有协作账单了，已为你打开现有账单。', '行程账单');
        goto('bill');
        return;
      }
      app.billCreateDialog.show = true;
      app.billCreateDialog.status = '';
      app.billCreateDialog.title = `${getTripDisplayTitle(trip)}账单`;
      app.billCreateDialog.baseCurrency = 'CNY';
      app.billCreateDialog.members = [];
      app.billCreateDialog.createChat = true;
    }

    function closeCreateBillDialog() {
      app.billCreateDialog.show = false;
      app.billCreateDialog.status = '';
      app.billCreateDialog.members = [];
    }

    function toggleBillCreateMember(name) {
      const list = Array.isArray(app.billCreateDialog.members) ? app.billCreateDialog.members.slice() : [];
      const idx = list.indexOf(name);
      if (idx >= 0) list.splice(idx, 1);
      else list.push(name);
      app.billCreateDialog.members = list;
    }

    async function createBillLinkedChat(billTitle, selectedMembers) {
      const members = [...new Set([app.current, ...(Array.isArray(selectedMembers) ? selectedMembers : [])].filter(Boolean))].sort();
      if (members.length < 2) return null;
      const groupName = `${billTitle}协商群`;
      const existing = dedupeChats(app.social.chats || []).find((chat) => isGroupChatRecord(chat) && String(chat.name || '').trim() === groupName);
      if (existing) {
        const currentMembers = Array.isArray(existing.members) ? existing.members.filter(Boolean) : [];
        const mergedMembers = [...new Set([...currentMembers, ...members])];
        if (mergedMembers.length !== currentMembers.length) {
          existing.members = mergedMembers;
          callSupabase('syncChat', existing, app.current);
        }
        return existing;
      }
      const chat = {
        id: uid(),
        members,
        name: groupName,
        isGroup: true,
        owner: app.current,
        messages: [{
          id: uid(),
          type: 'system',
          from: app.current,
          text: `${app.current} 创建了账单协商群`,
          createdAt: now()
        }]
      };
      const client = window.RJSupabase;
      try {
        if (client?.isEnabled?.() && typeof client.syncChat === 'function') {
          await client.syncChat(chat, app.current);
          await refreshChatsFromDb();
        } else {
          app.social.chats = dedupeChats([chat, ...(app.social.chats || [])]);
          setSocial(app.social, app.current);
        }
      } catch (err) {
        console.warn('[trip-bills] create bill chat failed', err?.message || err);
        app.social.chats = dedupeChats([chat, ...(app.social.chats || [])]);
        setSocial(app.social, app.current);
      }
      return dedupeChats(app.social.chats || []).find((c) => String(c.id || '') === String(chat.id || '')) || chat;
    }

    async function submitCreateBill() {
      const trip = tripData.value;
      if (!ensureLogin() || !trip) return;
      if (!canCreateBillForTrip(trip)) {
        app.billCreateDialog.status = '只有行程作者可以发起账单';
        return;
      }
      const existing = getExistingBillForTrip(trip.id);
      if (existing?.id) {
        app.billCreateDialog.status = '这个行程已经有账单了，正在为你打开现有账单…';
        closeCreateBillDialog();
        app.selectedBillId = existing.id;
        await loadBillDetail(existing.id);
        goto('bill');
        return;
      }
      const title = String(app.billCreateDialog.title || '').trim() || `${getTripDisplayTitle(trip)}账单`;
      const baseCurrency = String(app.billCreateDialog.baseCurrency || 'CNY').trim() || 'CNY';
      const invited = [...new Set((Array.isArray(app.billCreateDialog.members) ? app.billCreateDialog.members : []).filter(Boolean))];
      app.billCreateDialog.status = '创建中…';
      try {
        let linkedChat = null;
        if (app.billCreateDialog.createChat && invited.length) {
          linkedChat = await createBillLinkedChat(title, invited);
        }
        const payload = {
          id: uid(),
          tripId: trip.id,
          title,
          baseCurrency,
          creatorNickname: app.current,
          memberNicknames: invited,
          linkedChatId: linkedChat?.id || '',
          status: 'active'
        };
        const client = window.RJSupabase;
        let detail = null;
        if (client?.isEnabled?.() && typeof client.createTripBill === 'function') {
          detail = await client.createTripBill(payload);
        } else {
          detail = normalizeBillRecord({
            ...payload,
            createdBy: app.current,
            linkedChatName: linkedChat?.name || '',
            members: [app.current, ...invited].map((nickname, idx) => ({ nickname, role: idx === 0 ? 'owner' : 'member', status: 'active', joinedAt: now() })),
            items: [],
            events: [{ id: uid(), billId: payload.id, actor: app.current, eventType: 'bill_created', payload: { title, memberNicknames: invited }, createdAt: now() }],
            createdAt: now(),
            updatedAt: now()
          });
          persistLocalBillDetail(detail);
        }
        await loadTripBills(trip.id);
        if (detail?.id) {
          app.selectedBillId = detail.id;
          await loadBillDetail(detail.id);
        }
        closeCreateBillDialog();
        goto('bill');
      } catch (err) {
        console.warn('[trip-bills] submitCreateBill failed', err?.message || err);
        app.billCreateDialog.status = `创建失败：${err?.message || err}`;
      }
    }

    function openBill(billId) {
      if (!billId) return;
      app.selectedBillId = billId;
      void loadBillDetail(billId);
      goto('bill');
    }

    function canDeleteBill(bill) {
      return Boolean(bill && app.current && String(bill.createdBy || '').trim() === String(app.current || '').trim());
    }

    async function deleteBill(bill) {
      const target = bill ? normalizeBillRecord(bill) : null;
      if (!target?.id) return;
      if (!canDeleteBill(target)) {
        showCenterNotice('只有账单发起人可以删除账单。', '行程账单');
        return;
      }
      const tripId = String(target.tripId || '').trim();
      const ok = await showCenterConfirm(`确认删除账单《${target.title || '行程账单'}》吗？删除后将无法恢复。`, '行程账单', {
        confirmText: '确认',
        cancelText: '取消'
      });
      if (!ok) return;
      try {
        const client = window.RJSupabase;
        if (client?.isEnabled?.() && typeof client.deleteTripBill === 'function') {
          await client.deleteTripBill(target.id, app.current);
        }
        app.state.tripBills = (Array.isArray(app.state.tripBills) ? app.state.tripBills : []).filter((entry) => String(entry?.id || '') !== String(target.id || ''));
        setState(app.current, app.state);
        delete app.billDetails[target.id];
        if (tripId) {
          app.tripBillsByTrip[tripId] = (Array.isArray(app.tripBillsByTrip[tripId]) ? app.tripBillsByTrip[tripId] : []).filter((entry) => String(entry?.id || '') !== String(target.id || ''));
        }
        if (String(app.selectedBillId || '') === String(target.id || '')) app.selectedBillId = '';
        if (tripId) await loadTripBills(tripId);
        goto('trip');
        showCenterNotice('账单删除成功', '行程账单');
      } catch (err) {
        console.warn('[trip-bills] deleteBill failed', err?.message || err);
        showCenterNotice(`删除账单失败：${err?.message || err}`, '行程账单');
      }
    }

    function openBillInviteDialog(bill) {
      if (!bill) return;
      const currentMembers = (Array.isArray(bill.members) ? bill.members : []).map((member) => member.nickname).filter(Boolean);
      app.billInviteDialog.billId = bill.id;
      app.billInviteDialog.users = mutualFollowUsers.value.filter((name) => name && name !== app.current && !currentMembers.includes(name));
      app.billInviteDialog.show = true;
    }

    function closeBillInviteDialog() {
      app.billInviteDialog.show = false;
      app.billInviteDialog.billId = '';
      app.billInviteDialog.users = [];
    }

    async function inviteUserToBill(name) {
      const bill = billData.value;
      if (!bill || !name) return;
      try {
        const client = window.RJSupabase;
        if (client?.isEnabled?.() && typeof client.addTripBillMembers === 'function') {
          await client.addTripBillMembers(bill.id, [name], app.current);
        } else {
          const detail = normalizeBillRecord({
            ...bill,
            members: [...(bill.members || []), { nickname: name, role: 'member', status: 'active', joinedAt: now() }],
            events: [{ id: uid(), billId: bill.id, actor: app.current, eventType: 'members_invited', payload: { memberNicknames: [name] }, createdAt: now() }, ...(bill.events || [])]
          });
          persistLocalBillDetail(detail);
        }
        if (bill.linkedChatId) {
          const linkedChat = (app.social.chats || []).find((chat) => String(chat.id || '') === String(bill.linkedChatId || ''));
          if (linkedChat && !linkedChat.members.includes(name)) {
            linkedChat.members.push(name);
            linkedChat.messages.push({ id: uid(), type: 'system', text: `${app.current} 邀请 ${name} 加入了账单协商群`, createdAt: now() });
            setSocial(app.social, app.current);
            callSupabase('syncChat', linkedChat, app.current);
          }
        }
        await loadBillDetail(bill.id);
        closeBillInviteDialog();
      } catch (err) {
        showCenterNotice(`邀请失败：${err?.message || err}`, '账单成员');
      }
    }

    function openBillChat(bill) {
      const target = bill || billData.value;
      if (!target?.linkedChatId) return;
      openChat(target.linkedChatName || '账单协商群', target.linkedChatId);
    }

    function openBillItemDialog(bill, item = null) {
      const targetBill = bill || billData.value;
      if (!targetBill) return;
      const members = (Array.isArray(targetBill.members) ? targetBill.members : []).map((member) => member.nickname).filter(Boolean);
      const form = defaultBillForm();
      form.paidBy = item?.paidBy || app.current;
      form.expenseTime = item?.expenseTime ? String(item.expenseTime).slice(0, 16) : String(now()).slice(0, 16);
      form.participants = members.slice();
      if (item) {
        form.expenseType = item.expenseType || 'public';
        form.category = item.category || 'other';
        form.amountOriginal = item.amountOriginal || '';
        form.currencyOriginal = item.currencyOriginal || targetBill.baseCurrency || 'CNY';
        form.amountCnyActual = item.amountCnyActual == null ? '' : item.amountCnyActual;
        form.amountCnyEstimated = item.amountCnyEstimated == null ? '' : item.amountCnyEstimated;
        form.fxRate = item.amountOriginal && item.amountCnyEstimated != null && item.amountCnyEstimated !== '' ? (Number(item.amountCnyEstimated || 0) / Math.max(Number(item.amountOriginal || 0), 0.000001)).toFixed(6) : '';
        form.fxRateDate = item.expenseTime ? String(item.expenseTime).slice(0, 10) : '';
        form.fxRateSource = 'Frankfurter';
        form.fxStatus = '';
        form.fxLoading = false;
        form.amountEstimatedManual = item.amountCnyEstimated != null && item.amountCnyEstimated !== '';
        form.note = item.note || '';
        form.receiptImageUrl = item.receiptImageUrl || '';
        form.receiptImageUrls = parseBillReceiptUrls(item.receiptImageUrl || item.receiptImageUrls || '');
        form.receiptFileNames = form.receiptImageUrls.map((url, index) => receiptFileNameFromUrl(url, `已上传凭证${form.receiptImageUrls.length > 1 ? index + 1 : ''}`));
        form.receiptFileName = form.receiptFileNames[0] || '';
        form.receiptUploading = false;
        form.status = item.status || 'pending';
        form.participants = (Array.isArray(item.participants) ? item.participants : []).map((p) => p.nickname).filter(Boolean);
      } else {
        form.currencyOriginal = targetBill.baseCurrency || 'CNY';
        form.fxRate = '';
        form.fxRateDate = String(form.expenseTime || '').slice(0, 10);
        form.fxRateSource = 'Frankfurter';
        form.fxStatus = '';
        form.fxLoading = false;
        form.amountEstimatedManual = false;
        form.receiptImageUrls = [];
        form.receiptFileNames = [];
        form.receiptFileName = '';
        form.receiptUploading = false;
      }
      syncBillItemParticipantsForType(form, members);
      app.billItemDialog.show = true;
      app.billItemDialog.mode = item ? 'edit' : 'create';
      app.billItemDialog.billId = targetBill.id;
      app.billItemDialog.itemId = item?.id || '';
      app.billItemDialog.status = '';
      app.billItemDialog.form = form;
      queueMicrotask(() => { refreshBillEstimatedSettlement({ force: !item }); });
    }

    function closeBillItemDialog() {
      app.billItemDialog.show = false;
      app.billItemDialog.mode = 'create';
      app.billItemDialog.billId = '';
      app.billItemDialog.itemId = '';
      app.billItemDialog.status = '';
      app.billItemDialog.form = null;
    }

    function toggleBillItemParticipant(name) {
      const form = app.billItemDialog.form;
      if (!form || !isBillParticipantEditable(form)) return;
      const list = Array.isArray(form.participants) ? form.participants.slice() : [];
      const idx = list.indexOf(name);
      if (idx >= 0) list.splice(idx, 1);
      else list.push(name);
      form.participants = list;
    }

    function onBillExpenseTypeChange() {
      const bill = billData.value;
      const form = app.billItemDialog.form;
      const memberNames = (Array.isArray(bill?.members) ? bill.members : []).map((member) => member.nickname).filter(Boolean);
      syncBillItemParticipantsForType(form, memberNames);
    }

    function onBillPaidByChange() {
      const bill = billData.value;
      const form = app.billItemDialog.form;
      const memberNames = (Array.isArray(bill?.members) ? bill.members : []).map((member) => member.nickname).filter(Boolean);
      syncBillItemParticipantsForType(form, memberNames);
    }

    function billParticipantHint() {
      const form = app.billItemDialog.form;
      const type = String(form?.expenseType || 'public').toLowerCase();
      if (type === 'public') return '全员均摊时，系统会自动选中全部账单成员。';
      if (type === 'partial') return '部分成员分摊时，可自由勾选本笔费用由哪几个人承担。';
      if (type === 'personal') return '个人支出默认由付款人本人承担，不参与多人结算。';
      if (type === 'daigou') return '代购 / 代付默认先记到付款人名下，后续可单独核对。';
      return '';
    }

    function normalizeBillFxDate(value) {
      const raw = String(value || '').trim();
      if (!raw) return String(now()).slice(0, 10);
      return raw.slice(0, 10);
    }

    function roundBillAmount(value, digits = 2) {
      const num = Number(value || 0);
      if (!Number.isFinite(num)) return 0;
      const factor = 10 ** digits;
      return Math.round(num * factor) / factor;
    }

    function parseFrankfurterRate(payload, quoteCurrency) {
      const quote = String(quoteCurrency || '').toUpperCase();
      function walk(node) {
        if (!node) return null;
        if (Array.isArray(node)) {
          for (const entry of node) {
            const found = walk(entry);
            if (found != null) return found;
          }
          return null;
        }
        if (typeof node !== 'object') return null;
        if (node.rates && typeof node.rates === 'object' && node.rates[quote] != null) {
          const num = Number(node.rates[quote]);
          return Number.isFinite(num) ? num : null;
        }
        if ((node.quote === quote || node.currency === quote || node.target === quote || !quote) && node.rate != null) {
          const num = Number(node.rate);
          return Number.isFinite(num) ? num : null;
        }
        for (const key of ['data', 'result', 'results']) {
          if (node[key] != null) {
            const found = walk(node[key]);
            if (found != null) return found;
          }
        }
        return null;
      }
      return walk(payload);
    }

    async function fetchBillFxRate(fromCurrency, toCurrency, dateText) {
      const from = String(fromCurrency || '').toUpperCase();
      const to = String(toCurrency || '').toUpperCase();
      const fxDate = normalizeBillFxDate(dateText);
      if (!from || !to) throw new Error('缺少币种');
      if (from === to) return { rate: 1, date: fxDate, source: 'Frankfurter' };
      const url = `${BILL_FX_API_BASE}/rates?date=${encodeURIComponent(fxDate)}&base=${encodeURIComponent(from)}&quotes=${encodeURIComponent(to)}`;
      const response = await fetch(url, { headers: { Accept: 'application/json' } });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(payload?.message || `Frankfurter ${response.status}`);
      }
      const rate = parseFrankfurterRate(payload, to);
      if (!Number.isFinite(rate) || rate <= 0) throw new Error('未读取到有效汇率');
      return { rate, date: fxDate, source: 'Frankfurter' };
    }

    async function refreshBillEstimatedSettlement(options = {}) {
      const bill = billData.value;
      const form = app.billItemDialog.form;
      if (!bill || !form) return;
      const from = String(form.currencyOriginal || '').toUpperCase();
      const to = String(bill.baseCurrency || 'CNY').toUpperCase();
      const amount = Number(form.amountOriginal || 0);
      const force = options && options.force === true;
      if (!from || !to) return;
      form.fxRateDate = normalizeBillFxDate(form.expenseTime);
      if (!amount) {
        if (!form.amountEstimatedManual || force) form.amountCnyEstimated = '';
        form.fxRate = from === to ? '1.000000' : '';
        form.fxStatus = from === to ? `账单主币种与原币一致，1 ${from} = 1 ${to}` : '';
        form.fxLoading = false;
        return;
      }
      if (from === to) {
        form.fxLoading = false;
        form.fxRate = '1.000000';
        const converted = roundBillAmount(amount, 2).toFixed(2);
        if (!form.amountEstimatedManual || force || form.amountCnyEstimated === '') form.amountCnyEstimated = converted;
        form.fxStatus = `账单主币种与原币一致，已自动按 1 ${from} = 1 ${to} 回填结算金额。`;
        return;
      }
      form.fxLoading = true;
      form.fxStatus = `正在读取 ${form.fxRateDate} 的 ${from}→${to} 参考汇率…`;
      try {
        const result = await fetchBillFxRate(from, to, form.expenseTime);
        const rate = Number(result.rate || 0);
        form.fxRate = rate.toFixed(6);
        form.fxRateDate = result.date || form.fxRateDate;
        form.fxRateSource = result.source || 'Frankfurter';
        const converted = roundBillAmount(amount * rate, 2).toFixed(2);
        if (!form.amountEstimatedManual || force || form.amountCnyEstimated === '') form.amountCnyEstimated = converted;
        form.fxStatus = `已按 ${form.fxRateDate} 的 ${form.fxRateSource} 参考汇率自动换算：1 ${from} ≈ ${form.fxRate} ${to}。可手动修改结算金额。`;
      } catch (error) {
        console.warn('[trip-bills] fx lookup failed', error?.message || error);
        form.fxStatus = `汇率读取失败：${error?.message || error}。你仍可手动填写结算金额。`;
      } finally {
        form.fxLoading = false;
      }
    }

    function onBillAmountOriginalChange() {
      refreshBillEstimatedSettlement();
    }

    function onBillCurrencyChange() {
      refreshBillEstimatedSettlement({ force: true });
    }

    function onBillExpenseTimeChange() {
      refreshBillEstimatedSettlement({ force: true });
    }

    function onBillEstimatedAmountInput() {
      const form = app.billItemDialog.form;
      if (!form) return;
      form.amountEstimatedManual = true;
    }

    async function onBillReceiptFileChange(event) {
      const form = app.billItemDialog.form;
      const input = event?.target || null;
      const files = Array.from(input?.files || []).filter(Boolean);
      if (!form || !files.length) return;
      const existingUrls = Array.isArray(form.receiptImageUrls) ? form.receiptImageUrls.slice() : parseBillReceiptUrls(form.receiptImageUrl || '');
      const existingNames = Array.isArray(form.receiptFileNames) ? form.receiptFileNames.slice() : [];
      if (existingUrls.length + files.length > BILL_RECEIPT_MAX_FILES) {
        showCenterNotice(`最多可上传 ${BILL_RECEIPT_MAX_FILES} 张凭证图片，请先移除部分文件。`, '费用凭证');
        if (input) input.value = '';
        return;
      }
      const oversized = files.find((file) => Number(file?.size || 0) > BILL_RECEIPT_MAX_FILE_SIZE);
      if (oversized) {
        showCenterNotice(`单张图片请控制在 ${(BILL_RECEIPT_MAX_FILE_SIZE / 1024 / 1024).toFixed(0)}MB 以内：${oversized.name}`, '费用凭证');
        if (input) input.value = '';
        return;
      }
      const client = window.RJSupabase;
      if (!client?.isEnabled?.() || typeof client.uploadBillReceipt !== 'function') {
        showCenterNotice('请先配置 Supabase Storage，再上传小票或截图。', '费用凭证');
        if (input) input.value = '';
        return;
      }
      form.receiptUploading = true;
      form.receiptFileName = files.length === 1 ? (files[0].name || '上传中…') : `正在上传 ${files.length} 张图片…`;
      app.billItemDialog.status = `正在上传 ${files.length} 张小票 / 截图…`;
      try {
        const uploadedUrls = [];
        const uploadedNames = [];
        for (let index = 0; index < files.length; index += 1) {
          const file = files[index];
          app.billItemDialog.status = `正在上传 ${index + 1}/${files.length}：${file.name || '图片'}`;
          const uploadFile = await optimizeImageFile(file, { maxEdge: 2200, quality: 0.86, targetBytes: 2200 * 1024 });
          const result = await client.uploadBillReceipt(uploadFile, {
            nickname: app.current,
            billId: app.billItemDialog.billId,
            itemId: app.billItemDialog.itemId || '',
            originalName: file.name || ''
          });
          if (result?.url) {
            uploadedUrls.push(result.url);
            uploadedNames.push(file.name || `凭证${existingUrls.length + uploadedUrls.length}`);
          }
        }
        form.receiptImageUrls = existingUrls.concat(uploadedUrls);
        form.receiptFileNames = existingNames.concat(uploadedNames);
        form.receiptImageUrl = serializeBillReceiptUrls(form.receiptImageUrls);
        form.receiptFileName = form.receiptFileNames[0] || '';
        app.billItemDialog.status = `凭证上传成功，已添加 ${uploadedUrls.length} 张图片`;
      } catch (err) {
        console.warn('[trip-bills] receipt upload failed', err?.message || err);
        app.billItemDialog.status = `凭证上传失败：${err?.message || err}`;
      } finally {
        form.receiptUploading = false;
        if (input) input.value = '';
      }
    }

    function removeBillReceiptAt(index) {
      const form = app.billItemDialog.form;
      if (!form) return;
      const urls = Array.isArray(form.receiptImageUrls) ? form.receiptImageUrls.slice() : [];
      const names = Array.isArray(form.receiptFileNames) ? form.receiptFileNames.slice() : [];
      if (index < 0 || index >= urls.length) return;
      urls.splice(index, 1);
      names.splice(index, 1);
      form.receiptImageUrls = urls;
      form.receiptFileNames = names;
      form.receiptImageUrl = serializeBillReceiptUrls(urls);
      form.receiptFileName = names[0] || '';
      if (!urls.length && app.billItemDialog.status && app.billItemDialog.status.startsWith('凭证上传成功')) app.billItemDialog.status = '';
    }

    function clearBillReceiptImage() {
      const form = app.billItemDialog.form;
      if (!form) return;
      form.receiptImageUrl = '';
      form.receiptImageUrls = [];
      form.receiptFileName = '';
      form.receiptFileNames = [];
      if (app.billItemDialog.status === '凭证上传成功') app.billItemDialog.status = '';
    }

    async function submitBillItem() {
      const bill = billData.value;
      const form = app.billItemDialog.form;
      if (!bill || !form) return;
      syncBillItemParticipantsForType(form, billMemberNames.value);
      if (!form.amountOriginal || !form.paidBy || !Array.isArray(form.participants) || !form.participants.length) {
        app.billItemDialog.status = '请填写金额、付款人和承担人';
        return;
      }
      app.billItemDialog.status = '保存中…';
      try {
        const payload = {
          id: app.billItemDialog.itemId || undefined,
          billId: bill.id,
          actorNickname: app.current,
          expenseType: form.expenseType,
          category: form.category,
          amountOriginal: Number(form.amountOriginal || 0),
          currencyOriginal: form.currencyOriginal || bill.baseCurrency || 'CNY',
          amountCnyActual: form.amountCnyActual === '' ? null : Number(form.amountCnyActual || 0),
          amountCnyEstimated: form.amountCnyEstimated === '' ? null : Number(form.amountCnyEstimated || 0),
          paidBy: form.paidBy,
          expenseTime: form.expenseTime ? new Date(form.expenseTime).toISOString() : now(),
          note: form.note || '',
          receiptImageUrl: serializeBillReceiptUrls(form.receiptImageUrls),
          splitMethod: 'equal',
          status: form.status || 'pending',
          participants: form.participants.slice()
        };
        const client = window.RJSupabase;
        if (client?.isEnabled?.() && typeof client.upsertTripBillItem === 'function') {
          await client.upsertTripBillItem(payload);
        } else {
          const settlementBase = payload.amountCnyActual == null ? (payload.amountCnyEstimated == null ? payload.amountOriginal : payload.amountCnyEstimated) : payload.amountCnyActual;
          const shareAmount = payload.participants.length ? settlementBase / payload.participants.length : 0;
          const item = {
            id: payload.id || uid(),
            billId: bill.id,
            expenseType: payload.expenseType,
            category: payload.category,
            status: payload.status,
            amountOriginal: payload.amountOriginal,
            currencyOriginal: payload.currencyOriginal,
            amountCnyActual: payload.amountCnyActual,
            amountCnyEstimated: payload.amountCnyEstimated,
            paidBy: payload.paidBy,
            expenseTime: payload.expenseTime,
            note: payload.note,
            receiptImageUrl: payload.receiptImageUrl,
            receiptImageUrls: parseBillReceiptUrls(payload.receiptImageUrl),
            splitMethod: 'equal',
            createdBy: app.current,
            createdAt: now(),
            updatedAt: now(),
            participants: payload.participants.map((nickname) => ({ nickname, shareRatio: 1 / payload.participants.length, shareAmount, isIncluded: true }))
          };
          const items = Array.isArray(bill.items) ? bill.items.slice() : [];
          const index = items.findIndex((entry) => String(entry?.id || '') === String(item.id || ''));
          if (index >= 0) items[index] = item; else items.unshift(item);
          const events = [{ id: uid(), billId: bill.id, itemId: item.id, actor: app.current, eventType: app.billItemDialog.itemId ? 'item_updated' : 'item_created', payload: { note: item.note, participants: payload.participants, status: item.status }, createdAt: now() }, ...(bill.events || [])];
          persistLocalBillDetail({ ...bill, items, events, updatedAt: now() });
        }
        await loadBillDetail(bill.id);
        closeBillItemDialog();
      } catch (err) {
        console.warn('[trip-bills] submitBillItem failed', err?.message || err);
        app.billItemDialog.status = `保存失败：${err?.message || err}`;
      }
    }

    async function changeBillItemStatus(item, status) {
      const bill = billData.value;
      if (!bill || !item?.id || !status) return;
      try {
        const client = window.RJSupabase;
        if (client?.isEnabled?.() && typeof client.updateTripBillItemStatus === 'function') {
          await client.updateTripBillItemStatus(item.id, status, app.current, bill.id);
        } else {
          const items = (bill.items || []).map((entry) => String(entry?.id || '') === String(item.id || '') ? { ...entry, status, updatedAt: now() } : entry);
          const events = [{ id: uid(), billId: bill.id, itemId: item.id, actor: app.current, eventType: 'item_status_changed', payload: { status }, createdAt: now() }, ...(bill.events || [])];
          persistLocalBillDetail({ ...bill, items, events, updatedAt: now() });
        }
        await loadBillDetail(bill.id);
      } catch (err) {
        showCenterNotice(`更新状态失败：${err?.message || err}`, '账单费用');
      }
    }

    function markAllAsRead() {
      const stamp = now();
      app.social.chats.forEach((c) => { noticeState.chatReadAt[c.id] = stamp; });
      noticeState.systemReadAt = stamp;
      setNoticeState(noticeState, app.current);
      callSupabase('syncNoticeState', app.current, noticeState, app.social.chats);
    }

    const accountData = computed(() => {
      const user = app.selectedUser || app.current;
      if (!user) return null;
      const s = stateByUser.value[user] || getState(user);
      return { user, ...s };
    });
    const isSelfAccount = computed(() => Boolean(accountData.value?.user && accountData.value.user === app.current));
    const isFollowingAccount = computed(() => {
      const target = accountData.value?.user;
      if (!target || target === app.current) return false;
      return isFollowing(target);
    });
    const accountDiaryGroups = computed(() => {
      const publicSource = Array.isArray(app.publicDiaries) ? app.publicDiaries : [];
      const targetUser = accountData.value?.user || '';
      if (!targetUser) return [];
      if (app.publicDiariesLoading && !app.publicDiariesLoaded) return [];
      if (app.publicDiariesLoaded) return publicSource.filter((item) => item.user === targetUser);
      return [];
    });
    const accountDiaryCount = computed(() => accountDiaryGroups.value.length);
    const tripData = computed(() => allTrips.value.find((t) => t.id === app.selectedTripId) || (app.publicTrips || []).find((t) => t.id === app.selectedTripId) || null);

    const tripBills = computed(() => {
      const tripId = String(app.selectedTripId || '').trim();
      const local = tripId ? getLocalTripBillsForTrip(tripId) : [];
      const remote = tripId && Array.isArray(app.tripBillsByTrip[tripId]) ? app.tripBillsByTrip[tripId] : [];
      const merged = [...remote, ...local].map(normalizeBillRecord);
      const map = new Map();
      merged.forEach((bill) => map.set(String(bill.id || ''), bill));
      return [...map.values()].filter((bill) => canCurrentUserAccessBill(bill)).sort((a, b) => new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0));
    });
    const activeTripBill = computed(() => tripBills.value[0] || null);
    function getExistingBillForTrip(tripId) {
      const normalizedTripId = String(tripId || '').trim();
      if (!normalizedTripId) return null;
      const local = getLocalTripBillsForTrip(normalizedTripId) || [];
      const remote = Array.isArray(app.tripBillsByTrip[normalizedTripId]) ? app.tripBillsByTrip[normalizedTripId] : [];
      const merged = [...remote, ...local].map(normalizeBillRecord);
      const map = new Map();
      merged.forEach((bill) => map.set(String(bill.id || ''), bill));
      const accessible = [...map.values()]
        .filter((bill) => canCurrentUserAccessBill(bill))
        .sort((a, b) => new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0));
      return accessible[0] || null;
    }
    const billData = computed(() => {
      const selected = String(app.selectedBillId || '').trim();
      if (!selected) return activeTripBill.value;
      return app.billDetails[selected] || tripBills.value.find((bill) => String(bill.id || '') === selected) || null;
    });
    const billMemberNames = computed(() => (Array.isArray(billData.value?.members) ? billData.value.members : []).map((m) => m.nickname).filter(Boolean));
    const billSettlement = computed(() => {
      const bill = billData.value;
      const names = billMemberNames.value;
      const byName = new Map(names.map((name) => [name, { nickname: name, paid: 0, share: 0, net: 0 }]));
      const items = Array.isArray(bill?.items) ? bill.items : [];
      items.forEach((item) => {
        if (!item || item.expenseType === 'personal' || item.expenseType === 'daigou') return;
        const base = billSettlementAmount(item);
        const payer = String(item.paidBy || '').trim();
        if (payer) {
          if (!byName.has(payer)) byName.set(payer, { nickname: payer, paid: 0, share: 0, net: 0 });
          byName.get(payer).paid += base;
        }
        const participants = (Array.isArray(item.participants) ? item.participants : []).filter((p) => p && p.isIncluded !== false && p.nickname).map((p) => p.nickname);
        const uniqueParticipants = [...new Set(participants)];
        const per = uniqueParticipants.length ? base / uniqueParticipants.length : 0;
        uniqueParticipants.forEach((nickname) => {
          if (!byName.has(nickname)) byName.set(nickname, { nickname, paid: 0, share: 0, net: 0 });
          byName.get(nickname).share += per;
        });
      });
      const rows = [...byName.values()].map((row) => ({ ...row, net: row.paid - row.share }));
      const receivers = rows.filter((row) => row.net > 0.01).map((row) => ({ ...row }));
      const payers = rows.filter((row) => row.net < -0.01).map((row) => ({ ...row, need: Math.abs(row.net) }));
      const transfers = [];
      receivers.forEach((receiver) => {
        let available = receiver.net;
        payers.forEach((payer) => {
          if (available <= 0.01 || payer.need <= 0.01) return;
          const amount = Math.min(available, payer.need);
          if (amount > 0.01) {
            transfers.push({ from: payer.nickname, to: receiver.nickname, amount });
            available -= amount;
            payer.need -= amount;
          }
        });
      });
      return { rows, transfers };
    });
    const billPendingCount = computed(() => (Array.isArray(billData.value?.items) ? billData.value.items : []).filter((item) => item.status === 'pending').length);
    const billDisputedCount = computed(() => (Array.isArray(billData.value?.items) ? billData.value.items : []).filter((item) => item.status === 'disputed').length);
    const billDynamicFeed = computed(() => (Array.isArray(billData.value?.events) ? billData.value.events : []).slice().sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0)));
    const billEventTotalPages = computed(() => Math.max(1, Math.ceil((billDynamicFeed.value.length || 0) / Number(app.billEventsPageSize || 10))));
    const billDynamicFeedPaged = computed(() => {
      const size = Number(app.billEventsPageSize || 10);
      const page = Math.min(billEventTotalPages.value, Math.max(1, Number(app.billEventsPage || 1)));
      const start = (page - 1) * size;
      return billDynamicFeed.value.slice(start, start + size);
    });
    const linkedBillForCurrentChat = computed(() => {
      const chatId = String(currentChatMeta.value?.id || '').trim();
      if (!chatId) return null;
      const candidates = Object.values(app.billDetails || {}).map(normalizeBillRecord);
      return candidates.find((bill) => String(bill.linkedChatId || '').trim() === chatId) || null;
    });
    const diaryData = computed(() => {
      const selected = app.selectedDiaryRecord || null;
      const publicMatch = findPublicDiaryRecord(selected || { id: app.selectedDiaryId }) || null;
      const dbRecord = publicMatch || (isDbDiaryRecord(selected) ? selected : null);
      if (!dbRecord) return null;
      const images = Array.isArray(dbRecord.images) && dbRecord.images.length
        ? dbRecord.images.filter(Boolean)
        : Array.isArray(dbRecord.covers) && dbRecord.covers.length
          ? dbRecord.covers.filter(Boolean)
          : [dbRecord.cover].filter(Boolean);
      const comments = Array.isArray(dbRecord.comments)
        ? dbRecord.comments
            .filter((c) => isDbDiaryComment(c))
            .map((c) => ({ ...c, dbCommentId: c.dbCommentId || c.id, likes: Array.isArray(c.likes) ? c.likes : [] }))
        : [];
      return {
        ...dbRecord,
        dbPostId: getDiaryPrimaryId(dbRecord),
        caption: normalizeDiaryCaption(dbRecord.caption),
        images,
        comments,
        likes: Array.isArray(dbRecord.likes) ? dbRecord.likes : []
      };
    });
    const currentChat = computed(() => {
      const chat = ensureChat();
      return chat || { messages: [] };
    });
    const currentChatSendRule = computed(() => getChatSendRule(currentChat.value, app.current));
    const currentChatMeta = computed(() => {
      if (!app.selectedChatId && !app.chatPeer) return null;
      const chats = dedupeChats(Array.isArray(app.social.chats) ? app.social.chats : []);
      return chats.find((c) => c.id === app.selectedChatId)
        || chats.find((c) => isGroupChatRecord(c) && String(c.name || '').trim() === String(app.chatPeer || '').trim())
        || null;
    });
    const isCurrentGroup = computed(() => Boolean(currentChatMeta.value && isGroupChatRecord(currentChatMeta.value)));
    const chatTitle = computed(() => {
      if (isCurrentGroup.value) return String(currentChatMeta.value?.name || app.chatPeer || '群聊');
      return `与 ${app.chatPeer} 聊天`;
    });

    const adminStats = computed(() => {
      const events = read(KEYS.ADMIN, []);
      const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
      const weeklyEvents = events.filter((e) => new Date(e.createdAt || 0).getTime() >= weekAgo);
      const registerUsers = new Set(weeklyEvents.filter((e) => e.type === 'register').map((e) => e.payload?.user).filter(Boolean));
      const newTrips7d = allTrips.value.filter((item) => new Date(item.createdAt || 0).getTime() >= weekAgo).length;
      const newDiaries7d = allDiaries.value.filter((item) => new Date(item.createdAt || 0).getTime() >= weekAgo).length;
      const activeUsers7d = new Set(weeklyEvents.flatMap((e) => [e.payload?.user, e.payload?.from, e.payload?.to]).filter(Boolean)).size;
      return {
        users: app.users.length,
        trips: allTrips.value.length,
        diaries: allDiaries.value.length,
        newUsers7d: registerUsers.size,
        newTrips7d,
        newDiaries7d,
        activeUsers7d,
        events: events.slice(0, 50),
        feedbacks: events.filter((e) => e.type === 'feedback-submit')
      };
    });
    const feedbackTotalPages = computed(() => Math.max(1, Math.ceil((adminStats.value.feedbacks?.length || 0) / Number(app.feedbackPageSize || 10))));
    const feedbackPaged = computed(() => {
      const page = Math.min(feedbackTotalPages.value, Math.max(1, Number(app.feedbackPage || 1)));
      const size = Number(app.feedbackPageSize || 10);
      const start = (page - 1) * size;
      return (adminStats.value.feedbacks || []).slice(start, start + size);
    });
    const myBillsTotalPages = computed(() => { const list = Array.isArray(app.myBillsList) ? app.myBillsList : []; return Math.max(1, Math.ceil((list.length || 0) / Number(app.myBillsPageSize || 10))); });
    const myBillsPaged = computed(() => {
      const page = Math.min(myBillsTotalPages.value, Math.max(1, Number(app.myBillsPage || 1)));
      const size = Number(app.myBillsPageSize || 10);
      const start = (page - 1) * size;
      return (app.myBillsList || []).slice(start, start + size);
    });

    const chatPreviews = computed(() => {
      const rows = dedupeChats(app.social.chats || []);
      const mapped = rows
        .filter((c) => Array.isArray(c.members) && c.members.includes(app.current))
        .filter((c) => isGroupChatRecord(c) || (Array.isArray(c.members) && c.members.length === 2))
        .map((c) => {
          const isGroup = isGroupChatRecord(c);
          const peer = isGroup ? (String(c.name || '').trim() || '群聊') : (c.members.find((m) => m !== app.current) || '群聊');
          const messages = Array.isArray(c.messages) ? c.messages : [];
          const last = messages[messages.length - 1] || null;
          const readAt = new Date(noticeState.chatReadAt[c.id] || 0).getTime();
          const unread = messages.filter((m) => m.from !== app.current && new Date(m.createdAt || 0).getTime() > readAt).length;
          return { id: c.id, peer, last, unread, isGroup, owner: chatOwnerName(c), chat: c };
        })
        .sort((a, b) => new Date(b.last?.createdAt || 0) - new Date(a.last?.createdAt || 0));
      const deduped = [];
      const seen = new Set();
      mapped.forEach((row) => {
        const key = row.isGroup ? `group:${String(row.peer || '').trim()}` : `dm:${String(row.peer || '').trim()}`;
        if (seen.has(key)) return;
        seen.add(key);
        deduped.push(row);
      });
      return deduped;
    });
    const systemMessages = computed(() => {
      const events = read(KEYS.ADMIN, []);
      return events
        .filter((e) => {
          if (!e?.payload || e.payload.to !== app.current) return false;
          if (['like-trip', 'comment-trip', 'comment-diary', 'group-invite', 'group-dissolve'].includes(e.type)) return e.payload.from !== e.payload.to;
          if (e.type === 'toggle-follow') return Boolean(e.payload.active) && e.payload.from !== e.payload.to;
          return false;
        })
        .map((e) => {
          const actor = e?.payload?.from || '';
          if (e.type === 'like-trip') return { id: e.id, actor, kind: e.type, actionText: '点赞了你的行程', text: `${actor} 点赞了你的行程`, createdAt: e.createdAt };
          if (e.type === 'comment-trip') return { id: e.id, actor, kind: e.type, actionText: '评论了你的行程', text: `${actor} 评论了你的行程`, createdAt: e.createdAt };
          if (e.type === 'comment-diary') return { id: e.id, actor, kind: e.type, actionText: '评论了你的日记', text: `${actor} 评论了你的日记`, createdAt: e.createdAt };
          if (e.type === 'toggle-follow') return { id: e.id, actor, kind: e.type, actionText: '关注了你', text: `${actor} 关注了你`, createdAt: e.createdAt };
          if (e.type === 'group-invite') return { id: e.id, actor, kind: e.type, actionText: `邀请你加入群聊《${e.payload?.groupName || '群聊'}》`, text: `${actor} 邀请你加入群聊《${e.payload?.groupName || '群聊'}》`, createdAt: e.createdAt };
          if (e.type === 'group-dissolve') return { id: e.id, actor, kind: e.type, actionText: `解散了群聊《${e.payload?.groupName || '群聊'}》`, text: `${actor} 解散了群聊《${e.payload?.groupName || '群聊'}》`, createdAt: e.createdAt };
          return null;
        })
        .filter(Boolean);
    });
    const unreadChatCount = computed(() => chatPreviews.value.reduce((sum, c) => sum + c.unread, 0));
    const unreadSystemCount = computed(() => {
      const readAt = new Date(noticeState.systemReadAt || 0).getTime();
      return systemMessages.value.filter((m) => new Date(m.createdAt || 0).getTime() > readAt).length;
    });
    const unreadTotal = computed(() => unreadChatCount.value + unreadSystemCount.value);
    const unreadBadgeCount = computed(() => unreadTotal.value);
    const heroCarousel = computed(() => HERO_CAROUSEL);
    const activeHero = computed(() => HERO_CAROUSEL[app.heroIndex % HERO_CAROUSEL.length]);
    const draftDiaryBytes = computed(() => app.diaryDraftFiles.reduce((sum, f) => sum + Number(f?.size || 0), 0));
    const draftDiaryMB = computed(() => formatBytesToMB(draftDiaryBytes.value));
    const editDiaryBytes = computed(() => Number(app.diaryEditEstimatedBytes || 0));
    const editDiaryMB = computed(() => formatBytesToMB(editDiaryBytes.value));
    const myBadges = computed(() => calcBadges(app.state));
    const cityAchievements = computed(() => Array.isArray(app.achievementCenter.achievements) ? app.achievementCenter.achievements : []);
    const unlockedCityAchievements = computed(() => cityAchievements.value.filter((item) => item.isUnlocked));
    const lockedCityAchievements = computed(() => cityAchievements.value.filter((item) => !item.isUnlocked));
    const achievementProgressPercent = computed(() => {
      const total = cityAchievements.value.length;
      if (!total) return 0;
      return Math.min(100, Math.round((unlockedCityAchievements.value.length / total) * 100));
    });
    const achievementProgressStyle = computed(() => ({ '--achievement-progress': `${achievementProgressPercent.value}%` }));
    const achievementLevelStats = computed(() => {
      const base = {
        platinum: { key: 'platinum', label: '钻石奖杯', total: 0, unlocked: 0 },
        gold: { key: 'gold', label: '黄金奖杯', total: 0, unlocked: 0 },
        silver: { key: 'silver', label: '白银奖杯', total: 0, unlocked: 0 },
        bronze: { key: 'bronze', label: '青铜奖杯', total: 0, unlocked: 0 }
      };
      cityAchievements.value.forEach((item) => {
        const key = String(item?.level || '').toLowerCase();
        if (!base[key]) return;
        base[key].total += 1;
        if (item.isUnlocked) base[key].unlocked += 1;
      });
      return [base.platinum, base.gold, base.silver, base.bronze];
    });
    const featuredAchievement = computed(() => unlockedCityAchievements.value[0] || cityAchievements.value[0] || null);
    const achievementRecentList = computed(() => unlockedCityAchievements.value.slice().sort((a, b) => String(b.unlockedAt || '').localeCompare(String(a.unlockedAt || ''))).slice(0, 3));
    const cityAchievementSummaries = computed(() => Array.isArray(app.achievementCenter.citySummaries) ? app.achievementCenter.citySummaries : []);
    const orderedCityAchievements = computed(() => cityAchievements.value.slice().sort((a, b) => {
      if (a.isUnlocked !== b.isUnlocked) return a.isUnlocked ? -1 : 1;
      const ta = String(a.unlockedAt || '');
      const tb = String(b.unlockedAt || '');
      if (ta && tb && ta !== tb) return tb.localeCompare(ta);
      if (ta && !tb) return -1;
      if (!ta && tb) return 1;
      return Number(a.sort_order || 0) - Number(b.sort_order || 0);
    }));
    const achievementSelectedItem = computed(() => cityAchievements.value.find((item) => item.achievement_code === app.achievementCenter.selectedAchievementCode) || null);
    watch(homeTripTotalPages, (pages) => {
      if (Number(app.tripPage || 1) > pages) app.tripPage = pages;
    });
    function userBadges(user) {
      const s = stateByUser.value[user] || getState(user);
      return calcBadges(s);
    }
    function getFollowingCount(user) {
      if (!user) return 0;
      return (app.social.follows?.[user] || []).length;
    }
    function getFollowerCount(user) {
      if (!user) return 0;
      return Object.values(app.social.follows || {}).filter((list) => Array.isArray(list) && list.includes(user)).length;
    }
    const followingCount = computed(() => getFollowingCount(accountData.value?.user));
    const followerCount = computed(() => getFollowerCount(accountData.value?.user));
    const myAccountData = computed(() => {
      if (!app.current) return null;
      return { user: app.current, ...app.state };
    });
    const myFollowingCount = computed(() => getFollowingCount(app.current));
    const myFollowerCount = computed(() => getFollowerCount(app.current));
    function canQuickFollow(name) {
      return Boolean(app.current && name && name !== app.current && !isFollowing(name));
    }

    function openFollowList(kind, user) {
      const target = user || app.current;
      if (!target) return;
      if (kind === 'following') {
        app.followDialog.title = `${target} 的关注列表`;
        app.followDialog.users = [...(app.social.follows?.[target] || [])];
      } else {
        app.followDialog.title = `${target} 的粉丝列表`;
        app.followDialog.users = Object.keys(app.social.follows || {}).filter((name) => (app.social.follows?.[name] || []).includes(target));
      }
      app.followDialog.show = true;
    }

    function closeFollowList() {
      app.followDialog.show = false;
      app.followDialog.users = [];
      app.followDialog.mode = 'list';
      app.followDialog.groupId = '';
    }

    function goAccountFromList(user) {
      closeFollowList();
      openAccount(user);
    }

    function setHero(index) {
      app.heroIndex = index;
    }

    watch(() => currentChat.value?.messages?.length || 0, () => {
      if (app.route === 'chat') scrollChatToBottom(true);
    });
    watch(() => String(app.selectedBillId || ''), () => {
      app.billEventsPage = 1;
    });
    watch(() => app.current, (next) => {
      if (next && app.route === 'my-bills') {
        Promise.resolve(loadMyBills()).catch(() => {});
      }
    });

    let heroTimer = null;
    const onHashChange = () => {
      app.route = location.hash.replace('#/', '') || 'register';
      if (app.route === 'diary' && app.selectedDiaryId) {
        Promise.resolve(
          refreshDiaryDetails({ id: app.selectedDiaryId, ...(app.selectedDiaryRecord || {}) })
        ).catch(() => {});
      }
      if (app.route === 'trip' && app.selectedTripId) {
        Promise.resolve(loadPublicTrips()).catch(() => {});
        Promise.resolve(loadTripBills(app.selectedTripId, { openFirst: false })).catch(() => {});
      }
      if ((app.route === 'messages' || app.route === 'chat') && app.current) {
        Promise.resolve(refreshChatsFromDb()).catch(() => {});
        Promise.resolve(refreshSocialGraphFromDb()).catch(() => {});
      }
      if (app.route === 'my-bills' && app.current) {
        Promise.resolve(loadMyBills()).catch(() => {});
      }
    };
    onMounted(() => {
      void hydrateCurrentAuthUser();
      window.addEventListener('hashchange', onHashChange);
      void loadPublicTrips();
      void loadPublicDiaries();
      if (app.route === 'trip' && app.selectedTripId) {
        Promise.resolve(loadTripBills(app.selectedTripId, { openFirst: false })).catch(() => {});
      }
      if (app.route === 'my-bills' && app.current) {
        Promise.resolve(loadMyBills()).catch(() => {});
      }
      setTimeout(() => { try { preloadWorldAssets(); } catch {} }, 500);
      app.__openPreviewDialog = () => {
        const dlg = document.querySelector('dialog.image-preview-dialog');
        if (dlg && typeof dlg.showModal === 'function') dlg.showModal();
      };
      if (app.current) {
        const client = window.RJSupabase;
        Promise.resolve(client?.getSupabaseAuthSession?.())
          .then((session) => {
            if (!session?.access_token) {
              console.warn('[vue-auth] no session on mount, clear stale current user');
              localStorage.removeItem(KEYS.CURRENT);
              app.current = '';
      app.tripSquareSearch = '';
      app.userSearch = '';
              goto('register');
              return;
            }
            upsertCurrentUser();
            refreshMine();
            Promise.resolve(loadAchievementCenter(app.achievementCenter.cityCode || 'hangzhou')).catch(() => {});
            Promise.resolve(refreshSocialGraphFromDb()).catch(() => {});
            Promise.resolve(refreshChatsFromDb()).catch(() => {});
          })
          .catch(() => {
            localStorage.removeItem(KEYS.CURRENT);
            app.current = '';
      app.tripSquareSearch = '';
      app.userSearch = '';
            goto('register');
          });
      }
      heroTimer = window.setInterval(() => {
        app.heroIndex = (app.heroIndex + 1) % HERO_CAROUSEL.length;
      }, 2600);
    });
    onUnmounted(() => {
      window.removeEventListener('hashchange', onHashChange);
      if (heroTimer) window.clearInterval(heroTimer);
    });

    function getTripTagsArray(trip) {
      const raw = Array.isArray(trip?.tags) ? trip.tags : list(trip?.tags);
      return raw.map((x) => String(x || '').trim()).filter(Boolean);
    }

    function getTripSpotsArray(trip) {
      const raw = Array.isArray(trip?.spots) ? trip.spots : list(trip?.spots);
      return raw.map((x) => String(x || '').trim()).filter(Boolean);
    }

    function calcTripDaysLabel(trip) {
      const start = new Date(trip?.departDate || '');
      const end = new Date(trip?.returnDate || '');
      if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end < start) return '';
      const diffDays = Math.round((end - start) / 86400000) + 1;
      const nights = Math.max(0, diffDays - 1);
      return diffDays > 0 ? `${diffDays}天${nights}晚` : '';
    }

    function getCanonicalTrip(trip) {
      if (!trip || typeof trip !== 'object') return trip;
      const user = String(trip?.user || '').trim();
      const localTrip = ((stateByUser.value?.[user]?.trips) || []).find((item) => String(item?.id || '') === String(trip?.id || ''));
      return localTrip ? { ...trip, ...localTrip } : trip;
    }

    function getTripDisplayTitle(trip) {
      const source = getCanonicalTrip(trip);
      return String(source?.title || '').trim() || `${String(source?.destination || '').trim() || '旅行'} ${calcTripDaysLabel(source) || ''}旅行计划`.trim();
    }

    function getTripOriginDisplay(trip) {
      const source = getCanonicalTrip(trip) || trip || {};
      const syncPayload = parseMaybeObject(
        source?.syncPayload ||
        source?.trip_sync_payload ||
        source?.tripSyncPayload ||
        source?.payload ||
        source?.metadata
      );
      const originValue =
        source?.origin ||
        source?.departure ||
        source?.departure_place ||
        source?.departurePlace ||
        source?.depart_from ||
        source?.departFrom ||
        source?.from_city ||
        source?.fromCity ||
        source?.from ||
        syncPayload?.origin ||
        syncPayload?.departure ||
        syncPayload?.departure_place ||
        syncPayload?.departFrom ||
        syncPayload?.from ||
        '';
      const clean = String(originValue || '').trim();
      return clean ? `出发地：${clean}` : '出发地待定';
    }

    function getTripDisplayDate(trip) {
      const source = getCanonicalTrip(trip);
      const exactDepart = String(source?.departDate || '').trim();
      const exactReturn = String(source?.returnDate || '').trim();
      const flexDepart = String(source?.departFlex || '').trim();
      const flexReturn = String(source?.returnFlex || '').trim();
      const durationText = String(source?.durationText || '').trim();
      const exact = [exactDepart, exactReturn].filter(Boolean).join(' ~ ');
      const approxTime = [flexDepart, flexReturn].filter(Boolean).join(' · ');
      if (exact) return exact;
      if (approxTime && durationText) return `${approxTime} · ${durationText}`;
      if (approxTime) return approxTime;
      if (durationText) return durationText;
      return '';
    }

    function getTripFlag(destination) {
      return resolveCountryMeta(destination)?.flag || '📍';
    }

    function getShareCardDateRows(trip) {
      const source = getCanonicalTrip(trip);
      const exactDepart = String(source?.departDate || '').trim();
      const exactReturn = String(source?.returnDate || '').trim();
      const flexDepart = String(source?.departFlex || '').trim();
      const flexReturn = String(source?.returnFlex || '').trim();
      const durationText = String(source?.durationText || '').trim();

      if (exactDepart && exactReturn) {
        return [
          { label: '出发日期', value: exactDepart },
          { label: '返程日期', value: exactReturn }
        ];
      }

      const approxTime = [flexDepart, flexReturn].filter(Boolean).join(' · ');
      const rows = [];
      if (approxTime) rows.push({ label: '大概出行时间', value: approxTime });
      if (durationText) rows.push({ label: '大概出行天数', value: durationText });

      if (!rows.length) {
        if (exactDepart) rows.push({ label: '出发日期', value: exactDepart });
        if (exactReturn) rows.push({ label: '返程日期', value: exactReturn });
      }

      return rows.slice(0, 2);
    }

    function getTripDetailRows(trip) {
      const source = getCanonicalTrip(trip);
      const rows = [];
      const exactDepart = String(source?.departDate || '').trim();
      const exactReturn = String(source?.returnDate || '').trim();
      const approxTime = [source?.departFlex, source?.returnFlex].filter(Boolean).join(' · ');
      const durationText = String(source?.durationText || '').trim();
      if (exactDepart) rows.push({ label: '出发日期', value: exactDepart });
      if (exactReturn) rows.push({ label: '返程日期', value: exactReturn });
      if (!exactDepart && !exactReturn && approxTime) rows.push({ label: '大概出行时间', value: approxTime });
      if (durationText) rows.push({ label: '出行时长', value: durationText });
      if (source?.origin) rows.push({ label: '出发地', value: source.origin });
      if (source?.budget) rows.push({ label: '预算', value: `¥${source.budget}` });
      if (Array.isArray(source?.tags) && source.tags.length) rows.push({ label: '行程标签', value: source.tags.join(' / ') });
      if (Array.isArray(source?.spots) && source.spots.length) rows.push({ label: '想去景点', value: source.spots.join('、') });
      return rows;
    }

    function getTripCommentCount(trip) {
      return Array.isArray(trip?.comments) ? trip.comments.length : 0;
    }

    function getTripCardTone(index = 0) {
      const tones = [
        'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)',
        'linear-gradient(135deg, #fee2e2 0%, #fecdd3 100%)',
        'linear-gradient(135deg, #ffedd5 0%, #fdba74 100%)',
        'linear-gradient(135deg, #fce7f3 0%, #fbcfe8 100%)',
        'linear-gradient(135deg, #fae8ff 0%, #e9d5ff 100%)',
        'linear-gradient(135deg, #fed7aa 0%, #fdba74 100%)'
      ];
      return tones[index % tones.length];
    }

    function getTripOwnerProfile(trip) {
      const user = String(trip?.user || '').trim();
      const state = stateByUser.value[user] || {};
      const profile = state.profile || {};
      return {
        avatar: trip?.avatar || profile.avatar || defaultAvatar,
        nickname: user || '旅行者',
        bio: String(profile.bio || '').trim(),
        birthday: profile.birthday || '',
        age: calcAgeFromBirthday(profile.birthday || ''),
        gender: profile.gender || '',
        pace: profile.pace || trip?.pace || '',
        budgetLevel: profile.budgetLevel || '',
        wakeUp: profile.wakeUp || trip?.wakeUp || ''
      };
    }

    async function ensureHtml2Canvas() {
      if (window.html2canvas) return window.html2canvas;
      await new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js';
        script.onload = resolve;
        script.onerror = reject;
        document.head.appendChild(script);
      });
      return window.html2canvas;
    }

    function normalizeShareCardBackgroundAsset(item, fallback) {
      if (!item || typeof item !== 'object') {
        return { public_url: fallback, photographer_name: '', source_platform: '', source_page_url: '', credit_line: '' };
      }
      const meta = parseMaybeObject(item.metadata);
      const user = parseMaybeObject(item.user);
      const metaUser = parseMaybeObject(meta.user);

      const publicUrl =
        item.public_url ||
        item.image_url ||
        item.file_url ||
        item.url ||
        item.publicUrl ||
        meta.public_url ||
        meta.image_url ||
        meta.file_url ||
        meta.url ||
        fallback;

      let photographerName =
        item.photographer_name ||
        item.photographer ||
        item.author_name ||
        item.author_display_name ||
        item.author ||
        item.creator_name ||
        item.creator ||
        item.credit_name ||
        item.user_name ||
        item.source_author ||
        item.sourceAuthor ||
        meta.photographer_name ||
        meta.photographer ||
        meta.author_name ||
        meta.author_display_name ||
        meta.author ||
        meta.creator_name ||
        meta.credit_name ||
        meta.source_author ||
        meta.sourceAuthor ||
        user.name ||
        user.full_name ||
        user.fullName ||
        user.username ||
        metaUser.name ||
        metaUser.full_name ||
        metaUser.fullName ||
        metaUser.username ||
        '';

      let sourcePlatform =
        item.source_platform ||
        item.platform ||
        item.source ||
        item.provider ||
        item.site_name ||
        meta.source_platform ||
        meta.platform ||
        meta.source ||
        meta.provider ||
        '';

      const sourcePageUrl =
        item.source_page_url ||
        item.source_url ||
        item.page_url ||
        item.original_url ||
        item.link ||
        item.ref_url ||
        meta.source_page_url ||
        meta.source_url ||
        meta.page_url ||
        meta.original_url ||
        '';

      const creditText = String(
        item.credit_line ||
        item.credit ||
        item.attribution ||
        meta.credit_line ||
        meta.credit ||
        meta.attribution ||
        ''
      ).trim();

      if (!photographerName && creditText) {
        const byMatch = creditText.match(/photo by\s+(.+?)\s+on\s+(.+)/i);
        if (byMatch) {
          photographerName = String(byMatch[1] || '').trim() || photographerName;
          sourcePlatform = String(byMatch[2] || '').trim() || sourcePlatform;
        }
      }

      const urlText = `${publicUrl} ${sourcePageUrl}`.toLowerCase();
      if (!sourcePlatform) {
        if (urlText.includes('unsplash')) sourcePlatform = 'Unsplash';
        else if (urlText.includes('pexels')) sourcePlatform = 'Pexels';
        else if (urlText.includes('pixabay')) sourcePlatform = 'Pixabay';
        else if (urlText.includes('freepik')) sourcePlatform = 'Freepik';
      }

      const knownByUrl = {
        'tony-lee': 'Tony Lee',
        'abdelrahman-ismail': 'Abdelrahman Ismail',
        'wouter-groote-veldman': 'Wouter Groote Veldman'
      };
      if (!photographerName) {
        const lowerUrl = `${publicUrl} ${sourcePageUrl}`.toLowerCase();
        for (const key in knownByUrl) {
          if (lowerUrl.includes(key)) {
            photographerName = knownByUrl[key];
            break;
          }
        }
      }

      let creditLine = '';
      if (photographerName && sourcePlatform) creditLine = `Photo by ${photographerName} on ${sourcePlatform}`;
      else if (photographerName) creditLine = `Photo by ${photographerName}`;
      else if (sourcePlatform) creditLine = `Image source: ${sourcePlatform}`;
      else if (creditText) creditLine = creditText;

      return {
        public_url: publicUrl,
        photographer_name: photographerName,
        source_platform: sourcePlatform,
        source_page_url: sourcePageUrl,
        credit_line: creditLine
      };
    }

    function getShareCardBackgroundStyle(url) {
      const safeUrl = String(url || '').replace(/"/g, '%22');
      return {
        backgroundImage: `linear-gradient(180deg, rgba(7,31,46,.14), rgba(7,31,46,.26)), url("${safeUrl}")`,
        backgroundSize: 'cover',
        backgroundPosition: 'center center',
        backgroundRepeat: 'no-repeat',
        backgroundColor: '#7f8c8d'
      };
    }

    async function fetchShareCardBackground(trip) {
      const client = window.RJSupabase;
      const fallback = "https://images.unsplash.com/photo-1488085061387-422e29b40080?auto=format&fit=crop&w=1600&q=80";
      const cfg = client?.normalizeConfig?.();
      if (!cfg?.url || !cfg?.anonKey) return normalizeShareCardBackgroundAsset(null, fallback);

      const source = getCanonicalTrip(trip) || trip || {};
      const destination = String(source?.destination || '').trim();
      const origin = String(source?.origin || '').trim();
      const tags = getTripTagsArray(source).map(x => String(x || '').trim().toLowerCase());

      const meta = resolveCountryMeta(destination);
      const aliases = [
        destination,
        origin,
        meta?.countryName,
        meta?.countryCode,
        ...(Array.isArray(meta?.aliases) ? meta.aliases : [])
      ].filter(Boolean).map(x => String(x).trim().toLowerCase());

      const params = new URLSearchParams();
      params.set('select', '*');
      params.set('is_active', 'eq.true');
      params.set('order', 'priority.asc,created_at.desc');

      const url = `${cfg.url}/rest/v1/background_assets?${params.toString()}`;
      try {
        const res = await fetch(url, {
          headers: {
            apikey: cfg.anonKey,
            Authorization: `Bearer ${cfg.anonKey}`,
            Accept: 'application/json'
          }
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const rows = await res.json();
        if (!Array.isArray(rows) || !rows.length) return normalizeShareCardBackgroundAsset(null, fallback);

        const scored = rows.map((item) => {
          const itemMeta = parseMaybeObject(item.metadata);
          const textPool = [
            item.country_code,
            item.country_name,
            item.title,
            item.name,
            item.description,
            item.public_url,
            item.source_page_url,
            item.source_url,
            ...(Array.isArray(item.tags) ? item.tags : []),
            ...(Array.isArray(itemMeta.tags) ? itemMeta.tags : []),
            itemMeta.country_code,
            itemMeta.country_name,
            itemMeta.title,
            itemMeta.description
          ].filter(Boolean).join(' | ').toLowerCase();

          let score = 0;
          aliases.forEach(term => { if (term && textPool.includes(term)) score += 12; });
          tags.forEach(tag => { if (tag && textPool.includes(tag)) score += 2; });

          if (meta?.countryCode && String(item.country_code || itemMeta.country_code || '').toUpperCase() === String(meta.countryCode).toUpperCase()) {
            score += 18;
          }
          return { ...item, __score: score };
        }).sort((a, b) => (b.__score - a.__score) || ((a.priority || 99) - (b.priority || 99)));

        return normalizeShareCardBackgroundAsset(scored[0], fallback);
      } catch (err) {
        console.warn('[share-card] fetch background failed', err?.message || err);
        return normalizeShareCardBackgroundAsset(null, fallback);
      }
    }

    function buildShareCardData(trip, bgAsset) {
      const source = getCanonicalTrip(trip);
      const profile = getTripOwnerProfile(source);
      const bg = normalizeShareCardBackgroundAsset(bgAsset, "https://images.unsplash.com/photo-1488085061387-422e29b40080?auto=format&fit=crop&w=1600&q=80");
      const lowerBgUrl = `${String(bg.public_url || '')} ${String(bg.source_page_url || '')}`.toLowerCase();
      const inferredPlatform =
        bg.source_platform ||
        (lowerBgUrl.includes('unsplash') ? 'Unsplash' :
         lowerBgUrl.includes('pexels') ? 'Pexels' :
         lowerBgUrl.includes('pixabay') ? 'Pixabay' :
         lowerBgUrl.includes('freepik') ? 'Freepik' : '');

      const fallbackCredit =
        (bg.photographer_name && inferredPlatform) ? `Photo by ${bg.photographer_name} on ${inferredPlatform}` :
        (bg.photographer_name ? `Photo by ${bg.photographer_name}` :
        (inferredPlatform ? `Image source: ${inferredPlatform}` : ''));

      return {
        logo: 'assets/gemi-brand.png',
        title: getTripDisplayTitle(source),
        destination: source?.destination || '',
        origin: source?.origin || '',
        budget: source?.budget || '',
        dateRows: getShareCardDateRows(source),
        tags: getTripTagsArray(source),
        spots: getTripSpotsArray(source),
        profile,
        backgroundUrl: bg.public_url,
        photographerName: bg.photographer_name || '',
        sourcePlatform: inferredPlatform,
        sourcePageUrl: bg.source_page_url || '',
        creditLine: bg.credit_line || fallbackCredit,
        footerTitle: '更多旅行计划，见歌觅 Go With Me',
        footerUrl: 'https://romanticjourney.cn'
      };
    }

    async function openShareCard(trip) {
      if (!trip) return;
      app.shareCard.loading = true;
      app.shareCard.error = '';
      app.shareCard.show = true;
      try {
        const bg = await fetchShareCardBackground(trip);
        app.shareCard.data = buildShareCardData(trip, bg);
      } catch (err) {
        app.shareCard.error = `生成分享卡片失败：${err?.message || err}`;
      } finally {
        app.shareCard.loading = false;
      }
    }

    function closeShareCard() {
      app.shareCard.show = false;
      app.shareCard.loading = false;
      app.shareCard.downloading = false;
      app.shareCard.error = '';
    }

    async function downloadShareCard() {
      const el = document.getElementById('shareCardExport') || document.getElementById('shareCardCapture');
      if (!el) return;
      app.shareCard.downloading = true;
      try {
        const html2canvas = await ensureHtml2Canvas();
        const rect = el.getBoundingClientRect();
        const canvas = await html2canvas(el, {
          backgroundColor: null,
          scale: Math.max(5, window.devicePixelRatio || 1),
          width: Math.round(rect.width),
          height: Math.round(rect.height),
          useCORS: true,
          allowTaint: false,
          imageTimeout: 20000,
          logging: false
        });
        const link = document.createElement('a');
        const safeName = String(app.shareCard.data?.destination || 'trip').replace(/[\\/:*?"<>|]/g, '_');
        link.download = `${safeName}-share-card.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
      } catch (err) {
        app.shareCard.error = `下载失败：${err?.message || err}`;
      } finally {
        app.shareCard.downloading = false;
      }
    }


    return {
      app,
      fmt,
      t,
      setLang,
      shortName,
      goto,
      login,
      register,
      logout,
      openWorldMap,
      applyWorldDimensionMode,
      submitWorldSearch,
      toggleWorldCard,
      toggleWorldFullscreen,
      openWorldTripDrawer,
      closeWorldTripDrawer,
      openWorldTripDetail,
      selectWorldDestination,
      worldDestinations,
      selectedWorldDestination,
      worldMapRef,
      worldGlobeRef,
      worldFullRef,
      worldPointStyle,
      deleteAccount,
      normalizeDiaryCaption,
      toggleProfilePanel,
      closeProfilePanel,
      onAvatarChange,
      saveProfile,
      supportLike,
      submitFeedback,
      postTrip,
      generateTripByAI,
      postDiary,
      toggleRelation,
      isFollowing,
      likeTrip,
      addComment,
      toggleCommentLike,
      commentLikers,
      commentLikeOverflow,
      isCommentLikedByMe,
      commentIndentStyle,
      commentDisplayText,
      isTripReplyTarget,
      isDiaryReplyTarget,
      tripCommentRows,
      diaryCommentRows,
      toggleCommentThreadExpand,
      startReplyTripComment,
      cancelReplyTripComment,
      sortedTripComments,
      diaryLikers,
      diaryLikeOverflow,
      diaryGroupImages,
      diaryGroupItems,
      diaryGroupPrimary,
      diaryGroupLength,
      closeCenterNotice,
      resolveCenterConfirm,
      billCurrencyOptions: BILL_CURRENCY_OPTIONS,
      getBillSettlementFieldLabel,
      isBillParticipantEditable,
      onBillExpenseTypeChange,
      onBillPaidByChange,
      onBillAmountOriginalChange,
      onBillCurrencyChange,
      onBillExpenseTimeChange,
      onBillEstimatedAmountInput,
      billParticipantHint,
      onBillReceiptFileChange,
      removeBillReceiptAt,
      clearBillReceiptImage,
      billReceiptMaxFiles: BILL_RECEIPT_MAX_FILES,
      billReceiptMaxFileSizeMB: Math.round(BILL_RECEIPT_MAX_FILE_SIZE / 1024 / 1024),
      openShareCard,
      closeShareCard,
      downloadShareCard,
      isDiaryLikedByMe,
      toggleDiaryLike,
      addDiaryComment,
      toggleDiaryCommentLike,
      deleteDiaryComment,
      startReplyDiaryComment,
      cancelReplyDiaryComment,
      renderDiaryCommentText,
      sortedDiaryComments,
      startEditTrip,
      saveTripEdit,
      cancelTripEdit,
      deleteTrip,
      canDeleteBill,
      deleteBill,
      startEditDiary,
      addDiaryImages,
      removeDiaryImage,
      deleteDiary,
      openPreviewGallery,
      previewPrev,
      previewNext,
      saveDiaryEdit,
      cancelDiaryEdit,
      openAccount,
      openTrip,
      openDiary,
      openChat,
      openBill,
      openCreateBillDialog,
      canCreateBillForTrip,
      canViewTripBillSection,
      closeCreateBillDialog,
      toggleBillCreateMember,
      submitCreateBill,
      openBillInviteDialog,
      closeBillInviteDialog,
      inviteUserToBill,
      openBillChat,
      openBillItemDialog,
      closeBillItemDialog,
      toggleBillItemParticipant,
      submitBillItem,
      changeBillItemStatus,
      onChatInputEnter,
      sendChat,
      stateByUser,
      filteredUsers,
      filteredTrips,
      filteredDiaries,
      homeTrips,
      homeTripsPaged,
      homeTripTotalPages,
      hasSearchKeyword,
      getUserAvatar,
      avatarThumb,
      diaryThumb,
      formatTripItineraryHtml,
      getTripDisplayTitle,
      getTripDisplayDate,
      getTripOriginDisplay,
      getTripOriginDisplay,
      getTripDetailRows,
      getTripFlag,
      getShareCardDateRows,
      getTripCommentCount,
      getShareCardBackgroundStyle,
      getShareCardBackgroundStyle,
      getShareCardBackgroundStyle,
      normalizeShareCardBackgroundAsset,
      getTripCardTone,
      tripLikers,
      tripLikeOverflow,
      isTripLikedByMe,
      accountData,
      tripData,
      tripBills,
      activeTripBill,
      billData,
      billMemberNames,
      billSettlement,
      billLoadingByTrip: app.billLoadingByTrip,
      billPendingCount,
      billDisputedCount,
      billDynamicFeed,
      billDynamicFeedPaged,
      billEventTotalPages,
      linkedBillForCurrentChat,
      billEventText,
      billStatusLabel,
      diaryData,
      currentChat,
      isAdmin,
      adminStats,
      myBadges,
      cityAchievements,
      unlockedCityAchievements,
      lockedCityAchievements,
      achievementProgressPercent,
      achievementProgressStyle,
      achievementLevelStats,
      featuredAchievement,
      achievementRecentList,
      achievementSelectedItem,
      cityAchievementSummaries,
      orderedCityAchievements,
      loadAchievementCenter,
      gotoAchievementCity,
      backFromAchievementCity,
      openAchievementOverview,
      selectAchievementCity,
      closeAchievementOverview,
      openAchievementDetail,
      openAchievementDetailFromCode,
      closeAchievementDetail,
      getAchievementLevelIconSvg,
      getAchievementLevelIcon,
      formatAchievementTime,
      getAchievementHint,
      getAchievementTagLabel,
      getAchievementRouteTypeLabel,
      guideCities,
      selectedGuideCity,
      selectedGuide,
      selectedGuideHub,
      gotoGuides,
      gotoCityGuideHub,
      goBackFromCityGuideHub,
      gotoGuideDetail,
      goBackFromGuide,
      userBadges,
      followingCount,
      followerCount,
      myAccountData,
      myFollowingCount,
      myFollowerCount,
      openFollowList,
      closeFollowList,
      goAccountFromList,
      isSelfAccount,
      isFollowingAccount,
      mutualFollowUsers,
      accountDiaryGroups,
      accountDiaryCount,
      currentChatSendRule,
      billTripDisplayTitle,
      openBillFromList,
      myBillsPaged,
      myBillsTotalPages,
      toggleGroupMember,
      createGroupChat,
      isMutualFollow,
      openGroupMembers,
      openGroupInviteDialog,
      closeGroupInviteDialog,
      inviteMemberToGroup,
      canQuickFollow,
      quickFollowFromDialog,
      removeChat,
      dissolveCurrentGroup,
      leaveCurrentGroup,
      chatOwnerName,
      isChatOwner,
      markSystemMessagesAsRead,
      openSystemTab,
      isSystemMessageUnread,
      chatPreviews,
      systemMessages,
      unreadChatCount,
      unreadSystemCount,
      unreadTotal,
      unreadBadgeCount,
      myDiaryGroups,
      diaryGroupCountForUser,
      feedbackPaged,
      feedbackTotalPages,
      heroCarousel,
      activeHero,
      setHero,
      currentChatMeta,
      isCurrentGroup,
      chatTitle,
      chatHistoryRef,
      markAllAsRead,
      MAX_DIARY_UPLOAD_COUNT,
      MAX_DIARY_TOTAL_MB,
      onDiaryFilesChange,
      draftDiaryMB,
      editDiaryMB,
      isAdmin
    };
  },
  template: `
  <div :class="['app-shell', 'route-' + app.route]">
    <header class="top" v-if="app.route!=='register'">
      <div class="top-inner">
        <div class="brand"><img src="assets/gemi-brand.png" alt="歌觅 Go With Me" style="height:76px;width:auto;display:block;object-fit:contain" /></div>
        <nav class="nav nav-iconbar">
          <button :class="{active:app.route==='home'}" @click="goto('home')" :title="t('navHome')" :aria-label="t('navHome')" data-tip="首页"><span class="nav-ico">⌂</span></button>
          <button :class="{active:app.route==='publish'}" @click="goto('publish')" :title="t('navPublish')" :aria-label="t('navPublish')" data-tip="发布行程"><span class="nav-ico">＋</span></button>
          <button :class="{active:app.route==='my'}" @click="goto('my')" :title="t('navMy')" :aria-label="t('navMy')" data-tip="我的主页"><span class="nav-ico">◦</span></button>
          <button :class="{active:app.route==='messages'}" @click="goto('messages')" :title="t('navMsg')" :aria-label="t('navMsg')" data-tip="消息"><span class="nav-ico">✉</span><span v-if="unreadBadgeCount" class="msg-badge">{{unreadBadgeCount}}</span></button>
          <button :class="{active:app.route==='my-bills'}" @click="goto('my-bills')" title="我的账单" aria-label="我的账单" data-tip="我的账单"><span class="nav-ico">¤</span></button>
          <button :class="{active:app.route==='search'}" @click="goto('search')" :title="t('navSearch')" :aria-label="t('navSearch')" data-tip="查询"><span class="nav-ico">⌕</span></button>
          <button :class="{active:app.route==='guides' || app.route==='guide-detail' || app.route==='city-guide-hub'}" @click="gotoGuides" title="攻略" aria-label="攻略" data-tip="攻略"><span class="nav-ico">☰</span></button>
          <button :class="{active:app.route==='feedback'}" @click="goto('feedback')" title="支持与反馈" aria-label="支持与反馈" data-tip="支持与反馈"><span class="nav-ico">♡</span></button>
          <button :class="{active:app.route==='world'}" @click="openWorldMap" title="世界地图" aria-label="世界地图" data-tip="世界地图"><span class="nav-ico">🌍</span></button>
          <button v-if="isAdmin" :class="{active:app.route==='admin'}" @click="goto('admin')" :title="t('navAdmin')" :aria-label="t('navAdmin')" data-tip="后台"><span class="nav-ico">▦</span></button>
        </nav>
        <div class="row top-userbar" style="margin-left:auto">
          <select class="lang-switch" v-model="app.lang" @change="setLang" aria-label="language"><option value="zh-CN">中文</option><option value="ko">한국어</option><option value="ja">日本語</option><option value="en">English</option><option value="fr">Français</option></select>
          <button class="avatar-btn" @click="toggleProfilePanel" :aria-expanded="String(app.showProfilePanel)">
            <img class="avatar sm" :src="avatarThumb(app.profileAvatarPreview || app.state.profile?.avatar || '${defaultAvatar}', 96)" alt="avatar" />
          </button>
          <span class="chip top-name" :title="app.current || t('notLogin')">{{app.current || t('notLogin')}}</span>
          <button class="btn ghost" @click="logout">{{t('logout')}}</button>
        </div>
      </div>
    </header>

    <aside v-if="app.route!=='register' && app.showProfilePanel" class="profile-panel">
      <div class="profile-panel-card">
        <div class="row" style="justify-content:space-between"><h3 style="margin:0">{{t('profile')}}</h3><button class="btn ghost" @click="closeProfilePanel">{{t('close')}}</button></div>
        <form class="grid" @submit.prevent="saveProfile" style="margin-top:8px">
          <label class="full">头像
            <div class="row" style="align-items:center;gap:12px;flex-wrap:wrap">
              <img class="avatar lg" :src="avatarThumb(app.profileAvatarPreview || app.state.profile?.avatar || '${defaultAvatar}', 96)" alt="avatar preview" />
              <input type="file" accept="image/*" @change="onAvatarChange" />
            </div>
            <small class="hint" v-if="app.profileAvatarStatus">{{app.profileAvatarStatus}}</small>
          </label>
          <label class="full">个人简介 / 介绍
            <textarea v-model="app.profileForm.bio" rows="4" placeholder="介绍一下你自己、旅行偏好、想找什么样的搭子（可输入较长文本）"></textarea>
          </label>
          <label>生日（年月） <input v-model="app.profileForm.birthday" type="month" /></label>
          <label>{{t('gender')}}
            <select v-model="app.profileForm.gender">
              <option value="">请选择</option>
              <option value="男">{{t('male')}}</option>
              <option value="女">{{t('female')}}</option>
            </select>
          </label>
          <label>旅行节奏
            <select v-model="app.profileForm.pace"><option>特种兵式</option><option>平衡</option><option>慢游</option></select>
          </label>
          <label>预算偏好
            <select v-model="app.profileForm.budgetLevel"><option>经济</option><option>舒适</option><option>品质</option></select>
          </label>
          <label>作息
            <select v-model="app.profileForm.wakeUp"><option>早起</option><option>自然醒</option><option>夜猫</option></select>
          </label>

          <section class="full" style="margin-top:8px">
            <div class="row" style="justify-content:flex-end">
              <button class="btn ghost" type="button" @click="app.showAccountSecurityPanel = true">前往账号与安全</button>
            </div>
          </section>

          <button class="btn full">{{t('saveProfile')}}</button>
        </form>
      </div>
    </aside>

    <aside v-if="app.route!=='register' && app.showAccountSecurityPanel" class="profile-panel">
      <div class="profile-panel-card">
        <div class="row" style="justify-content:space-between">
          <h3 style="margin:0">账号与安全</h3>
          <button class="btn ghost" @click="app.showAccountSecurityPanel = false">关闭</button>
        </div>
        <div class="grid" style="margin-top:8px">
          <section class="full" style="padding:12px;border:1px solid rgba(255,255,255,.12);border-radius:16px;background:rgba(255,255,255,.03)">
            <p class="hint" style="margin:0 0 8px 0">你可以在 App / 网页端直接发起删除账号。删除后会清空个人资料、行程、日记、关注关系、聊天等数据；依法必须保留的记录可能会按合规要求保留一段时间。</p>
            <label class="full">删除原因（选填）
              <textarea v-model="app.accountDeleteForm.reason" rows="3" placeholder="例如：暂时不用了 / 想重新注册 / 隐私原因"></textarea>
            </label>
            <label class="full">请输入“删除账号”确认
              <input v-model="app.accountDeleteForm.confirmText" type="text" placeholder="删除账号" />
            </label>
            <small class="hint" v-if="app.accountDeleteStatus">{{app.accountDeleteStatus}}</small>
            <div class="row" style="margin-top:8px;justify-content:flex-end;gap:8px">
              <button class="btn ghost" type="button" @click="app.showAccountSecurityPanel = false">返回资料</button>
              <button class="btn ghost" type="button" @click="deleteAccount" :disabled="app.deletingAccount">{{ app.deletingAccount ? '删除中…' : '删除账号' }}</button>
            </div>
          </section>
        </div>
      </div>
    </aside>

    <section v-if="app.route==='register'" class="auth auth-simple">
      <div class="card auth-panel" style="position:relative">
        <div class="auth-logo-wrap">
          <img class="auth-logo" src="assets/gemi-brand.png" alt="歌觅 Go With Me" />
        </div>
        <div style="position:absolute;top:18px;right:18px;z-index:3">
          <select class="lang-switch" v-model="app.lang" @change="setLang" aria-label="language"
            style="min-width:104px;height:38px;padding:0 12px;border-radius:12px;background:rgba(255,255,255,.96);border:1px solid rgba(148,163,184,.35);box-shadow:0 4px 12px rgba(15,23,42,.08)">
            <option value="zh-CN">中文</option>
            <option value="en">English</option>
            <option value="ja">日本語</option>
            <option value="ko">한국어</option>
            <option value="fr">Français</option>
            <option value="es">Español</option>
            <option value="de">Deutsch</option>
            <option value="it">Italiano</option>
          </select>
        </div>
        <DotTextMorph class="auth-carousel-title" :text="activeHero.text" kind="hero" />
        <p class="hint">{{t('loginHint')}}</p>
        <div class="grid">
          <input v-model="app.auth.nickname" :placeholder="t('nickname')" />
          <input v-model="app.auth.password" type="password" :placeholder="t('password')" />
          <p class="hint" v-if="app.authError" style="color:#b91c1c;margin:0">{{app.authError}}</p>
          <button class="btn full" @click="login">{{t('loginBtn')}}</button>
        </div>
      </div>
    </section>

    <main v-else class="wrap" :class="{'route-feedback': app.route==='feedback'}">
      <template v-if="app.route==='home'">
        <section class="card full">
          <div class="row" style="justify-content:space-between;gap:10px;flex-wrap:wrap">
            <h3 style="margin:0">{{t('tripSquare')}}</h3>
            <div class="row trip-square-toolbar" style="gap:8px;flex-wrap:nowrap">
              <input v-model="app.tripSquareSearch" :placeholder="t('searchAll')" class="trip-square-search" />
              <select v-model="app.tripSquareSort" class="trip-square-sort-select" aria-label="行程排序">
                <option value="comprehensive">综合排序</option>
                <option value="newest">最新</option>
                <option value="hottest">最热</option>
              </select>
            </div>
          </div>
          <p class="hint" v-if="app.publicTripsLoading">正在从数据库加载行程...</p>
          <p class="hint" v-else-if="app.publicTripsError">{{app.publicTripsError}} <button class="btn ghost" @click="loadPublicTrips">重试</button></p>
          <p class="hint" v-else-if="!homeTrips.length">暂无行程</p>
          <div v-else class="trip-card-grid">
            <article class="trip-feed-card" v-for="(trip, idx) in homeTripsPaged" :key="trip.id" @click="openTrip(trip.id)">
              <div class="trip-feed-cover" :style="{ background: getTripCardTone(idx) }">
                <div class="trip-feed-cover-meta">
                  <span class="trip-feed-place">{{getTripOriginDisplay(trip)}}</span>
                  <span class="trip-feed-date">{{fmt(trip.createdAt)}}</span>
                </div>
                <h4 class="trip-feed-title">{{getTripDisplayTitle(trip)}}</h4>
                <p class="trip-feed-time" v-if="getTripDisplayDate(trip)">{{getTripDisplayDate(trip)}}</p>
              </div>
              <div class="trip-feed-body">
                <div class="trip-feed-user">
                  <img class="avatar avatar-clickable" :src="avatarThumb(trip.avatar || '${defaultAvatar}', 72)" alt="avatar" @click.stop="openAccount(trip.user)" />
                  <button class="user-link" type="button" @click.stop="openAccount(trip.user)">{{trip.user}}</button>
                </div>
                <p class="trip-feed-summary">{{(trip.tags||[]).slice(0, 4).join(' / ') || '点击查看完整行程详情'}}</p>
                <div class="trip-feed-stats">
                  <span>{{getTripFlag(trip.destination)}} {{trip.destination || '待定'}}</span>
                  <span>👍 {{trip.likeCount || 0}}</span>
                  <span>💬 {{getTripCommentCount(trip)}}</span>
                </div>
              </div>
            </article>
          </div>
          <div class="row" style="justify-content:space-between;align-items:center;margin-top:12px">
            <small class="meta">第 {{app.tripPage}} / {{homeTripTotalPages}} 页（共 {{homeTrips.length}} 条行程）</small>
            <div class="row">
              <button class="btn ghost" :disabled="app.tripPage<=1" @click="app.tripPage=Math.max(1, app.tripPage-1)">上一页</button>
              <button class="btn ghost" :disabled="app.tripPage>=homeTripTotalPages" @click="app.tripPage=Math.min(homeTripTotalPages, app.tripPage+1)">下一页</button>
            </div>
          </div>
        </section>

      </template>


      <template v-else-if="app.route==='world'">
        <section class="card full" style="padding:18px;min-height:76vh;background:linear-gradient(180deg, rgba(7,18,30,.92), rgba(8,16,28,.98));color:#f4f7fb;border:1px solid rgba(255,255,255,.08);overflow:hidden">
          <div class="gemi-world-full" ref="worldFullRef">
            <div class="gemi-world-topbar">
              <div class="chip" style="background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.08);color:#dce7f7">世界地图 Beta</div>
              <div class="gemi-world-searchbar">
                <select v-model="app.worldContinent" aria-label="大洲筛选">
                  <option value="global">全部大洲</option>
                  <option value="asia">亚洲</option>
                  <option value="europe">欧洲</option>
                  <option value="north-america">北美洲</option>
                  <option value="south-america">南美洲</option>
                  <option value="africa">非洲</option>
                  <option value="oceania">大洋洲</option>
                </select>
                <input v-model="app.worldKeyword" @keydown.enter.prevent="submitWorldSearch" type="text" placeholder="搜索国家 / 城市 / 勋章" />
                <button class="btn ghost" type="button" @click="submitWorldSearch">{{ app.worldGeocodeLoading ? '定位中…' : '搜索定位' }}</button>
                <div class="gemi-world-toggle">
                  <button type="button" :class="{ active: app.worldDimension==='2d' }" @click="applyWorldDimensionMode('2d')">2D</button>
                  <button type="button" :class="{ active: app.worldDimension==='3d' }" @click="applyWorldDimensionMode('3d')">3D</button>
                  <button type="button" :class="{ active: app.worldIsFullscreen }" @click="toggleWorldFullscreen" title="全屏">⛶</button>
                </div>
              </div>
            </div>

            <div class="gemi-map-wrap gemi-map-wrap--maplibre">
              <div ref="worldMapRef" class="gemi-map-canvas"></div>
              <div ref="worldGlobeRef" class="gemi-globe-canvas" :class="{ 'is-active': app.worldDimension==='3d' }"></div>
              <div class="gemi-map-overlay"></div>
              <div class="gemi-map-frame"></div>

              <div v-if="app.worldMapLoading" style="position:absolute;left:18px;top:18px;padding:10px 14px;border-radius:16px;background:rgba(9,18,31,.82);border:1px solid rgba(255,255,255,.08);font-size:13px;color:rgba(255,255,255,.8);backdrop-filter:blur(10px);z-index:5">
                正在加载地图…
              </div>
              <div v-if="app.worldMapError" style="position:absolute;left:18px;top:18px;z-index:6;padding:12px 14px;border-radius:16px;background:rgba(255,99,132,.14);border:1px solid rgba(255,133,158,.2);color:#ffd3dc">
                {{app.worldMapError}}
              </div>

              <div class="gemi-world-floating-card" :class="{ 'is-collapsed': app.worldCardCollapsed }" v-if="selectedWorldDestination" style="left:auto;right:18px;top:84px;">
                <div class="row" style="justify-content:space-between;align-items:flex-start;gap:12px">
                  <div class="chip" :style="{ background:selectedWorldDestination.tone, border:'none', color:'#09111f' }">{{selectedWorldDestination.country}} · {{selectedWorldDestination.city}}</div>
                  <button class="btn ghost" type="button" @click="toggleWorldCard">{{ app.worldCardCollapsed ? '展开' : '缩小' }}</button>
                </div>
                <template v-if="!app.worldCardCollapsed">
                  <h3>{{selectedWorldDestination.name}}</h3>
                  <p>{{selectedWorldDestination.summary}}</p>
                  <div class="gemi-world-badges">
                    <span v-for="badge in selectedWorldDestination.badges" :key="badge">{{badge}}</span>
                  </div>
                  <div class="gemi-world-stats">
                    <button type="button" class="btn ghost" style="height:auto;padding:0;border:none;background:transparent;text-align:left;color:#fff" @click="openWorldTripDrawer('visited')">
                      <div style="font-size:12px;color:#fff">已经去过</div>
                      <strong style="color:#fff">{{selectedWorldDestination.visitedCount || 0}}</strong>
                    </button>
                    <button type="button" class="btn ghost" style="height:auto;padding:0;border:none;background:transparent;text-align:left;color:#fff" @click="openWorldTripDrawer('planned')">
                      <div style="font-size:12px;color:#fff">未来计划去</div>
                      <strong style="color:#fff">{{selectedWorldDestination.plannedCount || 0}}</strong>
                    </button>
                  </div>
                  <div style="font-size:13px;color:rgba(255,255,255,.7)">
                    数据来源：用户发布的行程，按出发日期与今天比较自动区分“去过 / 计划去”。
                  </div>
                </template>
              </div>

              <aside v-if="app.worldTripDrawer.show" style="position:absolute;left:18px;top:84px;z-index:6;width:min(420px, calc(100vw - 96px));max-height:70vh;overflow:auto;padding:16px;border-radius:24px;background:rgba(14,24,39,.86);backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.1);box-shadow:0 18px 38px rgba(0,0,0,.26)">
                <div class="row" style="justify-content:space-between;align-items:center;margin-bottom:8px">
                  <strong>{{app.worldTripDrawer.title}}</strong>
                  <button class="btn ghost" type="button" @click="closeWorldTripDrawer">关闭</button>
                </div>
                <p class="hint" v-if="!app.worldTripDrawer.rows.length">暂无对应行程</p>
                <article class="trip trip-clickable" v-for="trip in app.worldTripDrawer.rows" :key="trip.id" @click="openWorldTripDetail(trip)" style="margin-bottom:10px;background:#fff;border-radius:18px;padding:14px;color:#0f172a">
                  <div><strong style="color:#0f172a">{{getTripDisplayTitle(trip)}}</strong></div>
                  <div class="meta" style="margin-top:4px">{{getTripDisplayDate(trip)}}</div>
                  <div class="row" style="margin-top:8px;align-items:center;gap:8px">
                    <img class="avatar sm" :src="avatarThumb(getUserAvatar(trip.user),72)" alt="avatar" />
                    <span>{{trip.user}} · {{trip.destination}} · 预算 ¥{{trip.budget || 0}}</span>
                  </div>
                  <p class="hint" style="margin-top:8px">{{(trip.tags || []).join(' / ')}}</p>
                </article>
              </aside>

              <div class="gemi-map-hint">
                当前：{{ app.worldDimension==='3d' ? '3D 球体' : '2D 平面' }} · 仅点击 2D / 3D 按钮切换
              </div>
            </div>
          </div>
        </section>
      </template>

      <template v-else-if="app.route==='feedback'">
        <section class="card full feedback-page-card">
          <div class="feedback-page-hero scenic">
            <div>
              <p class="feedback-page-kicker">Support</p>
              <h3>支持与反馈</h3>
              <p class="hint">喜欢歌觅的话可以点个支持，也欢迎留下你的功能建议和使用反馈。</p>
            </div>
          </div>
          <div class="feedback-stats-card">
            <p class="hint">累计收到点赞支持</p>
            <div class="feedback-stat-number">{{app.supportCount}}</div>
            <button class="btn" @click="supportLike">👍 点赞支持</button>
          </div>
          <form class="grid" @submit.prevent="submitFeedback" style="margin-top:16px">
            <label class="full">反馈内容
              <textarea v-model="app.feedback.content" maxlength="100" placeholder="写下你的意见（100字以内）" required></textarea>
            </label>
            <label class="full">联系邮箱
              <input type="email" v-model="app.feedback.email" placeholder="联系邮箱" required />
            </label>
            <button class="btn full">提交反馈</button>
          </form>
        </section>
      </template>

      <template v-else-if="app.route==='publish'">
        <section class="card full publish-page-card">
          <div class="publish-page-hero">
            <div>
              <p class="publish-page-kicker">Trip Post</p>
              <h3>{{t('publishTrip')}}</h3>
              <p class="hint">支持明确日期，也支持只填写月份和大概出行时长。</p>
            </div>
          </div>
          <form class="grid" @submit.prevent="postTrip">
            <label class="full">行程标题
              <input v-model="app.tripForm.title" placeholder="例如：土耳其热气球日出摄影搭子招募" required />
            </label>
            <label>{{t('destination')}}
              <input v-model="app.tripForm.destination" placeholder="例如：首尔 / 土耳其 / 巴黎" required />
            </label>
            <label>出发地
              <input v-model="app.tripForm.origin" placeholder="例如：上海 / 北京 / 广州" />
            </label>
            <label>{{t('budgetYuan')}}
              <input v-model="app.tripForm.budget" type="number" placeholder="例如：5000" required />
            </label>
            <label>{{t('departDate')}}
              <input v-model="app.tripForm.departDate" type="date" />
            </label>
            <label>出行月份 / 时间段
              <input v-model="app.tripForm.departFlex" placeholder="例如：6月 / 6月上旬 / 五一前后" />
            </label>
            <label>{{t('returnDate')}}
              <input v-model="app.tripForm.returnDate" type="date" />
            </label>
            <label>大概返程时间
              <input v-model="app.tripForm.returnFlex" placeholder="例如：6月中旬 / 端午后" />
            </label>
            <label class="full">大概出行天数
              <input v-model="app.tripForm.durationText" placeholder="例如：10天 / 7天左右 / 周末2-3天" />
            </label>
            <label class="full">{{t('tripTags')}}
              <input v-model="app.tripForm.tags" placeholder="如：citywalk,美食,摄影" required />
            </label>
            <label class="full">{{t('spotsWant')}}
              <input v-model="app.tripForm.spots" placeholder="如：首尔塔,明洞" required />
            </label>
            <label class="full">{{t('itinerary')}}
              <textarea v-model="app.tripForm.itinerary" placeholder="例如：D1 上午明洞，D2 弘大 citywalk" required></textarea>
            </label>
            <div class="row" style="align-items:flex-end">
              <button class="btn ghost" type="button" :disabled="app.ai.generating" @click="generateTripByAI">{{app.ai.generating ? t('aiGenerating') : t('aiGenerate')}}</button>
            </div>
            <p class="hint full" v-if="app.ai.generating">{{t('aiWaiting')}}</p>
            <p class="hint full" v-if="app.ai.error" style="color:#b91c1c">{{app.ai.error}}</p>
            <button class="btn full" :disabled="app.ai.generating">{{t('publish')}}</button>
          </form>
        </section>

      </template>

      <template v-else-if="app.route==='my'">
        <section class="card full">
          <h3>发布打卡日记（九宫格）</h3>
          <form class="grid" @submit.prevent="postDiary">
            <input v-model="app.mediaForm.location" placeholder="地点" required />
            <input v-model="app.mediaForm.checkin" placeholder="打卡文本（可选）" />
            <input class="full" v-model="app.mediaForm.caption" placeholder="标题" required />
            <input class="full" id="diaryFiles" type="file" accept="image/*" multiple required @change="onDiaryFilesChange" />
            <p class="hint full">最多上传 {{MAX_DIARY_UPLOAD_COUNT}} 张，合计不超过 {{MAX_DIARY_TOTAL_MB}}MB（超出将无法保存）。</p>
            <p class="hint full">当前已选 {{app.diaryDraftFiles.length}} 张，约 {{draftDiaryMB}}MB / {{MAX_DIARY_TOTAL_MB}}MB。</p>
            <section class="diary-grid diary-grid-nine full" v-if="app.diaryDraftPreviews.length">
              <button type="button" class="thumb-tile" v-for="(img, idx) in app.diaryDraftPreviews.slice(0, 9)" :key="img.previewUrl" @click="openPreviewGallery(app.diaryDraftPreviews.map(x=>x.previewUrl), idx)">
                <img :src="img.previewUrl" loading="eager" decoding="async" />
                <span v-if="idx===8 && app.diaryDraftPreviews.length>9" class="thumb-more">+{{app.diaryDraftPreviews.length-9}}</span>
              </button>
            </section>
            <button class="btn full">发布日记</button>
          </form>
        </section>
        <section class="card full" v-if="myAccountData">
          <div class="my-profile-shell">
            <div class="my-profile-main row">
              <img class="avatar lg" :src="avatarThumb(myAccountData.profile?.avatar || '${defaultAvatar}', 128)" alt="avatar" />
              <div>
                <h2 style="margin:.1rem 0">{{myAccountData.user}}{{t('accountHome')}}</h2>
                <p class="hint">行程 {{(myAccountData.trips||[]).length}} 条 ｜ 日记 {{myDiaryGroups.length}} 条</p>
                <p class="hint">已关注 <button class="inline-link" @click="openFollowList('following', myAccountData.user)">{{myFollowingCount}}</button> ｜ 粉丝 <button class="inline-link" @click="openFollowList('followers', myAccountData.user)">{{myFollowerCount}}</button></p>
              </div>
            </div>
            <div class="my-profile-trophy-dock" aria-label="我的奖杯统计">
              <button type="button" class="my-profile-trophy-chip" :class="'is-' + item.key" v-for="item in achievementLevelStats" :key="item.key">
                <span class="my-profile-trophy-chip__icon" v-html="getAchievementLevelIconSvg(item.key)"></span>
                <strong>{{item.unlocked}}</strong>
              </button>
            </div>
          </div>
        </section>
        <section class="card full my-achievement-hub">
          <div class="my-achievement-head">
            <div>
              <p class="my-achievement-kicker">城市成就</p>
              <h3>城市奖杯</h3>
            </div>
          </div>
          <div v-if="app.achievementCenter.loading" class="achievement-empty">城市成就加载中...</div>
          <div v-else-if="app.achievementCenter.error" class="achievement-empty achievement-empty-error">{{app.achievementCenter.error}}</div>
          <div v-else class="achievement-summary-shell achievement-summary-shell--cities">
            <div class="achievement-city-switcher achievement-city-switcher--cards" v-if="cityAchievementSummaries.length">
              <button
                type="button"
                class="achievement-city-chip achievement-city-chip--page"
                v-for="summary in cityAchievementSummaries"
                :key="summary.cityCode"
                @click="gotoAchievementCity(summary.cityCode)"
              >
                <span class="achievement-city-chip__name">{{summary.cityName}}</span>
                <span class="achievement-city-chip__meta">{{summary.unlocked}} / {{summary.total}}</span>
                <span class="achievement-city-chip__icons">
                  <span class="achievement-city-chip__icon" v-html="getAchievementLevelIconSvg('platinum')"></span><em>{{summary.counts?.platinum?.unlocked || 0}}</em>
                  <span class="achievement-city-chip__icon" v-html="getAchievementLevelIconSvg('gold')"></span><em>{{summary.counts?.gold?.unlocked || 0}}</em>
                  <span class="achievement-city-chip__icon" v-html="getAchievementLevelIconSvg('silver')"></span><em>{{summary.counts?.silver?.unlocked || 0}}</em>
                  <span class="achievement-city-chip__icon" v-html="getAchievementLevelIconSvg('bronze')"></span><em>{{summary.counts?.bronze?.unlocked || 0}}</em>
                </span>
                <span class="achievement-city-chip__enter">查看该城市奖杯详情</span>
              </button>
            </div>
            <div v-else class="achievement-empty">还没有城市奖杯数据。</div>
          </div>
        </section>
        </section>
        <section class="card full">
          <h3>{{t('myTrips')}}</h3>
          <p class="hint" v-if="!(app.state.trips||[]).length">{{t('noTripYet')}}</p>
          <article class="trip" v-for="tripItem in (app.state.trips||[])" :key="tripItem.id">
            <div class="row" style="justify-content:space-between"><strong>{{tripItem.destination}}</strong><span class="meta">{{tripItem.departDate}} - {{tripItem.returnDate}}</span></div>
            <p class="hint">预算 ¥{{tripItem.budget}} ｜ 标签 {{(tripItem.tags||[]).join(' / ')}}</p>
            <div v-html="formatTripItineraryHtml(tripItem.itinerary, true)"></div>
            <div class="row" style="margin-top:6px">
              <button class="btn ghost" @click="openTrip(tripItem.id)">{{t('viewDetail')}}</button>
              <button class="btn ghost" @click="startEditTrip(tripItem)">编辑</button>
              <button class="btn ghost" @click="deleteTrip(tripItem)">删除</button>
            </div>
          </article>
        </section>
        <section class="card">
          <h3>{{t('myDiaries')}}</h3>
          <p class="hint" v-if="app.publicDiariesLoading && !app.publicDiariesLoaded">正在从数据库加载日记...</p>
          <div class="account-diary-list" v-else-if="myDiaryGroups.length">
            <article class="trip account-diary-card" v-for="group in myDiaryGroups" :key="diaryGroupPrimary(group)?.batchId || diaryGroupPrimary(group)?.id">
              <div class="row" style="justify-content:space-between"><strong>{{normalizeDiaryCaption(diaryGroupPrimary(group)?.caption)}}</strong><span class="meta">{{diaryGroupPrimary(group)?.location}} · {{fmt(diaryGroupPrimary(group)?.createdAt)}}</span></div>
              <section class="my-diary-thumb-grid" v-if="diaryGroupLength(group)">
                <button type="button" class="thumb-tile" v-for="(imgItem, idx) in diaryGroupItems(group).slice(0, 9)" :key="imgItem.id" @click="openPreviewGallery(diaryGroupImages(group), idx)">
                  <img :src="diaryThumb(imgItem.cover, 720)" loading="lazy" decoding="async" />
                  <span v-if="idx===8 && diaryGroupLength(group)>9" class="thumb-more">+{{diaryGroupLength(group)-9}}</span>
                </button>
              </section>
              <div class="row" style="margin-top:6px">
                <button class="btn ghost" @click="openDiary(diaryGroupPrimary(group)?.id, '', diaryGroupPrimary(group))">{{t('viewDetail')}}</button>
                <button class="btn ghost" @click="startEditDiary(diaryGroupPrimary(group))">编辑</button>
                <button class="btn ghost" @click="deleteDiary(diaryGroupPrimary(group))">删除</button>
              </div>
            </article>
          </div>
          <p class="hint" v-else>{{t('noDiary')}}</p>
        </section>
        <section class="card my-badge-side">
          <h3>{{t('myBadges')}}</h3>
          <div class="row"><span class="chip" v-for="(badge, i) in myBadges" :key="i">{{badge}}</span></div>
        </section>
      </template>



      <template v-else-if="app.route==='search'">
        <section class="card full">
          <h3>{{t('globalSearch')}}</h3>
          <input v-model="app.userSearch" :placeholder="t('searchPlaceholder')" />
          <template v-if="hasSearchKeyword">
            <h4>{{t('account')}}</h4>
            <div class="search-user-list">
              <article class="trip trip-clickable search-user-item" v-for="u in filteredUsers" :key="u.nickname" @click="openAccount(u.nickname, 'search')">
                <img class="avatar" :src="avatarThumb(u.avatar, 72)" :alt="u.nickname" />
                <div>
                  <strong>{{u.nickname}}</strong>
                  <p class="hint">勋章：{{u.badges.join(' ｜ ')}}</p>
                  <p class="hint">行程 {{u.tripCount}} 条 ｜ 日记 {{u.diaryCount}} 条</p>
                </div>
              </article>
            </div>
            <h4>{{t('trip')}}</h4>
            <article class="trip trip-clickable" v-for="t in filteredTrips.slice(0,8)" :key="t.id" @click="openTrip(t.id, 'search')"><strong>{{t.user}} · {{t.destination}}</strong></article>
            <h4>{{t('diary')}}</h4>
            <article class="trip trip-clickable" v-for="d in filteredDiaries.slice(0,8)" :key="d.id" @click="openDiary(d.id, 'search', d)"><strong>{{d.caption}}</strong><p class="hint">{{d.user}} · {{d.imageCount}} 张图</p></article>
          </template>
          <p v-else class="hint">请输入关键词后再查询结果。</p>
        </section>
      </template>




      <template v-else-if="app.route==='guides'">
        <section class="card full guides-shell">
          <div class="guides-head">
            <div>
              <p class="my-achievement-kicker">城市攻略</p>
              <h2>攻略集</h2>
              <p class="hint">按城市查看奖杯攻略、白金路线和新手入门路线。</p>
            </div>
          </div>
          <div class="guide-city-list">
            <article class="guide-city-block" v-for="city in guideCities" :key="city.cityCode">
              <div class="guide-city-block__head">
                <div>
                  <h3>{{city.cityName}}</h3>
                  <p>{{city.guides.length}} 篇攻略</p>
                </div>
                <button class="btn ghost" @click="gotoCityGuideHub(city.cityCode)">查看该城市攻略</button>
              </div>
              <div class="guide-card-list">
                <button type="button" class="guide-entry-card" v-for="guide in city.guides" :key="guide.id" @click="gotoGuideDetail(guide.id, city.cityCode)">
                  <div class="guide-entry-card__cover"><img :src="guide.cover" :alt="guide.title"></div>
                  <div class="guide-entry-card__body">
                    <div class="guide-entry-card__meta">
                      <span>{{guide.updatedAt}}</span>
                      <span>{{guide.author}}</span>
                    </div>
                    <h4>{{guide.title}}</h4>
                    <p>{{guide.summary}}</p>
                    <div class="guide-entry-card__tags">
                      <span v-for="tag in guide.tags" :key="tag">{{tag}}</span>
                    </div>
                  </div>
                </button>
              </div>
            </article>
          </div>
        </section>
      </template>


      <template v-else-if="app.route==='city-guide-hub'">
        <section class="card full city-guide-hub-shell" v-if="selectedGuideHub">
          <div class="city-guide-hub-hero">
            <div class="city-guide-hub-hero__copy">
              <p class="guide-kicker">城市攻略主题页</p>
              <h2>{{selectedGuideHub.cityName}} 城市攻略</h2>
              <p>{{selectedGuideHub.subtitle}}</p>
              <div class="city-guide-hub-meta">
                <span>{{selectedGuideHub.guides.length}} 篇攻略</span>
                <span>推荐游玩 {{selectedGuideHub.days}}</span>
              </div>
              <div class="city-guide-hub-actions">
                <button class="btn ghost" @click="goBackFromCityGuideHub">← 返回攻略集</button>
                <button class="btn ghost" v-for="item in selectedGuideHub.heroButtons" :key="item.label" @click="gotoGuideDetail(item.guideId, selectedGuideHub.cityCode)">{{item.label}}</button>
              </div>
            </div>
          </div>

          <div class="city-guide-topic-list">
            <section class="city-guide-topic" v-for="section in selectedGuideHub.sectionEntries" :key="section.key">
              <div class="city-guide-topic__head">
                <div>
                  <h3>{{section.title}}</h3>
                  <p>{{section.subtitle}}</p>
                </div>
              </div>
              <div class="city-guide-topic__tabs" v-if="section.guides && section.guides.length">
                <button type="button" class="city-guide-topic__tab" v-for="guide in section.guides" :key="guide.id + '-tab'" @click="gotoGuideDetail(guide.id, selectedGuideHub.cityCode)">
                  <span>{{guide.shortTitle || guide.title.replace(/^《[^》]+》\s*/, '').replace(/攻略[:：]?\s*/, '')}}</span>
                </button>
              </div>
              <div class="city-guide-topic__item-grid">
                <button type="button" class="city-guide-topic__item" v-for="guide in section.guides" :key="guide.id" @click="gotoGuideDetail(guide.id, selectedGuideHub.cityCode)">
                  <div class="city-guide-topic__item-cover"><img :src="guide.cover" :alt="guide.title"></div>
                  <div class="city-guide-topic__item-title">{{guide.shortTitle || guide.title.replace(/^《[^》]+》\s*/, '').replace(/攻略[:：]?\s*/, '')}}</div>
                </button>
              </div>
            </section>
          </template>

      <template v-else-if="app.route==='guide-detail'">
        <section class="card full guide-detail-shell" v-if="selectedGuide && selectedGuideCity">
          <div class="guide-detail-hero">
            <img class="guide-detail-hero__bg" :src="selectedGuide.cover" :alt="selectedGuide.title">
            <button class="btn ghost guide-back-btn" @click="goBackFromGuide">← 返回攻略集</button>
            <div class="guide-detail-hero__body">
              <p class="guide-kicker">{{selectedGuideCity.cityName}} · 官方攻略</p>
              <h2>{{selectedGuide.title}}</h2>
              <p>{{selectedGuide.summary}}</p>
              <div class="guide-detail-hero__meta">
                <span>{{selectedGuide.updatedAt}}</span>
                <span>{{selectedGuide.author}}</span>
              </div>
            </div>
          </div>
          <article class="guide-article">
            <div class="guide-tags"><span v-for="tag in selectedGuide.tags" :key="tag">{{tag}}</span></div>
            <template v-for="(block, idx) in selectedGuide.content" :key="idx">
              <p v-if="block.type==='lead'" class="guide-lead">{{block.text}}</p>
              <h3 v-else-if="block.type==='section'" class="guide-section">{{block.title}}</h3>
              <p v-else-if="block.type==='paragraph'" class="guide-paragraph">{{block.text}}</p>
              <ul v-else-if="block.type==='list'" class="guide-list">
                <li v-for="(item, liIdx) in block.items" :key="liIdx">{{item}}</li>
              </ul>
            </template>
          </article>
        </section>
      </template>

      <template v-else-if="app.route==='achievement-city'">
        <section class="card full achievement-city-page">
          <div class="achievement-city-page__head">
            <div>
              <p class="my-achievement-kicker">城市奖杯</p>
              <h2>{{app.achievementCenter.cityName}} 奖杯详情</h2>
            </div>
            <button class="btn ghost" @click="backFromAchievementCity">返回我的主页</button>
          </div>
          <div v-if="app.achievementCenter.loading" class="achievement-empty">城市奖杯加载中...</div>
          <div v-else-if="app.achievementCenter.error" class="achievement-empty achievement-empty-error">{{app.achievementCenter.error}}</div>
          <div v-else class="achievement-city-page__body">
            <div class="achievement-summary-top">
              <div class="achievement-progress-card">
                <div class="achievement-progress-ring" :style="achievementProgressStyle">
                  <div class="achievement-progress-ring__inner">
                    <strong>{{achievementProgressPercent}}%</strong>
                    <span>完成度</span>
                  </div>
                </div>
                <div class="achievement-progress-copy">
                  <div class="achievement-progress-copy__value">{{unlockedCityAchievements.length}} / {{cityAchievements.length}}</div>
                  <p>已解锁 {{app.achievementCenter.cityName}} 奖杯，继续探索就能更接近白金。</p>
                  <p class="hint" v-if="app.achievementCenter.platinumRule?.description">{{app.achievementCenter.platinumRule.description}}</p>
                </div>
              </div>
              <div class="achievement-level-grid">
                <article class="achievement-level-tile" v-for="item in achievementLevelStats" :key="item.key">
                  <span class="achievement-level-tile__icon" v-html="getAchievementLevelIconSvg(item.key)"></span>
                  <strong>{{item.unlocked}}</strong>
                  <small>{{item.label}}</small>
                  <em>{{item.total}} 可获得</em>
                </article>
              </div>
            </div>
            <div class="achievement-card-grid achievement-card-grid--dialog achievement-card-grid--city-page">
              <button type="button" class="achievement-card" :class="{'is-unlocked': item.isUnlocked, 'is-locked': !item.isUnlocked}" v-for="item in orderedCityAchievements" :key="item.achievement_code" @click="openAchievementDetail(item)">
                <div class="achievement-card__top">
                  <span class="achievement-card__icon" v-html="getAchievementLevelIconSvg(item.level)"></span>
                  <span class="achievement-level-pill" :class="'level-' + item.level">{{item.level_name}}</span>
                </div>
                <strong>{{item.title}}</strong>
                <p>{{getAchievementHint(item)}}</p>
                <div class="achievement-card__bottom">
                  <span>{{getAchievementTagLabel(item)}}</span>
                  <span>{{item.isUnlocked ? formatAchievementTime(item.unlockedAt) : '未获得'}}</span>
                </div>
              </button>
            </div>
          </div>
        </section>
      </template>

      <template v-else-if="app.route==='account'">
        <section class="card full" v-if="accountData">
          <div class="row">
            <img class="avatar lg" :src="avatarThumb(accountData.profile?.avatar || '${defaultAvatar}', 128)" alt="avatar" />
            <div>
              <h2 style="margin:.1rem 0">{{accountData.user}}{{t('accountHome')}}</h2>
              <p class="hint">行程 {{(accountData.trips||[]).length}} 条 ｜ 日记 {{accountDiaryCount}} 条</p>
              <p class="hint">已关注 <button class="inline-link" @click="openFollowList('following', accountData.user)">{{followingCount}}</button> ｜ 粉丝 <button class="inline-link" @click="openFollowList('followers', accountData.user)">{{followerCount}}</button></p>
              <div class="row" v-if="!isSelfAccount" style="margin-top:6px">
                <button class="btn ghost" @click="toggleRelation('follow', accountData.user)">{{isFollowingAccount ? '取消关注' : '关注'}}</button>
                <button class="btn ghost" @click="openChat(accountData.user)">聊天</button>
              </div>
            </div>
          </div>
          <div class="grid" style="margin-top:8px">
            <div class="card">
              <h4>{{t('profileInfo')}}</h4>
              <p class="hint">生日 {{accountData.profile?.birthday||'-'}} ｜ MBTI {{accountData.profile?.mbti||'-'}}</p>
              <p class="hint">星座 {{accountData.profile?.zodiac||'-'}} ｜ 节奏 {{accountData.profile?.pace||'-'}}</p>
              <p class="hint">预算 {{accountData.profile?.budgetLevel||'-'}} ｜ 作息 {{accountData.profile?.wakeUp||'-'}}</p>
              <p class="hint">社交 {{accountData.profile?.social||'-'}}</p>
              <p class="hint">简介 {{accountData.profile?.bio||'-'}}</p>
              <p class="hint">技能 {{Array.isArray(accountData.profile?.skills)?accountData.profile.skills.join('、'):accountData.profile?.skills}}</p>
              <p class="hint">勋章 {{userBadges(accountData.user).join(' ｜ ')}}</p>
            </div>
            <div class="card"><h4>{{t('recentTrips')}}</h4><div class="trip" v-for="t in (accountData.trips||[])" :key="t.id" @click="openTrip(t.id)" style="cursor:pointer">{{t.destination}} · {{t.departDate}}-{{t.returnDate}}</div></div>
          </div>
          <section class="card" style="margin-top:10px">
            <h4>{{t('taDiary')}}</h4>
            <p class="hint" v-if="app.publicDiariesLoading && !app.publicDiariesLoaded">正在从数据库加载日记...</p>
            <p class="hint" v-else-if="!accountDiaryGroups.length">{{t('noDiary')}}</p>
            <div class="account-diary-list" v-if="accountDiaryGroups.length">
              <article class="trip account-diary-card" v-for="group in accountDiaryGroups" :key="diaryGroupPrimary(group)?.batchId || diaryGroupPrimary(group)?.id">
                <div class="row" style="justify-content:space-between"><strong>{{normalizeDiaryCaption(diaryGroupPrimary(group)?.caption)}}</strong><span class="meta">{{diaryGroupPrimary(group)?.location}} · {{fmt(diaryGroupPrimary(group)?.createdAt)}}</span></div>
                <section class="my-diary-thumb-grid" v-if="diaryGroupLength(group)">
                  <button type="button" class="thumb-tile" v-for="(imgItem, idx) in diaryGroupItems(group).slice(0, 9)" :key="imgItem.id" @click.stop="openPreviewGallery(diaryGroupImages(group), idx)">
                    <img :src="diaryThumb(imgItem.cover, 720)" loading="lazy" decoding="async" />
                    <span v-if="idx===8 && diaryGroupLength(group)>9" class="thumb-more">+{{diaryGroupLength(group)-9}}</span>
                  </button>
                </section>
                <div class="row" style="margin-top:6px">
                  <button class="btn ghost" @click="openDiary(diaryGroupPrimary(group)?.id, '', diaryGroupPrimary(group))">{{t('viewDetail')}}</button>
                </div>
              </article>
            </div>
          </section>
          <button v-if="app.fromSearch.account" class="btn ghost" @click="goto('search')">{{t('backSearch')}}</button>
        </section>
      </template>

      <template v-else-if="app.route==='trip'">
        <section class="card full" v-if="tripData">
          <template v-if="app.tripEditMode && tripData.user===app.current">
            <h2>编辑行程</h2>
            <form class="grid" @submit.prevent="saveTripEdit">
              <label class="full">行程标题<input v-model="app.tripEditForm.title" required /></label>
              <label>{{t('destination')}}<input v-model="app.tripEditForm.destination" required /></label>
              <label>出发地<input v-model="app.tripEditForm.origin" placeholder="如：上海 / 北京" /></label>
              <label>{{t('budgetYuan')}}<input v-model="app.tripEditForm.budget" type="number" required /></label>
              <label>{{t('departDate')}}<input v-model="app.tripEditForm.departDate" type="date" /></label>
              <label>大概出发时间<input v-model="app.tripEditForm.departFlex" placeholder="如：6月上旬" /></label>
              <label>{{t('returnDate')}}<input v-model="app.tripEditForm.returnDate" type="date" /></label>
              <label>大概返程时间<input v-model="app.tripEditForm.returnFlex" placeholder="如：端午后" /></label>
              <label class="full">预计出行时长<input v-model="app.tripEditForm.durationText" placeholder="如：10天左右" /></label>
              <label class="full">{{t('tripTags')}}<input v-model="app.tripEditForm.tags" /></label>
              <label class="full">{{t('spotsWant')}}<input v-model="app.tripEditForm.spots" /></label>
              <label>节奏<select v-model="app.tripEditForm.pace"><option>特种兵式</option><option>平衡</option><option>慢游</option></select></label>
              <label>作息<select v-model="app.tripEditForm.wakeUp"><option>早起</option><option>自然醒</option><option>夜猫</option></select></label>
              <label>社交<select v-model="app.tripEditForm.social"><option>外向</option><option>适中</option><option>安静</option></select></label>
              <label class="full">{{t('itinerary')}}<textarea v-model="app.tripEditForm.itinerary" required></textarea></label>
              <div class="row full">
                <button class="btn" type="submit">保存修改</button>
                <button class="btn ghost" type="button" @click="cancelTripEdit">取消</button>
                <button class="btn ghost" type="button" @click="deleteTrip(tripData)">删除行程</button>
              </div>
            </form>
          </template>
          <template v-else>
          <h2>{{getTripDisplayTitle(tripData)}}</h2>
          <div class="row" style="gap:8px;margin:.25rem 0 .15rem">
            <img class="avatar avatar-clickable" :src="tripData.avatar || getUserAvatar(tripData.user) || '${defaultAvatar}'" :alt="tripData.user" @click="openAccount(tripData.user)" />
            <button class="user-link" type="button" @click="openAccount(tripData.user)">{{tripData.user}}</button>
          </div>
          <p class="hint">发布者：{{tripData.user}} ｜ {{fmt(tripData.createdAt)}} ｜ 地点 {{tripData.destination}} ｜ 点赞 {{tripData.likeCount||0}}</p>
          <div class="trip-detail-meta-grid" v-if="getTripDetailRows(tripData).length">
            <div class="trip-detail-meta-item" v-for="(row, idx) in getTripDetailRows(tripData)" :key="'detail-meta-'+idx">
              <div class="trip-detail-meta-label">{{row.label}}</div>
              <div class="trip-detail-meta-value">{{row.value}}</div>
            </div>
          </div>
          <div v-html="formatTripItineraryHtml(tripData.itinerary, false)"></div>
          <div class="row trip-detail-actions">
            <button class="btn" :class="{liked:isTripLikedByMe(tripData)}" @click="likeTrip(tripData)">👍 {{tripData.likeCount||0}}</button>
            <button class="btn sec" @click="openShareCard(tripData)">生成分享卡片</button>
            <button v-if="activeTripBill || canCreateBillForTrip(tripData)" class="btn ghost" @click="activeTripBill ? openBill(activeTripBill.id) : openCreateBillDialog(tripData)">{{activeTripBill ? '查看账单' : '发起账单'}}</button>
            <button v-if="activeTripBill?.linkedChatId" class="btn ghost" @click="openBillChat(activeTripBill)">账单群聊</button>
            <button v-if="tripData.user===app.current" class="btn ghost" @click="startEditTrip(tripData)">编辑</button>
          </div>
          <section class="trip-bill-entry" v-if="canViewTripBillSection">
            <div class="trip-bill-entry__head">
              <div>
                <p class="my-achievement-kicker">行程账单</p>
                <h4>{{ activeTripBill ? activeTripBill.title : '还没有协作账单' }}</h4>
              </div>
              <div class="row" style="gap:8px">
                <button v-if="activeTripBill || canCreateBillForTrip(tripData)" class="btn ghost" @click="activeTripBill ? openBill(activeTripBill.id) : openCreateBillDialog(tripData)">{{activeTripBill ? '进入账单' : '发起账单'}}</button>
              </div>
            </div>
            <p class="hint" v-if="billLoadingByTrip && billLoadingByTrip[tripData.id]">账单加载中...</p>
            <template v-else-if="activeTripBill">
              <div class="trip-bill-entry__meta">
                <span class="chip">{{activeTripBill.members.length}} 人协作</span>
                <span class="chip">{{billPendingCount}} 笔待确认</span>
                <span class="chip" v-if="billDisputedCount">{{billDisputedCount}} 笔有争议</span>
              </div>
              <div class="trip-bill-members-preview" v-if="activeTripBill.members && activeTripBill.members.length">
                <article class="bill-member-card is-compact" v-for="member in activeTripBill.members.slice(0, 6)" :key="activeTripBill.id + '-preview-' + member.nickname" :title="member.nickname">
                  <img v-if="getUserAvatar(member.nickname)" class="avatar sm" :src="avatarThumb(getUserAvatar(member.nickname), 72)" :alt="member.nickname" />
                  <div v-else class="bill-member-card__fallback">{{ String(member.nickname || '?').slice(0, 1).toUpperCase() }}</div>
                  <div class="bill-member-card__meta">
                    <strong>{{member.nickname}}</strong>
                    <span class="bill-member-card__role">{{member.role==='owner' ? '发起人' : '成员'}}</span>
                  </div>
                </article>
              </div>
              <p class="hint">账单用于透明记录多人出行费用，方便协商和结算，不强制立即付款。</p>
            </template>
            <p class="hint" v-else>可以从这个行程直接发起一份协作账单，邀请互相关注的人加入，并一键拉账单沟通群。</p>
          </section>
          <div class="trip-likers" v-if="tripLikers(tripData).length">
            <img v-for="name in tripLikers(tripData)" :key="tripData.id + '-' + name" class="avatar sm" :src="avatarThumb(getUserAvatar(name), 72)" :title="name" :alt="name" />
            <span class="hint" v-if="tripLikeOverflow(tripData)">+{{tripLikeOverflow(tripData)}}</span>
          </div>
          <section class="trip-comments-block">
            <div class="row" style="justify-content:space-between;align-items:center">
              <h4 style="margin:.4rem 0">评论</h4>
              <select v-model="app.tripCommentSort" class="comment-sort-select">
                <option value="newest">最新</option>
                <option value="hottest">最热</option>
              </select>
            </div>

            <div class="row" v-if="!app.tripReplyTarget" style="margin:.35rem 0 .6rem">
              <input class="trip-comment-input" v-model="app.commentDraft[tripData.id]" placeholder="写评论，按发送发布" style="flex:1" />
              <button class="btn" @click="addComment(tripData)">发送</button>
            </div>

            <p class="hint" v-if="!tripCommentRows(tripData).some(r => r.kind==='comment')">暂无评论</p>

            <template v-for="row in tripCommentRows(tripData)" :key="row.key">
              <article v-if="row.kind==='comment'" class="trip" :style="commentIndentStyle(row.depth)">
                <div class="row" style="justify-content:space-between">
                  <div class="row">
                    <img class="avatar sm" :src="avatarThumb(getUserAvatar(row.node.user), 64)" :alt="row.node.user" />
                    <strong>{{row.node.user}}</strong>
                  </div>
                  <small class="meta">{{fmt(row.node.createdAt)}}</small>
                </div>

                <p style="margin:.35rem 0">{{commentDisplayText(row.node)}}</p>

                <div class="row">
                  <button class="btn ghost" :class="{liked:isCommentLikedByMe(row.node)}" @click="toggleCommentLike(tripData, row.node)">👍 {{row.node.likes?.length || 0}}</button>
                  <button class="btn ghost" @click="startReplyTripComment(row.node)">回复</button>
                </div>

                <div class="trip-likers" v-if="commentLikers(row.node).length">
                  <img
                    v-for="name in commentLikers(row.node)"
                    :key="(row.node.dbCommentId || row.node.id) + '-' + name"
                    class="avatar sm"
                    :src="avatarThumb(getUserAvatar(name), 72)"
                    :title="name"
                    :alt="name"
                  />
                  <span class="hint" v-if="commentLikeOverflow(row.node)">+{{commentLikeOverflow(row.node)}}</span>
                </div>

                <div v-if="isTripReplyTarget(row.node)" style="margin-top:.55rem;padding-top:.45rem;border-top:1px solid rgba(148,163,184,.18)">
                  <div class="row" style="justify-content:space-between;align-items:center;margin-bottom:.35rem">
                    <small class="hint">正在回复 @{{row.node.user}}</small>
                    <button class="btn ghost" @click="cancelReplyTripComment">取消回复</button>
                  </div>
                  <div class="row" style="margin:0">
                    <input
                      class="trip-comment-input"
                      :data-trip-reply-for="row.node.dbCommentId || row.node.id"
                      v-model="app.commentDraft[tripData.id]"
                      :placeholder="'回复 @' + row.node.user"
                      style="flex:1"
                    />
                    <button class="btn" @click="addComment(tripData)">发送</button>
                  </div>
                </div>
              </article>

              <div
                v-else
                class="hint"
                :style="[commentIndentStyle(row.depth), {display:'flex',alignItems:'center',gap:'.5rem',padding:'.25rem 0 .5rem'}]"
              >
                <button class="btn ghost" @click="toggleCommentThreadExpand(app.tripCommentExpanded, row.parentId)">
                  展开 {{row.hiddenCount}} 条更多回复
                </button>
              </div>
            </template>
          </section>
          <button v-if="app.fromSearch.trip" class="btn ghost" @click="goto('search')">{{t('backSearch')}}</button>
          </template>
        </section>
      </template>

      <template v-else-if="app.route==='diary'">
        <section class="card full" v-if="diaryData">          <template v-if="app.diaryEditMode && diaryData.user===app.current">
            <h2>编辑日记</h2>
            <form class="grid" @submit.prevent="saveDiaryEdit">
              <label class="full">标题<input v-model="app.diaryEditForm.caption" required /></label>
              <label>地点<input v-model="app.diaryEditForm.location" required /></label>
              <label>打卡文本<input v-model="app.diaryEditForm.checkin" /></label>
              <label class="full">追加图片<input type="file" accept="image/*" multiple @change="addDiaryImages" /></label>
              <p class="hint full">最多保留 {{MAX_DIARY_UPLOAD_COUNT}} 张，合计不超过 {{MAX_DIARY_TOTAL_MB}}MB。</p>
              <p class="hint full">当前共 {{app.diaryEditImages.length}} 张，约 {{editDiaryMB}}MB / {{MAX_DIARY_TOTAL_MB}}MB。</p>
              <div class="full">
                <p class="hint">已选择图片（可删除）</p>
                <section class="diary-grid diary-grid-nine">
                  <div v-for="(img,i) in app.diaryEditImages" :key="img + i" style="position:relative" class="thumb-tile">
                    <img :src="diaryThumb(img, 720)" loading="lazy" decoding="async" @click="openPreviewGallery(app.diaryEditImages, i)" />
                    <button type="button" class="btn ghost" style="position:absolute;top:4px;right:4px;padding:2px 6px;z-index:2" @click.stop="removeDiaryImage(i)">✕</button>
                  </div>
                </section>
              </div>
              <div class="row full">
                <button class="btn" type="submit">保存修改</button>
                <button class="btn ghost" type="button" @click="cancelDiaryEdit">取消</button>
                <button class="btn ghost" type="button" @click="deleteDiary(diaryData)">删除日记</button>
              </div>
            </form>
          </template>
          <template v-else>
          <h2>{{diaryData.caption}}</h2>
          <p class="hint">{{diaryData.user}} · {{diaryData.location}} · {{diaryData.checkin}}</p>
          <section class="diary-grid diary-grid-nine">
            <button type="button" class="thumb-tile" v-for="(img,i) in diaryData.images" :key="i" @click="openPreviewGallery(diaryData.images, i)">
              <img :src="diaryThumb(img, 900)" loading="lazy" decoding="async" />
            </button>
          </section>
          <div class="row" style="margin-top:8px">
            <button class="btn" :class="{liked:isDiaryLikedByMe(diaryData)}" @click="toggleDiaryLike(diaryData)">👍 {{diaryData.likes?.length || 0}}</button>
            <button v-if="diaryData.user===app.current" class="btn ghost" @click="startEditDiary(diaryData)">编辑</button>
          </div>
          <div class="trip-likers" v-if="diaryLikers(diaryData).length">
            <img v-for="name in diaryLikers(diaryData)" :key="diaryData.id + '-' + name" class="avatar sm" :src="avatarThumb(getUserAvatar(name), 72)" :title="name" :alt="name" />
            <span class="hint" v-if="diaryLikeOverflow(diaryData)">+{{diaryLikeOverflow(diaryData)}}</span>
          </div>
          <section class="trip-comments-block">
            <div class="row" style="justify-content:space-between;align-items:center">
              <h4 style="margin:.4rem 0">评论</h4>
              <select v-model="app.diaryCommentSort" class="comment-sort-select">
                <option value="newest">最新</option>
                <option value="hottest">最热</option>
              </select>
            </div>

            <div class="row" v-if="!app.diaryReplyTarget" style="margin:.35rem 0 .6rem">
              <input class="diary-comment-input" v-model="app.commentDraft[diaryData.id]" placeholder="写评论，按发送发布" style="flex:1" />
              <button class="btn" @click="addDiaryComment(diaryData)">发送</button>
            </div>

            <p class="hint" v-if="!diaryCommentRows(diaryData).some(r => r.kind==='comment')">暂无评论</p>

            <template v-for="row in diaryCommentRows(diaryData)" :key="row.key">
              <article v-if="row.kind==='comment'" class="trip" :style="commentIndentStyle(row.depth)">
                <div class="row" style="justify-content:space-between">
                  <div class="row">
                    <img class="avatar sm" :src="avatarThumb(getUserAvatar(row.node.user), 64)" :alt="row.node.user" />
                    <strong>{{row.node.user}}</strong>
                  </div>
                  <small class="meta">{{fmt(row.node.createdAt)}}</small>
                </div>

                <p style="margin:.35rem 0">{{commentDisplayText(row.node)}}</p>

                <div class="row">
                  <button class="btn ghost" :class="{liked:isCommentLikedByMe(row.node)}" @click="toggleDiaryCommentLike(diaryData, row.node)">👍 {{row.node.likes?.length || 0}}</button>
                  <button class="btn ghost" @click="startReplyDiaryComment(row.node)">回复</button>
                  <button v-if="row.node.user===app.current" class="btn ghost" @click="deleteDiaryComment(diaryData, row.node)">删除</button>
                </div>

                <div class="trip-likers" v-if="commentLikers(row.node).length">
                  <img
                    v-for="name in commentLikers(row.node)"
                    :key="(row.node.dbCommentId || row.node.id) + '-' + name"
                    class="avatar sm"
                    :src="avatarThumb(getUserAvatar(name), 72)"
                    :title="name"
                    :alt="name"
                  />
                  <span class="hint" v-if="commentLikeOverflow(row.node)">+{{commentLikeOverflow(row.node)}}</span>
                </div>

                <div v-if="isDiaryReplyTarget(row.node)" style="margin-top:.55rem;padding-top:.45rem;border-top:1px solid rgba(148,163,184,.18)">
                  <div class="row" style="justify-content:space-between;align-items:center;margin-bottom:.35rem">
                    <small class="hint">正在回复 @{{row.node.user}}</small>
                    <button class="btn ghost" @click="cancelReplyDiaryComment">取消回复</button>
                  </div>
                  <div class="row" style="margin:0">
                    <input
                      class="diary-comment-input"
                      :data-diary-reply-for="row.node.dbCommentId || row.node.id"
                      v-model="app.commentDraft[diaryData.id]"
                      :placeholder="'回复 @' + row.node.user"
                      style="flex:1"
                    />
                    <button class="btn" @click="addDiaryComment(diaryData)">发送</button>
                  </div>
                </div>
              </article>

              <div
                v-else
                class="hint"
                :style="[commentIndentStyle(row.depth), {display:'flex',alignItems:'center',gap:'.5rem',padding:'.25rem 0 .5rem'}]"
              >
                <button class="btn ghost" @click="toggleCommentThreadExpand(app.diaryCommentExpanded, row.parentId)">
                  展开 {{row.hiddenCount}} 条更多回复
                </button>
              </div>
            </template>
          </section>
          <button v-if="app.fromSearch.diary" class="btn ghost" @click="goto('search')" style="margin-top:8px">{{t('backSearch')}}</button>
          </template>
        </section>
        <section class="card full" v-else>
          <h3>日记详情</h3>
          <p class="hint">这篇日记当前没有数据库详情，可能仍是旧缓存数据。请返回列表页重新打开，或先清理浏览器 localStorage 后再试。</p>
          <div class="row" style="margin-top:8px">
            <button class="btn ghost" @click="loadPublicDiaries">重新加载日记</button>
            <button class="btn ghost" @click="goto(app.fromSearch.diary ? 'search' : 'my')">返回</button>
          </div>
        </section>
      </template>

      <template v-else-if="app.route==='chat'">
        <section class="card full chat-page">
          <div class="row" style="justify-content:space-between">
            <h2 style="margin:.2rem 0">{{chatTitle}}</h2>
            <div class="row" style="gap:8px;flex-wrap:nowrap">
              <button class="btn ghost" v-if="linkedBillForCurrentChat" @click="openBill(linkedBillForCurrentChat.id)" style="white-space:nowrap">账单</button>
              <button class="btn ghost" v-if="isCurrentGroup" @click="openGroupMembers(currentChatMeta)" style="white-space:nowrap">群成员</button>
              <button class="btn ghost" v-if="isCurrentGroup" @click="openGroupInviteDialog(currentChatMeta)" style="white-space:nowrap">+ 邀请成员</button>
              <button class="btn ghost" v-if="isCurrentGroup && isChatOwner(currentChatMeta)" @click="dissolveCurrentGroup" style="white-space:nowrap">解散群聊</button>
              <button class="btn ghost" v-if="isCurrentGroup && !isChatOwner(currentChatMeta)" @click="leaveCurrentGroup" style="white-space:nowrap">退出群聊</button>
            </div>
          </div>
          <div class="trip chat-history" ref="chatHistoryRef">
            <p v-if="!currentChat.messages.length" class="hint">还没有消息</p>
            <template v-for="m in currentChat.messages" :key="m.id">
              <div v-if="m.type==='system'" style="display:flex;justify-content:center;margin:12px 0;">
                <div style="padding:6px 14px;border-radius:999px;background:rgba(15,23,42,.06);color:#64748b;font-size:13px;line-height:1.4;text-align:center;max-width:80%;">
                  {{m.text}}
                </div>
              </div>
              <div v-else class="msg-row" :class="{me: m.from===app.current}">
                <div class="msg-bubble">
                  <div class="msg-head">
                    <img class="avatar sm avatar-clickable" :src="avatarThumb(getUserAvatar(m.from), 72)" alt="avatar" @click="openAccount(m.from)" />
                    <button class="user-link msg-user-link" type="button" @click="openAccount(m.from)">{{m.from}}</button>
                  </div>
                  <p style="margin:.2rem 0">{{m.text}}</p><small class="meta">{{fmt(m.createdAt)}}</small>
                </div>
              </div>
            </template>
          </div>
          <div class="row chat-input-row"><input v-model="app.chatDraft" @compositionstart="app.isChatComposing = true" @compositionend="app.isChatComposing = false" @keydown.enter.exact.prevent="onChatInputEnter" placeholder="输入消息，回车发送" style="flex:1" :disabled="!currentChatSendRule.ok"/><button class="btn" @click="sendChat" :disabled="!currentChatSendRule.ok">发送</button><button class="btn ghost" @click="goto('home')">返回首页</button></div><p v-if="!currentChatSendRule.ok" class="hint" style="margin-top:6px;color:#b91c1c">{{currentChatSendRule.message}}</p>
        </section>
      </template>


      <template v-else-if="app.route==='bill'">
        <section class="card full bill-page" v-if="billData">
          <div class="bill-page__head">
            <div>
              <p class="my-achievement-kicker">行程账单</p>
              <h2 style="margin:.2rem 0">{{billData.title}}</h2>
              <p class="hint">关联行程：{{tripData ? getTripDisplayTitle(tripData) : billData.tripId}} · {{billData.members.length}} 人参与</p>
            </div>
            <div class="row" style="gap:8px;flex-wrap:wrap;justify-content:flex-end">
              <button class="btn ghost" @click="openBillItemDialog(billData)">记一笔</button>
              <button class="btn ghost" @click="openBillInviteDialog(billData)">邀请成员</button>
              <button class="btn ghost" v-if="billData.linkedChatId" @click="openBillChat(billData)">去群聊</button>
              <button class="btn ghost" v-if="canDeleteBill(billData)" @click="deleteBill(billData)">删除账单</button>
              <button class="btn ghost" @click="goto('trip')">返回行程</button>
            </div>
          </div>

          <div class="bill-summary-grid">
            <article class="bill-summary-card">
              <span class="bill-summary-card__label">我的垫付</span>
              <strong>¥{{(billSettlement.rows.find(r => r.nickname===app.current)?.paid || 0).toFixed(2)}}</strong>
            </article>
            <article class="bill-summary-card">
              <span class="bill-summary-card__label">我的应承担</span>
              <strong>¥{{(billSettlement.rows.find(r => r.nickname===app.current)?.share || 0).toFixed(2)}}</strong>
            </article>
            <article class="bill-summary-card">
              <span class="bill-summary-card__label">我的净额</span>
              <strong>{{(billSettlement.rows.find(r => r.nickname===app.current)?.net || 0) >= 0 ? '应收' : '应付'}} ¥{{Math.abs(billSettlement.rows.find(r => r.nickname===app.current)?.net || 0).toFixed(2)}}</strong>
            </article>
            <article class="bill-summary-card">
              <span class="bill-summary-card__label">当前状态</span>
              <strong>{{billPendingCount ? (billPendingCount + ' 笔待确认') : '可快速结算'}}</strong>
              <small class="hint" v-if="billDisputedCount">另有 {{billDisputedCount}} 笔有争议</small>
            </article>
          </div>

          <section class="bill-member-row">
            <article class="bill-member-card" v-for="member in billData.members" :key="billData.id + '-' + member.nickname" :title="member.nickname">
              <img v-if="getUserAvatar(member.nickname)" class="avatar sm" :src="avatarThumb(getUserAvatar(member.nickname), 72)" :alt="member.nickname" />
              <div v-else class="bill-member-card__fallback">{{ String(member.nickname || '?').slice(0, 1).toUpperCase() }}</div>
              <div class="bill-member-card__meta">
                <strong>{{member.nickname}}</strong>
                <span class="bill-member-card__role">{{member.role==='owner' ? '发起人' : '成员'}}</span>
              </div>
            </article>
          </section>

          <section class="bill-page-grid">
            <div class="bill-main-column">
              <section class="bill-block">
                <div class="row" style="justify-content:space-between;align-items:center">
                  <h3 style="margin:0">账单动态</h3>
                  <small class="hint">任何人修改后，这里都会留下轨迹</small>
                </div>
                <p class="hint" v-if="!billDynamicFeed.length">还没有账单动态</p>
                <article class="bill-event-row" v-for="event in billDynamicFeedPaged" :key="event.id">
                  <div>
                    <strong>{{event.actor}}</strong>
                    <p>{{billEventText(event)}}</p>
                  </div>
                  <small class="meta">{{fmt(event.createdAt)}}</small>
                </article>
                <div class="row" v-if="billDynamicFeed.length > app.billEventsPageSize" style="justify-content:space-between;margin-top:12px">
                  <small class="meta">第 {{app.billEventsPage}} / {{billEventTotalPages}} 页（共 {{billDynamicFeed.length}} 条）</small>
                  <div class="row">
                    <button class="btn ghost" :disabled="app.billEventsPage<=1" @click="app.billEventsPage=Math.max(1, app.billEventsPage-1)">上一页</button>
                    <button class="btn ghost" :disabled="app.billEventsPage>=billEventTotalPages" @click="app.billEventsPage=Math.min(billEventTotalPages, app.billEventsPage+1)">下一页</button>
                  </div>
                </div>
              </section>

              <section class="bill-block">
                <div class="row" style="justify-content:space-between;align-items:center">
                  <h3 style="margin:0">费用明细</h3>
                  <button class="btn ghost" @click="openBillItemDialog(billData)">新增费用</button>
                </div>
                <p class="hint" v-if="!billData.items.length">还没有费用，先记第一笔吧。</p>
                <article class="bill-item-row" v-for="item in billData.items" :key="item.id">
                  <div class="bill-item-row__main">
                    <div class="row" style="justify-content:space-between;align-items:flex-start">
                      <div>
                        <strong>{{item.note || '未命名费用'}}</strong>
                        <p class="hint">{{item.paidBy}} 支付 · {{item.currencyOriginal}} {{Number(item.amountOriginal || 0).toFixed(2)}} · {{item.participants.map(p => p.nickname).join('、') || '待补充承担人'}}</p>
                      </div>
                      <span class="bill-status-pill" :class="'is-' + item.status">{{billStatusLabel(item.status)}}</span>
                    </div>
                    <small class="meta">{{fmt(item.expenseTime)}}</small>
                  </div>
                  <div class="bill-item-row__actions">
                    <button class="btn ghost" @click="openBillItemDialog(billData, item)">修改</button>
                    <button class="btn ghost" v-if="item.status!=='confirmed'" @click="changeBillItemStatus(item, 'confirmed')">确认</button>
                    <button class="btn ghost" v-if="item.status!=='disputed'" @click="changeBillItemStatus(item, 'disputed')">有争议</button>
                    <button class="btn ghost" v-if="item.status!=='pending'" @click="changeBillItemStatus(item, 'pending')">待确认</button>
                  </div>
                </article>
              </section>
            </div>

            <aside class="bill-side-column">
              <section class="bill-block">
                <div class="row" style="justify-content:space-between;align-items:center">
                  <h3 style="margin:0">结算结果</h3>
                  <small class="hint">先透明，再结算</small>
                </div>
                <p class="hint" v-if="billPendingCount || billDisputedCount">当前还有待确认或有争议费用，建议先逐笔核对后再结算。</p>
                <article class="bill-settlement-row" v-for="row in billSettlement.rows" :key="row.nickname">
                  <div>
                    <strong>{{row.nickname}}</strong>
                    <p class="hint">垫付 ¥{{row.paid.toFixed(2)}} · 应承担 ¥{{row.share.toFixed(2)}}</p>
                  </div>
                  <strong :class="row.net >= 0 ? 'bill-net-positive' : 'bill-net-negative'">{{row.net >= 0 ? '应收' : '应付'}} ¥{{Math.abs(row.net).toFixed(2)}}</strong>
                </article>
                <div class="bill-transfer-list" v-if="billSettlement.transfers.length">
                  <h4>最优转账方案</h4>
                  <p class="hint" v-for="(transfer, idx) in billSettlement.transfers" :key="transfer.from + transfer.to + idx">{{transfer.from}} → {{transfer.to}}：¥{{transfer.amount.toFixed(2)}}</p>
                </div>
              </section>
            </aside>
          </section>
        </section>
        <section class="card full" v-else>
          <h3>行程账单</h3>
          <p class="hint">当前还没有选中的账单，请先从行程页发起账单。</p>
          <button class="btn ghost" @click="goto('trip')">返回行程</button>
        </section>
      </template>

      <template v-else-if="app.route==='my-bills'">
        <section class="card full">
          <div class="row" style="justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
            <div>
              <h2 style="margin:0">我的账单</h2>
              <p class="hint" style="margin:.3rem 0 0">快速查看我发起或参与的账单</p>
            </div>
            <button class="btn ghost" @click="loadMyBills()">刷新</button>
          </div>
          <p class="hint" v-if="app.myBillsLoading">正在加载账单…</p>
          <p class="hint" v-else-if="app.myBillsError">{{app.myBillsError}}</p>
          <template v-else>
            <article class="trip" v-for="bill in myBillsPaged" :key="bill.id">
              <div class="row" style="justify-content:space-between;gap:12px;align-items:flex-start">
                <div>
                  <strong>{{bill.title}}</strong>
                  <p class="hint" style="margin:.25rem 0 0">关联行程：{{billTripDisplayTitle(bill)}} · 主币种 {{bill.baseCurrency || 'CNY'}} · {{(bill.members || []).length}} 人参与</p>
                  <p class="hint" style="margin:.2rem 0 0">更新时间：{{fmt(bill.updatedAt || bill.createdAt)}}</p>
                </div>
                <div class="row" style="gap:8px;flex-wrap:wrap;justify-content:flex-end">
                  <button class="btn ghost" @click="openBillFromList(bill)">打开账单</button>
                  <button class="btn ghost" v-if="bill.linkedChatId" @click="openBillChat(bill)">去群聊</button>
                </div>
              </div>
            </article>
            <p class="hint" v-if="!myBillsPaged.length && app.myBillsLoaded">还没有找到你参与的账单。</p>
            <div class="row" v-if="(Array.isArray(app.myBillsList) ? app.myBillsList.length : 0) > app.myBillsPageSize" style="justify-content:space-between;margin-top:12px">
              <small class="meta">第 {{app.myBillsPage}} / {{myBillsTotalPages}} 页（共 {{Array.isArray(app.myBillsList) ? app.myBillsList.length : 0}} 条）</small>
              <div class="row">
                <button class="btn ghost" :disabled="app.myBillsPage<=1" @click="app.myBillsPage=Math.max(1, app.myBillsPage-1)">上一页</button>
                <button class="btn ghost" :disabled="app.myBillsPage>=myBillsTotalPages" @click="app.myBillsPage=Math.min(myBillsTotalPages, app.myBillsPage+1)">下一页</button>
              </div>
            </div>
          </template>
        </section>
      </template>

      <template v-else-if="app.route==='messages'">
        <section class="card full">
          <div class="row" style="justify-content:space-between"><h2>{{t('messageCenter')}}</h2><div class="row"><button class="btn ghost" @click="app.groupDialog.show=true">发起群聊</button><button class="btn ghost" @click="markAllAsRead">{{t('markRead')}}</button></div></div>
          <div class="row msg-tabs" style="margin-bottom:10px">
            <button class="btn ghost" :class="{active: app.activeMsgTab==='chats'}" @click="app.activeMsgTab='chats'">{{t('chatMsg')}}<span v-if="unreadChatCount" class="tab-unread-badge">{{unreadChatCount > 99 ? '99+' : unreadChatCount}}</span></button>
            <button class="btn ghost" :class="{active: app.activeMsgTab==='system'}" @click="openSystemTab">{{t('sysMsg')}}<span v-if="unreadSystemCount" class="tab-unread-badge">{{unreadSystemCount > 99 ? '99+' : unreadSystemCount}}</span></button>
          </div>
          <div>
            <template v-if="app.activeMsgTab==='chats'">
              <article class="trip trip-clickable" v-for="c in chatPreviews" :key="c.id" @click="openChat(c.peer, c.id)">
                <div class="row" style="justify-content:space-between">
                  <div>
                    <strong>{{c.peer}}</strong>
                    <p class="hint" v-if="c.isGroup && c.owner" style="margin:.15rem 0 0">群主：{{c.owner}}</p>
                  </div>
                  <span class="meta">{{fmt(c.last?.createdAt)}}</span>
                </div>
                <p class="hint" :style="c.unread ? {color:'#b91c1c',fontWeight:'700'} : {}">{{c.last?.text || '暂无内容'}} <span v-if="c.unread">· 未读 {{c.unread}}</span></p>
                <div class="row" style="justify-content:flex-end">
                  <button class="btn ghost" v-if="!c.isGroup || isChatOwner(c.chat)" @click.stop="removeChat(c.id)">{{c.isGroup ? '删除群聊' : '删除聊天'}}</button>
                </div>
              </article>
              <p class="hint" v-if="!chatPreviews.length">{{t('noChatMsg')}}</p>
            </template>
            <template v-else>
              <article class="trip system-msg-card" v-for="m in systemMessages" :key="m.id" @click="markSystemMessagesAsRead()" :style="isSystemMessageUnread(m) ? {borderColor:'rgba(220,38,38,.3)', background:'rgba(254,242,242,.75)'} : {}">
                <strong :style="isSystemMessageUnread(m) ? {color:'#b91c1c'} : {}">系统提醒</strong>
                <p :style="isSystemMessageUnread(m) ? {color:'#991b1b',fontWeight:'700'} : {}">
                  <button v-if="m.actor" class="inline-link system-actor-link" @click.stop="openAccount(m.actor)">{{m.actor}}</button>
                  <span>{{m.actionText || m.text}}</span>
                </p>
                <p class="meta">{{fmt(m.createdAt)}}</p>
              </article>
              <p class="hint" v-if="!systemMessages.length">{{t('noSysMsg')}}</p>
            </template>
          </div>
        </section>
      </template>

      <template v-else-if="app.route==='admin'">
        <section class="card full">
          <h2>{{t('admin')}}</h2>
          <div class="row">
            <span class="chip">{{t('users')}} {{adminStats.users}}</span>
            <span class="chip">{{t('trips')}} {{adminStats.trips}}</span>
            <span class="chip">{{t('diaries')}} {{adminStats.diaries}}</span>
          </div>
          <h4>{{t('kpiOverview')}}</h4>
          <div class="admin-kpi-grid">
            <article class="trip"><strong>{{t('totalUsers')}}</strong><p class="meta">{{adminStats.users}}</p></article>
            <article class="trip"><strong>{{t('newUsers7d')}}</strong><p class="meta">{{adminStats.newUsers7d}}</p></article>
            <article class="trip"><strong>{{t('newTrips7d')}}</strong><p class="meta">{{adminStats.newTrips7d}}</p></article>
            <article class="trip"><strong>{{t('newDiaries7d')}}</strong><p class="meta">{{adminStats.newDiaries7d}}</p></article>
            <article class="trip"><strong>{{t('activeUsers7d')}}</strong><p class="meta">{{adminStats.activeUsers7d}}</p></article>
          </div>
          <h4>用户反馈</h4>
          <p class="hint" v-if="!adminStats.feedbacks.length">暂无用户反馈</p>
          <div class="row" v-if="adminStats.feedbacks.length" style="justify-content:space-between;margin:.35rem 0 .6rem">
            <small class="meta">第 {{app.feedbackPage}} / {{feedbackTotalPages}} 页（共 {{adminStats.feedbacks.length}} 条）</small>
            <div class="row">
              <button class="btn ghost" :disabled="app.feedbackPage<=1" @click="app.feedbackPage=Math.max(1, app.feedbackPage-1)">上一页</button>
              <button class="btn ghost" :disabled="app.feedbackPage>=feedbackTotalPages" @click="app.feedbackPage=Math.min(feedbackTotalPages, app.feedbackPage+1)">下一页</button>
            </div>
          </div>
          <article class="trip" v-for="fb in feedbackPaged" :key="fb.id">
            <strong>{{fb.payload?.from || 'guest'}} · {{fb.payload?.email || '-'}}</strong>
            <p>{{fb.payload?.content || '-'}}</p>
            <p class="meta">{{fmt(fb.createdAt)}}</p>
          </article>
          <h4>{{t('recentEvents')}}</h4>
          <article class="trip" v-for="e in adminStats.events" :key="e.id"><strong>{{e.type}}</strong><p class="meta">{{fmt(e.createdAt)}} · {{JSON.stringify(e.payload)}}</p></article>
        </section>
      </template>
    </main>

    <dialog v-if="app.confirmModal.show" open class="feedback-success-dialog" @click.self="resolveCenterConfirm(false)">
      <article class="feedback-success-card">
        <h3>{{app.confirmModal.title}}</h3>
        <p>{{app.confirmModal.message}}</p>
        <div class="row" style="justify-content:flex-end;gap:8px">
          <button class="btn ghost" type="button" @click="resolveCenterConfirm(false)">{{app.confirmModal.cancelText}}</button>
          <button class="btn" type="button" @click="resolveCenterConfirm(true)">{{app.confirmModal.confirmText}}</button>
        </div>
      </article>
    </dialog>

    <dialog v-if="app.noticeModal.show" open class="feedback-success-dialog" @click.self="closeCenterNotice">
      <article class="feedback-success-card">
        <h3>{{app.noticeModal.title}}</h3>
        <p>{{app.noticeModal.message}}</p>
        <div class="row" style="justify-content:flex-end"><button class="btn" type="button" @click="closeCenterNotice">知道了</button></div>
      </article>
    </dialog>

    <dialog v-if="app.feedbackSuccessVisible" open class="feedback-success-dialog">
      <div class="feedback-success-card">
        <h3>反馈提交成功</h3>
        <p>感谢反馈，我们已收到你的建议！</p>
        <div class="row" style="justify-content:flex-end"><button class="btn" @click="app.feedbackSuccessVisible=false">我知道了</button></div>
      </div>
    </dialog>
    <dialog ref="pv" class="image-preview-dialog">
      <div class="image-preview-wrap">
        <button class="image-preview-close" type="button" aria-label="关闭预览" @click="$refs.pv.close()">✕</button>
        <div class="image-preview-stage">
          <img class="image-preview-img" :src="app.previewSrc" />
        </div>
        <div class="image-preview-toolbar" v-if="app.previewList.length>1">
          <button class="btn ghost" type="button" @click="previewPrev">上一张</button>
          <small class="meta">{{app.previewIndex + 1}} / {{app.previewList.length}}</small>
          <button class="btn ghost" type="button" @click="previewNext">下一张</button>
        </div>
      </div>
    </dialog>
    <aside v-if="app.followDialog.show" class="follow-panel">
      <div class="follow-panel-card">
        <div class="row" style="justify-content:space-between">
          <h3 style="margin:0">{{app.followDialog.title}}</h3>
          <button class="btn ghost" @click="closeFollowList">关闭</button>
        </div>
        <p class="hint" v-if="!app.followDialog.users.length">暂无数据</p>
        <article class="trip trip-clickable" v-for="name in app.followDialog.users" :key="name" @click="goAccountFromList(name)">
          <div class="row no-wrap" style="justify-content:space-between">
            <div class="row">
              <img class="avatar avatar-clickable" :src="avatarThumb(getUserAvatar(name), 72)" :alt="name" />
              <button class="user-link" type="button" @click.stop="goAccountFromList(name)">{{name}}</button>
            </div>
            <template v-if="app.followDialog.mode==='group'">
              <span v-if="chatOwnerName(currentChatMeta)===name" class="chip">群主</span>
              <button v-else-if="canQuickFollow(name)" class="btn ghost" type="button" @click.stop="quickFollowFromDialog(name)">关注</button>
              <span v-else-if="name !== app.current" class="hint">{{ isFollowing(name) ? '已关注' : '' }}</span>
            </template>
          </div>
        </article>
      </div>
    </aside>
    <aside v-if="app.groupMemberDialog.show" class="follow-panel">
      <div class="follow-panel-card">
        <div class="row" style="justify-content:space-between">
          <h3 style="margin:0">{{app.groupMemberDialog.title || '邀请成员'}}</h3>
          <button class="btn ghost" @click="closeGroupInviteDialog">关闭</button>
        </div>
        <p class="hint" v-if="!app.groupMemberDialog.users.length">暂无可邀请用户</p>
        <article class="trip group-member-row" v-for="name in app.groupMemberDialog.users" :key="'invite-' + name">
          <div class="row no-wrap" style="justify-content:space-between;align-items:center;flex-wrap:nowrap">
            <div class="row no-wrap">
              <img class="avatar" :src="avatarThumb(getUserAvatar(name), 72)" :alt="name" />
              <strong>{{name}}</strong>
            </div>
            <button class="btn ghost" type="button" @click="inviteMemberToGroup(name)" style="white-space:nowrap;min-width:4rem">邀请</button>
          </div>
        </article>
      </div>
    </aside>
    <aside v-if="app.groupDialog.show" class="follow-panel">
      <div class="follow-panel-card">
        <div class="row" style="justify-content:space-between">
          <h3 style="margin:0">选择群聊成员（仅互相关注）</h3>
          <button class="btn ghost" @click="app.groupDialog.show=false;app.groupDialog.members=[];app.groupName=''">关闭</button>
        </div>
        <input v-model="app.groupName" placeholder="输入群聊名称" style="margin:8px 0" />
        <p class="hint" v-if="!mutualFollowUsers.length">暂无可邀请用户</p>
        <article class="trip trip-clickable group-member-row" v-for="name in mutualFollowUsers" :key="'group-' + name" @click="toggleGroupMember(name)">
          <div class="row no-wrap" style="justify-content:space-between">
            <div class="row no-wrap">
              <img class="avatar" :src="avatarThumb(getUserAvatar(name), 72)" :alt="name" />
              <strong>{{name}}</strong>
            </div>
            <input class="group-member-check" type="checkbox" :checked="app.groupDialog.members.includes(name)" readonly />
          </div>
        </article>
        <div class="row" style="justify-content:flex-end;margin-top:8px">
          <button class="btn" :disabled="!app.groupDialog.members.length || !app.groupName.trim()" @click="createGroupChat">创建群聊</button>
        </div>
      </div>

    </aside>


    <aside v-if="app.billCreateDialog.show" class="follow-panel">
      <div class="follow-panel-card bill-dialog-card">
        <div class="row" style="justify-content:space-between">
          <h3 style="margin:0">发起行程账单</h3>
          <button class="btn ghost" @click="closeCreateBillDialog">关闭</button>
        </div>
        <label class="full">账单名称<input v-model="app.billCreateDialog.title" placeholder="例如：秘鲁、智利13天12晚账单" /></label>
        <label>主币种
          <select v-model="app.billCreateDialog.baseCurrency">
            <option value="CNY">CNY</option>
            <option value="USD">USD</option>
            <option value="EUR">EUR</option>
            <option value="JPY">JPY</option>
            <option value="KRW">KRW</option>
            <option value="CLP">CLP</option>
            <option value="PEN">PEN</option>
          </select>
        </label>
        <div class="bill-dialog-section">
          <div class="bill-switch-card" @click="app.billCreateDialog.createChat=!app.billCreateDialog.createChat">
            <div>
              <div class="bill-switch-card__title">创建账单协商群</div>
              <p class="hint">开启后会同步创建一个仅账单成员可见的协商群，方便逐笔核对费用。</p>
            </div>
            <input type="checkbox" v-model="app.billCreateDialog.createChat" @click.stop />
          </div>
          <p class="bill-private-note">账单默认仅对账单参与成员可见，其他陌生人无法查看。</p>
        </div>
        <div class="bill-dialog-section">
          <div class="row" style="justify-content:space-between;align-items:center;gap:12px">
            <div>
              <div class="bill-switch-card__title">邀请账单成员</div>
              <p class="hint">可邀请互相关注的用户加入，先把费用过程透明记录下来，再协商结算。</p>
            </div>
            <span class="chip">已选 {{app.billCreateDialog.members.length}} 人</span>
          </div>
          <p class="hint" v-if="!mutualFollowUsers.length">暂无可邀请用户</p>
          <div class="bill-invite-list" v-else>
            <article class="trip trip-clickable group-member-row" v-for="name in mutualFollowUsers" :key="'bill-create-' + name" @click="toggleBillCreateMember(name)">
              <div class="row no-wrap" style="justify-content:space-between">
                <div class="row no-wrap">
                  <img class="avatar" :src="avatarThumb(getUserAvatar(name), 72)" :alt="name" />
                  <strong>{{name}}</strong>
                </div>
                <input class="group-member-check" type="checkbox" :checked="app.billCreateDialog.members.includes(name)" readonly />
              </div>
            </article>
          </div>
        </div>
        <p class="hint" v-if="app.billCreateDialog.status">{{app.billCreateDialog.status}}</p>
        <div class="row" style="justify-content:flex-end;margin-top:8px">
          <button class="btn" @click="submitCreateBill">创建账单</button>
        </div>
      </div>
    </aside>

    <aside v-if="app.billInviteDialog.show" class="follow-panel">
      <div class="follow-panel-card">
        <div class="row" style="justify-content:space-between">
          <h3 style="margin:0">邀请账单成员</h3>
          <button class="btn ghost" @click="closeBillInviteDialog">关闭</button>
        </div>
        <p class="hint" v-if="!app.billInviteDialog.users.length">暂无可邀请成员</p>
        <article class="trip group-member-row" v-for="name in app.billInviteDialog.users" :key="'bill-invite-' + name">
          <div class="row no-wrap" style="justify-content:space-between;align-items:center;flex-wrap:nowrap">
            <div class="row no-wrap">
              <img class="avatar" :src="avatarThumb(getUserAvatar(name), 72)" :alt="name" />
              <strong>{{name}}</strong>
            </div>
            <button class="btn ghost" type="button" @click="inviteUserToBill(name)" style="white-space:nowrap;min-width:4rem">邀请</button>
          </div>
        </article>
      </div>
    </aside>

    <dialog v-if="app.billItemDialog.show" open class="feedback-success-dialog bill-item-dialog" @click.self="closeBillItemDialog">
      <article class="feedback-success-card bill-item-dialog__card">
        <div class="row" style="justify-content:space-between;align-items:flex-start">
          <div>
            <h3>{{app.billItemDialog.mode === 'edit' ? '修改费用' : '新增费用'}}</h3>
            <p class="hint" style="margin:4px 0 0">一笔一笔记清楚，后续就能快速结算。</p>
          </div>
          <button class="btn ghost" type="button" @click="closeBillItemDialog">关闭</button>
        </div>
        <div class="grid" v-if="app.billItemDialog.form">
          <label>费用类型
            <select v-model="app.billItemDialog.form.expenseType" @change="onBillExpenseTypeChange">
              <option value="public">全员均摊</option>
              <option value="partial">部分成员分摊</option>
              <option value="personal">个人支出</option>
              <option value="daigou">代购 / 代付</option>
            </select>
          </label>
          <label>分类
            <select v-model="app.billItemDialog.form.category">
              <option value="food">餐饮</option>
              <option value="transport">交通</option>
              <option value="hotel">酒店</option>
              <option value="ticket">门票</option>
              <option value="shopping">购物</option>
              <option value="daigou">代购</option>
              <option value="other">其他</option>
            </select>
          </label>
          <label>金额<input v-model="app.billItemDialog.form.amountOriginal" type="number" min="0" step="0.01" @change="onBillAmountOriginalChange" @blur="onBillAmountOriginalChange" /></label>
          <label>币种
            <select v-model="app.billItemDialog.form.currencyOriginal" @change="onBillCurrencyChange">
              <option v-for="currency in billCurrencyOptions" :key="'bill-currency-' + currency" :value="currency">{{currency}}</option>
            </select>
          </label>
          <label>付款人
            <select v-model="app.billItemDialog.form.paidBy" @change="onBillPaidByChange">
              <option v-for="name in billMemberNames" :key="'bill-paid-' + name" :value="name">{{name}}</option>
            </select>
          </label>
          <label>费用时间<input v-model="app.billItemDialog.form.expenseTime" type="datetime-local" @change="onBillExpenseTimeChange" /></label>
          <label>{{getBillSettlementFieldLabel(billData?.baseCurrency, 'actual')}}<input v-model="app.billItemDialog.form.amountCnyActual" type="number" min="0" step="0.01" /></label>
          <label>{{getBillSettlementFieldLabel(billData?.baseCurrency, 'estimated')}}<input v-model="app.billItemDialog.form.amountCnyEstimated" type="number" min="0" step="0.01" @input="onBillEstimatedAmountInput" /></label>
          <div class="full" v-if="app.billItemDialog.form.currencyOriginal !== (billData?.baseCurrency || 'CNY')">
            <p class="hint" style="margin:2px 0 0">{{ app.billItemDialog.form.fxLoading ? '正在读取 Frankfurter 参考汇率…' : (app.billItemDialog.form.fxStatus || '系统会按费用日期读取 Frankfurter 参考汇率，并自动回填结算金额。') }}</p>
          </div>
          <label class="full">备注<input v-model="app.billItemDialog.form.note" placeholder="例如：晚餐 / 打车 / 门票" /></label>
          <div class="full">
            <label>小票或截图（可选）</label>
            <label class="bill-receipt-dropzone" :class="{ uploading: app.billItemDialog.form.receiptUploading }">
              <input type="file" accept="image/*" multiple style="display:none" @change="onBillReceiptFileChange" />
              <strong>{{ app.billItemDialog.form.receiptUploading ? '正在上传图片…' : '点击上传图片' }}</strong>
              <span class="hint">支持最多 {{billReceiptMaxFiles}} 张图片，单张不超过 {{billReceiptMaxFileSizeMB}}MB</span>
            </label>
            <div class="bill-receipt-meta" v-if="(app.billItemDialog.form.receiptImageUrls || []).length">
              <div class="bill-receipt-item" v-for="(url, index) in app.billItemDialog.form.receiptImageUrls" :key="url + '-' + index">
                <span class="hint">{{ app.billItemDialog.form.receiptFileNames[index] || ('凭证' + (index + 1)) }}</span>
                <div class="bill-receipt-actions">
                  <a :href="url" target="_blank" rel="noopener">查看</a>
                  <button type="button" class="link-button" @click="removeBillReceiptAt(index)">移除</button>
                </div>
              </div>
              <button type="button" class="link-button" @click="clearBillReceiptImage">清空全部</button>
            </div>
          </div>
          <div class="full">
            <div class="row" style="justify-content:space-between;align-items:center;gap:12px">
              <p class="hint" style="margin:0 0 8px 0">承担人</p>
              <small class="hint">{{billParticipantHint()}}</small>
            </div>
            <div class="bill-member-pick-grid">
              <button type="button" class="bill-member-pick" :class="{active: app.billItemDialog.form.participants.includes(name), disabled: !isBillParticipantEditable(app.billItemDialog.form)}" v-for="name in billMemberNames" :key="'bill-share-' + name" @click="toggleBillItemParticipant(name)" :disabled="!isBillParticipantEditable(app.billItemDialog.form)">{{name}}</button>
            </div>
            <p class="hint" style="margin:8px 0 0" v-if="app.billItemDialog.form.currencyOriginal !== (billData?.baseCurrency || 'CNY')">本笔原始币种是 {{app.billItemDialog.form.currencyOriginal}}，最终结算仍按账单主币种 {{billData?.baseCurrency || 'CNY'}} 统计。</p>
          </div>
          <label>状态
            <select v-model="app.billItemDialog.form.status">
              <option value="pending">待确认</option>
              <option value="confirmed">已确认</option>
              <option value="disputed">有争议</option>
            </select>
          </label>
        </div>
        <p class="hint" v-if="app.billItemDialog.status">{{app.billItemDialog.status}}</p>
        <div class="row" style="justify-content:flex-end;gap:8px;margin-top:12px">
          <button class="btn ghost" type="button" @click="closeBillItemDialog">取消</button>
          <button class="btn" type="button" @click="submitBillItem">保存</button>
        </div>
      </article>
    </dialog>

    <div v-if="app.shareCard.show" class="sharecard-modal" @click.self="closeShareCard">
      <div class="sharecard-panel">
        <div class="sharecard-toolbar">
          <div>
            <strong>分享卡片预览</strong>
            <p class="hint" style="margin:4px 0 0" v-if="app.shareCard.error">{{app.shareCard.error}}</p>
          </div>
          <div class="row">
            <button class="btn ghost" @click="closeShareCard">关闭</button>
            <button class="btn" :disabled="app.shareCard.loading || app.shareCard.downloading || !app.shareCard.data" @click="downloadShareCard">
              {{ app.shareCard.downloading ? '生成中...' : '下载 PNG' }}
            </button>
          </div>
        </div>

        <div class="sharecard-preview-wrap">
          <div v-if="app.shareCard.loading" class="sharecard-loading">正在生成分享卡片…</div>

          <div
            v-else-if="app.shareCard.data"
            class="sharecard-preview-viewport"
          >
            <div
              id="shareCardPreview"
              class="sharecard-canvas sharecard-canvas-export sharecard-preview-stage"
              :style="{ backgroundImage: 'linear-gradient(180deg, rgba(7, 31, 46, .18), rgba(7,31,46,.28)), url(' + app.shareCard.data.backgroundUrl + ')' }"
            >
              <div class="sharecard-inner">
                <div class="sharecard-brand">
                  <img class="sharecard-logo" :src="app.shareCard.data.logo" alt="歌觅 Go With Me" style="filter: drop-shadow(0 10px 24px rgba(0,0,0,.18));" />
                </div>

                <h2 class="sharecard-title" style="color:#fff;text-shadow:0 8px 24px rgba(0,0,0,.28);letter-spacing:.02em;">{{app.shareCard.data.title}}</h2>

                <div class="sharecard-main-glass" style="background:linear-gradient(180deg, rgba(255,255,255,.18), rgba(255,255,255,.10));border:1px solid rgba(255,255,255,.24);box-shadow:inset 0 1px 0 rgba(255,255,255,.22);">
                  <section class="sharecard-info-card">
                    <div class="sharecard-info-row">
                      <span class="sharecard-pill">✦ 目的地</span>
                      <span class="sharecard-value" style="color:rgba(255,255,255,.98);text-shadow:0 4px 12px rgba(0,0,0,.26);font-weight:900;">{{app.shareCard.data.destination}}</span>
                    </div>
                    <div class="sharecard-info-row" v-if="app.shareCard.data.origin">
                      <span class="sharecard-pill">📍 出发地</span>
                      <span class="sharecard-value" style="color:rgba(255,255,255,.98);text-shadow:0 4px 12px rgba(0,0,0,.26);font-weight:900;">{{app.shareCard.data.origin}}</span>
                    </div>
                    <div class="sharecard-info-row">
                      <span class="sharecard-pill">◌ 预算（元）</span>
                      <span class="sharecard-value" style="color:rgba(255,255,255,.98);text-shadow:0 4px 12px rgba(0,0,0,.26);font-weight:900;">{{app.shareCard.data.budget}}</span>
                    </div>
                    <div class="sharecard-info-row sharecard-info-row-date" v-for="(row, idx) in (app.shareCard.data.dateRows || [])" :key="'preview-date-'+idx">
                      <span class="sharecard-pill">{{row.label === '出发日期' ? '☼ 出发日期' : (row.label === '返程日期' ? '↺ 返程日期' : '✦ ' + row.label)}}</span>
                      <span class="sharecard-value" style="color:rgba(255,255,255,.98);text-shadow:0 4px 12px rgba(0,0,0,.26);font-weight:900;">{{row.value}}</span>
                    </div>
                    <div class="sharecard-info-row sharecard-info-row-tags" v-if="(app.shareCard.data.tags || []).length">
                      <span class="sharecard-pill">✿ 行程标签</span>
                      <span class="sharecard-value sharecard-value-wrap" style="color:rgba(255,255,255,.98);text-shadow:0 4px 12px rgba(0,0,0,.26);font-weight:800;">{{app.shareCard.data.tags.join(' / ')}}</span>
                    </div>
                    <div class="sharecard-info-row sharecard-info-row-tags" v-if="(app.shareCard.data.spots || []).length">
                      <span class="sharecard-pill">✈ 想去景点</span>
                      <span class="sharecard-value sharecard-value-wrap" style="color:rgba(255,255,255,.98);text-shadow:0 4px 12px rgba(0,0,0,.26);font-weight:800;">{{app.shareCard.data.spots.join('、')}}</span>
                    </div>
                  </section>

                  <section class="sharecard-profile-card" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.16);border-radius:24px;backdrop-filter: blur(12px);">
                    <div class="sharecard-profile-top">
                      <img class="sharecard-avatar" :src="app.shareCard.data.profile.avatar || '${defaultAvatar}'" :alt="app.shareCard.data.profile.nickname" />
                      <div class="sharecard-profile-main">
                        <h3 class="sharecard-nickname" style="color:#fff;text-shadow:0 6px 16px rgba(0,0,0,.26);">✦ {{app.shareCard.data.profile.nickname}}</h3>
                      </div>
                    </div>

                    <div style="padding:4px 8px 10px;">
                      <div style="color:rgba(255,255,255,.94);font-size:16px;font-weight:800;display:flex;align-items:center;gap:8px;margin-bottom:10px;"><span>✧</span><span>个人介绍</span></div>
                      <div style="background:rgba(255,255,255,.10);border:1px solid rgba(255,255,255,.16);border-radius:18px;padding:14px 16px;color:rgba(255,255,255,.98);font-size:18px;line-height:1.55;text-shadow:0 2px 8px rgba(0,0,0,.22);min-height:64px;">
                        {{app.shareCard.data.profile.bio || '这个人很神秘，等你来认识。'}}
                      </div>
                    </div>

                    <div class="sharecard-profile-grid" style="margin-top:12px;">
                      <div class="sharecard-profile-item"><span style="color:rgba(255,255,255,.94);font-size:14px;">◦ 年龄</span><strong style="color:#fff;font-size:16px;">{{app.shareCard.data.profile.age || '—'}}</strong></div>
                      <div class="sharecard-profile-item"><span style="color:rgba(255,255,255,.94);font-size:14px;">♡ 性别</span><strong style="color:#fff;font-size:16px;">{{app.shareCard.data.profile.gender || '—'}}</strong></div>
                      <div class="sharecard-profile-item"><span style="color:rgba(255,255,255,.94);font-size:14px;">✈ 旅行节奏</span><strong style="color:#fff;font-size:16px;">{{app.shareCard.data.profile.pace || '—'}}</strong></div>
                      <div class="sharecard-profile-item"><span style="color:rgba(255,255,255,.94);font-size:14px;">◌ 预算偏好</span><strong style="color:#fff;font-size:16px;">{{app.shareCard.data.profile.budgetLevel || '—'}}</strong></div>
                      <div class="sharecard-profile-item"><span style="color:rgba(255,255,255,.94);font-size:14px;">☾ 作息</span><strong style="color:#fff;font-size:16px;">{{app.shareCard.data.profile.wakeUp || '—'}}</strong></div>
                    </div>
                  </section>

                  <div class="sharecard-footer" style="color:#fff;">
                    <div class="sharecard-footer-title" style="text-shadow:0 4px 10px rgba(0,0,0,.24);">✦ {{app.shareCard.data.footerTitle}}</div>
                    <div class="sharecard-footer-url">{{app.shareCard.data.footerUrl}}</div>
                    <div class="sharecard-attribution" v-if="app.shareCard.data.creditLine">{{app.shareCard.data.creditLine}}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div v-else class="sharecard-loading">暂无分享卡片数据</div>
        </div>

        <div
          v-if="app.shareCard.data"
          class="sharecard-export-stage"
        >
          <div
            id="shareCardExport"
            class="sharecard-canvas sharecard-canvas-export"
            :style="{ backgroundImage: 'linear-gradient(180deg, rgba(7, 31, 46, .18), rgba(7,31,46,.28)), url(' + app.shareCard.data.backgroundUrl + ')' }"
          >
            <div class="sharecard-inner">
              <div class="sharecard-brand">
                <img class="sharecard-logo" :src="app.shareCard.data.logo" alt="歌觅 Go With Me" style="filter: drop-shadow(0 10px 24px rgba(0,0,0,.18));" />
              </div>

              <h2 class="sharecard-title" style="color:#fff;text-shadow:0 8px 24px rgba(0,0,0,.28);letter-spacing:.02em;">{{app.shareCard.data.title}}</h2>

              <div class="sharecard-main-glass" style="background:linear-gradient(180deg, rgba(255,255,255,.18), rgba(255,255,255,.10));border:1px solid rgba(255,255,255,.24);box-shadow:inset 0 1px 0 rgba(255,255,255,.22);">
                <section class="sharecard-info-card">
                  <div class="sharecard-info-row">
                    <span class="sharecard-pill">✦ 目的地</span>
                    <span class="sharecard-value" style="color:rgba(255,255,255,.98);text-shadow:0 4px 12px rgba(0,0,0,.26);font-weight:900;">{{app.shareCard.data.destination}}</span>
                  </div>
                  <div class="sharecard-info-row" v-if="app.shareCard.data.origin">
                    <span class="sharecard-pill">📍 出发地</span>
                    <span class="sharecard-value" style="color:rgba(255,255,255,.98);text-shadow:0 4px 12px rgba(0,0,0,.26);font-weight:900;">{{app.shareCard.data.origin}}</span>
                  </div>
                  <div class="sharecard-info-row">
                    <span class="sharecard-pill">◌ 预算（元）</span>
                    <span class="sharecard-value" style="color:rgba(255,255,255,.98);text-shadow:0 4px 12px rgba(0,0,0,.26);font-weight:900;">{{app.shareCard.data.budget}}</span>
                  </div>
                  <div class="sharecard-info-row sharecard-info-row-date" v-for="(row, idx) in (app.shareCard.data.dateRows || [])" :key="'export-date-'+idx">
                    <span class="sharecard-pill">{{row.label === '出发日期' ? '☼ 出发日期' : (row.label === '返程日期' ? '↺ 返程日期' : '✦ ' + row.label)}}</span>
                    <span class="sharecard-value" style="color:rgba(255,255,255,.98);text-shadow:0 4px 12px rgba(0,0,0,.26);font-weight:900;">{{row.value}}</span>
                  </div>
                  <div class="sharecard-info-row sharecard-info-row-tags" v-if="(app.shareCard.data.tags || []).length">
                    <span class="sharecard-pill">✿ 行程标签</span>
                    <span class="sharecard-value sharecard-value-wrap" style="color:rgba(255,255,255,.98);text-shadow:0 4px 12px rgba(0,0,0,.26);font-weight:800;">{{app.shareCard.data.tags.join(' / ')}}</span>
                  </div>
                  <div class="sharecard-info-row sharecard-info-row-tags" v-if="(app.shareCard.data.spots || []).length">
                    <span class="sharecard-pill">✈ 想去景点</span>
                    <span class="sharecard-value sharecard-value-wrap" style="color:rgba(255,255,255,.98);text-shadow:0 4px 12px rgba(0,0,0,.26);font-weight:800;">{{app.shareCard.data.spots.join('、')}}</span>
                  </div>
                </section>

                <section class="sharecard-profile-card" style="background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.16);border-radius:24px;backdrop-filter: blur(12px);">
                  <div class="sharecard-profile-top">
                    <img class="sharecard-avatar" :src="app.shareCard.data.profile.avatar || '${defaultAvatar}'" :alt="app.shareCard.data.profile.nickname" />
                    <div class="sharecard-profile-main">
                      <h3 class="sharecard-nickname" style="color:#fff;text-shadow:0 6px 16px rgba(0,0,0,.26);">✦ {{app.shareCard.data.profile.nickname}}</h3>
                    </div>
                  </div>

                  <div style="padding:4px 8px 10px;">
                    <div style="color:rgba(255,255,255,.94);font-size:16px;font-weight:800;display:flex;align-items:center;gap:8px;margin-bottom:10px;"><span>✧</span><span>个人介绍</span></div>
                    <div style="background:rgba(255,255,255,.10);border:1px solid rgba(255,255,255,.16);border-radius:18px;padding:14px 16px;color:rgba(255,255,255,.98);font-size:18px;line-height:1.55;text-shadow:0 2px 8px rgba(0,0,0,.22);min-height:64px;">
                      {{app.shareCard.data.profile.bio || '这个人很神秘，等你来认识。'}}
                    </div>
                  </div>

                  <div class="sharecard-profile-grid" style="margin-top:12px;">
                    <div class="sharecard-profile-item"><span style="color:rgba(255,255,255,.94);font-size:14px;">◦ 年龄</span><strong style="color:#fff;font-size:16px;">{{app.shareCard.data.profile.age || '—'}}</strong></div>
                    <div class="sharecard-profile-item"><span style="color:rgba(255,255,255,.94);font-size:14px;">♡ 性别</span><strong style="color:#fff;font-size:16px;">{{app.shareCard.data.profile.gender || '—'}}</strong></div>
                    <div class="sharecard-profile-item"><span style="color:rgba(255,255,255,.94);font-size:14px;">✈ 旅行节奏</span><strong style="color:#fff;font-size:16px;">{{app.shareCard.data.profile.pace || '—'}}</strong></div>
                    <div class="sharecard-profile-item"><span style="color:rgba(255,255,255,.94);font-size:14px;">◌ 预算偏好</span><strong style="color:#fff;font-size:16px;">{{app.shareCard.data.profile.budgetLevel || '—'}}</strong></div>
                    <div class="sharecard-profile-item"><span style="color:rgba(255,255,255,.94);font-size:14px;">☾ 作息</span><strong style="color:#fff;font-size:16px;">{{app.shareCard.data.profile.wakeUp || '—'}}</strong></div>
                  </div>
                </section>

                <div class="sharecard-footer" style="color:#fff;">
                  <div class="sharecard-footer-title" style="text-shadow:0 4px 10px rgba(0,0,0,.24);">✦ {{app.shareCard.data.footerTitle}}</div>
                  <div class="sharecard-footer-url">{{app.shareCard.data.footerUrl}}</div>
                  <div class="sharecard-attribution" v-if="app.shareCard.data.creditLine">{{app.shareCard.data.creditLine}}</div>
                </div>
              </div>
            </div>
          </div>
        </div>

      <div v-if="app.achievementCenter.overviewOpen" class="achievement-overlay" @click.self="closeAchievementOverview">
        <div class="achievement-dialog achievement-dialog--overview">
          <div class="achievement-dialog__head">
            <div>
              <p class="my-achievement-kicker">{{app.achievementCenter.cityName}}</p>
              <h3>城市奖杯详情</h3>
            </div>
            <button class="btn ghost" @click="closeAchievementOverview">关闭</button>
          </div>
          <div class="achievement-dialog__summary">
            <div class="achievement-progress-ring achievement-progress-ring--sm" :style="achievementProgressStyle">
              <div class="achievement-progress-ring__inner">
                <strong>{{achievementProgressPercent}}%</strong>
                <span>完成度</span>
              </div>
            </div>
            <div>
              <p><strong>{{unlockedCityAchievements.length}}</strong> / {{cityAchievements.length}} 已解锁</p>
              <p class="hint" v-if="app.achievementCenter.platinumRule?.description">{{app.achievementCenter.platinumRule.description}}</p>
            </div>
          </div>
          <div class="achievement-card-grid achievement-card-grid--dialog">
            <button type="button" class="achievement-card" :class="{'is-unlocked': item.isUnlocked, 'is-locked': !item.isUnlocked}" v-for="item in orderedCityAchievements" :key="item.achievement_code" @click="openAchievementDetail(item)">
              <div class="achievement-card__top">
                <span class="achievement-card__icon" v-html="getAchievementLevelIconSvg(item.level)"></span>
                <span class="achievement-level-pill" :class="'level-' + item.level">{{item.level_name}}</span>
              </div>
              <strong>{{item.title}}</strong>
              <p>{{getAchievementHint(item)}}</p>
              <div class="achievement-card__bottom">
                <span>{{getAchievementTagLabel(item)}}</span>
                <span>{{item.isUnlocked ? formatAchievementTime(item.unlockedAt) : '未解锁'}}</span>
              </div>
            </button>
          </div>
        </div>
      </div>

      <div v-if="app.achievementCenter.detailOpen && achievementSelectedItem" class="achievement-overlay" @click.self="closeAchievementDetail">
        <div class="achievement-dialog achievement-dialog--detail">
          <div class="achievement-dialog__head">
            <div>
              <p class="my-achievement-kicker">{{app.achievementCenter.cityName}} · {{getAchievementTagLabel(achievementSelectedItem)}}</p>
              <h3>{{achievementSelectedItem.title}}</h3>
            </div>
            <button class="btn ghost" @click="closeAchievementDetail">关闭</button>
          </div>
          <div class="achievement-detail-hero" :class="{'is-unlocked': achievementSelectedItem.isUnlocked}">
            <div class="achievement-detail-hero__badge">{{getAchievementLevelIcon(achievementSelectedItem.level)}}</div>
            <div class="achievement-detail-hero__copy">
              <div class="achievement-detail-hero__meta">
                <span class="achievement-level-pill" :class="'level-' + achievementSelectedItem.level">{{achievementSelectedItem.level_name}}</span>
                <span class="achievement-tag">{{getAchievementRouteTypeLabel(achievementSelectedItem)}}</span>
              </div>
              <p>{{getAchievementHint(achievementSelectedItem)}}</p>
              <p class="hint">{{achievementSelectedItem.description || achievementSelectedItem.unlock_rule || '去对应地点探索，即可触发自动解锁。'}}</p>
            </div>
          </div>
          <div class="achievement-detail-grid">
            <article class="achievement-detail-panel">
              <h4>解锁方式</h4>
              <p>{{achievementSelectedItem.unlock_rule || '到点自动判定'}}</p>
            </article>
            <article class="achievement-detail-panel">
              <h4>当前状态</h4>
              <p>{{achievementSelectedItem.isUnlocked ? '已解锁' : '尚未解锁'}}</p>
              <p class="hint">{{achievementSelectedItem.isUnlocked ? formatAchievementTime(achievementSelectedItem.unlockedAt) : '还差一次真实探索'}}</p>
            </article>
            <article class="achievement-detail-panel">
              <h4>社区分享文案</h4>
              <p>{{achievementSelectedItem.share_text || '我在歌觅解锁了一枚新的城市成就。'}}</p>
            </article>
            <article class="achievement-detail-panel">
              <h4>适合入口</h4>
              <p>建议从“我的主页 → 城市成就”进入，后续可继续接入地图打卡和自动跳杯提示。</p>
            </article>
          </div>
        </div>
      </div>

      </div>
    </div>
  </div>`
}).mount('#app');
