-- Romantic Journey MVP schema (Supabase/Postgres)
-- Regenerated to match current frontend writes in supabase-client.js
-- Notes:
-- 1) all business IDs use UUID to avoid text/uuid mismatches.
-- 2) tables written with upsert (resolution=merge-duplicates) all have PK/unique constraints.
-- 3) id columns that may be omitted by frontend now have default gen_random_uuid().

create extension if not exists pgcrypto;

-- ========= 1) 用户与画像 =========
create table if not exists app_users (
  id uuid primary key default gen_random_uuid(),
  nickname text not null unique,
  password text not null,
  first_login boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists user_profiles (
  user_id uuid primary key references app_users(id) on delete cascade,
  avatar text,
  birthday date,
  mbti text,
  zodiac text,
  pace text,
  budget_level text,
  wake_up text,
  social text,
  skills text[] not null default '{}',
  bio text,
  updated_at timestamptz not null default now()
);

-- ========= 2) 行程 =========
create table if not exists trips (
  id uuid primary key,
  user_id uuid not null references app_users(id) on delete cascade,
  destination text not null,
  depart_date date,
  return_date date,
  budget numeric(12,2) not null default 0,
  tags text[] not null default '{}',
  spots text[] not null default '{}',
  itinerary text not null default '',
  pace text,
  wake_up text,
  social text,
  countries text[] not null default '{}',
  badges jsonb not null default '[]'::jsonb,
  review jsonb not null default '{"score":5.0,"count":1,"highlights":[]}'::jsonb,
  trust jsonb not null default '{"score":4.5,"completion":90,"verified":false}'::jsonb,
  like_count integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint chk_trips_date_range check (
    return_date is null or depart_date is null or return_date >= depart_date
  )
);
create index if not exists idx_trips_user_id on trips(user_id);
create index if not exists idx_trips_created_at on trips(created_at desc);

create table if not exists trip_comments (
  id uuid primary key,
  trip_id uuid not null references trips(id) on delete cascade,
  user_id uuid not null references app_users(id) on delete cascade,
  reply_to_nickname text,
  content text not null,
  pinned boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists idx_trip_comments_trip_id on trip_comments(trip_id);

create table if not exists trip_likes (
  trip_id uuid not null references trips(id) on delete cascade,
  user_id uuid not null references app_users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (trip_id, user_id)
);

create table if not exists trip_comment_likes (
  comment_id uuid not null references trip_comments(id) on delete cascade,
  user_id uuid not null references app_users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (comment_id, user_id)
);

-- ========= 3) 日记/媒体 =========
create table if not exists media_posts (
  id uuid primary key,
  user_id uuid not null references app_users(id) on delete cascade,
  media_type text not null check (media_type in ('图片','视频')),
  location text,
  cover text,
  caption text,
  checkin text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);
create index if not exists idx_media_posts_user_id on media_posts(user_id);

create table if not exists media_comments (
  id uuid primary key,
  media_post_id uuid not null references media_posts(id) on delete cascade,
  user_id uuid not null references app_users(id) on delete cascade,
  reply_to_nickname text,
  content text not null,
  pinned boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists idx_media_comments_post_id on media_comments(media_post_id);

create table if not exists media_likes (
  media_post_id uuid not null references media_posts(id) on delete cascade,
  user_id uuid not null references app_users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (media_post_id, user_id)
);

create table if not exists media_comment_likes (
  comment_id uuid not null references media_comments(id) on delete cascade,
  user_id uuid not null references app_users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (comment_id, user_id)
);

-- ========= 4) 社交关系 =========
create table if not exists user_follows (
  follower_id uuid not null references app_users(id) on delete cascade,
  followee_id uuid not null references app_users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, followee_id),
  check (follower_id <> followee_id)
);

create table if not exists user_blocks (
  blocker_id uuid not null references app_users(id) on delete cascade,
  blocked_id uuid not null references app_users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);

-- ========= 5) 聊天 =========
create table if not exists chats (
  id uuid primary key,
  chat_type text not null check (chat_type in ('dm','group')),
  name text,
  created_by uuid references app_users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists chat_members (
  chat_id uuid not null references chats(id) on delete cascade,
  user_id uuid not null references app_users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (chat_id, user_id)
);

create table if not exists chat_messages (
  id uuid primary key default gen_random_uuid(),
  chat_id uuid not null references chats(id) on delete cascade,
  sender_id uuid not null references app_users(id) on delete cascade,
  content text not null,
  created_at timestamptz not null default now()
);
create index if not exists idx_chat_messages_chat_id_created_at on chat_messages(chat_id, created_at desc);

-- ========= 6) 已读状态 / 管理事件 =========
create table if not exists user_read_state (
  user_id uuid not null references app_users(id) on delete cascade,
  scope text not null,
  last_read_at timestamptz not null default now(),
  primary key (user_id, scope)
);

create table if not exists admin_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references app_users(id) on delete set null,
  user_nickname text,
  event_type text not null,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists idx_admin_events_type_created on admin_events(event_type, created_at desc);

-- ========= 7) 更新时间触发器 =========
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_app_users_updated_at on app_users;
create trigger trg_app_users_updated_at
before update on app_users
for each row execute function set_updated_at();

drop trigger if exists trg_user_profiles_updated_at on user_profiles;
create trigger trg_user_profiles_updated_at
before update on user_profiles
for each row execute function set_updated_at();

drop trigger if exists trg_trips_updated_at on trips;
create trigger trg_trips_updated_at
before update on trips
for each row execute function set_updated_at();

drop trigger if exists trg_media_posts_updated_at on media_posts;
create trigger trg_media_posts_updated_at
before update on media_posts
for each row execute function set_updated_at();


-- ========= 8) 行程账单 / 协作结算 =========
create table if not exists trip_bills (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references trips(id) on delete cascade,
  created_by uuid references app_users(id) on delete set null,
  title text not null default '行程账单',
  base_currency text not null default 'CNY',
  linked_chat_id uuid references chats(id) on delete set null,
  status text not null default 'active' check (status in ('active','review','settled','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_trip_bills_trip_id on trip_bills(trip_id);
create index if not exists idx_trip_bills_chat_id on trip_bills(linked_chat_id);

create table if not exists trip_bill_members (
  bill_id uuid not null references trip_bills(id) on delete cascade,
  user_id uuid not null references app_users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','member')),
  member_status text not null default 'active' check (member_status in ('active','left','removed')),
  invited_by uuid references app_users(id) on delete set null,
  joined_at timestamptz not null default now(),
  primary key (bill_id, user_id)
);
create index if not exists idx_trip_bill_members_user_id on trip_bill_members(user_id);

create table if not exists trip_bill_items (
  id uuid primary key default gen_random_uuid(),
  bill_id uuid not null references trip_bills(id) on delete cascade,
  expense_type text not null default 'public' check (expense_type in ('public','partial','personal','daigou')),
  category text not null default 'other',
  status text not null default 'pending' check (status in ('pending','confirmed','disputed')),
  amount_original numeric(12,2) not null default 0,
  currency_original text not null default 'CNY',
  amount_cny_actual numeric(12,2),
  amount_cny_estimated numeric(12,2),
  paid_by uuid references app_users(id) on delete set null,
  expense_time timestamptz not null default now(),
  note text,
  receipt_image_url text,
  split_method text not null default 'equal',
  created_by uuid references app_users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_trip_bill_items_bill_id on trip_bill_items(bill_id);
create index if not exists idx_trip_bill_items_expense_time on trip_bill_items(expense_time desc);

create table if not exists trip_bill_item_shares (
  item_id uuid not null references trip_bill_items(id) on delete cascade,
  user_id uuid not null references app_users(id) on delete cascade,
  share_ratio numeric(12,6) not null default 0,
  share_amount numeric(12,2) not null default 0,
  is_included boolean not null default true,
  primary key (item_id, user_id)
);
create index if not exists idx_trip_bill_item_shares_user_id on trip_bill_item_shares(user_id);

create table if not exists trip_bill_events (
  id uuid primary key default gen_random_uuid(),
  bill_id uuid not null references trip_bills(id) on delete cascade,
  item_id uuid references trip_bill_items(id) on delete cascade,
  actor_id uuid references app_users(id) on delete set null,
  event_type text not null,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists idx_trip_bill_events_bill_id on trip_bill_events(bill_id, created_at desc);

drop trigger if exists trg_trip_bills_updated_at on trip_bills;
create trigger trg_trip_bills_updated_at
before update on trip_bills
for each row execute function set_updated_at();

drop trigger if exists trg_trip_bill_items_updated_at on trip_bill_items;
create trigger trg_trip_bill_items_updated_at
before update on trip_bill_items
for each row execute function set_updated_at();
