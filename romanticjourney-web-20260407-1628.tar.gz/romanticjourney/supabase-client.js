(function initRomanticJourneySupabase(global) {
  const URL_KEY = 'romanticJourneySupabaseUrl';
  const ANON_KEY = 'romanticJourneySupabaseAnonKey';
  const STORAGE_BUCKET_KEY = 'romanticJourneySupabaseBucket';
  const DEFAULT_STORAGE_BUCKET = 'Trip_Photos';
  const BILL_RECEIPT_BUCKET = 'bill-receipts';
  const userIdCache = new Map();
  let mediaPostsSyncDisabled = false;
  let supabaseClientInstance = null;
  let initLogged = false;
  let authContextCache = { expiresAt: 0, value: null };

  function getSupabaseFactory() {
    if (typeof global.supabase?.createClient === 'function') return global.supabase.createClient;
    if (typeof global.supabasejs?.createClient === 'function') return global.supabasejs.createClient;
    return null;
  }

  function logSdkInit(url, anonKey, hasFactory, created) {
    if (initLogged) return;
    initLogged = true;
    console.log('[supabase-init] sdkLoaded', Boolean(hasFactory));
    console.log('[supabase-init] clientCreated', Boolean(created));
    console.log('[supabase-init] url', url || null);
    console.log('[supabase-init] hasAnonKey', Boolean(anonKey));
  }

  function getSupabaseClient() {
    if (supabaseClientInstance) return supabaseClientInstance;
    const { url, anonKey } = normalizeConfig();
    const createClient = getSupabaseFactory();
    if (!url || !anonKey || !createClient) {
      logSdkInit(url, anonKey, createClient, false);
      return null;
    }
    supabaseClientInstance = createClient(url, anonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true
      }
    });
    logSdkInit(url, anonKey, createClient, true);
    return supabaseClientInstance;
  }

  function normalizeConfig() {
    const fromWindow = global.APP_CONFIG || global.SUPABASE_CONFIG || {};
    const url = String(fromWindow.SUPABASE_URL || fromWindow.url || localStorage.getItem(URL_KEY) || '').trim();
    const anonKey = String(fromWindow.SUPABASE_ANON_KEY || fromWindow.anonKey || localStorage.getItem(ANON_KEY) || '').trim();
    const storageBucket = String(fromWindow.STORAGE_BUCKET || fromWindow.storageBucket || localStorage.getItem(STORAGE_BUCKET_KEY) || DEFAULT_STORAGE_BUCKET).trim();
    return { url, anonKey, storageBucket };
  }

  function isEnabled() {
    const { url, anonKey } = normalizeConfig();
    return Boolean(url && anonKey);
  }

  function setConfig(url, anonKey, storageBucket) {
    localStorage.setItem(URL_KEY, String(url || '').trim());
    localStorage.setItem(ANON_KEY, String(anonKey || '').trim());
    if (typeof storageBucket !== 'undefined') localStorage.setItem(STORAGE_BUCKET_KEY, String(storageBucket || '').trim());
  }

  function extFromFileName(name, fallback = 'jpg') {
    const value = String(name || '');
    const idx = value.lastIndexOf('.');
    if (idx < 0) return fallback;
    return value.slice(idx + 1).toLowerCase().replace(/[^a-z0-9]/g, '') || fallback;
  }

  function safePathPart(value) {
    return String(value || '').trim().replace(/[^a-zA-Z0-9_-]/g, '_') || 'unknown';
  }

  function buildAuthEmailFromNickname(nickname) {
    const raw = String(nickname || '').trim();
    if (!raw) return 'unknown@romanticjourney.app';
    const bytes = Array.from(new TextEncoder().encode(raw));
    const hex = bytes.map((b) => b.toString(16).padStart(2, '0')).join('').slice(0, 48) || 'unknown';
    return `u_${hex}@romanticjourney.app`;
  }

  async function signUpWithLocalAccount(nickname, password) {
    if (!nickname || !password) throw new Error('nickname and password are required');
    const client = getSupabaseClient();
    if (!client?.auth?.signUp) throw new Error('Supabase SDK 未加载，无法注册');
    const email = buildAuthEmailFromNickname(nickname);
    console.log('[supabase-auth] signUp start', { nickname, email });
    const result = await client.auth.signUp({ email, password });
    console.log('[supabase-auth] signUp result', {
      data: {
        userId: result?.data?.user?.id || null,
        hasSession: Boolean(result?.data?.session),
        identities: Array.isArray(result?.data?.user?.identities) ? result.data.user.identities.length : null
      },
      error: result?.error || null
    });
    if (result?.error) throw result.error;
    if (!result?.data?.user?.id) {
      throw new Error('Supabase 注册失败：未创建 Auth 用户');
    }
    authContextCache = { expiresAt: 0, value: null };
    return result?.data || null;
  }

  async function signInWithLocalAccount(nickname, password) {
    if (!nickname || !password) throw new Error('nickname and password are required');
    const client = getSupabaseClient();
    if (!client?.auth?.signInWithPassword) throw new Error('Supabase SDK 未加载，无法登录');
    const email = buildAuthEmailFromNickname(nickname);
    console.log('[supabase-auth] signIn start', { nickname, email });
    const result = await client.auth.signInWithPassword({ email, password });
    console.log('[supabase-auth] signIn result', {
      data: {
        userId: result?.data?.user?.id || null,
        hasSession: Boolean(result?.data?.session),
        accessToken: Boolean(result?.data?.session?.access_token),
        refreshToken: Boolean(result?.data?.session?.refresh_token)
      },
      error: result?.error || null
    });
    if (result?.error) throw result.error;
    if (!result?.data?.session?.access_token || !result?.data?.session?.refresh_token) {
      throw new Error('Supabase 登录成功但未返回 session（可能开启了邮箱确认）');
    }
    authContextCache = { expiresAt: 0, value: null };
    return result.data.session;
  }

  async function getSupabaseAuthSession() {
    const client = getSupabaseClient();
    if (!client?.auth?.getSession) return null;
    const sessionResult = await client.auth.getSession();
    console.log('[supabase-auth] getSession', sessionResult);
    return sessionResult?.data?.session || null;
  }

  async function restoreSupabaseSession() {
    return getSupabaseAuthSession();
  }

  async function signOutSupabaseSession(options = {}) {
    const client = getSupabaseClient();
    if (!client?.auth?.signOut) return;
    const suppressErrors = Boolean(options?.suppressErrors);
    const ignoreStatuses = Array.isArray(options?.ignoreStatuses) ? options.ignoreStatuses : [401, 403, 404];
    const result = await client.auth.signOut();
    authContextCache = { expiresAt: 0, value: null };
    if (result?.error) {
      const status = Number(result.error?.status || result.error?.code || 0);
      if (suppressErrors || ignoreStatuses.includes(status)) {
        console.warn('[supabase-auth] signOut ignored after account delete', result.error);
        return;
      }
      console.error('[supabase-auth] signOut failed', result.error);
      throw result.error;
    }
  }

  async function getCurrentAuthContext(debugLabel = 'supabase-auth', options = {}) {
    const client = getSupabaseClient();
    if (!client?.auth?.getSession || !client?.auth?.getUser) {
      throw new Error('Supabase SDK 未加载，无法校验登录态');
    }
    const force = Boolean(options && options.force);
    if (!force && authContextCache.value && authContextCache.expiresAt > Date.now()) {
      return authContextCache.value;
    }
    const sessionResult = await client.auth.getSession();
    const session = sessionResult?.data?.session || null;
    console.log(`[${debugLabel}] auth.getSession`, sessionResult);
    if (!session?.access_token) {
      const empty = { client, user: null, session: null, sessionResult, userResult: null };
      authContextCache = { expiresAt: 0, value: empty };
      return empty;
    }
    const userResult = await client.auth.getUser();
    console.log(`[${debugLabel}] auth.getUser`, userResult);
    const user = userResult?.data?.user || null;
    const ctx = { client, user, session, sessionResult, userResult };
    authContextCache = { expiresAt: Date.now() + 15000, value: ctx };
    return ctx;
  }


  async function getAuthenticatedSessionOrThrow(debugLabel = 'supabase-rest-auth') {
    const client = getSupabaseClient();
    if (!client?.auth?.getSession) {
      throw new Error('Supabase SDK 未加载，无法校验登录态');
    }
    const sessionResult = await client.auth.getSession();
    console.log(`[${debugLabel}] auth.getSession`, sessionResult);
    const session = sessionResult?.data?.session || null;
    const accessToken = String(session?.access_token || '').trim();
    if (!accessToken) {
      throw new Error('当前未登录 Supabase 或登录态已失效，请重新登录后再试');
    }
    return { client, session, accessToken };
  }

  async function uploadUserAvatar(file) {
    if (!file) throw new Error('file is required');
    const { url, anonKey, storageBucket } = normalizeConfig();
    if (!url || !anonKey) throw new Error('Supabase config missing');
    await restoreSupabaseSession();
    const { user, session } = await getCurrentAuthContext('supabase-avatar-debug');
    if (!session?.access_token || !user?.id) {
      throw new Error('当前未登录 Supabase，无法上传头像');
    }
    const ext = (String(file.name || '').split('.').pop() || 'jpg').replace(/[^a-zA-Z0-9]/g, '').toLowerCase() || 'jpg';
    const objectPath = `${String(user.id).trim()}/avatars/${Date.now()}-avatar.${ext}`;
    const encodedPath = objectPath.split('/').map((s) => encodeURIComponent(s)).join('/');
    const uploadUrl = `${url}/storage/v1/object/${encodeURIComponent(storageBucket)}/${encodedPath}`;
    const response = await fetch(uploadUrl, {
      method: 'POST',
      headers: {
        apikey: anonKey,
        Authorization: `Bearer ${session.access_token}`,
        'x-upsert': 'true',
        'Content-Type': file.type || 'application/octet-stream'
      },
      body: file
    });
    if (!response.ok) {
      const text = await response.text();
      throw new Error(`Supabase avatar upload ${response.status}: ${text}`);
    }
    const publicUrl = `${url}/storage/v1/object/public/${encodeURIComponent(storageBucket)}/${encodedPath}`;
    return { bucket: storageBucket, path: objectPath, url: publicUrl, size: Number(file.size || 0) };
  }

  async function uploadDiaryImage(file, options = {}) {
    if (!file) throw new Error('file is required');
    const { url, anonKey, storageBucket } = normalizeConfig();
    if (!url || !anonKey) throw new Error('Supabase config missing');

    await restoreSupabaseSession();
    const { user, session } = await getCurrentAuthContext('supabase-upload-debug');
    if (!session?.access_token || !user?.id) {
      throw new Error('当前未登录 Supabase，无法上传图片');
    }

    const resolvedUserId = String(user.id || '').trim();
    if (!resolvedUserId) {
      throw new Error('当前未登录 Supabase，无法上传图片');
    }

    if (storageBucket !== 'Trip_Photos') {
      console.warn('[supabase-upload-debug] bucket mismatch, expected "Trip_Photos"', { storageBucket });
    }

    const safeName = String(file.name || 'image.jpg').replace(/[^\w.-]+/g, '_');
    const objectPath = `${resolvedUserId}/${Date.now()}-${safeName}`;
    console.log('[supabase-upload-debug] bucket', storageBucket);
    console.log('[supabase-upload-debug] filePath', objectPath);

    const encodedPath = objectPath.split('/').map((s) => encodeURIComponent(s)).join('/');
    const uploadUrl = `${url}/storage/v1/object/${encodeURIComponent(storageBucket)}/${encodedPath}`;
    console.log('[supabase-upload-debug] uploadUrl', uploadUrl);
    const response = await fetch(uploadUrl, {
      method: 'POST',
      headers: {
        apikey: anonKey,
        Authorization: `Bearer ${session.access_token}`,
        'x-upsert': 'false',
        'Content-Type': file.type || 'application/octet-stream'
      },
      body: file
    });
    let uploadData = null;
    let uploadError = null;
    if (!response.ok) {
      const text = await response.text();
      uploadError = `Supabase storage ${response.status}: ${text}`;
      console.log('[supabase-upload-debug] storage upload result', { data: uploadData, error: uploadError });
      throw new Error(uploadError);
    }
    uploadData = await response.json().catch(() => null);
    console.log('[supabase-upload-debug] storage upload result', { data: uploadData, error: uploadError });
    const publicUrl = `${url}/storage/v1/object/public/${encodeURIComponent(storageBucket)}/${encodedPath}`;
    return {
      bucket: storageBucket,
      path: objectPath,
      url: publicUrl,
      size: Number(file.size || 0)
    };
  }


  async function uploadBillReceipt(file, options = {}) {
    if (!file) throw new Error('file is required');
    const { url, anonKey } = normalizeConfig();
    if (!url || !anonKey) throw new Error('Supabase config missing');

    await restoreSupabaseSession();
    const { user, session } = await getCurrentAuthContext('supabase-bill-receipt-debug');
    if (!session?.access_token || !user?.id) {
      throw new Error('当前未登录 Supabase，无法上传凭证图片');
    }

    const resolvedUserId = String(user.id || '').trim();
    const billId = safePathPart(options?.billId || 'draft_bill');
    const itemId = safePathPart(options?.itemId || 'draft_item');
    const ext = extFromFileName(options?.originalName || file.name || 'receipt.jpg', 'jpg');
    const objectPath = `${resolvedUserId}/${billId}/${itemId}_${Date.now()}.${ext}`;
    const encodedPath = objectPath.split('/').map((s) => encodeURIComponent(s)).join('/');
    const uploadUrl = `${url}/storage/v1/object/${encodeURIComponent(BILL_RECEIPT_BUCKET)}/${encodedPath}`;

    const response = await fetch(uploadUrl, {
      method: 'POST',
      headers: {
        apikey: anonKey,
        Authorization: `Bearer ${session.access_token}`,
        'x-upsert': 'false',
        'Content-Type': file.type || 'application/octet-stream'
      },
      body: file
    });

    if (!response.ok) {
      const text = await response.text();
      throw new Error(`Supabase receipt upload ${response.status}: ${text}`);
    }

    const publicUrl = `${url}/storage/v1/object/public/${encodeURIComponent(BILL_RECEIPT_BUCKET)}/${encodedPath}`;
    return {
      bucket: BILL_RECEIPT_BUCKET,
      path: objectPath,
      url: publicUrl,
      size: Number(file.size || 0)
    };
  }

  async function request(path, options = {}) {
    const { url, anonKey } = normalizeConfig();
    if (!url || !anonKey) throw new Error('Supabase config missing');

    const method = String(options.method || 'GET').toUpperCase();
    const needsAuth = !['GET', 'HEAD', 'OPTIONS'].includes(method) || options.requireAuth === true;

    let accessToken = '';
    if (needsAuth) {
      const auth = await getAuthenticatedSessionOrThrow('supabase-rest-request');
      accessToken = auth.accessToken;
    } else {
      try {
        const auth = await getAuthenticatedSessionOrThrow('supabase-rest-request');
        accessToken = auth.accessToken;
      } catch (error) {
        accessToken = '';
      }
    }

    const headers = {
      'Content-Type': 'application/json',
      apikey: anonKey,
      Prefer: 'return=representation',
      ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
      ...(options.headers || {})
    };

    const response = await fetch(`${url}/rest/v1/${path}`, {
      ...options,
      headers
    });

    const text = await response.text();
    if (!response.ok) {
      throw new Error(`Supabase ${response.status}: ${text}`);
    }
    return text ? JSON.parse(text) : null;
  }

  async function findUserByNickname(nickname) {
    if (!nickname) return null;
    const encoded = encodeURIComponent(`eq.${nickname}`);
    const rows = await request(`app_users?nickname=${encoded}&select=id,nickname,password,first_login,created_at&limit=1`, {
      method: 'GET'
    });
    const found = Array.isArray(rows) && rows.length ? rows[0] : null;
    if (found?.id) userIdCache.set(nickname, found.id);
    return found;
  }

  async function createUserWithProfile(payload) {
    const body = {
      nickname: payload.nickname,
      password: payload.password,
      first_login: true
    };

    let user = null;
    try {
      const created = await request('app_users', { method: 'POST', body: JSON.stringify(body) });
      user = Array.isArray(created) ? created[0] : null;
    } catch (error) {
      const msg = String(error?.message || '');
      const isDuplicateNickname = /duplicate key value violates unique constraint .*app_users_nickname_key|already exists/i.test(msg);
      if (!isDuplicateNickname) throw error;
      console.warn('[RJSupabase.createUserWithProfile] nickname already exists, reuse existing row', payload.nickname);
      user = await findUserByNickname(payload.nickname);
    }

    if (!user?.id) throw new Error('Supabase user insert failed');

    try {
      await request('user_profiles', {
        method: 'POST',
        body: JSON.stringify({ user_id: user.id }),
        headers: { Prefer: 'return=minimal' }
      });
    } catch (error) {
      const msg = String(error?.message || '');
      const isDuplicateProfile = /duplicate key value violates unique constraint/i.test(msg);
      if (!isDuplicateProfile) throw error;
      console.warn('[RJSupabase.createUserWithProfile] profile already exists, skip insert', user.id);
    }

    userIdCache.set(payload.nickname, user.id);
    return user;
  }

  async function ensureUser(nickname, password = '123456') {
    const name = String(nickname || '').trim();
    if (!name) return null;
    if (/^群聊\(\d+\)$/u.test(name)) return null;
    if (name.includes('搭子群') || name.includes('群聊') || name.endsWith('群')) return null;
    try {
      const groupMatch = await request(`chats?name=eq.${encodeURIComponent(name)}&chat_type=eq.group&select=id&limit=1`, { method: 'GET' });
      if (Array.isArray(groupMatch) && groupMatch.length) return null;
    } catch (_) {}
    if (userIdCache.has(name)) return userIdCache.get(name);
    const found = await findUserByNickname(name);
    if (found?.id) return found.id;
    const created = await createUserWithProfile({ nickname: name, password });
    return created.id;
  }

  async function syncUserProfile(nickname, profile = {}) {
    const userId = await ensureUser(nickname);
    if (!userId) return;
    const headers = { Prefer: 'resolution=merge-duplicates,return=minimal' };
    let payload = {
      user_id: userId,
      avatar: profile.avatar || null,
      birthday: profile.birthday || null,
      mbti: profile.mbti || null,
      zodiac: profile.zodiac || null,
      pace: profile.pace || null,
      budget_level: profile.budgetLevel || null,
      wake_up: profile.wakeUp || null,
      social: profile.social || null,
      bio: profile.bio || null,
      skills: Array.isArray(profile.skills) ? profile.skills : []
    };

    const tryPost = async (body) => {
      return request('user_profiles?on_conflict=user_id', {
        method: 'POST',
        body: JSON.stringify(body),
        headers
      });
    };

    for (let attempt = 0; attempt < 6; attempt += 1) {
      try {
        await tryPost(payload);
        return;
      } catch (error) {
        const msg = String(error?.message || '');
        const missing = msg.match(/Could not find the '([^']+)' column/i);
        if (missing?.[1] && Object.prototype.hasOwnProperty.call(payload, missing[1])) {
          console.warn(`[RJSupabase.syncUserProfile] ${missing[1]} column missing on remote schema, retry without it`);
          const nextPayload = { ...payload };
          delete nextPayload[missing[1]];
          payload = nextPayload;
          continue;
        }
        if (/updated_at/i.test(msg)) {
          console.warn('[RJSupabase.syncUserProfile] remote schema rejected updated_at-dependent upsert, retry minimal avatar/profile payload');
          payload = Object.fromEntries(Object.entries(payload).filter(([k, v]) => k === 'user_id' || k === 'avatar' || (v !== null && v !== '' && !(Array.isArray(v) && !v.length))));
          continue;
        }
        throw error;
      }
    }
    throw new Error('syncUserProfile failed after schema fallback retries');
  }

  async function syncTrip(trip) {
    const userId = await ensureUser(trip.user);
    if (!userId || !trip?.id) return;
    const payload = {
      id: trip.id,
      user_id: userId,
      destination: trip.destination || '未知目的地',
      depart_date: trip.departDate || null,
      return_date: trip.returnDate || null,
      budget: Number(trip.budget || 0),
      tags: Array.isArray(trip.tags) ? trip.tags : [],
      spots: Array.isArray(trip.spots) ? trip.spots : [],
      itinerary: trip.itinerary || '',
      pace: trip.pace || null,
      wake_up: trip.wakeUp || null,
      social: trip.social || null,
      countries: Array.isArray(trip.countries) ? trip.countries : [],
      badges: Array.isArray(trip.badges) ? trip.badges : [],
      review: trip.review || { score: 5.0, count: 1, highlights: [] },
      trust: trip.trust || { score: 4.5, completion: 90, verified: false },
      like_count: Number(trip.likeCount || 0),
      created_at: trip.createdAt || new Date().toISOString()
    };
    await request('trips', {
      method: 'POST',
      body: JSON.stringify(payload),
      headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
    });
  }

  async function syncTripLike(tripId, nickname, liked) {
    if (!tripId || !nickname) return;
    const userId = await ensureUser(nickname);
    if (!userId) return;
    const filter = `trip_id=eq.${encodeURIComponent(tripId)}&user_id=eq.${encodeURIComponent(userId)}`;
    if (liked) {
      await request('trip_likes', {
        method: 'POST',
        body: JSON.stringify({ trip_id: tripId, user_id: userId }),
        headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
      });
    } else {
      await request(`trip_likes?${filter}`, {
        method: 'DELETE',
        headers: { Prefer: 'return=minimal' }
      });
    }
  }

  async function syncTripComment(tripId, comment) {
    if (!tripId || !comment?.id) return;
    const userId = await ensureUser(comment.user);
    if (!userId) return;
    await request('trip_comments', {
      method: 'POST',
      body: JSON.stringify({
        id: comment.id,
        trip_id: tripId,
        user_id: userId,
        reply_to_nickname: comment.replyTo || null,
        parent_comment_id: comment.parentCommentId || null,
        content: comment.text || '',
        pinned: Boolean(comment.pinned),
        created_at: comment.createdAt || new Date().toISOString()
      }),
      headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
    });
  }

  async function fetchRowsByIds(table, column, ids, select) {
    const source = Array.isArray(ids) ? ids.map((id) => String(id || '').trim()).filter(Boolean) : [];
    if (!source.length) return [];
    const unique = [...new Set(source)];
    const chunks = [];
    for (let i = 0; i < unique.length; i += 50) chunks.push(unique.slice(i, i + 50));
    const rows = [];
    for (const chunk of chunks) {
      const filter = `${column}=in.(${chunk.map((value) => encodeURIComponent(value)).join(',')})`;
      const result = await request(`${table}?select=${select}&${filter}`, { method: 'GET' });
      if (Array.isArray(result)) rows.push(...result);
    }
    return rows;
  }

  function buildUserLookup(users = []) {
    const byId = new Map();
    users.forEach((row) => {
      if (!row?.id) return;
      byId.set(String(row.id), row);
    });
    return byId;
  }

  async function fetchPublicTrips() {
    const trips = await request('trips?select=id,user_id,destination,depart_date,return_date,budget,tags,spots,itinerary,pace,wake_up,social,countries,badges,review,trust,like_count,created_at&order=created_at.desc', {
      method: 'GET'
    });
    const tripRows = Array.isArray(trips) ? trips : [];
    if (!tripRows.length) return [];

    const authorIds = tripRows.map((row) => row.user_id).filter(Boolean);
    const likes = await fetchRowsByIds('trip_likes', 'trip_id', tripRows.map((row) => row.id), 'trip_id,user_id,created_at');
    const comments = await fetchRowsByIds('trip_comments', 'trip_id', tripRows.map((row) => row.id), 'id,trip_id,user_id,parent_comment_id,reply_to_nickname,content,pinned,created_at');
    const commentLikes = await fetchRowsByIds('trip_comment_likes', 'comment_id', comments.map((row) => row.id), 'comment_id,user_id,created_at');

    const userIds = new Set(authorIds);
    likes.forEach((row) => row?.user_id && userIds.add(row.user_id));
    comments.forEach((row) => row?.user_id && userIds.add(row.user_id));
    commentLikes.forEach((row) => row?.user_id && userIds.add(row.user_id));

    const users = await fetchRowsByIds('app_users', 'id', [...userIds], 'id,nickname');
    const profiles = await fetchRowsByIds('user_profiles', 'user_id', authorIds, 'user_id,avatar,skills,bio,birthday,mbti,zodiac,pace,budget_level,wake_up,social');

    const userById = buildUserLookup(users);
    const profileByUserId = new Map();
    profiles.forEach((row) => {
      if (!row?.user_id) return;
      profileByUserId.set(String(row.user_id), row);
    });

    const likesByTrip = new Map();
    likes.forEach((row) => {
      const key = String(row?.trip_id || '');
      if (!key) return;
      const list = likesByTrip.get(key) || [];
      const liker = userById.get(String(row.user_id || ''));
      if (liker?.nickname) list.push(liker.nickname);
      likesByTrip.set(key, list);
    });

    const commentLikesByComment = new Map();
    commentLikes.forEach((row) => {
      const key = String(row?.comment_id || '');
      if (!key) return;
      const list = commentLikesByComment.get(key) || [];
      const liker = userById.get(String(row.user_id || ''));
      if (liker?.nickname && !list.includes(liker.nickname)) list.push(liker.nickname);
      commentLikesByComment.set(key, list);
    });

    const commentsByTrip = new Map();
    comments.forEach((row) => {
      const key = String(row?.trip_id || '');
      if (!key) return;
      const list = commentsByTrip.get(key) || [];
      const commenter = userById.get(String(row.user_id || ''));
      list.push({
        id: row.id,
        dbCommentId: row.id,
        user: commenter?.nickname || '未知用户',
        text: row.content || '',
        parentCommentId: row.parent_comment_id || '',
        replyTo: row.reply_to_nickname || '',
        pinned: Boolean(row.pinned),
        batchId: row.id,
        createdAt: row.created_at || new Date().toISOString(),
        likes: commentLikesByComment.get(String(row.id)) || []
      });
      commentsByTrip.set(key, list);
    });

    return tripRows.map((row) => {
      const author = userById.get(String(row.user_id || '')) || {};
      const profile = profileByUserId.get(String(row.user_id || '')) || {};
      const tripLikes = likesByTrip.get(String(row.id)) || [];
      const tripComments = (commentsByTrip.get(String(row.id)) || []).sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
      return {
        id: row.id,
        user: author.nickname || '未知用户',
        avatar: profile.avatar || null,
        destination: row.destination || '未知目的地',
        departDate: row.depart_date || null,
        returnDate: row.return_date || null,
        budget: Number(row.budget || 0),
        tags: Array.isArray(row.tags) ? row.tags : [],
        spots: Array.isArray(row.spots) ? row.spots : [],
        itinerary: row.itinerary || '',
        pace: row.pace || null,
        wakeUp: row.wake_up || null,
        social: row.social || null,
        countries: Array.isArray(row.countries) ? row.countries : [],
        badges: Array.isArray(row.badges) ? row.badges : [],
        review: row.review || { score: 5.0, count: 1, highlights: [] },
        trust: row.trust || { score: 4.5, completion: 90, verified: false },
        likes: tripLikes,
        likeCount: Number(row.like_count || tripLikes.length || 0),
        comments: tripComments,
        ownerSkills: Array.isArray(profile.skills) ? profile.skills : [],
        ownerBadges: Array.isArray(row.badges) ? row.badges : [],
        batchId: row.batch_id || row.id,
        createdAt: row.created_at || new Date().toISOString(),
        source: 'supabase'
      };
    });
  }

  async function syncMediaPost(post) {
    if (!post?.id) throw new Error('post.id is required');

    const userId = await ensureUser(post.user);
    if (!userId) throw new Error('cannot resolve user_id for media post');

    const headers = { Prefer: 'resolution=merge-duplicates,return=minimal' };
    let payload = {
      id: post.id,
      user_id: userId,
      media_type: post.type || '图片',
      location: post.location || null,
      cover: post.cover || null,
      caption: post.caption || null,
      checkin: post.checkin || null,
      batch_id: post.batchId || post.id,
      created_at: post.createdAt || new Date().toISOString(),
      updated_at: new Date().toISOString(),
      deleted_at: null
    };

    const tryPost = async (body) => {
      return request('media_posts?on_conflict=id', {
        method: 'POST',
        body: JSON.stringify(body),
        headers
      });
    };

    for (let attempt = 0; attempt < 6; attempt += 1) {
      try {
        await tryPost(payload);
        mediaPostsSyncDisabled = false;
        return {
          ...post,
          dbPostId: post.id
        };
      } catch (error) {
        const msg = String(error?.message || error || '');
        const missing = msg.match(/Could not find the '([^']+)' column/i);

        if (missing?.[1] && Object.prototype.hasOwnProperty.call(payload, missing[1])) {
          console.warn(`[RJSupabase.syncMediaPost] column missing on remote schema: ${missing[1]}, retry without it`);
          const nextPayload = { ...payload };
          delete nextPayload[missing[1]];
          payload = nextPayload;
          continue;
        }

        throw error;
      }
    }

    throw new Error('syncMediaPost failed after schema fallback retries');
  }

  async function syncMediaLike(mediaPostId, nickname, liked) {
    if (!mediaPostId || !nickname) return;
    const userId = await ensureUser(nickname);
    if (!userId) return;
    const filter = `media_post_id=eq.${encodeURIComponent(mediaPostId)}&user_id=eq.${encodeURIComponent(userId)}`;
    if (liked) {
      await request('media_likes', {
        method: 'POST',
        body: JSON.stringify({ media_post_id: mediaPostId, user_id: userId }),
        headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
      });
    } else {
      await request(`media_likes?${filter}`, {
        method: 'DELETE',
        headers: { Prefer: 'return=minimal' }
      });
    }
  }

  async function syncMediaComment(mediaPostId, comment) {
    if (!mediaPostId || !comment?.id) return;
    const userId = await ensureUser(comment.user);
    if (!userId) return;
    await request('media_comments', {
      method: 'POST',
      body: JSON.stringify({
        id: comment.id,
        media_post_id: mediaPostId,
        user_id: userId,
        reply_to_nickname: comment.replyTo || null,
        parent_comment_id: comment.parentCommentId || null,
        content: comment.text || '',
        pinned: Boolean(comment.pinned),
        created_at: comment.createdAt || new Date().toISOString()
      }),
      headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
    });
  }

  async function deleteTrip(tripId) {
    if (!tripId) return;
    await request(`trips?id=eq.${encodeURIComponent(tripId)}`, {
      method: 'DELETE',
      headers: { Prefer: 'return=minimal' }
    });
  }

  async function deleteMediaPost(mediaPostId) {
    if (!mediaPostId || mediaPostsSyncDisabled) return;
    const encodedId = encodeURIComponent(mediaPostId);
    try {
      await request(`media_posts?id=eq.${encodedId}`, {
        method: 'PATCH',
        body: JSON.stringify({
          deleted_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }),
        headers: { Prefer: 'return=minimal' }
      });
      return;
    } catch (err) {
      const message = String(err?.message || err || '');
      const missing = message.match(/Could not find the '([^']+)' column/i);
      if (missing?.[1] === 'deleted_at') {
        await request(`media_posts?id=eq.${encodedId}`, {
          method: 'DELETE',
          headers: { Prefer: 'return=minimal' }
        });
        return;
      }
      if (message.includes('updated_at')) {
        await request(`media_posts?id=eq.${encodedId}`, {
          method: 'PATCH',
          body: JSON.stringify({
            deleted_at: new Date().toISOString()
          }),
          headers: { Prefer: 'return=minimal' }
        });
        return;
      }
      throw err;
    }
  }

  async function syncChat(chat, creatorNickname) {
    if (!chat?.id) return;
    const isGroup = Boolean(chat.isGroup) || String(chat.type || '').toLowerCase() === 'group' || Boolean(String(chat.name || '').trim());
    const creatorId = await ensureUser(creatorNickname || chat.owner || chat.members?.[0]);
    await request('chats', {
      method: 'POST',
      body: JSON.stringify({
        id: chat.id,
        chat_type: isGroup ? 'group' : 'dm',
        name: isGroup ? (String(chat.name || '').trim() || null) : null,
        created_by: creatorId || null
      }),
      headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
    });

    const members = [...new Set((Array.isArray(chat.members) ? chat.members : []).map((x) => String(x || '').trim()).filter(Boolean))];
    for (const nickname of members) {
      const userId = await ensureUser(nickname);
      if (!userId) continue;
      await request('chat_members', {
        method: 'POST',
        body: JSON.stringify({ chat_id: chat.id, user_id: userId }),
        headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
      });
    }

    const messages = Array.isArray(chat.messages) ? chat.messages : [];
    for (const msg of messages) {
      const senderNickname = msg.type === 'system'
        ? (msg.from || creatorNickname || chat.owner || chat.members?.[0])
        : (msg.from || msg.sender || creatorNickname || chat.members?.[0]);
      const payloadText = msg.type === 'system'
        ? `[SYSTEM] ${msg.text || ''}`
        : (msg.text || '');
      await syncChatMessage(chat.id, senderNickname, payloadText, msg.createdAt, msg.id);
    }
  }

  async function syncChatMessage(chatId, senderNickname, content, createdAt, messageId) {
    if (!chatId || !senderNickname || !content) return;
    const senderId = await ensureUser(senderNickname);
    if (!senderId) return;
    await request('chat_messages', {
      method: 'POST',
      body: JSON.stringify({
        id: messageId || undefined,
        chat_id: chatId,
        sender_id: senderId,
        content,
        created_at: createdAt || new Date().toISOString()
      }),
      headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
    });
  }

  async function syncFollow(actorNickname, targetNickname, following) {
    const actorId = await ensureUser(actorNickname);
    const targetId = await ensureUser(targetNickname);
    if (!actorId || !targetId) return;
    const filter = `follower_id=eq.${encodeURIComponent(actorId)}&followee_id=eq.${encodeURIComponent(targetId)}`;
    if (following) {
      await request('user_follows', {
        method: 'POST',
        body: JSON.stringify({ follower_id: actorId, followee_id: targetId }),
        headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
      });
    } else {
      await request(`user_follows?${filter}`, { method: 'DELETE', headers: { Prefer: 'return=minimal' } });
    }
  }

  async function syncBlock(actorNickname, targetNickname, blocked) {
    const actorId = await ensureUser(actorNickname);
    const targetId = await ensureUser(targetNickname);
    if (!actorId || !targetId) return;
    const filter = `blocker_id=eq.${encodeURIComponent(actorId)}&blocked_id=eq.${encodeURIComponent(targetId)}`;
    if (blocked) {
      await request('user_blocks', {
        method: 'POST',
        body: JSON.stringify({ blocker_id: actorId, blocked_id: targetId }),
        headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
      });
    } else {
      await request(`user_blocks?${filter}`, { method: 'DELETE', headers: { Prefer: 'return=minimal' } });
    }
  }

  async function syncTripCommentLike(commentId, nickname, liked) {
    if (!commentId || !nickname) return;
    const userId = await ensureUser(nickname);
    if (!userId) return;
    const filter = `comment_id=eq.${encodeURIComponent(commentId)}&user_id=eq.${encodeURIComponent(userId)}`;
    if (liked) {
      await request('trip_comment_likes', {
        method: 'POST',
        body: JSON.stringify({ comment_id: commentId, user_id: userId }),
        headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
      });
    } else {
      await request(`trip_comment_likes?${filter}`, { method: 'DELETE', headers: { Prefer: 'return=minimal' } });
    }
  }

  async function syncMediaCommentLike(commentId, nickname, liked) {
    if (!commentId || !nickname) return;
    const userId = await ensureUser(nickname);
    if (!userId) return;
    const filter = `comment_id=eq.${encodeURIComponent(commentId)}&user_id=eq.${encodeURIComponent(userId)}`;
    if (liked) {
      await request('media_comment_likes', {
        method: 'POST',
        body: JSON.stringify({ comment_id: commentId, user_id: userId }),
        headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
      });
    } else {
      await request(`media_comment_likes?${filter}`, { method: 'DELETE', headers: { Prefer: 'return=minimal' } });
    }
  }

  async function syncNoticeState(nickname, noticeState = {}, chats = []) {
    if (!nickname) return;
    const userId = await ensureUser(nickname);
    if (!userId) return;
    const rows = [{
      user_id: userId,
      scope: 'notifications',
      last_read_at: noticeState.systemReadAt || new Date().toISOString()
    }];
    (Array.isArray(chats) ? chats : []).forEach((chat) => {
      if (!chat?.id) return;
      rows.push({
        user_id: userId,
        scope: `chat:${chat.id}`,
        last_read_at: noticeState.chatReadAt?.[chat.id] || new Date().toISOString()
      });
    });
    await request('user_read_state', {
      method: 'POST',
      body: JSON.stringify(rows),
      headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
    });
  }

  async function syncAdminEvent(eventType, payload = {}, createdAt) {
    if (!eventType) return;
    const actorNickname = payload.user || payload.from || payload.actor || null;
    const userId = actorNickname ? await ensureUser(actorNickname).catch(() => null) : null;
    await request('admin_events', {
      method: 'POST',
      body: JSON.stringify({
        event_type: eventType,
        payload,
        user_id: userId || null,
        user_nickname: actorNickname,
        created_at: createdAt || new Date().toISOString()
      }),
      headers: { Prefer: 'return=minimal' }
    });
  }





  async function deleteMediaComment(commentId) {
    if (!commentId) return;
    await restoreSupabaseSession();
    const { session } = await getCurrentAuthContext('supabase-delete-comment', { force: true });
    if (!session?.access_token) {
      throw new Error('当前未登录 Supabase，无法删除评论');
    }

    const encoded = encodeURIComponent(commentId);

    await request(`media_comment_likes?comment_id=eq.${encoded}`, {
      method: 'DELETE',
      headers: { Prefer: 'return=minimal' }
    }).catch((error) => {
      console.warn('[RJSupabase.deleteMediaComment] delete comment likes failed', error?.message || error);
    });

    await request(`media_comments?id=eq.${encoded}`, {
      method: 'DELETE',
      headers: { Prefer: 'return=minimal' }
    });

    const remain = await request(`media_comments?id=eq.${encoded}&select=id&limit=1`, {
      method: 'GET'
    }).catch(() => []);
    if (Array.isArray(remain) && remain.length) {
      throw new Error('评论删除未生效，请检查 Supabase 外键约束或删除策略');
    }
  }

  async function fetchProfilesByUserIds(userIds = []) {
    const ids = [...new Set((Array.isArray(userIds) ? userIds : []).map((id) => String(id || '').trim()).filter(Boolean))];
    if (!ids.length) return [];
    const chunks = [];
    for (let i = 0; i < ids.length; i += 50) chunks.push(ids.slice(i, i + 50));
    const baseColumns = ['user_id','avatar','birthday','mbti','zodiac','pace','budget_level','wake_up','social','skills','bio'];
    const rows = [];
    for (const chunk of chunks) {
      let columns = [...baseColumns];
      for (let attempt = 0; attempt < baseColumns.length; attempt += 1) {
        const filter = `user_id=in.(${chunk.map((value) => encodeURIComponent(value)).join(',')})`;
        try {
          const result = await request(`user_profiles?select=${columns.join(',')}&${filter}`, { method: 'GET' });
          if (Array.isArray(result)) rows.push(...result);
          break;
        } catch (error) {
          const msg = String(error?.message || '');
          const missing = msg.match(/Could not find the '([^']+)' column/i);
          if (missing?.[1] && columns.includes(missing[1])) {
            columns = columns.filter((col) => col !== missing[1]);
            continue;
          }
          throw error;
        }
      }
    }
    return rows;
  }

  async function fetchPublicUsers() {
    const users = await request('app_users?select=id,nickname,created_at&order=created_at.asc', { method: 'GET' });
    const userRows = Array.isArray(users) ? users : [];
    if (!userRows.length) return [];
    const profiles = await fetchProfilesByUserIds(userRows.map((row) => row.id));
    const profileByUserId = new Map();
    profiles.forEach((row) => {
      if (!row?.user_id) return;
      profileByUserId.set(String(row.user_id), row);
    });
    return userRows.map((row) => {
      const profile = profileByUserId.get(String(row.id)) || {};
      return {
        id: row.id,
        nickname: row.nickname || '',
        createdAt: row.created_at || null,
        profile: {
          avatar: profile.avatar || null,
          birthday: profile.birthday || '',
          mbti: profile.mbti || '',
          zodiac: profile.zodiac || '',
          pace: profile.pace || '',
          budgetLevel: profile.budget_level || '',
          wakeUp: profile.wake_up || '',
          social: profile.social || '',
          skills: Array.isArray(profile.skills) ? profile.skills : [],
          bio: profile.bio || ''
        }
      };
    });
  }

  async function fetchPublicDiaries() {
    const posts = await request('media_posts?deleted_at=is.null&select=id,user_id,media_type,location,cover,caption,checkin,batch_id,created_at&order=created_at.desc', {
      method: 'GET'
    });
    const mediaRows = Array.isArray(posts) ? posts : [];
    if (!mediaRows.length) return [];

    const batchKeys = mediaRows.map((row) => String(row?.batch_id || row?.id || '')).filter(Boolean);
    const allBatchRows = batchKeys.length
      ? await fetchRowsByIds('media_posts', 'batch_id', batchKeys, 'id,batch_id,deleted_at,created_at')
      : [];

    const relatedPostIdsByBatch = new Map();
    mediaRows.forEach((row) => {
      const key = String(row?.batch_id || row?.id || '');
      if (!key) return;
      const list = relatedPostIdsByBatch.get(key) || [];
      if (row?.id && !list.includes(row.id)) list.push(row.id);
      relatedPostIdsByBatch.set(key, list);
    });
    (Array.isArray(allBatchRows) ? allBatchRows : []).forEach((row) => {
      const key = String(row?.batch_id || '');
      if (!key) return;
      const list = relatedPostIdsByBatch.get(key) || [];
      if (row?.id && !list.includes(row.id)) list.push(row.id);
      relatedPostIdsByBatch.set(key, list);
    });

    const relatedPostIds = [...new Set(Array.from(relatedPostIdsByBatch.values()).flat().filter(Boolean))];
    const userIds = new Set(mediaRows.map((row) => row.user_id).filter(Boolean));

    const likes = await fetchRowsByIds('media_likes', 'media_post_id', relatedPostIds, 'media_post_id,user_id,created_at');
    const comments = await fetchRowsByIds('media_comments', 'media_post_id', relatedPostIds, 'id,media_post_id,user_id,parent_comment_id,reply_to_nickname,content,pinned,created_at');
    const commentIds = comments.map((row) => row?.id).filter(Boolean);
    const commentLikes = commentIds.length
      ? await fetchRowsByIds('media_comment_likes', 'comment_id', commentIds, 'comment_id,user_id,created_at')
      : [];
    likes.forEach((row) => row?.user_id && userIds.add(row.user_id));
    comments.forEach((row) => row?.user_id && userIds.add(row.user_id));
    commentLikes.forEach((row) => row?.user_id && userIds.add(row.user_id));

    const users = await fetchRowsByIds('app_users', 'id', [...userIds], 'id,nickname');
    const profiles = await fetchProfilesByUserIds(mediaRows.map((row) => row.user_id).filter(Boolean));

    const userById = buildUserLookup(users);
    const profileByUserId = new Map();
    profiles.forEach((row) => {
      if (!row?.user_id) return;
      profileByUserId.set(String(row.user_id), row);
    });

    const likesByPost = new Map();
    likes.forEach((row) => {
      const key = String(row?.media_post_id || '');
      if (!key) return;
      const list = likesByPost.get(key) || [];
      const liker = userById.get(String(row.user_id || ''));
      if (liker?.nickname && !list.includes(liker.nickname)) list.push(liker.nickname);
      likesByPost.set(key, list);
    });

    const commentLikesByComment = new Map();
    commentLikes.forEach((row) => {
      const key = String(row?.comment_id || '');
      if (!key) return;
      const list = commentLikesByComment.get(key) || [];
      const liker = userById.get(String(row.user_id || ''));
      if (liker?.nickname && !list.includes(liker.nickname)) list.push(liker.nickname);
      commentLikesByComment.set(key, list);
    });

    const commentsByPost = new Map();
    comments.forEach((row) => {
      const key = String(row?.media_post_id || '');
      if (!key) return;
      const list = commentsByPost.get(key) || [];
      const commenter = userById.get(String(row.user_id || ''));
      list.push({
        id: row.id,
        dbCommentId: row.id,
        mediaPostId: row.media_post_id,
        user: commenter?.nickname || '未知用户',
        text: row.content || '',
        parentCommentId: row.parent_comment_id || '',
        replyTo: row.reply_to_nickname || '',
        pinned: Boolean(row.pinned),
        createdAt: row.created_at || new Date().toISOString(),
        likes: commentLikesByComment.get(String(row.id)) || []
      });
      commentsByPost.set(key, list);
    });

    const rowsWithRelations = mediaRows.map((row) => {
      const author = userById.get(String(row.user_id || '')) || {};
      const profile = profileByUserId.get(String(row.user_id || '')) || {};
      return {
        id: row.id,
        dbPostId: row.id,
        user: author.nickname || '未知用户',
        type: row.media_type || '图片',
        location: row.location || '',
        cover: row.cover || '',
        caption: row.caption || '',
        checkin: row.checkin || '',
        batchId: row.batch_id || row.id,
        createdAt: row.created_at || new Date().toISOString(),
        likes: likesByPost.get(String(row.id)) || [],
        comments: (commentsByPost.get(String(row.id)) || []).sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0)),
        avatar: profile.avatar || null,
        source: 'supabase'
      };
    });

    const groups = new Map();
    rowsWithRelations.forEach((row) => {
      const key = String(row.batchId || row.id || '');
      const list = groups.get(key) || [];
      list.push(row);
      groups.set(key, list);
    });

    return Array.from(groups.entries())
      .map(([groupKey, group]) => {
        const sorted = group.slice().sort((a, b) => new Date(a.createdAt || 0) - new Date(b.createdAt || 0));
        const primary = sorted[0] || group[0] || {};
        const latest = sorted[sorted.length - 1] || primary;
        const images = sorted.map((row) => row.cover).filter(Boolean);
        const relatedIds = relatedPostIdsByBatch.get(String(groupKey || primary.batchId || primary.id || '')) || sorted.map((row) => row.id).filter(Boolean);
        const likes = [...new Set(relatedIds.flatMap((postId) => Array.isArray(likesByPost.get(String(postId))) ? likesByPost.get(String(postId)) : []))];
        const commentMap = new Map();
        relatedIds.forEach((postId) => {
          (Array.isArray(commentsByPost.get(String(postId))) ? commentsByPost.get(String(postId)) : []).forEach((comment) => {
            const key = String(comment?.dbCommentId || comment?.id || '');
            if (!key || commentMap.has(key)) return;
            commentMap.set(key, {
              ...comment,
              likes: [...new Set(Array.isArray(comment.likes) ? comment.likes : [])]
            });
          });
        });
        const mergedComments = Array.from(commentMap.values())
          .sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
        return {
          ...primary,
          caption: String(primary.caption || '').replace(/\s·\s\d+(?:\s·\s\d+)*$/, '').trim(),
          checkin: primary.checkin || latest.checkin || '',
          images,
          covers: images,
          imageCount: images.length,
          mediaPostIds: sorted.map((row) => row.id).filter(Boolean),
          allMediaPostIds: relatedIds.slice(),
          likes,
          comments: mergedComments,
          basePostId: primary.id,
          dbPostId: primary.id,
          createdAt: primary.createdAt || latest.createdAt || new Date().toISOString(),
          updatedAt: latest.createdAt || primary.createdAt || new Date().toISOString(),
          source: 'supabase'
        };
      })
      .sort((a, b) => new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0));
  }

  async function fetchPublicSocialGraph() {
    const follows = await request('user_follows?select=follower_id,followee_id', { method: 'GET' });
    const blocks = await request('user_blocks?select=blocker_id,blocked_id', { method: 'GET' });

    const userIds = new Set();
    (Array.isArray(follows) ? follows : []).forEach((row) => {
      row?.follower_id && userIds.add(row.follower_id);
      row?.followee_id && userIds.add(row.followee_id);
    });
    (Array.isArray(blocks) ? blocks : []).forEach((row) => {
      row?.blocker_id && userIds.add(row.blocker_id);
      row?.blocked_id && userIds.add(row.blocked_id);
    });

    const users = await fetchRowsByIds('app_users', 'id', [...userIds], 'id,nickname');
    const userById = buildUserLookup(users);

    const followMap = {};
    (Array.isArray(follows) ? follows : []).forEach((row) => {
      const from = userById.get(String(row.follower_id || ''))?.nickname;
      const to = userById.get(String(row.followee_id || ''))?.nickname;
      if (!from || !to) return;
      followMap[from] = followMap[from] || [];
      if (!followMap[from].includes(to)) followMap[from].push(to);
    });

    const blockMap = {};
    (Array.isArray(blocks) ? blocks : []).forEach((row) => {
      const from = userById.get(String(row.blocker_id || ''))?.nickname;
      const to = userById.get(String(row.blocked_id || ''))?.nickname;
      if (!from || !to) return;
      blockMap[from] = blockMap[from] || [];
      if (!blockMap[from].includes(to)) blockMap[from].push(to);
    });

    return { follows: followMap, blocks: blockMap };
  }


  async function fetchChatsForUser(nickname) {
    const user = await findUserByNickname(nickname);
    if (!user?.id) return [];
    const memberships = await request(`chat_members?user_id=eq.${encodeURIComponent(user.id)}&select=chat_id`, { method: 'GET' });
    const chatIds = [...new Set((Array.isArray(memberships) ? memberships : []).map((row) => row?.chat_id).filter(Boolean))];
    if (!chatIds.length) return [];

    const chats = await fetchRowsByIds('chats', 'id', chatIds, 'id,chat_type,name,created_by,created_at');
    const members = await fetchRowsByIds('chat_members', 'chat_id', chatIds, 'chat_id,user_id');
    const messages = await fetchRowsByIds('chat_messages', 'chat_id', chatIds, 'id,chat_id,sender_id,content,created_at');

    const userIds = new Set();
    chats.forEach((row) => row?.created_by && userIds.add(row.created_by));
    members.forEach((row) => row?.user_id && userIds.add(row.user_id));
    messages.forEach((row) => row?.sender_id && userIds.add(row.sender_id));

    const users = await fetchRowsByIds('app_users', 'id', [...userIds], 'id,nickname');
    const userById = buildUserLookup(users);

    const membersByChat = new Map();
    members.forEach((row) => {
      const key = String(row?.chat_id || '');
      if (!key) return;
      const nickname = userById.get(String(row.user_id || ''))?.nickname;
      if (!nickname) return;
      const list = membersByChat.get(key) || [];
      if (!list.includes(nickname)) list.push(nickname);
      membersByChat.set(key, list);
    });

    const messagesByChat = new Map();
    messages
      .sort((a, b) => new Date(a?.created_at || 0) - new Date(b?.created_at || 0))
      .forEach((row) => {
        const key = String(row?.chat_id || '');
        if (!key) return;
        const from = userById.get(String(row.sender_id || ''))?.nickname;
        const list = messagesByChat.get(key) || [];
        const rawText = String(row.content || '');
        const isSystem = rawText.startsWith('[SYSTEM] ');
        list.push({
          id: row.id,
          from: from || '',
          type: isSystem ? 'system' : 'text',
          text: isSystem ? rawText.replace(/^\[SYSTEM\]\s*/, '') : rawText,
          createdAt: row.created_at || new Date().toISOString()
        });
        messagesByChat.set(key, list);
      });

    const groupNames = new Set(
      (Array.isArray(chats) ? chats : [])
        .filter((chat) => (chat?.chat_type || '') === 'group' && String(chat?.name || '').trim())
        .map((chat) => String(chat.name || '').trim())
    );

    return (Array.isArray(chats) ? chats : [])
      .map((chat) => {
        const members = membersByChat.get(String(chat.id)) || [];
        const owner = userById.get(String(chat.created_by || ''))?.nickname || '';
        return {
          id: chat.id,
          name: chat.name || '',
          isGroup: (chat.chat_type || '') === 'group',
          type: (chat.chat_type || '') === 'group' ? 'group' : 'dm',
          owner,
          members,
          messages: messagesByChat.get(String(chat.id)) || [],
          createdAt: chat.created_at || new Date().toISOString()
        };
      })
      .filter((chat) => {
        if (chat.type === 'group') return Boolean(String(chat.name || '').trim());
        const members = Array.isArray(chat.members) ? chat.members.filter(Boolean) : [];
        if (members.length !== 2) return false;
        return !members.some((name) => groupNames.has(String(name || '').trim()));
      });
  }

  async function leaveChat(chatId, nickname, systemText = '') {
    const userId = await ensureUser(nickname);
    if (!chatId || !userId) return;
    const text = String(systemText || '').trim();
    if (text) {
      await request('chat_messages', {
        method: 'POST',
        body: JSON.stringify({
          id: crypto.randomUUID(),
          chat_id: chatId,
          sender_id: userId,
          content: `[SYSTEM] ${text}`,
          created_at: new Date().toISOString()
        }),
        headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
      });
    }
    await request(`chat_members?chat_id=eq.${encodeURIComponent(chatId)}&user_id=eq.${encodeURIComponent(userId)}`, {
      method: 'DELETE',
      headers: { Prefer: 'return=minimal' }
    });
  }

  async function deleteCurrentAccount(options = {}) {
    const nickname = String(options?.nickname || '').trim();
    const reason = String(options?.reason || '').trim();
    if (!nickname) throw new Error('缺少当前账号昵称，无法删除');

    const ctx = await getCurrentAuthContext('supabase-delete-account', { force: true });
    if (!ctx?.session?.access_token) {
      throw new Error('当前未登录 Supabase 或登录态已失效，请重新登录后再试');
    }

    const endpoint = String(global.APP_CONFIG?.DELETE_ACCOUNT_ENDPOINT || global.APP_CONFIG?.ACCOUNT_DELETE_ENDPOINT || '/api/account/delete').trim();
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${ctx.session.access_token}`
      },
      body: JSON.stringify({ nickname, reason })
    });

    let payload = null;
    try { payload = await response.json(); } catch {}
    if (!response.ok) {
      throw new Error(payload?.error || payload?.message || `删除账号接口失败（${response.status}）`);
    }

    authContextCache = { expiresAt: 0, value: null };
    return payload || { ok: true };
  }


  async function logTripBillEvent(billId, actorNickname, eventType, payload = {}, itemId = null) {
    if (!billId || !actorNickname || !eventType) return;
    const actorId = await ensureUser(actorNickname);
    if (!actorId) return;
    await request('trip_bill_events', {
      method: 'POST',
      body: JSON.stringify({
        bill_id: billId,
        item_id: itemId || null,
        actor_id: actorId,
        event_type: eventType,
        payload: payload && typeof payload === 'object' ? payload : {}
      }),
      headers: { Prefer: 'return=representation' }
    });
  }

  async function createTripBill(payload) {
    if (!payload?.tripId || !payload?.creatorNickname) throw new Error('tripId and creatorNickname are required');
    const creatorId = await ensureUser(payload.creatorNickname);
    if (!creatorId) throw new Error('cannot resolve creator');
    const billId = payload.id || crypto.randomUUID();
    await request('trip_bills?on_conflict=id', {
      method: 'POST',
      body: JSON.stringify({
        id: billId,
        trip_id: payload.tripId,
        created_by: creatorId,
        title: payload.title || '行程账单',
        base_currency: payload.baseCurrency || 'CNY',
        linked_chat_id: payload.linkedChatId || null,
        status: payload.status || 'active'
      }),
      headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
    });

    const names = [...new Set([payload.creatorNickname, ...((Array.isArray(payload.memberNicknames) ? payload.memberNicknames : []).filter(Boolean))])];
    for (const nickname of names) {
      const userId = await ensureUser(nickname);
      if (!userId) continue;
      await request('trip_bill_members', {
        method: 'POST',
        body: JSON.stringify({
          bill_id: billId,
          user_id: userId,
          role: nickname === payload.creatorNickname ? 'owner' : 'member',
          member_status: 'active',
          invited_by: creatorId
        }),
        headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
      });
    }

    await logTripBillEvent(billId, payload.creatorNickname, 'bill_created', {
      title: payload.title || '行程账单',
      memberNicknames: names,
      linkedChatId: payload.linkedChatId || null
    });

    return fetchTripBillDetail(billId);
  }

  async function addTripBillMembers(billId, memberNicknames, invitedByNickname) {
    if (!billId || !Array.isArray(memberNicknames) || !memberNicknames.length || !invitedByNickname) return [];
    const inviterId = await ensureUser(invitedByNickname);
    if (!inviterId) return [];
    const added = [];
    for (const nickname of [...new Set(memberNicknames.filter(Boolean))]) {
      const userId = await ensureUser(nickname);
      if (!userId) continue;
      await request('trip_bill_members', {
        method: 'POST',
        body: JSON.stringify({
          bill_id: billId,
          user_id: userId,
          role: 'member',
          member_status: 'active',
          invited_by: inviterId
        }),
        headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
      });
      added.push(nickname);
    }
    if (added.length) {
      await logTripBillEvent(billId, invitedByNickname, 'members_invited', { memberNicknames: added });
    }
    return added;
  }

  async function updateTripBill(billId, payload = {}, actorNickname = '') {
    if (!billId) throw new Error('billId is required');
    const patch = {};
    if (Object.prototype.hasOwnProperty.call(payload, 'title')) patch.title = payload.title || '行程账单';
    if (Object.prototype.hasOwnProperty.call(payload, 'baseCurrency')) patch.base_currency = payload.baseCurrency || 'CNY';
    if (Object.prototype.hasOwnProperty.call(payload, 'linkedChatId')) patch.linked_chat_id = payload.linkedChatId || null;
    if (Object.prototype.hasOwnProperty.call(payload, 'status')) patch.status = payload.status || 'active';
    if (Object.keys(patch).length) {
      await request(`trip_bills?id=eq.${encodeURIComponent(billId)}`, {
        method: 'PATCH',
        body: JSON.stringify(patch),
        headers: { Prefer: 'return=minimal' }
      });
    }
    if (actorNickname) {
      await logTripBillEvent(billId, actorNickname, 'bill_updated', payload);
    }
    return fetchTripBillDetail(billId);
  }

  async function deleteTripBill(billId, actorUser) {
    if (!billId) throw new Error('billId is required');
    const actorRaw = String(actorUser || '').trim();
    if (!actorRaw) throw new Error('actorUser is required');

    let actorUserId = actorRaw;
    const uuidLike = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    if (!uuidLike.test(actorUserId)) {
      const foundUser = await findUserByNickname(actorRaw);
      actorUserId = String(foundUser?.id || '').trim();
    }
    if (!actorUserId) {
      throw new Error('未找到当前用户，无法删除账单');
    }

    const result = await request('rpc/delete_trip_bill_by_app_user', {
      method: 'POST',
      body: JSON.stringify({
        p_bill_id: billId,
        p_actor_user_id: actorUserId
      }),
      headers: { Prefer: 'return=representation' }
    });

    const payload = Array.isArray(result) ? result[0] : result;
    if (!payload || payload.success !== true) {
      throw new Error(payload?.message || '删除账单失败');
    }
    return payload;
  }


  function canNicknameAccessTripBill(currentNickname = '', createdBy = '', members = []) {
    const current = String(currentNickname || '').trim();
    if (!current) return false;
    const creator = String(createdBy || '').trim();
    if (creator && creator === current) return true;
    const list = Array.isArray(members) ? members : [];
    return list.some((member) => String(member?.nickname || '').trim() === current);
  }

  async function fetchTripBillsByTrip(tripId, currentNickname = '') {
    if (!tripId) return [];
    const rows = await request(`trip_bills?trip_id=eq.${encodeURIComponent(tripId)}&select=id,trip_id,title,base_currency,linked_chat_id,status,created_by,created_at,updated_at&order=created_at.desc`, { method: 'GET' });
    const bills = Array.isArray(rows) ? rows : [];
    if (!bills.length) return [];

    const billIds = bills.map((row) => row.id).filter(Boolean);
    const members = await fetchRowsByIds('trip_bill_members', 'bill_id', billIds, 'bill_id,user_id,role,member_status,invited_by,joined_at');
    const userIds = new Set();
    bills.forEach((row) => row?.created_by && userIds.add(row.created_by));
    members.forEach((row) => { if (row?.user_id) userIds.add(row.user_id); if (row?.invited_by) userIds.add(row.invited_by); });
    const users = await fetchRowsByIds('app_users', 'id', [...userIds], 'id,nickname');
    const userById = buildUserLookup(users);
    const membersByBill = new Map();
    members.forEach((row) => {
      const key = String(row?.bill_id || '');
      if (!key) return;
      const list = membersByBill.get(key) || [];
      const user = userById.get(String(row.user_id || ''));
      list.push({
        nickname: user?.nickname || '未知用户',
        role: row.role || 'member',
        status: row.member_status || 'active',
        joinedAt: row.joined_at || null
      });
      membersByBill.set(key, list);
    });

    const chats = await fetchRowsByIds('chats', 'id', bills.map((row) => row.linked_chat_id).filter(Boolean), 'id,name,chat_type');
    const chatById = new Map();
    chats.forEach((row) => row?.id && chatById.set(String(row.id), row));

    return bills.map((row) => ({
      id: row.id,
      tripId: row.trip_id,
      title: row.title || '行程账单',
      baseCurrency: row.base_currency || 'CNY',
      linkedChatId: row.linked_chat_id || '',
      linkedChatName: chatById.get(String(row.linked_chat_id || ''))?.name || '',
      status: row.status || 'active',
      createdBy: userById.get(String(row.created_by || ''))?.nickname || '',
      createdAt: row.created_at || new Date().toISOString(),
      updatedAt: row.updated_at || row.created_at || new Date().toISOString(),
      members: membersByBill.get(String(row.id)) || []
    })).filter((bill) => canNicknameAccessTripBill(currentNickname, bill.createdBy, bill.members));
  }


  async function fetchAccessibleTripBills(currentNickname = '') {
    if (!currentNickname) return [];
    const rows = await request('trip_bills?select=id,trip_id,title,base_currency,linked_chat_id,status,created_by,created_at,updated_at&order=updated_at.desc.nullslast,created_at.desc', { method: 'GET' });
    const bills = Array.isArray(rows) ? rows : [];
    if (!bills.length) return [];

    const billIds = bills.map((row) => row.id).filter(Boolean);
    const members = await fetchRowsByIds('trip_bill_members', 'bill_id', billIds, 'bill_id,user_id,role,member_status,invited_by,joined_at');
    const userIds = new Set();
    bills.forEach((row) => row?.created_by && userIds.add(row.created_by));
    members.forEach((row) => { if (row?.user_id) userIds.add(row.user_id); if (row?.invited_by) userIds.add(row.invited_by); });
    const users = await fetchRowsByIds('app_users', 'id', [...userIds], 'id,nickname');
    const userById = buildUserLookup(users);
    const membersByBill = new Map();
    members.forEach((row) => {
      const key = String(row?.bill_id || '');
      if (!key) return;
      const list = membersByBill.get(key) || [];
      const user = userById.get(String(row.user_id || ''));
      list.push({
        nickname: user?.nickname || '未知用户',
        role: row.role || 'member',
        status: row.member_status || 'active',
        joinedAt: row.joined_at || null
      });
      membersByBill.set(key, list);
    });

    const chats = await fetchRowsByIds('chats', 'id', bills.map((row) => row.linked_chat_id).filter(Boolean), 'id,name,chat_type');
    const chatById = new Map();
    chats.forEach((row) => row?.id && chatById.set(String(row.id), row));

    return bills.map((row) => ({
      id: row.id,
      tripId: row.trip_id,
      title: row.title || '行程账单',
      baseCurrency: row.base_currency || 'CNY',
      linkedChatId: row.linked_chat_id || '',
      linkedChatName: chatById.get(String(row.linked_chat_id || ''))?.name || '',
      status: row.status || 'active',
      createdBy: userById.get(String(row.created_by || ''))?.nickname || '',
      createdAt: row.created_at || new Date().toISOString(),
      updatedAt: row.updated_at || row.created_at || new Date().toISOString(),
      members: membersByBill.get(String(row.id)) || []
    })).filter((bill) => canNicknameAccessTripBill(currentNickname, bill.createdBy, bill.members));
  }

  async function fetchTripBillDetail(billId, currentNickname = '') {
    if (!billId) return null;
    const billRows = await request(`trip_bills?id=eq.${encodeURIComponent(billId)}&select=id,trip_id,title,base_currency,linked_chat_id,status,created_by,created_at,updated_at`, { method: 'GET' });
    const row = Array.isArray(billRows) ? billRows[0] : null;
    if (!row) return null;

    const members = await request(`trip_bill_members?bill_id=eq.${encodeURIComponent(billId)}&select=bill_id,user_id,role,member_status,invited_by,joined_at`, { method: 'GET' });
    const items = await request(`trip_bill_items?bill_id=eq.${encodeURIComponent(billId)}&select=id,bill_id,expense_type,category,status,amount_original,currency_original,amount_cny_actual,amount_cny_estimated,paid_by,expense_time,note,receipt_image_url,split_method,created_by,created_at,updated_at&order=expense_time.desc`, { method: 'GET' });
    const shares = await fetchRowsByIds('trip_bill_item_shares', 'item_id', (Array.isArray(items) ? items : []).map((item) => item.id), 'item_id,user_id,share_ratio,share_amount,is_included');
    const events = await request(`trip_bill_events?bill_id=eq.${encodeURIComponent(billId)}&select=id,bill_id,item_id,actor_id,event_type,payload,created_at&order=created_at.desc`, { method: 'GET' });

    const userIds = new Set([row.created_by]);
    (Array.isArray(members) ? members : []).forEach((m) => { if (m?.user_id) userIds.add(m.user_id); if (m?.invited_by) userIds.add(m.invited_by); });
    (Array.isArray(items) ? items : []).forEach((item) => { if (item?.paid_by) userIds.add(item.paid_by); if (item?.created_by) userIds.add(item.created_by); });
    (Array.isArray(shares) ? shares : []).forEach((s) => s?.user_id && userIds.add(s.user_id));
    (Array.isArray(events) ? events : []).forEach((e) => e?.actor_id && userIds.add(e.actor_id));
    const users = await fetchRowsByIds('app_users', 'id', [...userIds].filter(Boolean), 'id,nickname');
    const userById = buildUserLookup(users);

    const membersMapped = (Array.isArray(members) ? members : []).map((m) => ({
      nickname: userById.get(String(m.user_id || ''))?.nickname || '未知用户',
      role: m.role || 'member',
      status: m.member_status || 'active',
      joinedAt: m.joined_at || null
    }));

    const shareByItem = new Map();
    (Array.isArray(shares) ? shares : []).forEach((s) => {
      const key = String(s?.item_id || '');
      if (!key) return;
      const list = shareByItem.get(key) || [];
      list.push({
        nickname: userById.get(String(s.user_id || ''))?.nickname || '未知用户',
        shareRatio: Number(s.share_ratio || 0),
        shareAmount: Number(s.share_amount || 0),
        isIncluded: s.is_included !== false
      });
      shareByItem.set(key, list);
    });

    const itemsMapped = (Array.isArray(items) ? items : []).map((item) => ({
      id: item.id,
      billId: item.bill_id,
      expenseType: item.expense_type || 'public',
      category: item.category || 'other',
      status: item.status || 'pending',
      amountOriginal: Number(item.amount_original || 0),
      currencyOriginal: item.currency_original || 'CNY',
      amountCnyActual: item.amount_cny_actual == null ? null : Number(item.amount_cny_actual),
      amountCnyEstimated: item.amount_cny_estimated == null ? null : Number(item.amount_cny_estimated),
      paidBy: userById.get(String(item.paid_by || ''))?.nickname || '',
      expenseTime: item.expense_time || item.created_at || new Date().toISOString(),
      note: item.note || '',
      receiptImageUrl: item.receipt_image_url || '',
      splitMethod: item.split_method || 'equal',
      createdBy: userById.get(String(item.created_by || ''))?.nickname || '',
      createdAt: item.created_at || new Date().toISOString(),
      updatedAt: item.updated_at || item.created_at || new Date().toISOString(),
      participants: shareByItem.get(String(item.id)) || []
    }));

    const eventsMapped = (Array.isArray(events) ? events : []).map((e) => ({
      id: e.id,
      billId: e.bill_id,
      itemId: e.item_id || '',
      actor: userById.get(String(e.actor_id || ''))?.nickname || '系统',
      eventType: e.event_type || 'bill_updated',
      payload: e.payload && typeof e.payload === 'object' ? e.payload : {},
      createdAt: e.created_at || new Date().toISOString()
    }));

    let linkedChatName = '';
    if (row.linked_chat_id) {
      const chatRows = await request(`chats?id=eq.${encodeURIComponent(row.linked_chat_id)}&select=id,name`, { method: 'GET' });
      linkedChatName = Array.isArray(chatRows) && chatRows[0] ? (chatRows[0].name || '') : '';
    }

    return {
      id: row.id,
      tripId: row.trip_id,
      title: row.title || '行程账单',
      baseCurrency: row.base_currency || 'CNY',
      linkedChatId: row.linked_chat_id || '',
      linkedChatName,
      status: row.status || 'active',
      createdBy: userById.get(String(row.created_by || ''))?.nickname || '',
      createdAt: row.created_at || new Date().toISOString(),
      updatedAt: row.updated_at || row.created_at || new Date().toISOString(),
      members: membersMapped,
      items: itemsMapped,
      events: eventsMapped
    };
  }

  async function upsertTripBillItem(payload) {
    if (!payload?.billId || !payload?.actorNickname) throw new Error('billId and actorNickname are required');
    const actorId = await ensureUser(payload.actorNickname);
    if (!actorId) throw new Error('cannot resolve actor');
    const paidById = payload.paidBy ? await ensureUser(payload.paidBy) : null;
    const itemId = payload.id || crypto.randomUUID();
    await request('trip_bill_items?on_conflict=id', {
      method: 'POST',
      body: JSON.stringify({
        id: itemId,
        bill_id: payload.billId,
        expense_type: payload.expenseType || 'public',
        category: payload.category || 'other',
        status: payload.status || 'pending',
        amount_original: Number(payload.amountOriginal || 0),
        currency_original: payload.currencyOriginal || 'CNY',
        amount_cny_actual: payload.amountCnyActual == null || payload.amountCnyActual === '' ? null : Number(payload.amountCnyActual),
        amount_cny_estimated: payload.amountCnyEstimated == null || payload.amountCnyEstimated === '' ? null : Number(payload.amountCnyEstimated),
        paid_by: paidById,
        expense_time: payload.expenseTime || new Date().toISOString(),
        note: payload.note || '',
        receipt_image_url: payload.receiptImageUrl || null,
        split_method: payload.splitMethod || 'equal',
        created_by: actorId
      }),
      headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
    });

    await request(`trip_bill_item_shares?item_id=eq.${encodeURIComponent(itemId)}`, { method: 'DELETE', headers: { Prefer: 'return=minimal' } });
    const participants = Array.isArray(payload.participants) ? payload.participants.filter(Boolean) : [];
    if (participants.length) {
      const ratio = 1 / participants.length;
      const settlementBase = payload.amountCnyActual == null || payload.amountCnyActual === ''
        ? (payload.amountCnyEstimated == null || payload.amountCnyEstimated === '' ? Number(payload.amountOriginal || 0) : Number(payload.amountCnyEstimated || 0))
        : Number(payload.amountCnyActual || 0);
      const shareAmount = participants.length ? settlementBase / participants.length : 0;
      for (const nickname of participants) {
        const userId = await ensureUser(nickname);
        if (!userId) continue;
        await request('trip_bill_item_shares', {
          method: 'POST',
          body: JSON.stringify({
            item_id: itemId,
            user_id: userId,
            share_ratio: ratio,
            share_amount: shareAmount,
            is_included: true
          }),
          headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
        });
      }
    }

    await logTripBillEvent(payload.billId, payload.actorNickname, payload.id ? 'item_updated' : 'item_created', {
      note: payload.note || '',
      amountOriginal: Number(payload.amountOriginal || 0),
      currencyOriginal: payload.currencyOriginal || 'CNY',
      participants,
      status: payload.status || 'pending'
    }, itemId);

    return fetchTripBillDetail(payload.billId);
  }

  async function updateTripBillItemStatus(itemId, status, actorNickname, billId) {
    if (!itemId || !status) throw new Error('itemId and status are required');
    await request(`trip_bill_items?id=eq.${encodeURIComponent(itemId)}`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
      headers: { Prefer: 'return=minimal' }
    });
    if (billId && actorNickname) {
      await logTripBillEvent(billId, actorNickname, 'item_status_changed', { status }, itemId);
      return fetchTripBillDetail(billId);
    }
    return null;
  }

  async function deleteChat(chatId) {
    if (!chatId) return;
    await request(`chat_members?chat_id=eq.${encodeURIComponent(chatId)}`, { method: 'DELETE', headers: { Prefer: 'return=minimal' } });
    await request(`chat_messages?chat_id=eq.${encodeURIComponent(chatId)}`, { method: 'DELETE', headers: { Prefer: 'return=minimal' } });
    await request(`chats?id=eq.${encodeURIComponent(chatId)}`, { method: 'DELETE', headers: { Prefer: 'return=minimal' } });
  }

  global.RJSupabase = {
    URL_KEY,
    ANON_KEY,
    STORAGE_BUCKET_KEY,
    DEFAULT_STORAGE_BUCKET,
    BILL_RECEIPT_BUCKET,
    normalizeConfig,
    setConfig,
    isEnabled,
    signUpWithLocalAccount,
    signInWithLocalAccount,
    restoreSupabaseSession,
    getSupabaseAuthSession,
    signOutSupabaseSession,
    findUserByNickname,
    createUserWithProfile,
    ensureUser,
    syncUserProfile,
    syncTrip,
    syncTripLike,
    syncTripComment,
    fetchPublicTrips,
    fetchPublicUsers,
    fetchPublicDiaries,
    fetchPublicSocialGraph,
    syncMediaPost,
    syncMediaLike,
    syncMediaComment,
    deleteMediaComment,
    deleteTrip,
    deleteMediaPost,
    createTripBill,
    updateTripBill,
    fetchTripBillsByTrip,
    fetchAccessibleTripBills,
    fetchTripBillDetail,
    deleteTripBill,
    addTripBillMembers,
    upsertTripBillItem,
    updateTripBillItemStatus,
    syncChat,
    syncChatMessage,
    fetchChatsForUser,
    leaveChat,
    deleteChat,
    deleteCurrentAccount,
    syncFollow,
    syncBlock,
    syncTripCommentLike,
    syncMediaCommentLike,
    syncNoticeState,
    syncAdminEvent,
    uploadUserAvatar,
    uploadDiaryImage,
    uploadBillReceipt
  };

  getSupabaseClient();
  void restoreSupabaseSession();
})(window);
